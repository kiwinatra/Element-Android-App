package com.google.android.material.transformation;

import android.content.Context;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.W;
import d0.a;
import java.util.List;

@Deprecated
public abstract class ExpandableBehavior extends CoordinatorLayout.b {

    /* renamed from: a  reason: collision with root package name */
    private int f5277a = 0;

    public ExpandableBehavior() {
    }

    /* access modifiers changed from: protected */
    public a I(CoordinatorLayout coordinatorLayout, View view) {
        List q2 = coordinatorLayout.q(view);
        int size = q2.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view2 = (View) q2.get(i2);
            if (i(coordinatorLayout, view, view2)) {
                b.a(view2);
                return null;
            }
        }
        return null;
    }

    public abstract boolean i(CoordinatorLayout coordinatorLayout, View view, View view2);

    public boolean l(CoordinatorLayout coordinatorLayout, View view, View view2) {
        b.a(view2);
        throw null;
    }

    public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
        if (W.U(view)) {
            return false;
        }
        I(coordinatorLayout, view);
        return false;
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
