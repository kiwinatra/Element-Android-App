package com.google.android.material.transformation;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

@Deprecated
public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {

    /* renamed from: b  reason: collision with root package name */
    private final Rect f5278b = new Rect();

    /* renamed from: c  reason: collision with root package name */
    private final RectF f5279c = new RectF();

    /* renamed from: d  reason: collision with root package name */
    private final RectF f5280d = new RectF();

    /* renamed from: e  reason: collision with root package name */
    private final int[] f5281e = new int[2];

    public FabTransformationBehavior() {
    }

    public boolean i(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() != 8) {
            return false;
        }
        throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
    }

    public void k(CoordinatorLayout.e eVar) {
        if (eVar.f2064h == 0) {
            eVar.f2064h = 80;
        }
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
