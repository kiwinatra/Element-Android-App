package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;

@Deprecated
public class FabTransformationSheetBehavior extends FabTransformationBehavior {
    public FabTransformationSheetBehavior() {
    }

    public FabTransformationSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
