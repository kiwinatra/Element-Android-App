package com.google.android.material.snackbar;

import T.a;
import T.c;
import T.e;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.view.W;
import f0.h;

public class SnackbarContentLayout extends LinearLayout {

    /* renamed from: a  reason: collision with root package name */
    private TextView f4977a;

    /* renamed from: b  reason: collision with root package name */
    private Button f4978b;

    /* renamed from: c  reason: collision with root package name */
    private final TimeInterpolator f4979c;

    /* renamed from: d  reason: collision with root package name */
    private int f4980d;

    public SnackbarContentLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f4979c = h.g(context, a.motionEasingEmphasizedInterpolator, U.a.f256b);
    }

    private static void a(View view, int i2, int i3) {
        if (W.W(view)) {
            W.D0(view, W.H(view), i2, W.G(view), i3);
        } else {
            view.setPadding(view.getPaddingLeft(), i2, view.getPaddingRight(), i3);
        }
    }

    private boolean b(int i2, int i3, int i4) {
        boolean z2;
        if (i2 != getOrientation()) {
            setOrientation(i2);
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.f4977a.getPaddingTop() == i3 && this.f4977a.getPaddingBottom() == i4) {
            return z2;
        }
        a(this.f4977a, i3, i4);
        return true;
    }

    public Button getActionView() {
        return this.f4978b;
    }

    public TextView getMessageView() {
        return this.f4977a;
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f4977a = (TextView) findViewById(e.snackbar_text);
        this.f4978b = (Button) findViewById(e.snackbar_action);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (getOrientation() != 1) {
            int dimensionPixelSize = getResources().getDimensionPixelSize(c.design_snackbar_padding_vertical_2lines);
            int dimensionPixelSize2 = getResources().getDimensionPixelSize(c.design_snackbar_padding_vertical);
            Layout layout = this.f4977a.getLayout();
            boolean z2 = layout != null && layout.getLineCount() > 1;
            if (!z2 || this.f4980d <= 0 || this.f4978b.getMeasuredWidth() <= this.f4980d) {
                if (!z2) {
                    dimensionPixelSize = dimensionPixelSize2;
                }
                if (!b(0, dimensionPixelSize, dimensionPixelSize)) {
                    return;
                }
            } else if (!b(1, dimensionPixelSize, dimensionPixelSize - dimensionPixelSize2)) {
                return;
            }
            super.onMeasure(i2, i3);
        }
    }

    public void setMaxInlineActionWidth(int i2) {
        this.f4980d = i2;
    }
}
