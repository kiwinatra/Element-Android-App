package com.google.android.material.snackbar;

import T.j;
import a0.C0087a;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.W;
import com.google.android.material.behavior.SwipeDismissBehavior;
import com.google.android.material.internal.B;
import com.google.android.material.snackbar.a;
import k0.g;
import k0.k;

public abstract class BaseTransientBottomBar {

    /* renamed from: a  reason: collision with root package name */
    private static final TimeInterpolator f4958a = U.a.f256b;

    /* renamed from: b  reason: collision with root package name */
    private static final TimeInterpolator f4959b = U.a.f255a;

    /* renamed from: c  reason: collision with root package name */
    private static final TimeInterpolator f4960c = U.a.f258d;

    /* renamed from: d  reason: collision with root package name */
    static final Handler f4961d = new Handler(Looper.getMainLooper(), new a());

    /* renamed from: e  reason: collision with root package name */
    private static final boolean f4962e = false;

    /* renamed from: f  reason: collision with root package name */
    private static final int[] f4963f = {T.a.snackbarStyle};

    /* renamed from: g  reason: collision with root package name */
    private static final String f4964g = BaseTransientBottomBar.class.getSimpleName();

    public static class Behavior extends SwipeDismissBehavior<View> {

        /* renamed from: k  reason: collision with root package name */
        private final b f4965k = new b(this);

        public boolean J(View view) {
            return this.f4965k.a(view);
        }

        public boolean o(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            this.f4965k.b(coordinatorLayout, view, motionEvent);
            return super.o(coordinatorLayout, view, motionEvent);
        }
    }

    class a implements Handler.Callback {
        a() {
        }

        public boolean handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 0) {
                android.support.v4.media.session.b.a(message.obj);
                throw null;
            } else if (i2 != 1) {
                return false;
            } else {
                android.support.v4.media.session.b.a(message.obj);
                throw null;
            }
        }
    }

    public static class b {
        public b(SwipeDismissBehavior swipeDismissBehavior) {
            swipeDismissBehavior.P(0.1f);
            swipeDismissBehavior.O(0.6f);
            swipeDismissBehavior.Q(0);
        }

        public boolean a(View view) {
            return view instanceof c;
        }

        public void b(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked != 0) {
                if (actionMasked == 1 || actionMasked == 3) {
                    a.b().f((a.b) null);
                }
            } else if (coordinatorLayout.z(view, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                a.b().e((a.b) null);
            }
        }
    }

    protected static class c extends FrameLayout {

        /* renamed from: k  reason: collision with root package name */
        private static final View.OnTouchListener f4966k = new a();

        /* renamed from: a  reason: collision with root package name */
        k f4967a;

        /* renamed from: b  reason: collision with root package name */
        private int f4968b;

        /* renamed from: c  reason: collision with root package name */
        private final float f4969c;

        /* renamed from: d  reason: collision with root package name */
        private final float f4970d;

        /* renamed from: e  reason: collision with root package name */
        private final int f4971e;

        /* renamed from: f  reason: collision with root package name */
        private final int f4972f;

        /* renamed from: g  reason: collision with root package name */
        private ColorStateList f4973g;

        /* renamed from: h  reason: collision with root package name */
        private PorterDuff.Mode f4974h;

        /* renamed from: i  reason: collision with root package name */
        private Rect f4975i;

        /* renamed from: j  reason: collision with root package name */
        private boolean f4976j;

        class a implements View.OnTouchListener {
            a() {
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        }

        protected c(Context context, AttributeSet attributeSet) {
            super(n0.a.c(context, attributeSet, 0, 0), attributeSet);
            Context context2 = getContext();
            TypedArray obtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, j.l5);
            int i2 = j.s5;
            if (obtainStyledAttributes.hasValue(i2)) {
                W.x0(this, (float) obtainStyledAttributes.getDimensionPixelSize(i2, 0));
            }
            this.f4968b = obtainStyledAttributes.getInt(j.o5, 0);
            if (obtainStyledAttributes.hasValue(j.u5) || obtainStyledAttributes.hasValue(j.v5)) {
                this.f4967a = k.e(context2, attributeSet, 0, 0).m();
            }
            this.f4969c = obtainStyledAttributes.getFloat(j.p5, 1.0f);
            setBackgroundTintList(h0.c.a(context2, obtainStyledAttributes, j.q5));
            setBackgroundTintMode(B.i(obtainStyledAttributes.getInt(j.r5, -1), PorterDuff.Mode.SRC_IN));
            this.f4970d = obtainStyledAttributes.getFloat(j.n5, 1.0f);
            this.f4971e = obtainStyledAttributes.getDimensionPixelSize(j.m5, -1);
            this.f4972f = obtainStyledAttributes.getDimensionPixelSize(j.t5, -1);
            obtainStyledAttributes.recycle();
            setOnTouchListener(f4966k);
            setFocusable(true);
            if (getBackground() == null) {
                W.u0(this, a());
            }
        }

        private Drawable a() {
            int l2 = C0087a.l(this, T.a.colorSurface, T.a.colorOnSurface, getBackgroundOverlayColorAlpha());
            k kVar = this.f4967a;
            Drawable a2 = kVar != null ? BaseTransientBottomBar.d(l2, kVar) : BaseTransientBottomBar.c(l2, getResources());
            ColorStateList colorStateList = this.f4973g;
            Drawable r2 = androidx.core.graphics.drawable.a.r(a2);
            if (colorStateList != null) {
                androidx.core.graphics.drawable.a.o(r2, this.f4973g);
            }
            return r2;
        }

        private void b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            this.f4975i = new Rect(marginLayoutParams.leftMargin, marginLayoutParams.topMargin, marginLayoutParams.rightMargin, marginLayoutParams.bottomMargin);
        }

        private void setBaseTransientBottomBar(BaseTransientBottomBar baseTransientBottomBar) {
        }

        /* access modifiers changed from: package-private */
        public float getActionTextColorAlpha() {
            return this.f4970d;
        }

        /* access modifiers changed from: package-private */
        public int getAnimationMode() {
            return this.f4968b;
        }

        /* access modifiers changed from: package-private */
        public float getBackgroundOverlayColorAlpha() {
            return this.f4969c;
        }

        /* access modifiers changed from: package-private */
        public int getMaxInlineActionWidth() {
            return this.f4972f;
        }

        /* access modifiers changed from: package-private */
        public int getMaxWidth() {
            return this.f4971e;
        }

        /* access modifiers changed from: protected */
        public void onAttachedToWindow() {
            super.onAttachedToWindow();
            W.n0(this);
        }

        /* access modifiers changed from: protected */
        public void onDetachedFromWindow() {
            super.onDetachedFromWindow();
        }

        /* access modifiers changed from: protected */
        public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
            super.onLayout(z2, i2, i3, i4, i5);
        }

        /* access modifiers changed from: protected */
        public void onMeasure(int i2, int i3) {
            int i4;
            super.onMeasure(i2, i3);
            if (this.f4971e > 0 && getMeasuredWidth() > (i4 = this.f4971e)) {
                super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
            }
        }

        /* access modifiers changed from: package-private */
        public void setAnimationMode(int i2) {
            this.f4968b = i2;
        }

        public void setBackground(Drawable drawable) {
            setBackgroundDrawable(drawable);
        }

        public void setBackgroundDrawable(Drawable drawable) {
            if (!(drawable == null || this.f4973g == null)) {
                drawable = androidx.core.graphics.drawable.a.r(drawable.mutate());
                androidx.core.graphics.drawable.a.o(drawable, this.f4973g);
                androidx.core.graphics.drawable.a.p(drawable, this.f4974h);
            }
            super.setBackgroundDrawable(drawable);
        }

        public void setBackgroundTintList(ColorStateList colorStateList) {
            this.f4973g = colorStateList;
            if (getBackground() != null) {
                Drawable r2 = androidx.core.graphics.drawable.a.r(getBackground().mutate());
                androidx.core.graphics.drawable.a.o(r2, colorStateList);
                androidx.core.graphics.drawable.a.p(r2, this.f4974h);
                if (r2 != getBackground()) {
                    super.setBackgroundDrawable(r2);
                }
            }
        }

        public void setBackgroundTintMode(PorterDuff.Mode mode) {
            this.f4974h = mode;
            if (getBackground() != null) {
                Drawable r2 = androidx.core.graphics.drawable.a.r(getBackground().mutate());
                androidx.core.graphics.drawable.a.p(r2, mode);
                if (r2 != getBackground()) {
                    super.setBackgroundDrawable(r2);
                }
            }
        }

        public void setLayoutParams(ViewGroup.LayoutParams layoutParams) {
            super.setLayoutParams(layoutParams);
            if (!this.f4976j && (layoutParams instanceof ViewGroup.MarginLayoutParams)) {
                b((ViewGroup.MarginLayoutParams) layoutParams);
            }
        }

        public void setOnClickListener(View.OnClickListener onClickListener) {
            setOnTouchListener(onClickListener != null ? null : f4966k);
            super.setOnClickListener(onClickListener);
        }
    }

    /* access modifiers changed from: private */
    public static GradientDrawable c(int i2, Resources resources) {
        float dimension = resources.getDimension(T.c.mtrl_snackbar_background_corner_radius);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(dimension);
        gradientDrawable.setColor(i2);
        return gradientDrawable;
    }

    /* access modifiers changed from: private */
    public static g d(int i2, k kVar) {
        g gVar = new g(kVar);
        gVar.T(ColorStateList.valueOf(i2));
        return gVar;
    }
}
