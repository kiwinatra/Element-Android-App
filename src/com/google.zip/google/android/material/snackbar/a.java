package com.google.android.material.snackbar;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

class a {

    /* renamed from: c  reason: collision with root package name */
    private static a f4981c;

    /* renamed from: a  reason: collision with root package name */
    private final Object f4982a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private final Handler f4983b = new Handler(Looper.getMainLooper(), new C0070a());

    /* renamed from: com.google.android.material.snackbar.a$a  reason: collision with other inner class name */
    class C0070a implements Handler.Callback {
        C0070a() {
        }

        public boolean handleMessage(Message message) {
            if (message.what != 0) {
                return false;
            }
            a aVar = a.this;
            android.support.v4.media.session.b.a(message.obj);
            aVar.c((c) null);
            return true;
        }
    }

    interface b {
    }

    private static class c {
    }

    private a() {
    }

    private boolean a(c cVar, int i2) {
        throw null;
    }

    static a b() {
        if (f4981c == null) {
            f4981c = new a();
        }
        return f4981c;
    }

    private boolean d(b bVar) {
        return false;
    }

    /* access modifiers changed from: package-private */
    public void c(c cVar) {
        synchronized (this.f4982a) {
            a(cVar, 2);
        }
    }

    public void e(b bVar) {
        synchronized (this.f4982a) {
            try {
                if (d(bVar)) {
                    throw null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void f(b bVar) {
        synchronized (this.f4982a) {
            try {
                if (d(bVar)) {
                    throw null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
