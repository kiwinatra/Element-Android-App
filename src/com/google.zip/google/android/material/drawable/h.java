package com.google.android.material.drawable;

import android.graphics.drawable.Drawable;
import g.C0239c;

public class h extends C0239c {

    /* renamed from: b  reason: collision with root package name */
    private final int f4694b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4695c;

    public h(Drawable drawable, int i2, int i3) {
        super(drawable);
        this.f4694b = i2;
        this.f4695c = i3;
    }

    public int getIntrinsicHeight() {
        return this.f4695c;
    }

    public int getIntrinsicWidth() {
        return this.f4694b;
    }
}
