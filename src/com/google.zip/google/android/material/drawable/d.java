package com.google.android.material.drawable;

import android.graphics.drawable.ColorStateListDrawable;

public abstract /* synthetic */ class d {
    public static /* bridge */ /* synthetic */ ColorStateListDrawable a(Object obj) {
        return (ColorStateListDrawable) obj;
    }
}
