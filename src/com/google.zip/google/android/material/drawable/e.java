package com.google.android.material.drawable;

public abstract /* synthetic */ class e {
}
