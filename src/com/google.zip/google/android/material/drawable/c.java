package com.google.android.material.drawable;

import android.graphics.drawable.ColorStateListDrawable;

public abstract /* synthetic */ class c {
    public static /* bridge */ /* synthetic */ boolean a(Object obj) {
        return obj instanceof ColorStateListDrawable;
    }
}
