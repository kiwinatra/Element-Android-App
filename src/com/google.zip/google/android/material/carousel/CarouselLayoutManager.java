package com.google.android.material.carousel;

import T.j;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.g;
import com.google.android.material.carousel.f;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import v.C0288a;
import x.h;

public class CarouselLayoutManager extends RecyclerView.o implements b, RecyclerView.y.b {

    /* renamed from: A  reason: collision with root package name */
    private int f4424A;

    /* renamed from: B  reason: collision with root package name */
    private Map f4425B;

    /* renamed from: C  reason: collision with root package name */
    private c f4426C;

    /* renamed from: D  reason: collision with root package name */
    private final View.OnLayoutChangeListener f4427D;

    /* renamed from: E  reason: collision with root package name */
    private int f4428E;

    /* renamed from: F  reason: collision with root package name */
    private int f4429F;

    /* renamed from: G  reason: collision with root package name */
    private int f4430G;

    /* renamed from: s  reason: collision with root package name */
    int f4431s;

    /* renamed from: t  reason: collision with root package name */
    int f4432t;

    /* renamed from: u  reason: collision with root package name */
    int f4433u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f4434v;

    /* renamed from: w  reason: collision with root package name */
    private final c f4435w;

    /* renamed from: x  reason: collision with root package name */
    private d f4436x;
    /* access modifiers changed from: private */

    /* renamed from: y  reason: collision with root package name */
    public g f4437y;

    /* renamed from: z  reason: collision with root package name */
    private f f4438z;

    class a extends g {
        a(Context context) {
            super(context);
        }

        public PointF a(int i2) {
            return CarouselLayoutManager.this.e(i2);
        }

        public int t(View view, int i2) {
            if (CarouselLayoutManager.this.f4437y == null || !CarouselLayoutManager.this.f()) {
                return 0;
            }
            CarouselLayoutManager carouselLayoutManager = CarouselLayoutManager.this;
            return carouselLayoutManager.g2(carouselLayoutManager.l0(view));
        }

        public int u(View view, int i2) {
            if (CarouselLayoutManager.this.f4437y == null || CarouselLayoutManager.this.f()) {
                return 0;
            }
            CarouselLayoutManager carouselLayoutManager = CarouselLayoutManager.this;
            return carouselLayoutManager.g2(carouselLayoutManager.l0(view));
        }
    }

    private static final class b {

        /* renamed from: a  reason: collision with root package name */
        final View f4440a;

        /* renamed from: b  reason: collision with root package name */
        final float f4441b;

        /* renamed from: c  reason: collision with root package name */
        final float f4442c;

        /* renamed from: d  reason: collision with root package name */
        final d f4443d;

        b(View view, float f2, float f3, d dVar) {
            this.f4440a = view;
            this.f4441b = f2;
            this.f4442c = f3;
            this.f4443d = dVar;
        }
    }

    private static class c extends RecyclerView.n {

        /* renamed from: a  reason: collision with root package name */
        private final Paint f4444a;

        /* renamed from: b  reason: collision with root package name */
        private List f4445b = Collections.unmodifiableList(new ArrayList());

        c() {
            Paint paint = new Paint();
            this.f4444a = paint;
            paint.setStrokeWidth(5.0f);
            paint.setColor(-65281);
        }

        public void i(Canvas canvas, RecyclerView recyclerView, RecyclerView.z zVar) {
            float V1;
            float f2;
            float W1;
            float f3;
            super.i(canvas, recyclerView, zVar);
            this.f4444a.setStrokeWidth(recyclerView.getResources().getDimension(T.c.m3_carousel_debug_keyline_width));
            for (f.c cVar : this.f4445b) {
                this.f4444a.setColor(androidx.core.graphics.a.c(-65281, -16776961, cVar.f4476c));
                if (((CarouselLayoutManager) recyclerView.getLayoutManager()).f()) {
                    V1 = cVar.f4475b;
                    f2 = (float) ((CarouselLayoutManager) recyclerView.getLayoutManager()).A2();
                    W1 = cVar.f4475b;
                    f3 = (float) ((CarouselLayoutManager) recyclerView.getLayoutManager()).v2();
                } else {
                    V1 = (float) ((CarouselLayoutManager) recyclerView.getLayoutManager()).x2();
                    f2 = cVar.f4475b;
                    W1 = (float) ((CarouselLayoutManager) recyclerView.getLayoutManager()).y2();
                    f3 = cVar.f4475b;
                }
                canvas.drawLine(V1, f2, W1, f3, this.f4444a);
            }
        }

        /* access modifiers changed from: package-private */
        public void j(List list) {
            this.f4445b = Collections.unmodifiableList(list);
        }
    }

    private static class d {

        /* renamed from: a  reason: collision with root package name */
        final f.c f4446a;

        /* renamed from: b  reason: collision with root package name */
        final f.c f4447b;

        d(f.c cVar, f.c cVar2) {
            h.a(cVar.f4474a <= cVar2.f4474a);
            this.f4446a = cVar;
            this.f4447b = cVar2;
        }
    }

    public CarouselLayoutManager() {
        this(new h());
    }

    /* access modifiers changed from: private */
    public int A2() {
        return this.f4426C.j();
    }

    private int B2() {
        if (R() || !this.f4436x.f()) {
            return 0;
        }
        return u2() == 1 ? h0() : j0();
    }

    private int C2(int i2, f fVar) {
        return F2() ? (int) (((((float) n2()) - fVar.h().f4474a) - (((float) i2) * fVar.f())) - (fVar.f() / 2.0f)) : (int) (((((float) i2) * fVar.f()) - fVar.a().f4474a) + (fVar.f() / 2.0f));
    }

    private int D2(int i2, f fVar) {
        int i3 = Integer.MAX_VALUE;
        for (f.c cVar : fVar.e()) {
            float f2 = (((float) i2) * fVar.f()) + (fVar.f() / 2.0f);
            int n2 = (F2() ? (int) ((((float) n2()) - cVar.f4474a) - f2) : (int) (f2 - cVar.f4474a)) - this.f4431s;
            if (Math.abs(i3) > Math.abs(n2)) {
                i3 = n2;
            }
        }
        return i3;
    }

    private static d E2(List list, float f2, boolean z2) {
        float f3 = Float.MAX_VALUE;
        float f4 = Float.MAX_VALUE;
        float f5 = Float.MAX_VALUE;
        float f6 = -3.4028235E38f;
        int i2 = -1;
        int i3 = -1;
        int i4 = -1;
        int i5 = -1;
        for (int i6 = 0; i6 < list.size(); i6++) {
            f.c cVar = (f.c) list.get(i6);
            float f7 = z2 ? cVar.f4475b : cVar.f4474a;
            float abs = Math.abs(f7 - f2);
            if (f7 <= f2 && abs <= f3) {
                i2 = i6;
                f3 = abs;
            }
            if (f7 > f2 && abs <= f4) {
                i4 = i6;
                f4 = abs;
            }
            if (f7 <= f5) {
                i3 = i6;
                f5 = f7;
            }
            if (f7 > f6) {
                i5 = i6;
                f6 = f7;
            }
        }
        if (i2 == -1) {
            i2 = i3;
        }
        if (i4 == -1) {
            i4 = i5;
        }
        return new d((f.c) list.get(i2), (f.c) list.get(i4));
    }

    /* JADX WARNING: Removed duplicated region for block: B:4:0x0018 A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean G2(float r3, com.google.android.material.carousel.CarouselLayoutManager.d r4) {
        /*
            r2 = this;
            float r4 = r2.s2(r3, r4)
            r0 = 1073741824(0x40000000, float:2.0)
            float r4 = r4 / r0
            float r3 = r2.Z1(r3, r4)
            boolean r4 = r2.F2()
            r0 = 0
            r1 = 1
            if (r4 == 0) goto L_0x001a
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x0024
        L_0x0018:
            r0 = 1
            goto L_0x0024
        L_0x001a:
            int r4 = r2.n2()
            float r4 = (float) r4
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0024
            goto L_0x0018
        L_0x0024:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.carousel.CarouselLayoutManager.G2(float, com.google.android.material.carousel.CarouselLayoutManager$d):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:4:0x001c A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean H2(float r3, com.google.android.material.carousel.CarouselLayoutManager.d r4) {
        /*
            r2 = this;
            float r4 = r2.s2(r3, r4)
            r0 = 1073741824(0x40000000, float:2.0)
            float r4 = r4 / r0
            float r3 = r2.Y1(r3, r4)
            boolean r4 = r2.F2()
            r0 = 0
            r1 = 1
            if (r4 == 0) goto L_0x001e
            int r4 = r2.n2()
            float r4 = (float) r4
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 <= 0) goto L_0x0024
        L_0x001c:
            r0 = 1
            goto L_0x0024
        L_0x001e:
            r4 = 0
            int r3 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
            if (r3 >= 0) goto L_0x0024
            goto L_0x001c
        L_0x0024:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.carousel.CarouselLayoutManager.H2(float, com.google.android.material.carousel.CarouselLayoutManager$d):boolean");
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void I2(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
        if (i2 != i6 || i3 != i7 || i4 != i8 || i5 != i9) {
            view.post(new X.b(this));
        }
    }

    private void J2() {
        if (this.f4434v && Log.isLoggable("CarouselLayoutManager", 3)) {
            Log.d("CarouselLayoutManager", "internal representation of views on the screen");
            for (int i2 = 0; i2 < O(); i2++) {
                View N2 = N(i2);
                float o2 = o2(N2);
                Log.d("CarouselLayoutManager", "item position " + l0(N2) + ", center:" + o2 + ", child index:" + i2);
            }
            Log.d("CarouselLayoutManager", "==============");
        }
    }

    private b K2(RecyclerView.u uVar, float f2, int i2) {
        View o2 = uVar.o(i2);
        E0(o2, 0, 0);
        float Y1 = Y1(f2, this.f4438z.f() / 2.0f);
        d E2 = E2(this.f4438z.g(), Y1, false);
        return new b(o2, Y1, d2(o2, Y1, E2), E2);
    }

    private float L2(View view, float f2, float f3, Rect rect) {
        float Y1 = Y1(f2, f3);
        d E2 = E2(this.f4438z.g(), Y1, false);
        float d2 = d2(view, Y1, E2);
        super.U(view, rect);
        V2(view, Y1, E2);
        this.f4426C.l(view, rect, f3, d2);
        return d2;
    }

    private void M2(RecyclerView.u uVar) {
        View o2 = uVar.o(0);
        E0(o2, 0, 0);
        f g2 = this.f4436x.g(this, o2);
        if (F2()) {
            g2 = f.n(g2, (float) n2());
        }
        this.f4437y = g.f(this, g2, (float) p2(), (float) r2(), (float) B2());
    }

    /* access modifiers changed from: private */
    public void N2() {
        this.f4437y = null;
        x1();
    }

    private void O2(RecyclerView.u uVar) {
        while (O() > 0) {
            View N2 = N(0);
            float o2 = o2(N2);
            if (!H2(o2, E2(this.f4438z.g(), o2, true))) {
                break;
            }
            q1(N2, uVar);
        }
        while (O() - 1 >= 0) {
            View N3 = N(O() - 1);
            float o22 = o2(N3);
            if (G2(o22, E2(this.f4438z.g(), o22, true))) {
                q1(N3, uVar);
            } else {
                return;
            }
        }
    }

    private int P2(int i2, RecyclerView.u uVar, RecyclerView.z zVar) {
        if (O() == 0 || i2 == 0) {
            return 0;
        }
        if (this.f4437y == null) {
            M2(uVar);
        }
        int h2 = h2(i2, this.f4431s, this.f4432t, this.f4433u);
        this.f4431s += h2;
        W2(this.f4437y);
        float f2 = this.f4438z.f() / 2.0f;
        float e2 = e2(l0(N(0)));
        Rect rect = new Rect();
        float f3 = (F2() ? this.f4438z.h() : this.f4438z.a()).f4475b;
        float f4 = Float.MAX_VALUE;
        for (int i3 = 0; i3 < O(); i3++) {
            View N2 = N(i3);
            float abs = Math.abs(f3 - L2(N2, e2, f2, rect));
            if (N2 != null && abs < f4) {
                this.f4429F = l0(N2);
                f4 = abs;
            }
            e2 = Y1(e2, this.f4438z.f());
        }
        k2(uVar, zVar);
        return h2;
    }

    private void Q2(RecyclerView recyclerView, int i2) {
        if (f()) {
            recyclerView.scrollBy(i2, 0);
        } else {
            recyclerView.scrollBy(0, i2);
        }
    }

    private void S2(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.f201Y);
            R2(obtainStyledAttributes.getInt(j.f202Z, 0));
            U2(obtainStyledAttributes.getInt(j.K4, 0));
            obtainStyledAttributes.recycle();
        }
    }

    private void V2(View view, float f2, d dVar) {
    }

    private void W2(g gVar) {
        int i2 = this.f4433u;
        int i3 = this.f4432t;
        this.f4438z = i2 <= i3 ? F2() ? gVar.h() : gVar.l() : gVar.j((float) this.f4431s, (float) i3, (float) i2);
        this.f4435w.j(this.f4438z.g());
    }

    private void X1(View view, int i2, b bVar) {
        float f2 = this.f4438z.f() / 2.0f;
        j(view, i2);
        float f3 = bVar.f4442c;
        this.f4426C.k(view, (int) (f3 - f2), (int) (f3 + f2));
        V2(view, bVar.f4441b, bVar.f4443d);
    }

    private void X2() {
        int b2 = b();
        int i2 = this.f4428E;
        if (b2 != i2 && this.f4437y != null) {
            if (this.f4436x.h(this, i2)) {
                N2();
            }
            this.f4428E = b2;
        }
    }

    private float Y1(float f2, float f3) {
        return F2() ? f2 - f3 : f2 + f3;
    }

    private void Y2() {
        if (this.f4434v && O() >= 1) {
            int i2 = 0;
            while (i2 < O() - 1) {
                int l02 = l0(N(i2));
                int i3 = i2 + 1;
                int l03 = l0(N(i3));
                if (l02 <= l03) {
                    i2 = i3;
                } else {
                    J2();
                    throw new IllegalStateException("Detected invalid child order. Child at index [" + i2 + "] had adapter position [" + l02 + "] and child at index [" + i3 + "] had adapter position [" + l03 + "].");
                }
            }
        }
    }

    private float Z1(float f2, float f3) {
        return F2() ? f2 + f3 : f2 - f3;
    }

    private void a2(RecyclerView.u uVar, int i2, int i3) {
        if (i2 >= 0 && i2 < b()) {
            b K2 = K2(uVar, e2(i2), i2);
            X1(K2.f4440a, i3, K2);
        }
    }

    private void b2(RecyclerView.u uVar, RecyclerView.z zVar, int i2) {
        float e2 = e2(i2);
        while (i2 < zVar.b()) {
            b K2 = K2(uVar, e2, i2);
            if (!G2(K2.f4442c, K2.f4443d)) {
                e2 = Y1(e2, this.f4438z.f());
                if (!H2(K2.f4442c, K2.f4443d)) {
                    X1(K2.f4440a, -1, K2);
                }
                i2++;
            } else {
                return;
            }
        }
    }

    private void c2(RecyclerView.u uVar, int i2) {
        float e2 = e2(i2);
        while (i2 >= 0) {
            b K2 = K2(uVar, e2, i2);
            if (!H2(K2.f4442c, K2.f4443d)) {
                e2 = Z1(e2, this.f4438z.f());
                if (!G2(K2.f4442c, K2.f4443d)) {
                    X1(K2.f4440a, 0, K2);
                }
                i2--;
            } else {
                return;
            }
        }
    }

    private float d2(View view, float f2, d dVar) {
        f.c cVar = dVar.f4446a;
        float f3 = cVar.f4475b;
        f.c cVar2 = dVar.f4447b;
        float b2 = U.a.b(f3, cVar2.f4475b, cVar.f4474a, cVar2.f4474a, f2);
        if (dVar.f4447b != this.f4438z.c() && dVar.f4446a != this.f4438z.j()) {
            return b2;
        }
        float d2 = this.f4426C.d((RecyclerView.p) view.getLayoutParams()) / this.f4438z.f();
        f.c cVar3 = dVar.f4447b;
        return b2 + ((f2 - cVar3.f4474a) * ((1.0f - cVar3.f4476c) + d2));
    }

    private float e2(int i2) {
        return Y1((float) (z2() - this.f4431s), this.f4438z.f() * ((float) i2));
    }

    private int f2(RecyclerView.z zVar, g gVar) {
        boolean F2 = F2();
        f l2 = F2 ? gVar.l() : gVar.h();
        f.c a2 = F2 ? l2.a() : l2.h();
        int b2 = (int) ((((((float) (zVar.b() - 1)) * l2.f()) * (F2 ? -1.0f : 1.0f)) - (a2.f4474a - ((float) z2()))) + (((float) w2()) - a2.f4474a) + (F2 ? -a2.f4480g : a2.f4481h));
        return F2 ? Math.min(0, b2) : Math.max(0, b2);
    }

    private static int h2(int i2, int i3, int i4, int i5) {
        int i6 = i3 + i2;
        if (i6 < i4) {
            return i4 - i3;
        }
        return i6 > i5 ? i5 - i3 : i2;
    }

    private int i2(g gVar) {
        boolean F2 = F2();
        f h2 = F2 ? gVar.h() : gVar.l();
        return (int) (((float) z2()) - Z1((F2 ? h2.h() : h2.a()).f4474a, h2.f() / 2.0f));
    }

    private int j2(int i2) {
        int u2 = u2();
        if (i2 == 1) {
            return -1;
        }
        if (i2 == 2) {
            return 1;
        }
        if (i2 != 17) {
            if (i2 == 33) {
                return u2 == 1 ? -1 : Integer.MIN_VALUE;
            }
            if (i2 != 66) {
                if (i2 == 130) {
                    return u2 == 1 ? 1 : Integer.MIN_VALUE;
                }
                Log.d("CarouselLayoutManager", "Unknown focus request:" + i2);
                return Integer.MIN_VALUE;
            } else if (u2 == 0) {
                return F2() ? -1 : 1;
            } else {
                return Integer.MIN_VALUE;
            }
        } else if (u2 == 0) {
            return F2() ? 1 : -1;
        } else {
            return Integer.MIN_VALUE;
        }
    }

    private void k2(RecyclerView.u uVar, RecyclerView.z zVar) {
        O2(uVar);
        if (O() == 0) {
            c2(uVar, this.f4424A - 1);
            b2(uVar, zVar, this.f4424A);
        } else {
            int l02 = l0(N(0));
            int l03 = l0(N(O() - 1));
            c2(uVar, l02 - 1);
            b2(uVar, zVar, l03 + 1);
        }
        Y2();
    }

    private View l2() {
        return N(F2() ? 0 : O() - 1);
    }

    private View m2() {
        return N(F2() ? O() - 1 : 0);
    }

    private int n2() {
        return f() ? a() : d();
    }

    private float o2(View view) {
        Rect rect = new Rect();
        super.U(view, rect);
        return (float) (f() ? rect.centerX() : rect.centerY());
    }

    private int p2() {
        int i2;
        int i3;
        if (O() <= 0) {
            return 0;
        }
        RecyclerView.p pVar = (RecyclerView.p) N(0).getLayoutParams();
        if (this.f4426C.f4456a == 0) {
            i2 = pVar.leftMargin;
            i3 = pVar.rightMargin;
        } else {
            i2 = pVar.topMargin;
            i3 = pVar.bottomMargin;
        }
        return i2 + i3;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r4 = (com.google.android.material.carousel.f) r0.get(java.lang.Integer.valueOf(v.C0288a.b(r4, 0, java.lang.Math.max(0, b() - 1))));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.google.android.material.carousel.f q2(int r4) {
        /*
            r3 = this;
            java.util.Map r0 = r3.f4425B
            if (r0 == 0) goto L_0x0020
            int r1 = r3.b()
            int r1 = r1 + -1
            r2 = 0
            int r1 = java.lang.Math.max(r2, r1)
            int r4 = v.C0288a.b(r4, r2, r1)
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            java.lang.Object r4 = r0.get(r4)
            com.google.android.material.carousel.f r4 = (com.google.android.material.carousel.f) r4
            if (r4 == 0) goto L_0x0020
            return r4
        L_0x0020:
            com.google.android.material.carousel.g r4 = r3.f4437y
            com.google.android.material.carousel.f r4 = r4.g()
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.carousel.CarouselLayoutManager.q2(int):com.google.android.material.carousel.f");
    }

    private int r2() {
        if (R() || !this.f4436x.f()) {
            return 0;
        }
        return u2() == 1 ? k0() : i0();
    }

    private float s2(float f2, d dVar) {
        f.c cVar = dVar.f4446a;
        float f3 = cVar.f4477d;
        f.c cVar2 = dVar.f4447b;
        return U.a.b(f3, cVar2.f4477d, cVar.f4475b, cVar2.f4475b, f2);
    }

    /* access modifiers changed from: private */
    public int v2() {
        return this.f4426C.e();
    }

    private int w2() {
        return this.f4426C.f();
    }

    /* access modifiers changed from: private */
    public int x2() {
        return this.f4426C.g();
    }

    /* access modifiers changed from: private */
    public int y2() {
        return this.f4426C.h();
    }

    private int z2() {
        return this.f4426C.i();
    }

    public int A(RecyclerView.z zVar) {
        return this.f4433u - this.f4432t;
    }

    public int A1(int i2, RecyclerView.u uVar, RecyclerView.z zVar) {
        if (p()) {
            return P2(i2, uVar, zVar);
        }
        return 0;
    }

    public void B1(int i2) {
        this.f4429F = i2;
        if (this.f4437y != null) {
            this.f4431s = C2(i2, q2(i2));
            this.f4424A = C0288a.b(i2, 0, Math.max(0, b() - 1));
            W2(this.f4437y);
            x1();
        }
    }

    public int C1(int i2, RecyclerView.u uVar, RecyclerView.z zVar) {
        if (q()) {
            return P2(i2, uVar, zVar);
        }
        return 0;
    }

    public void E0(View view, int i2, int i3) {
        throw new IllegalStateException("All children of a RecyclerView using CarouselLayoutManager must use MaskableFrameLayout as their root ViewGroup.");
    }

    /* access modifiers changed from: package-private */
    public boolean F2() {
        return f() && d0() == 1;
    }

    public RecyclerView.p I() {
        return new RecyclerView.p(-2, -2);
    }

    public void K0(RecyclerView recyclerView) {
        super.K0(recyclerView);
        this.f4436x.e(recyclerView.getContext());
        N2();
        recyclerView.addOnLayoutChangeListener(this.f4427D);
    }

    public void M0(RecyclerView recyclerView, RecyclerView.u uVar) {
        super.M0(recyclerView, uVar);
        recyclerView.removeOnLayoutChangeListener(this.f4427D);
    }

    public void M1(RecyclerView recyclerView, RecyclerView.z zVar, int i2) {
        a aVar = new a(recyclerView.getContext());
        aVar.p(i2);
        N1(aVar);
    }

    public View N0(View view, int i2, RecyclerView.u uVar, RecyclerView.z zVar) {
        int j2;
        if (O() == 0 || (j2 = j2(i2)) == Integer.MIN_VALUE) {
            return null;
        }
        int l02 = l0(view);
        if (j2 == -1) {
            if (l02 == 0) {
                return null;
            }
            a2(uVar, l0(N(0)) - 1, 0);
            return m2();
        } else if (l02 == b() - 1) {
            return null;
        } else {
            a2(uVar, l0(N(O() - 1)) + 1, -1);
            return l2();
        }
    }

    public void O0(AccessibilityEvent accessibilityEvent) {
        super.O0(accessibilityEvent);
        if (O() > 0) {
            accessibilityEvent.setFromIndex(l0(N(0)));
            accessibilityEvent.setToIndex(l0(N(O() - 1)));
        }
    }

    public void R2(int i2) {
        this.f4430G = i2;
        N2();
    }

    public void T2(d dVar) {
        this.f4436x = dVar;
        N2();
    }

    public void U(View view, Rect rect) {
        super.U(view, rect);
        float centerY = (float) rect.centerY();
        if (f()) {
            centerY = (float) rect.centerX();
        }
        float s2 = s2(centerY, E2(this.f4438z.g(), centerY, true));
        float f2 = 0.0f;
        float width = f() ? (((float) rect.width()) - s2) / 2.0f : 0.0f;
        if (!f()) {
            f2 = (((float) rect.height()) - s2) / 2.0f;
        }
        rect.set((int) (((float) rect.left) + width), (int) (((float) rect.top) + f2), (int) (((float) rect.right) - width), (int) (((float) rect.bottom) - f2));
    }

    public void U2(int i2) {
        if (i2 == 0 || i2 == 1) {
            l((String) null);
            c cVar = this.f4426C;
            if (cVar == null || i2 != cVar.f4456a) {
                this.f4426C = c.b(this, i2);
                N2();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("invalid orientation:" + i2);
    }

    public void V0(RecyclerView recyclerView, int i2, int i3) {
        super.V0(recyclerView, i2, i3);
        X2();
    }

    public void Y0(RecyclerView recyclerView, int i2, int i3) {
        super.Y0(recyclerView, i2, i3);
        X2();
    }

    public int a() {
        return s0();
    }

    public void b1(RecyclerView.u uVar, RecyclerView.z zVar) {
        if (zVar.b() <= 0 || ((float) n2()) <= 0.0f) {
            o1(uVar);
            this.f4424A = 0;
            return;
        }
        boolean F2 = F2();
        boolean z2 = this.f4437y == null;
        if (z2) {
            M2(uVar);
        }
        int i2 = i2(this.f4437y);
        int f2 = f2(zVar, this.f4437y);
        this.f4432t = F2 ? f2 : i2;
        if (F2) {
            f2 = i2;
        }
        this.f4433u = f2;
        if (z2) {
            this.f4431s = i2;
            this.f4425B = this.f4437y.i(b(), this.f4432t, this.f4433u, F2());
            int i3 = this.f4429F;
            if (i3 != -1) {
                this.f4431s = C2(i3, q2(i3));
            }
        }
        int i4 = this.f4431s;
        this.f4431s = i4 + h2(0, i4, this.f4432t, this.f4433u);
        this.f4424A = C0288a.b(this.f4424A, 0, zVar.b());
        W2(this.f4437y);
        B(uVar);
        k2(uVar, zVar);
        this.f4428E = b();
    }

    public int c() {
        return this.f4430G;
    }

    public void c1(RecyclerView.z zVar) {
        super.c1(zVar);
        if (O() == 0) {
            this.f4424A = 0;
        } else {
            this.f4424A = l0(N(0));
        }
        Y2();
    }

    public int d() {
        return b0();
    }

    public PointF e(int i2) {
        if (this.f4437y == null) {
            return null;
        }
        int t2 = t2(i2, q2(i2));
        return f() ? new PointF((float) t2, 0.0f) : new PointF(0.0f, (float) t2);
    }

    public boolean f() {
        return this.f4426C.f4456a == 0;
    }

    /* access modifiers changed from: package-private */
    public int g2(int i2) {
        return (int) (((float) this.f4431s) - ((float) C2(i2, q2(i2))));
    }

    public boolean p() {
        return f();
    }

    public boolean q() {
        return !f();
    }

    /* access modifiers changed from: package-private */
    public int t2(int i2, f fVar) {
        return C2(i2, fVar) - this.f4431s;
    }

    public int u2() {
        return this.f4426C.f4456a;
    }

    public int v(RecyclerView.z zVar) {
        if (O() == 0 || this.f4437y == null || b() <= 1) {
            return 0;
        }
        return (int) (((float) s0()) * (this.f4437y.g().f() / ((float) x(zVar))));
    }

    public int w(RecyclerView.z zVar) {
        return this.f4431s;
    }

    public boolean w0() {
        return true;
    }

    public boolean w1(RecyclerView recyclerView, View view, Rect rect, boolean z2, boolean z3) {
        int D2;
        if (this.f4437y == null || (D2 = D2(l0(view), q2(l0(view)))) == 0) {
            return false;
        }
        Q2(recyclerView, D2(l0(view), this.f4437y.j((float) (this.f4431s + h2(D2, this.f4431s, this.f4432t, this.f4433u)), (float) this.f4432t, (float) this.f4433u)));
        return true;
    }

    public int x(RecyclerView.z zVar) {
        return this.f4433u - this.f4432t;
    }

    public int y(RecyclerView.z zVar) {
        if (O() == 0 || this.f4437y == null || b() <= 1) {
            return 0;
        }
        return (int) (((float) b0()) * (this.f4437y.g().f() / ((float) A(zVar))));
    }

    public int z(RecyclerView.z zVar) {
        return this.f4431s;
    }

    @SuppressLint({"UnknownNullness"})
    public CarouselLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f4434v = false;
        this.f4435w = new c();
        this.f4424A = 0;
        this.f4427D = new X.a(this);
        this.f4429F = -1;
        this.f4430G = 0;
        T2(new h());
        S2(context, attributeSet);
    }

    public CarouselLayoutManager(d dVar) {
        this(dVar, 0);
    }

    public CarouselLayoutManager(d dVar, int i2) {
        this.f4434v = false;
        this.f4435w = new c();
        this.f4424A = 0;
        this.f4427D = new X.a(this);
        this.f4429F = -1;
        this.f4430G = 0;
        T2(dVar);
        U2(i2);
    }
}
