package com.google.android.material.carousel;

import android.content.Context;
import android.view.View;

public abstract class d {

    /* renamed from: a  reason: collision with root package name */
    private float f4459a;

    /* renamed from: b  reason: collision with root package name */
    private float f4460b;

    static int[] a(int[] iArr) {
        int length = iArr.length;
        int[] iArr2 = new int[length];
        for (int i2 = 0; i2 < length; i2++) {
            iArr2[i2] = iArr[i2] * 2;
        }
        return iArr2;
    }

    static float b(float f2, float f3, float f4) {
        return 1.0f - ((f2 - f4) / (f3 - f4));
    }

    public float c() {
        return this.f4460b;
    }

    public float d() {
        return this.f4459a;
    }

    /* access modifiers changed from: package-private */
    public void e(Context context) {
        float f2 = this.f4459a;
        if (f2 <= 0.0f) {
            f2 = e.h(context);
        }
        this.f4459a = f2;
        float f3 = this.f4460b;
        if (f3 <= 0.0f) {
            f3 = e.g(context);
        }
        this.f4460b = f3;
    }

    /* access modifiers changed from: package-private */
    public boolean f() {
        return true;
    }

    /* access modifiers changed from: package-private */
    public abstract f g(b bVar, View view);

    /* access modifiers changed from: package-private */
    public abstract boolean h(b bVar, int i2);
}
