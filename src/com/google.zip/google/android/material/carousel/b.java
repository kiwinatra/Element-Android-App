package com.google.android.material.carousel;

interface b {
    int a();

    int b();

    int c();

    int d();

    boolean f();
}
