package com.google.android.material.carousel;

import U.a;
import com.google.android.material.carousel.f;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import v.C0288a;

class g {

    /* renamed from: a  reason: collision with root package name */
    private final f f4482a;

    /* renamed from: b  reason: collision with root package name */
    private final List f4483b;

    /* renamed from: c  reason: collision with root package name */
    private final List f4484c;

    /* renamed from: d  reason: collision with root package name */
    private final float[] f4485d;

    /* renamed from: e  reason: collision with root package name */
    private final float[] f4486e;

    /* renamed from: f  reason: collision with root package name */
    private final float f4487f;

    /* renamed from: g  reason: collision with root package name */
    private final float f4488g;

    private g(f fVar, List list, List list2) {
        this.f4482a = fVar;
        this.f4483b = Collections.unmodifiableList(list);
        this.f4484c = Collections.unmodifiableList(list2);
        float f2 = ((f) list.get(list.size() - 1)).c().f4474a - fVar.c().f4474a;
        this.f4487f = f2;
        float f3 = fVar.j().f4474a - ((f) list2.get(list2.size() - 1)).j().f4474a;
        this.f4488g = f3;
        this.f4485d = m(f2, list, true);
        this.f4486e = m(f3, list2, false);
    }

    private f a(List list, float f2, float[] fArr) {
        float[] o2 = o(list, f2, fArr);
        return (f) list.get((int) (o2[0] >= 0.5f ? o2[2] : o2[1]));
    }

    private static int b(f fVar, float f2) {
        for (int i2 = fVar.i(); i2 < fVar.g().size(); i2++) {
            if (f2 == ((f.c) fVar.g().get(i2)).f4476c) {
                return i2;
            }
        }
        return fVar.g().size() - 1;
    }

    private static int c(f fVar) {
        for (int i2 = 0; i2 < fVar.g().size(); i2++) {
            if (!((f.c) fVar.g().get(i2)).f4478e) {
                return i2;
            }
        }
        return -1;
    }

    private static int d(f fVar, float f2) {
        for (int b2 = fVar.b() - 1; b2 >= 0; b2--) {
            if (f2 == ((f.c) fVar.g().get(b2)).f4476c) {
                return b2;
            }
        }
        return 0;
    }

    private static int e(f fVar) {
        for (int size = fVar.g().size() - 1; size >= 0; size--) {
            if (!((f.c) fVar.g().get(size)).f4478e) {
                return size;
            }
        }
        return -1;
    }

    static g f(b bVar, f fVar, float f2, float f3, float f4) {
        return new g(fVar, p(bVar, fVar, f2, f3), n(bVar, fVar, f2, f4));
    }

    private static float[] m(float f2, List list, boolean z2) {
        int size = list.size();
        float[] fArr = new float[size];
        int i2 = 1;
        while (i2 < size) {
            int i3 = i2 - 1;
            f fVar = (f) list.get(i3);
            f fVar2 = (f) list.get(i2);
            fArr[i2] = i2 == size + -1 ? 1.0f : fArr[i3] + ((z2 ? fVar2.c().f4474a - fVar.c().f4474a : fVar.j().f4474a - fVar2.j().f4474a) / f2);
            i2++;
        }
        return fArr;
    }

    private static List n(b bVar, f fVar, float f2, float f3) {
        f fVar2 = fVar;
        float f4 = f2;
        float f5 = f3;
        ArrayList arrayList = new ArrayList();
        arrayList.add(fVar2);
        int e2 = e(fVar);
        float a2 = (float) (bVar.f() ? bVar.a() : bVar.d());
        if (r(bVar, fVar) || e2 == -1) {
            if (f5 > 0.0f) {
                arrayList.add(u(fVar2, f5, a2, false, f4));
            }
            return arrayList;
        }
        int i2 = e2 - fVar.i();
        float f6 = fVar.c().f4475b - (fVar.c().f4477d / 2.0f);
        if (i2 > 0 || fVar.h().f4479f <= 0.0f) {
            float f7 = 0.0f;
            int i3 = 0;
            while (i3 < i2) {
                f fVar3 = (f) arrayList.get(arrayList.size() - 1);
                int i4 = e2 - i3;
                float f8 = f7 + ((f.c) fVar.g().get(i4)).f4479f;
                int i5 = i4 + 1;
                int i6 = i3;
                f t2 = t(fVar3, e2, i5 < fVar.g().size() ? d(fVar3, ((f.c) fVar.g().get(i5)).f4476c) + 1 : 0, f6 - f8, fVar.b() + i3 + 1, fVar.i() + i3 + 1, a2);
                if (i6 == i2 - 1 && f5 > 0.0f) {
                    t2 = u(t2, f5, a2, false, f4);
                }
                arrayList.add(t2);
                i3 = i6 + 1;
                f7 = f8;
            }
            return arrayList;
        }
        arrayList.add(v(fVar2, f6 - fVar.h().f4479f, a2));
        return arrayList;
    }

    private static float[] o(List list, float f2, float[] fArr) {
        int size = list.size();
        float f3 = fArr[0];
        int i2 = 1;
        while (i2 < size) {
            float f4 = fArr[i2];
            if (f2 <= f4) {
                return new float[]{a.b(0.0f, 1.0f, f3, f4, f2), (float) (i2 - 1), (float) i2};
            }
            i2++;
            f3 = f4;
        }
        return new float[]{0.0f, 0.0f, 0.0f};
    }

    private static List p(b bVar, f fVar, float f2, float f3) {
        f fVar2 = fVar;
        float f4 = f2;
        float f5 = f3;
        ArrayList arrayList = new ArrayList();
        arrayList.add(fVar2);
        int c2 = c(fVar);
        float a2 = (float) (bVar.f() ? bVar.a() : bVar.d());
        int i2 = 1;
        if (q(fVar) || c2 == -1) {
            if (f5 > 0.0f) {
                arrayList.add(u(fVar2, f5, a2, true, f4));
            }
            return arrayList;
        }
        int b2 = fVar.b() - c2;
        float f6 = fVar.c().f4475b - (fVar.c().f4477d / 2.0f);
        if (b2 > 0 || fVar.a().f4479f <= 0.0f) {
            float f7 = 0.0f;
            int i3 = 0;
            while (i3 < b2) {
                f fVar3 = (f) arrayList.get(arrayList.size() - i2);
                int i4 = c2 + i3;
                int size = fVar.g().size() - i2;
                float f8 = f7 + ((f.c) fVar.g().get(i4)).f4479f;
                int i5 = i4 - i2;
                int b3 = i5 >= 0 ? b(fVar3, ((f.c) fVar.g().get(i5)).f4476c) - i2 : size;
                int i6 = i3;
                f t2 = t(fVar3, c2, b3, f6 + f8, (fVar.b() - i3) - 1, (fVar.i() - i3) - 1, a2);
                if (i6 == b2 - 1 && f5 > 0.0f) {
                    t2 = u(t2, f5, a2, true, f4);
                }
                arrayList.add(t2);
                i3 = i6 + 1;
                f7 = f8;
                i2 = 1;
            }
            return arrayList;
        }
        arrayList.add(v(fVar2, f6 + fVar.a().f4479f, a2));
        return arrayList;
    }

    private static boolean q(f fVar) {
        return fVar.a().f4475b - (fVar.a().f4477d / 2.0f) >= 0.0f && fVar.a() == fVar.d();
    }

    private static boolean r(b bVar, f fVar) {
        int d2 = bVar.d();
        if (bVar.f()) {
            d2 = bVar.a();
        }
        return fVar.h().f4475b + (fVar.h().f4477d / 2.0f) <= ((float) d2) && fVar.h() == fVar.k();
    }

    private static f s(List list, float f2, float[] fArr) {
        float[] o2 = o(list, f2, fArr);
        return f.m((f) list.get((int) o2[1]), (f) list.get((int) o2[2]), o2[0]);
    }

    private static f t(f fVar, int i2, int i3, float f2, int i4, int i5, float f3) {
        ArrayList arrayList = new ArrayList(fVar.g());
        arrayList.add(i3, (f.c) arrayList.remove(i2));
        f.b bVar = new f.b(fVar.f(), f3);
        int i6 = 0;
        while (i6 < arrayList.size()) {
            f.c cVar = (f.c) arrayList.get(i6);
            float f4 = cVar.f4477d;
            bVar.e(f2 + (f4 / 2.0f), cVar.f4476c, f4, i6 >= i4 && i6 <= i5, cVar.f4478e, cVar.f4479f);
            f2 += cVar.f4477d;
            i6++;
        }
        return bVar.i();
    }

    private static f u(f fVar, float f2, float f3, boolean z2, float f4) {
        ArrayList arrayList = new ArrayList(fVar.g());
        f.b bVar = new f.b(fVar.f(), f3);
        float l2 = f2 / ((float) fVar.l());
        float f5 = z2 ? f2 : 0.0f;
        int i2 = 0;
        while (i2 < arrayList.size()) {
            f.c cVar = (f.c) arrayList.get(i2);
            if (cVar.f4478e) {
                bVar.e(cVar.f4475b, cVar.f4476c, cVar.f4477d, false, true, cVar.f4479f);
            } else {
                boolean z3 = i2 >= fVar.b() && i2 <= fVar.i();
                float f6 = cVar.f4477d - l2;
                float b2 = d.b(f6, fVar.f(), f4);
                float f7 = (f6 / 2.0f) + f5;
                float f8 = f7 - cVar.f4475b;
                bVar.f(f7, b2, f6, z3, false, cVar.f4479f, z2 ? f8 : 0.0f, z2 ? 0.0f : f8);
                f5 += f6;
            }
            i2++;
        }
        return bVar.i();
    }

    private static f v(f fVar, float f2, float f3) {
        return t(fVar, 0, 0, f2, fVar.b(), fVar.i(), f3);
    }

    /* access modifiers changed from: package-private */
    public f g() {
        return this.f4482a;
    }

    /* access modifiers changed from: package-private */
    public f h() {
        List list = this.f4484c;
        return (f) list.get(list.size() - 1);
    }

    /* access modifiers changed from: package-private */
    public Map i(int i2, int i3, int i4, boolean z2) {
        float f2 = this.f4482a.f();
        HashMap hashMap = new HashMap();
        int i5 = 0;
        int i6 = 0;
        while (true) {
            int i7 = -1;
            if (i5 >= i2) {
                break;
            }
            int i8 = z2 ? (i2 - i5) - 1 : i5;
            float f3 = ((float) i8) * f2;
            if (!z2) {
                i7 = 1;
            }
            if (f3 * ((float) i7) > ((float) i4) - this.f4488g || i5 >= i2 - this.f4484c.size()) {
                Integer valueOf = Integer.valueOf(i8);
                List list = this.f4484c;
                hashMap.put(valueOf, (f) list.get(C0288a.b(i6, 0, list.size() - 1)));
                i6++;
            }
            i5++;
        }
        int i9 = 0;
        for (int i10 = i2 - 1; i10 >= 0; i10--) {
            int i11 = z2 ? (i2 - i10) - 1 : i10;
            if (((float) i11) * f2 * ((float) (z2 ? -1 : 1)) < ((float) i3) + this.f4487f || i10 < this.f4483b.size()) {
                Integer valueOf2 = Integer.valueOf(i11);
                List list2 = this.f4483b;
                hashMap.put(valueOf2, (f) list2.get(C0288a.b(i9, 0, list2.size() - 1)));
                i9++;
            }
        }
        return hashMap;
    }

    public f j(float f2, float f3, float f4) {
        return k(f2, f3, f4, false);
    }

    /* access modifiers changed from: package-private */
    public f k(float f2, float f3, float f4, boolean z2) {
        float[] fArr;
        List list;
        float f5;
        float f6 = this.f4487f + f3;
        float f7 = f4 - this.f4488g;
        float f8 = l().a().f4480g;
        float f9 = h().h().f4481h;
        if (this.f4487f == f8) {
            f6 += f8;
        }
        if (this.f4488g == f9) {
            f7 -= f9;
        }
        if (f2 < f6) {
            f5 = a.b(1.0f, 0.0f, f3, f6, f2);
            list = this.f4483b;
            fArr = this.f4485d;
        } else if (f2 <= f7) {
            return this.f4482a;
        } else {
            f5 = a.b(0.0f, 1.0f, f7, f4, f2);
            list = this.f4484c;
            fArr = this.f4486e;
        }
        return z2 ? a(list, f5, fArr) : s(list, f5, fArr);
    }

    /* access modifiers changed from: package-private */
    public f l() {
        List list = this.f4483b;
        return (f) list.get(list.size() - 1);
    }
}
