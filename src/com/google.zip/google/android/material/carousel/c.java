package com.google.android.material.carousel;

import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

abstract class c {

    /* renamed from: a  reason: collision with root package name */
    final int f4456a;

    class a extends c {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ CarouselLayoutManager f4457b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(int i2, CarouselLayoutManager carouselLayoutManager) {
            super(i2, (a) null);
            this.f4457b = carouselLayoutManager;
        }

        public float d(RecyclerView.p pVar) {
            return (float) (pVar.topMargin + pVar.bottomMargin);
        }

        /* access modifiers changed from: package-private */
        public int e() {
            return this.f4457b.b0();
        }

        /* access modifiers changed from: package-private */
        public int f() {
            return e();
        }

        /* access modifiers changed from: package-private */
        public int g() {
            return this.f4457b.i0();
        }

        /* access modifiers changed from: package-private */
        public int h() {
            return this.f4457b.s0() - this.f4457b.j0();
        }

        /* access modifiers changed from: package-private */
        public int i() {
            return j();
        }

        /* access modifiers changed from: package-private */
        public int j() {
            return 0;
        }

        public void k(View view, int i2, int i3) {
            int g2 = g();
            this.f4457b.D0(view, g2, i2, g2 + m(view), i3);
        }

        public void l(View view, Rect rect, float f2, float f3) {
            view.offsetTopAndBottom((int) (f3 - (((float) rect.top) + f2)));
        }

        /* access modifiers changed from: package-private */
        public int m(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f4457b.X(view) + pVar.leftMargin + pVar.rightMargin;
        }
    }

    class b extends c {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ CarouselLayoutManager f4458b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(int i2, CarouselLayoutManager carouselLayoutManager) {
            super(i2, (a) null);
            this.f4458b = carouselLayoutManager;
        }

        public float d(RecyclerView.p pVar) {
            return (float) (pVar.rightMargin + pVar.leftMargin);
        }

        /* access modifiers changed from: package-private */
        public int e() {
            return this.f4458b.b0() - this.f4458b.h0();
        }

        /* access modifiers changed from: package-private */
        public int f() {
            return this.f4458b.F2() ? g() : h();
        }

        /* access modifiers changed from: package-private */
        public int g() {
            return 0;
        }

        /* access modifiers changed from: package-private */
        public int h() {
            return this.f4458b.s0();
        }

        /* access modifiers changed from: package-private */
        public int i() {
            return this.f4458b.F2() ? h() : g();
        }

        /* access modifiers changed from: package-private */
        public int j() {
            return this.f4458b.k0();
        }

        public void k(View view, int i2, int i3) {
            int j2 = j();
            this.f4458b.D0(view, i2, j2, i3, j2 + m(view));
        }

        public void l(View view, Rect rect, float f2, float f3) {
            view.offsetLeftAndRight((int) (f3 - (((float) rect.left) + f2)));
        }

        /* access modifiers changed from: package-private */
        public int m(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f4458b.W(view) + pVar.topMargin + pVar.bottomMargin;
        }
    }

    private c(int i2) {
        this.f4456a = i2;
    }

    private static c a(CarouselLayoutManager carouselLayoutManager) {
        return new b(0, carouselLayoutManager);
    }

    static c b(CarouselLayoutManager carouselLayoutManager, int i2) {
        if (i2 == 0) {
            return a(carouselLayoutManager);
        }
        if (i2 == 1) {
            return c(carouselLayoutManager);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    private static c c(CarouselLayoutManager carouselLayoutManager) {
        return new a(1, carouselLayoutManager);
    }

    /* access modifiers changed from: package-private */
    public abstract float d(RecyclerView.p pVar);

    /* access modifiers changed from: package-private */
    public abstract int e();

    /* access modifiers changed from: package-private */
    public abstract int f();

    /* access modifiers changed from: package-private */
    public abstract int g();

    /* access modifiers changed from: package-private */
    public abstract int h();

    /* access modifiers changed from: package-private */
    public abstract int i();

    /* access modifiers changed from: package-private */
    public abstract int j();

    /* access modifiers changed from: package-private */
    public abstract void k(View view, int i2, int i3);

    /* access modifiers changed from: package-private */
    public abstract void l(View view, Rect rect, float f2, float f3);

    /* synthetic */ c(int i2, a aVar) {
        this(i2);
    }
}
