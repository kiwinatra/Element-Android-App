package com.google.android.material.carousel;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import v.C0288a;

public final class h extends d {

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f4489d = {1};

    /* renamed from: e  reason: collision with root package name */
    private static final int[] f4490e = {1, 0};

    /* renamed from: c  reason: collision with root package name */
    private int f4491c = 0;

    /* access modifiers changed from: package-private */
    public f g(b bVar, View view) {
        float d2 = (float) bVar.d();
        if (bVar.f()) {
            d2 = (float) bVar.a();
        }
        RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
        float f2 = (float) (pVar.topMargin + pVar.bottomMargin);
        float measuredHeight = (float) view.getMeasuredHeight();
        if (bVar.f()) {
            f2 = (float) (pVar.leftMargin + pVar.rightMargin);
            measuredHeight = (float) view.getMeasuredWidth();
        }
        float f3 = f2;
        float d3 = d() + f3;
        float max = Math.max(c() + f3, d3);
        float min = Math.min(measuredHeight + f3, d2);
        float a2 = C0288a.a((measuredHeight / 3.0f) + f3, d3 + f3, max + f3);
        float f4 = (min + a2) / 2.0f;
        int[] iArr = f4489d;
        if (d2 < 2.0f * d3) {
            iArr = new int[]{0};
        }
        int[] iArr2 = f4490e;
        if (bVar.c() == 1) {
            iArr = d.a(iArr);
            iArr2 = d.a(iArr2);
        }
        int[] iArr3 = iArr;
        int[] iArr4 = iArr2;
        int ceil = (int) Math.ceil((double) (d2 / min));
        int max2 = (ceil - ((int) Math.max(1.0d, Math.floor((double) (((d2 - (((float) e.i(iArr4)) * f4)) - (((float) e.i(iArr3)) * max)) / min))))) + 1;
        int[] iArr5 = new int[max2];
        for (int i2 = 0; i2 < max2; i2++) {
            iArr5[i2] = ceil - i2;
        }
        a c2 = a.c(d2, a2, d3, max, iArr3, f4, iArr4, min, iArr5);
        this.f4491c = c2.e();
        if (i(c2, bVar.b())) {
            c2 = a.c(d2, a2, d3, max, new int[]{c2.f4450c}, f4, new int[]{c2.f4451d}, min, new int[]{c2.f4454g});
        }
        return e.d(view.getContext(), f3, d2, c2, bVar.c());
    }

    /* access modifiers changed from: package-private */
    public boolean h(b bVar, int i2) {
        return (i2 < this.f4491c && bVar.b() >= this.f4491c) || (i2 >= this.f4491c && bVar.b() < this.f4491c);
    }

    /* access modifiers changed from: package-private */
    public boolean i(a aVar, int i2) {
        int e2 = aVar.e() - i2;
        boolean z2 = e2 > 0 && (aVar.f4450c > 0 || aVar.f4451d > 1);
        while (e2 > 0) {
            int i3 = aVar.f4450c;
            if (i3 > 0) {
                aVar.f4450c = i3 - 1;
            } else {
                int i4 = aVar.f4451d;
                if (i4 > 1) {
                    aVar.f4451d = i4 - 1;
                }
            }
            e2--;
        }
        return z2;
    }
}
