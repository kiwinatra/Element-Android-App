package com.google.android.material.carousel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class f {

    /* renamed from: a  reason: collision with root package name */
    private final float f4461a;

    /* renamed from: b  reason: collision with root package name */
    private final List f4462b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4463c;

    /* renamed from: d  reason: collision with root package name */
    private final int f4464d;

    static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final float f4465a;

        /* renamed from: b  reason: collision with root package name */
        private final float f4466b;

        /* renamed from: c  reason: collision with root package name */
        private final List f4467c = new ArrayList();

        /* renamed from: d  reason: collision with root package name */
        private c f4468d;

        /* renamed from: e  reason: collision with root package name */
        private c f4469e;

        /* renamed from: f  reason: collision with root package name */
        private int f4470f = -1;

        /* renamed from: g  reason: collision with root package name */
        private int f4471g = -1;

        /* renamed from: h  reason: collision with root package name */
        private float f4472h = 0.0f;

        /* renamed from: i  reason: collision with root package name */
        private int f4473i = -1;

        b(float f2, float f3) {
            this.f4465a = f2;
            this.f4466b = f3;
        }

        private static float j(float f2, float f3, int i2, int i3) {
            return (f2 - (((float) i2) * f3)) + (((float) i3) * f3);
        }

        /* access modifiers changed from: package-private */
        public b a(float f2, float f3, float f4) {
            return d(f2, f3, f4, false, true);
        }

        /* access modifiers changed from: package-private */
        public b b(float f2, float f3, float f4) {
            return c(f2, f3, f4, false);
        }

        /* access modifiers changed from: package-private */
        public b c(float f2, float f3, float f4, boolean z2) {
            return d(f2, f3, f4, z2, false);
        }

        /* access modifiers changed from: package-private */
        public b d(float f2, float f3, float f4, boolean z2, boolean z3) {
            float f5;
            float abs;
            float f6 = f4 / 2.0f;
            float f7 = f2 - f6;
            float f8 = f6 + f2;
            float f9 = this.f4466b;
            if (f8 > f9) {
                abs = Math.abs(f8 - Math.max(f8 - f4, f9));
            } else if (f7 < 0.0f) {
                abs = Math.abs(f7 - Math.min(f7 + f4, 0.0f));
            } else {
                f5 = 0.0f;
                return e(f2, f3, f4, z2, z3, f5);
            }
            f5 = abs;
            return e(f2, f3, f4, z2, z3, f5);
        }

        /* access modifiers changed from: package-private */
        public b e(float f2, float f3, float f4, boolean z2, boolean z3, float f5) {
            return f(f2, f3, f4, z2, z3, f5, 0.0f, 0.0f);
        }

        /* access modifiers changed from: package-private */
        public b f(float f2, float f3, float f4, boolean z2, boolean z3, float f5, float f6, float f7) {
            if (f4 <= 0.0f) {
                return this;
            }
            if (z3) {
                if (!z2) {
                    int i2 = this.f4473i;
                    if (i2 == -1 || i2 == 0) {
                        this.f4473i = this.f4467c.size();
                    } else {
                        throw new IllegalArgumentException("Anchor keylines must be either the first or last keyline.");
                    }
                } else {
                    throw new IllegalArgumentException("Anchor keylines cannot be focal.");
                }
            }
            c cVar = new c(Float.MIN_VALUE, f2, f3, f4, z3, f5, f6, f7);
            c cVar2 = this.f4468d;
            if (z2) {
                if (cVar2 == null) {
                    this.f4468d = cVar;
                    this.f4470f = this.f4467c.size();
                }
                if (this.f4471g != -1 && this.f4467c.size() - this.f4471g > 1) {
                    throw new IllegalArgumentException("Keylines marked as focal must be placed next to each other. There cannot be non-focal keylines between focal keylines.");
                } else if (f4 == this.f4468d.f4477d) {
                    this.f4469e = cVar;
                    this.f4471g = this.f4467c.size();
                } else {
                    throw new IllegalArgumentException("Keylines that are marked as focal must all have the same masked item size.");
                }
            } else if (cVar2 == null && cVar.f4477d < this.f4472h) {
                throw new IllegalArgumentException("Keylines before the first focal keyline must be ordered by incrementing masked item size.");
            } else if (this.f4469e != null && cVar.f4477d > this.f4472h) {
                throw new IllegalArgumentException("Keylines after the last focal keyline must be ordered by decreasing masked item size.");
            }
            this.f4472h = cVar.f4477d;
            this.f4467c.add(cVar);
            return this;
        }

        /* access modifiers changed from: package-private */
        public b g(float f2, float f3, float f4, int i2) {
            return h(f2, f3, f4, i2, false);
        }

        /* access modifiers changed from: package-private */
        public b h(float f2, float f3, float f4, int i2, boolean z2) {
            if (i2 > 0 && f4 > 0.0f) {
                for (int i3 = 0; i3 < i2; i3++) {
                    c((((float) i3) * f4) + f2, f3, f4, z2);
                }
            }
            return this;
        }

        /* access modifiers changed from: package-private */
        public f i() {
            if (this.f4468d != null) {
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < this.f4467c.size(); i2++) {
                    c cVar = (c) this.f4467c.get(i2);
                    arrayList.add(new c(j(this.f4468d.f4475b, this.f4465a, this.f4470f, i2), cVar.f4475b, cVar.f4476c, cVar.f4477d, cVar.f4478e, cVar.f4479f, cVar.f4480g, cVar.f4481h));
                }
                return new f(this.f4465a, arrayList, this.f4470f, this.f4471g);
            }
            throw new IllegalStateException("There must be a keyline marked as focal.");
        }
    }

    static final class c {

        /* renamed from: a  reason: collision with root package name */
        final float f4474a;

        /* renamed from: b  reason: collision with root package name */
        final float f4475b;

        /* renamed from: c  reason: collision with root package name */
        final float f4476c;

        /* renamed from: d  reason: collision with root package name */
        final float f4477d;

        /* renamed from: e  reason: collision with root package name */
        final boolean f4478e;

        /* renamed from: f  reason: collision with root package name */
        final float f4479f;

        /* renamed from: g  reason: collision with root package name */
        final float f4480g;

        /* renamed from: h  reason: collision with root package name */
        final float f4481h;

        c(float f2, float f3, float f4, float f5) {
            this(f2, f3, f4, f5, false, 0.0f, 0.0f, 0.0f);
        }

        static c a(c cVar, c cVar2, float f2) {
            return new c(U.a.a(cVar.f4474a, cVar2.f4474a, f2), U.a.a(cVar.f4475b, cVar2.f4475b, f2), U.a.a(cVar.f4476c, cVar2.f4476c, f2), U.a.a(cVar.f4477d, cVar2.f4477d, f2));
        }

        c(float f2, float f3, float f4, float f5, boolean z2, float f6, float f7, float f8) {
            this.f4474a = f2;
            this.f4475b = f3;
            this.f4476c = f4;
            this.f4477d = f5;
            this.f4478e = z2;
            this.f4479f = f6;
            this.f4480g = f7;
            this.f4481h = f8;
        }
    }

    private f(float f2, List list, int i2, int i3) {
        this.f4461a = f2;
        this.f4462b = Collections.unmodifiableList(list);
        this.f4463c = i2;
        this.f4464d = i3;
    }

    static f m(f fVar, f fVar2, float f2) {
        if (fVar.f() == fVar2.f()) {
            List g2 = fVar.g();
            List g3 = fVar2.g();
            if (g2.size() == g3.size()) {
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < fVar.g().size(); i2++) {
                    arrayList.add(c.a((c) g2.get(i2), (c) g3.get(i2), f2));
                }
                return new f(fVar.f(), arrayList, U.a.c(fVar.b(), fVar2.b(), f2), U.a.c(fVar.i(), fVar2.i(), f2));
            }
            throw new IllegalArgumentException("Keylines being linearly interpolated must have the same number of keylines.");
        }
        throw new IllegalArgumentException("Keylines being linearly interpolated must have the same item size.");
    }

    static f n(f fVar, float f2) {
        b bVar = new b(fVar.f(), f2);
        float f3 = (f2 - fVar.j().f4475b) - (fVar.j().f4477d / 2.0f);
        int size = fVar.g().size() - 1;
        while (size >= 0) {
            c cVar = (c) fVar.g().get(size);
            bVar.d(f3 + (cVar.f4477d / 2.0f), cVar.f4476c, cVar.f4477d, size >= fVar.b() && size <= fVar.i(), cVar.f4478e);
            f3 += cVar.f4477d;
            size--;
        }
        return bVar.i();
    }

    /* access modifiers changed from: package-private */
    public c a() {
        return (c) this.f4462b.get(this.f4463c);
    }

    /* access modifiers changed from: package-private */
    public int b() {
        return this.f4463c;
    }

    /* access modifiers changed from: package-private */
    public c c() {
        return (c) this.f4462b.get(0);
    }

    /* access modifiers changed from: package-private */
    public c d() {
        for (int i2 = 0; i2 < this.f4462b.size(); i2++) {
            c cVar = (c) this.f4462b.get(i2);
            if (!cVar.f4478e) {
                return cVar;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public List e() {
        return this.f4462b.subList(this.f4463c, this.f4464d + 1);
    }

    /* access modifiers changed from: package-private */
    public float f() {
        return this.f4461a;
    }

    /* access modifiers changed from: package-private */
    public List g() {
        return this.f4462b;
    }

    /* access modifiers changed from: package-private */
    public c h() {
        return (c) this.f4462b.get(this.f4464d);
    }

    /* access modifiers changed from: package-private */
    public int i() {
        return this.f4464d;
    }

    /* access modifiers changed from: package-private */
    public c j() {
        List list = this.f4462b;
        return (c) list.get(list.size() - 1);
    }

    /* access modifiers changed from: package-private */
    public c k() {
        for (int size = this.f4462b.size() - 1; size >= 0; size--) {
            c cVar = (c) this.f4462b.get(size);
            if (!cVar.f4478e) {
                return cVar;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public int l() {
        int i2 = 0;
        for (c cVar : this.f4462b) {
            if (cVar.f4478e) {
                i2++;
            }
        }
        return this.f4462b.size() - i2;
    }
}
