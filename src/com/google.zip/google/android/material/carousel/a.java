package com.google.android.material.carousel;

import v.C0288a;

final class a {

    /* renamed from: a  reason: collision with root package name */
    final int f4448a;

    /* renamed from: b  reason: collision with root package name */
    float f4449b;

    /* renamed from: c  reason: collision with root package name */
    int f4450c;

    /* renamed from: d  reason: collision with root package name */
    int f4451d;

    /* renamed from: e  reason: collision with root package name */
    float f4452e;

    /* renamed from: f  reason: collision with root package name */
    float f4453f;

    /* renamed from: g  reason: collision with root package name */
    final int f4454g;

    /* renamed from: h  reason: collision with root package name */
    final float f4455h;

    a(int i2, float f2, float f3, float f4, int i3, float f5, int i4, float f6, int i5, float f7) {
        this.f4448a = i2;
        this.f4449b = C0288a.a(f2, f3, f4);
        this.f4450c = i3;
        this.f4452e = f5;
        this.f4451d = i4;
        this.f4453f = f6;
        this.f4454g = i5;
        d(f7, f3, f4, f6);
        this.f4455h = b(f6);
    }

    private float a(float f2, int i2, float f3, int i3, int i4) {
        if (i2 <= 0) {
            f3 = 0.0f;
        }
        float f4 = ((float) i3) / 2.0f;
        return (f2 - ((((float) i2) + f4) * f3)) / (((float) i4) + f4);
    }

    private float b(float f2) {
        if (!g()) {
            return Float.MAX_VALUE;
        }
        return Math.abs(f2 - this.f4453f) * ((float) this.f4448a);
    }

    static a c(float f2, float f3, float f4, float f5, int[] iArr, float f6, int[] iArr2, float f7, int[] iArr3) {
        int[] iArr4 = iArr;
        int[] iArr5 = iArr2;
        a aVar = null;
        int i2 = 1;
        for (int i3 : iArr3) {
            int length = iArr5.length;
            int i4 = 0;
            while (i4 < length) {
                int i5 = iArr5[i4];
                int length2 = iArr4.length;
                int i6 = 0;
                while (i6 < length2) {
                    a aVar2 = r8;
                    int i7 = i6;
                    int i8 = length2;
                    int i9 = i4;
                    int i10 = length;
                    a aVar3 = new a(i2, f3, f4, f5, iArr4[i6], f6, i5, f7, i3, f2);
                    if (aVar == null || aVar2.f4455h < aVar.f4455h) {
                        if (aVar2.f4455h == 0.0f) {
                            return aVar2;
                        }
                        aVar = aVar2;
                    }
                    i2++;
                    i6 = i7 + 1;
                    length2 = i8;
                    i4 = i9;
                    length = i10;
                }
                int i11 = length;
                i4++;
            }
        }
        return aVar;
    }

    private void d(float f2, float f3, float f4, float f5) {
        float f6;
        float f7 = f2 - f();
        int i2 = this.f4450c;
        if (i2 > 0 && f7 > 0.0f) {
            float f8 = this.f4449b;
            this.f4449b = f8 + Math.min(f7 / ((float) i2), f4 - f8);
        } else if (i2 > 0 && f7 < 0.0f) {
            float f9 = this.f4449b;
            this.f4449b = f9 + Math.max(f7 / ((float) i2), f3 - f9);
        }
        int i3 = this.f4450c;
        float f10 = i3 > 0 ? this.f4449b : 0.0f;
        this.f4449b = f10;
        float a2 = a(f2, i3, f10, this.f4451d, this.f4454g);
        this.f4453f = a2;
        float f11 = (this.f4449b + a2) / 2.0f;
        this.f4452e = f11;
        int i4 = this.f4451d;
        if (i4 > 0 && a2 != f5) {
            float f12 = (f5 - a2) * ((float) this.f4454g);
            float min = Math.min(Math.abs(f12), f11 * 0.1f * ((float) i4));
            if (f12 > 0.0f) {
                this.f4452e -= min / ((float) this.f4451d);
                f6 = this.f4453f + (min / ((float) this.f4454g));
            } else {
                this.f4452e += min / ((float) this.f4451d);
                f6 = this.f4453f - (min / ((float) this.f4454g));
            }
            this.f4453f = f6;
        }
    }

    private float f() {
        return (this.f4453f * ((float) this.f4454g)) + (this.f4452e * ((float) this.f4451d)) + (this.f4449b * ((float) this.f4450c));
    }

    private boolean g() {
        int i2 = this.f4454g;
        if (i2 <= 0 || this.f4450c <= 0 || this.f4451d <= 0) {
            return i2 <= 0 || this.f4450c <= 0 || this.f4453f > this.f4449b;
        }
        float f2 = this.f4453f;
        float f3 = this.f4452e;
        return f2 > f3 && f3 > this.f4449b;
    }

    /* access modifiers changed from: package-private */
    public int e() {
        return this.f4450c + this.f4451d + this.f4454g;
    }

    public String toString() {
        return "Arrangement [priority=" + this.f4448a + ", smallCount=" + this.f4450c + ", smallSize=" + this.f4449b + ", mediumCount=" + this.f4451d + ", mediumSize=" + this.f4452e + ", largeCount=" + this.f4454g + ", largeSize=" + this.f4453f + ", cost=" + this.f4455h + "]";
    }
}
