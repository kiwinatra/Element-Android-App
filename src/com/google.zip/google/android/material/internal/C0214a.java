package com.google.android.material.internal;

import a0.C0087a;
import android.animation.TimeInterpolator;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import androidx.core.text.p;
import androidx.core.view.C0156s;
import androidx.core.view.W;
import com.google.android.material.internal.u;
import h0.a;
import h0.d;
import h0.j;
import v.C0288a;
import x.h;

/* renamed from: com.google.android.material.internal.a  reason: case insensitive filesystem */
public final class C0214a {

    /* renamed from: t0  reason: collision with root package name */
    private static final boolean f4730t0 = false;

    /* renamed from: u0  reason: collision with root package name */
    private static final Paint f4731u0 = null;

    /* renamed from: A  reason: collision with root package name */
    private Typeface f4732A;

    /* renamed from: B  reason: collision with root package name */
    private Typeface f4733B;

    /* renamed from: C  reason: collision with root package name */
    private Typeface f4734C;

    /* renamed from: D  reason: collision with root package name */
    private a f4735D;

    /* renamed from: E  reason: collision with root package name */
    private a f4736E;

    /* renamed from: F  reason: collision with root package name */
    private TextUtils.TruncateAt f4737F = TextUtils.TruncateAt.END;

    /* renamed from: G  reason: collision with root package name */
    private CharSequence f4738G;

    /* renamed from: H  reason: collision with root package name */
    private CharSequence f4739H;

    /* renamed from: I  reason: collision with root package name */
    private boolean f4740I;

    /* renamed from: J  reason: collision with root package name */
    private boolean f4741J = true;

    /* renamed from: K  reason: collision with root package name */
    private boolean f4742K;

    /* renamed from: L  reason: collision with root package name */
    private Bitmap f4743L;

    /* renamed from: M  reason: collision with root package name */
    private Paint f4744M;

    /* renamed from: N  reason: collision with root package name */
    private float f4745N;

    /* renamed from: O  reason: collision with root package name */
    private float f4746O;

    /* renamed from: P  reason: collision with root package name */
    private float f4747P;

    /* renamed from: Q  reason: collision with root package name */
    private float f4748Q;

    /* renamed from: R  reason: collision with root package name */
    private float f4749R;

    /* renamed from: S  reason: collision with root package name */
    private int f4750S;

    /* renamed from: T  reason: collision with root package name */
    private int[] f4751T;

    /* renamed from: U  reason: collision with root package name */
    private boolean f4752U;

    /* renamed from: V  reason: collision with root package name */
    private final TextPaint f4753V;

    /* renamed from: W  reason: collision with root package name */
    private final TextPaint f4754W;

    /* renamed from: X  reason: collision with root package name */
    private TimeInterpolator f4755X;

    /* renamed from: Y  reason: collision with root package name */
    private TimeInterpolator f4756Y;

    /* renamed from: Z  reason: collision with root package name */
    private float f4757Z;

    /* renamed from: a  reason: collision with root package name */
    private final View f4758a;

    /* renamed from: a0  reason: collision with root package name */
    private float f4759a0;

    /* renamed from: b  reason: collision with root package name */
    private float f4760b;

    /* renamed from: b0  reason: collision with root package name */
    private float f4761b0;

    /* renamed from: c  reason: collision with root package name */
    private boolean f4762c;

    /* renamed from: c0  reason: collision with root package name */
    private ColorStateList f4763c0;

    /* renamed from: d  reason: collision with root package name */
    private float f4764d;

    /* renamed from: d0  reason: collision with root package name */
    private float f4765d0;

    /* renamed from: e  reason: collision with root package name */
    private float f4766e;

    /* renamed from: e0  reason: collision with root package name */
    private float f4767e0;

    /* renamed from: f  reason: collision with root package name */
    private int f4768f;

    /* renamed from: f0  reason: collision with root package name */
    private float f4769f0;

    /* renamed from: g  reason: collision with root package name */
    private final Rect f4770g;

    /* renamed from: g0  reason: collision with root package name */
    private ColorStateList f4771g0;

    /* renamed from: h  reason: collision with root package name */
    private final Rect f4772h;

    /* renamed from: h0  reason: collision with root package name */
    private float f4773h0;

    /* renamed from: i  reason: collision with root package name */
    private final RectF f4774i;

    /* renamed from: i0  reason: collision with root package name */
    private float f4775i0;

    /* renamed from: j  reason: collision with root package name */
    private int f4776j = 16;

    /* renamed from: j0  reason: collision with root package name */
    private float f4777j0;

    /* renamed from: k  reason: collision with root package name */
    private int f4778k = 16;

    /* renamed from: k0  reason: collision with root package name */
    private StaticLayout f4779k0;

    /* renamed from: l  reason: collision with root package name */
    private float f4780l = 15.0f;

    /* renamed from: l0  reason: collision with root package name */
    private float f4781l0;

    /* renamed from: m  reason: collision with root package name */
    private float f4782m = 15.0f;

    /* renamed from: m0  reason: collision with root package name */
    private float f4783m0;

    /* renamed from: n  reason: collision with root package name */
    private ColorStateList f4784n;

    /* renamed from: n0  reason: collision with root package name */
    private float f4785n0;

    /* renamed from: o  reason: collision with root package name */
    private ColorStateList f4786o;

    /* renamed from: o0  reason: collision with root package name */
    private CharSequence f4787o0;

    /* renamed from: p  reason: collision with root package name */
    private int f4788p;

    /* renamed from: p0  reason: collision with root package name */
    private int f4789p0 = 1;

    /* renamed from: q  reason: collision with root package name */
    private float f4790q;

    /* renamed from: q0  reason: collision with root package name */
    private float f4791q0 = 0.0f;

    /* renamed from: r  reason: collision with root package name */
    private float f4792r;

    /* renamed from: r0  reason: collision with root package name */
    private float f4793r0 = 1.0f;

    /* renamed from: s  reason: collision with root package name */
    private float f4794s;

    /* renamed from: s0  reason: collision with root package name */
    private int f4795s0 = u.f4863n;

    /* renamed from: t  reason: collision with root package name */
    private float f4796t;

    /* renamed from: u  reason: collision with root package name */
    private float f4797u;

    /* renamed from: v  reason: collision with root package name */
    private float f4798v;

    /* renamed from: w  reason: collision with root package name */
    private Typeface f4799w;

    /* renamed from: x  reason: collision with root package name */
    private Typeface f4800x;

    /* renamed from: y  reason: collision with root package name */
    private Typeface f4801y;

    /* renamed from: z  reason: collision with root package name */
    private Typeface f4802z;

    /* renamed from: com.google.android.material.internal.a$a  reason: collision with other inner class name */
    class C0068a implements a.C0074a {
        C0068a() {
        }

        public void a(Typeface typeface) {
            C0214a.this.T(typeface);
        }
    }

    public C0214a(View view) {
        this.f4758a = view;
        TextPaint textPaint = new TextPaint(129);
        this.f4753V = textPaint;
        this.f4754W = new TextPaint(textPaint);
        this.f4772h = new Rect();
        this.f4770g = new Rect();
        this.f4774i = new RectF();
        this.f4766e = e();
        H(view.getContext().getResources().getConfiguration());
    }

    private void A(TextPaint textPaint) {
        textPaint.setTextSize(this.f4780l);
        textPaint.setTypeface(this.f4802z);
        textPaint.setLetterSpacing(this.f4775i0);
    }

    private void B(float f2) {
        if (this.f4762c) {
            this.f4774i.set(f2 < this.f4766e ? this.f4770g : this.f4772h);
            return;
        }
        this.f4774i.left = G((float) this.f4770g.left, (float) this.f4772h.left, f2, this.f4755X);
        this.f4774i.top = G(this.f4790q, this.f4792r, f2, this.f4755X);
        this.f4774i.right = G((float) this.f4770g.right, (float) this.f4772h.right, f2, this.f4755X);
        this.f4774i.bottom = G((float) this.f4770g.bottom, (float) this.f4772h.bottom, f2, this.f4755X);
    }

    private static boolean C(float f2, float f3) {
        return Math.abs(f2 - f3) < 1.0E-5f;
    }

    private boolean D() {
        return W.C(this.f4758a) == 1;
    }

    private boolean F(CharSequence charSequence, boolean z2) {
        return (z2 ? p.f2284d : p.f2283c).a(charSequence, 0, charSequence.length());
    }

    private static float G(float f2, float f3, float f4, TimeInterpolator timeInterpolator) {
        if (timeInterpolator != null) {
            f4 = timeInterpolator.getInterpolation(f4);
        }
        return U.a.a(f2, f3, f4);
    }

    private float I(TextPaint textPaint, CharSequence charSequence) {
        return textPaint.measureText(charSequence, 0, charSequence.length());
    }

    private static boolean L(Rect rect, int i2, int i3, int i4, int i5) {
        return rect.left == i2 && rect.top == i3 && rect.right == i4 && rect.bottom == i5;
    }

    private void Q(float f2) {
        this.f4783m0 = f2;
        W.h0(this.f4758a);
    }

    private boolean U(Typeface typeface) {
        a aVar = this.f4736E;
        if (aVar != null) {
            aVar.c();
        }
        if (this.f4801y == typeface) {
            return false;
        }
        this.f4801y = typeface;
        Typeface b2 = j.b(this.f4758a.getContext().getResources().getConfiguration(), typeface);
        this.f4800x = b2;
        if (b2 == null) {
            b2 = this.f4801y;
        }
        this.f4799w = b2;
        return true;
    }

    private void Y(float f2) {
        this.f4785n0 = f2;
        W.h0(this.f4758a);
    }

    private static int a(int i2, int i3, float f2) {
        float f3 = 1.0f - f2;
        return Color.argb(Math.round((((float) Color.alpha(i2)) * f3) + (((float) Color.alpha(i3)) * f2)), Math.round((((float) Color.red(i2)) * f3) + (((float) Color.red(i3)) * f2)), Math.round((((float) Color.green(i2)) * f3) + (((float) Color.green(i3)) * f2)), Math.round((((float) Color.blue(i2)) * f3) + (((float) Color.blue(i3)) * f2)));
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0076  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0089  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00a1  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x00aa  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00be  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00ee  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00f9  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x010a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void b(boolean r10) {
        /*
            r9 = this;
            r0 = 1065353216(0x3f800000, float:1.0)
            r9.i(r0, r10)
            java.lang.CharSequence r0 = r9.f4739H
            if (r0 == 0) goto L_0x001c
            android.text.StaticLayout r1 = r9.f4779k0
            if (r1 == 0) goto L_0x001c
            android.text.TextPaint r2 = r9.f4753V
            int r1 = r1.getWidth()
            float r1 = (float) r1
            android.text.TextUtils$TruncateAt r3 = r9.f4737F
            java.lang.CharSequence r0 = android.text.TextUtils.ellipsize(r0, r2, r1, r3)
            r9.f4787o0 = r0
        L_0x001c:
            java.lang.CharSequence r0 = r9.f4787o0
            r1 = 0
            if (r0 == 0) goto L_0x002a
            android.text.TextPaint r2 = r9.f4753V
            float r0 = r9.I(r2, r0)
            r9.f4781l0 = r0
            goto L_0x002c
        L_0x002a:
            r9.f4781l0 = r1
        L_0x002c:
            int r0 = r9.f4778k
            boolean r2 = r9.f4740I
            int r0 = androidx.core.view.C0156s.b(r0, r2)
            r2 = r0 & 112(0x70, float:1.57E-43)
            r3 = 80
            r4 = 48
            r5 = 1073741824(0x40000000, float:2.0)
            if (r2 == r4) goto L_0x0068
            if (r2 == r3) goto L_0x0059
            android.text.TextPaint r2 = r9.f4753V
            float r2 = r2.descent()
            android.text.TextPaint r6 = r9.f4753V
            float r6 = r6.ascent()
            float r2 = r2 - r6
            float r2 = r2 / r5
            android.graphics.Rect r6 = r9.f4772h
            int r6 = r6.centerY()
            float r6 = (float) r6
            float r6 = r6 - r2
            r9.f4792r = r6
            goto L_0x006e
        L_0x0059:
            android.graphics.Rect r2 = r9.f4772h
            int r2 = r2.bottom
            float r2 = (float) r2
            android.text.TextPaint r6 = r9.f4753V
            float r6 = r6.ascent()
            float r2 = r2 + r6
        L_0x0065:
            r9.f4792r = r2
            goto L_0x006e
        L_0x0068:
            android.graphics.Rect r2 = r9.f4772h
            int r2 = r2.top
            float r2 = (float) r2
            goto L_0x0065
        L_0x006e:
            r2 = 8388615(0x800007, float:1.1754953E-38)
            r0 = r0 & r2
            r6 = 5
            r7 = 1
            if (r0 == r7) goto L_0x0089
            if (r0 == r6) goto L_0x0080
            android.graphics.Rect r0 = r9.f4772h
            int r0 = r0.left
            float r0 = (float) r0
        L_0x007d:
            r9.f4796t = r0
            goto L_0x0094
        L_0x0080:
            android.graphics.Rect r0 = r9.f4772h
            int r0 = r0.right
            float r0 = (float) r0
            float r8 = r9.f4781l0
        L_0x0087:
            float r0 = r0 - r8
            goto L_0x007d
        L_0x0089:
            android.graphics.Rect r0 = r9.f4772h
            int r0 = r0.centerX()
            float r0 = (float) r0
            float r8 = r9.f4781l0
            float r8 = r8 / r5
            goto L_0x0087
        L_0x0094:
            r9.i(r1, r10)
            android.text.StaticLayout r10 = r9.f4779k0
            if (r10 == 0) goto L_0x00a1
            int r10 = r10.getHeight()
            float r10 = (float) r10
            goto L_0x00a2
        L_0x00a1:
            r10 = 0
        L_0x00a2:
            android.text.StaticLayout r0 = r9.f4779k0
            if (r0 == 0) goto L_0x00b0
            int r8 = r9.f4789p0
            if (r8 <= r7) goto L_0x00b0
            int r0 = r0.getWidth()
            float r1 = (float) r0
            goto L_0x00ba
        L_0x00b0:
            java.lang.CharSequence r0 = r9.f4739H
            if (r0 == 0) goto L_0x00ba
            android.text.TextPaint r1 = r9.f4753V
            float r1 = r9.I(r1, r0)
        L_0x00ba:
            android.text.StaticLayout r0 = r9.f4779k0
            if (r0 == 0) goto L_0x00c3
            int r0 = r0.getLineCount()
            goto L_0x00c4
        L_0x00c3:
            r0 = 0
        L_0x00c4:
            r9.f4788p = r0
            int r0 = r9.f4776j
            boolean r8 = r9.f4740I
            int r0 = androidx.core.view.C0156s.b(r0, r8)
            r8 = r0 & 112(0x70, float:1.57E-43)
            if (r8 == r4) goto L_0x00ee
            if (r8 == r3) goto L_0x00e0
            float r10 = r10 / r5
            android.graphics.Rect r3 = r9.f4770g
            int r3 = r3.centerY()
            float r3 = (float) r3
            float r3 = r3 - r10
        L_0x00dd:
            r9.f4790q = r3
            goto L_0x00f5
        L_0x00e0:
            android.graphics.Rect r3 = r9.f4770g
            int r3 = r3.bottom
            float r3 = (float) r3
            float r3 = r3 - r10
            android.text.TextPaint r10 = r9.f4753V
            float r10 = r10.descent()
            float r3 = r3 + r10
            goto L_0x00dd
        L_0x00ee:
            android.graphics.Rect r10 = r9.f4770g
            int r10 = r10.top
            float r10 = (float) r10
            r9.f4790q = r10
        L_0x00f5:
            r10 = r0 & r2
            if (r10 == r7) goto L_0x010a
            if (r10 == r6) goto L_0x0103
            android.graphics.Rect r10 = r9.f4770g
            int r10 = r10.left
            float r10 = (float) r10
        L_0x0100:
            r9.f4794s = r10
            goto L_0x0113
        L_0x0103:
            android.graphics.Rect r10 = r9.f4770g
            int r10 = r10.right
            float r10 = (float) r10
        L_0x0108:
            float r10 = r10 - r1
            goto L_0x0100
        L_0x010a:
            android.graphics.Rect r10 = r9.f4770g
            int r10 = r10.centerX()
            float r10 = (float) r10
            float r1 = r1 / r5
            goto L_0x0108
        L_0x0113:
            r9.j()
            float r10 = r9.f4760b
            r9.d0(r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.internal.C0214a.b(boolean):void");
    }

    private boolean b0(Typeface typeface) {
        a aVar = this.f4735D;
        if (aVar != null) {
            aVar.c();
        }
        if (this.f4733B == typeface) {
            return false;
        }
        this.f4733B = typeface;
        Typeface b2 = j.b(this.f4758a.getContext().getResources().getConfiguration(), typeface);
        this.f4732A = b2;
        if (b2 == null) {
            b2 = this.f4733B;
        }
        this.f4802z = b2;
        return true;
    }

    private void c() {
        g(this.f4760b);
    }

    private float d(float f2) {
        float f3 = this.f4766e;
        return f2 <= f3 ? U.a.b(1.0f, 0.0f, this.f4764d, f3, f2) : U.a.b(0.0f, 1.0f, f3, 1.0f, f2);
    }

    private void d0(float f2) {
        h(f2);
        boolean z2 = f4730t0 && this.f4745N != 1.0f;
        this.f4742K = z2;
        if (z2) {
            n();
        }
        W.h0(this.f4758a);
    }

    private float e() {
        float f2 = this.f4764d;
        return f2 + ((1.0f - f2) * 0.5f);
    }

    private boolean f(CharSequence charSequence) {
        boolean D2 = D();
        return this.f4741J ? F(charSequence, D2) : D2;
    }

    private void g(float f2) {
        float f3;
        B(f2);
        if (!this.f4762c) {
            this.f4797u = G(this.f4794s, this.f4796t, f2, this.f4755X);
            this.f4798v = G(this.f4790q, this.f4792r, f2, this.f4755X);
            d0(f2);
            f3 = f2;
        } else if (f2 < this.f4766e) {
            this.f4797u = this.f4794s;
            this.f4798v = this.f4790q;
            d0(0.0f);
            f3 = 0.0f;
        } else {
            this.f4797u = this.f4796t;
            this.f4798v = this.f4792r - ((float) Math.max(0, this.f4768f));
            d0(1.0f);
            f3 = 1.0f;
        }
        TimeInterpolator timeInterpolator = U.a.f256b;
        Q(1.0f - G(0.0f, 1.0f, 1.0f - f2, timeInterpolator));
        Y(G(1.0f, 0.0f, f2, timeInterpolator));
        if (this.f4786o != this.f4784n) {
            this.f4753V.setColor(a(v(), t(), f3));
        } else {
            this.f4753V.setColor(t());
        }
        int i2 = Build.VERSION.SDK_INT;
        float f4 = this.f4773h0;
        float f5 = this.f4775i0;
        if (f4 != f5) {
            this.f4753V.setLetterSpacing(G(f5, f4, f2, timeInterpolator));
        } else {
            this.f4753V.setLetterSpacing(f4);
        }
        this.f4747P = G(this.f4765d0, this.f4757Z, f2, (TimeInterpolator) null);
        this.f4748Q = G(this.f4767e0, this.f4759a0, f2, (TimeInterpolator) null);
        this.f4749R = G(this.f4769f0, this.f4761b0, f2, (TimeInterpolator) null);
        int a2 = a(u(this.f4771g0), u(this.f4763c0), f2);
        this.f4750S = a2;
        this.f4753V.setShadowLayer(this.f4747P, this.f4748Q, this.f4749R, a2);
        if (this.f4762c) {
            int alpha = this.f4753V.getAlpha();
            this.f4753V.setAlpha((int) (d(f2) * ((float) alpha)));
            if (i2 >= 31) {
                TextPaint textPaint = this.f4753V;
                textPaint.setShadowLayer(this.f4747P, this.f4748Q, this.f4749R, C0087a.a(this.f4750S, textPaint.getAlpha()));
            }
        }
        W.h0(this.f4758a);
    }

    private void h(float f2) {
        i(f2, false);
    }

    private void i(float f2, boolean z2) {
        float f3;
        float f4;
        Typeface typeface;
        if (this.f4738G != null) {
            float width = (float) this.f4772h.width();
            float width2 = (float) this.f4770g.width();
            if (C(f2, 1.0f)) {
                f4 = this.f4782m;
                f3 = this.f4773h0;
                this.f4745N = 1.0f;
                typeface = this.f4799w;
            } else {
                float f5 = this.f4780l;
                float f6 = this.f4775i0;
                Typeface typeface2 = this.f4802z;
                if (C(f2, 0.0f)) {
                    this.f4745N = 1.0f;
                } else {
                    this.f4745N = G(this.f4780l, this.f4782m, f2, this.f4756Y) / this.f4780l;
                }
                float f7 = this.f4782m / this.f4780l;
                width = (z2 || this.f4762c || width2 * f7 <= width) ? width2 : Math.min(width / f7, width2);
                f4 = f5;
                f3 = f6;
                typeface = typeface2;
            }
            int i2 = 1;
            boolean z3 = false;
            if (width > 0.0f) {
                boolean z4 = this.f4746O != f4;
                boolean z5 = this.f4777j0 != f3;
                boolean z6 = this.f4734C != typeface;
                StaticLayout staticLayout = this.f4779k0;
                boolean z7 = z4 || z5 || (staticLayout != null && (width > ((float) staticLayout.getWidth()) ? 1 : (width == ((float) staticLayout.getWidth()) ? 0 : -1)) != 0) || z6 || this.f4752U;
                this.f4746O = f4;
                this.f4777j0 = f3;
                this.f4734C = typeface;
                this.f4752U = false;
                TextPaint textPaint = this.f4753V;
                if (this.f4745N != 1.0f) {
                    z3 = true;
                }
                textPaint.setLinearText(z3);
                z3 = z7;
            }
            if (this.f4739H == null || z3) {
                this.f4753V.setTextSize(this.f4746O);
                this.f4753V.setTypeface(this.f4734C);
                this.f4753V.setLetterSpacing(this.f4777j0);
                this.f4740I = f(this.f4738G);
                if (j0()) {
                    i2 = this.f4789p0;
                }
                StaticLayout k2 = k(i2, width, this.f4740I);
                this.f4779k0 = k2;
                this.f4739H = k2.getText();
            }
        }
    }

    private void j() {
        Bitmap bitmap = this.f4743L;
        if (bitmap != null) {
            bitmap.recycle();
            this.f4743L = null;
        }
    }

    private boolean j0() {
        return this.f4789p0 > 1 && (!this.f4740I || this.f4762c) && !this.f4742K;
    }

    private StaticLayout k(int i2, float f2, boolean z2) {
        Layout.Alignment alignment;
        StaticLayout staticLayout = null;
        if (i2 == 1) {
            try {
                alignment = Layout.Alignment.ALIGN_NORMAL;
            } catch (u.a e2) {
                Log.e("CollapsingTextHelper", e2.getCause().getMessage(), e2);
            }
        } else {
            alignment = y();
        }
        staticLayout = u.c(this.f4738G, this.f4753V, (int) f2).e(this.f4737F).h(z2).d(alignment).g(false).j(i2).i(this.f4791q0, this.f4793r0).f(this.f4795s0).k((v) null).a();
        return (StaticLayout) h.g(staticLayout);
    }

    private void m(Canvas canvas, float f2, float f3) {
        int alpha = this.f4753V.getAlpha();
        canvas.translate(f2, f3);
        if (!this.f4762c) {
            this.f4753V.setAlpha((int) (this.f4785n0 * ((float) alpha)));
            if (Build.VERSION.SDK_INT >= 31) {
                TextPaint textPaint = this.f4753V;
                textPaint.setShadowLayer(this.f4747P, this.f4748Q, this.f4749R, C0087a.a(this.f4750S, textPaint.getAlpha()));
            }
            Canvas canvas2 = canvas;
            this.f4779k0.draw(canvas);
        } else {
            Canvas canvas3 = canvas;
        }
        if (!this.f4762c) {
            this.f4753V.setAlpha((int) (this.f4783m0 * ((float) alpha)));
        }
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 31) {
            TextPaint textPaint2 = this.f4753V;
            textPaint2.setShadowLayer(this.f4747P, this.f4748Q, this.f4749R, C0087a.a(this.f4750S, textPaint2.getAlpha()));
        }
        int lineBaseline = this.f4779k0.getLineBaseline(0);
        CharSequence charSequence = this.f4787o0;
        float f4 = (float) lineBaseline;
        canvas.drawText(charSequence, 0, charSequence.length(), 0.0f, f4, this.f4753V);
        if (i2 >= 31) {
            this.f4753V.setShadowLayer(this.f4747P, this.f4748Q, this.f4749R, this.f4750S);
        }
        if (!this.f4762c) {
            String trim = this.f4787o0.toString().trim();
            if (trim.endsWith("…")) {
                trim = trim.substring(0, trim.length() - 1);
            }
            String str = trim;
            this.f4753V.setAlpha(alpha);
            canvas.drawText(str, 0, Math.min(this.f4779k0.getLineEnd(0), str.length()), 0.0f, f4, this.f4753V);
        }
    }

    private void n() {
        if (this.f4743L == null && !this.f4770g.isEmpty() && !TextUtils.isEmpty(this.f4739H)) {
            g(0.0f);
            int width = this.f4779k0.getWidth();
            int height = this.f4779k0.getHeight();
            if (width > 0 && height > 0) {
                this.f4743L = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                this.f4779k0.draw(new Canvas(this.f4743L));
                if (this.f4744M == null) {
                    this.f4744M = new Paint(3);
                }
            }
        }
    }

    private float r(int i2, int i3) {
        if (i3 == 17 || (i3 & 7) == 1) {
            return (((float) i2) / 2.0f) - (this.f4781l0 / 2.0f);
        }
        return ((i3 & 8388613) == 8388613 || (i3 & 5) == 5) ? this.f4740I ? (float) this.f4772h.left : ((float) this.f4772h.right) - this.f4781l0 : this.f4740I ? ((float) this.f4772h.right) - this.f4781l0 : (float) this.f4772h.left;
    }

    private float s(RectF rectF, int i2, int i3) {
        if (i3 == 17 || (i3 & 7) == 1) {
            return (((float) i2) / 2.0f) + (this.f4781l0 / 2.0f);
        }
        return ((i3 & 8388613) == 8388613 || (i3 & 5) == 5) ? this.f4740I ? rectF.left + this.f4781l0 : (float) this.f4772h.right : this.f4740I ? (float) this.f4772h.right : rectF.left + this.f4781l0;
    }

    private int u(ColorStateList colorStateList) {
        if (colorStateList == null) {
            return 0;
        }
        int[] iArr = this.f4751T;
        return iArr != null ? colorStateList.getColorForState(iArr, 0) : colorStateList.getDefaultColor();
    }

    private int v() {
        return u(this.f4784n);
    }

    private Layout.Alignment y() {
        int b2 = C0156s.b(this.f4776j, this.f4740I ? 1 : 0) & 7;
        if (b2 != 1) {
            return b2 != 5 ? this.f4740I ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL : this.f4740I ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_OPPOSITE;
        }
        return Layout.Alignment.ALIGN_CENTER;
    }

    private void z(TextPaint textPaint) {
        textPaint.setTextSize(this.f4782m);
        textPaint.setTypeface(this.f4799w);
        textPaint.setLetterSpacing(this.f4773h0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x000a, code lost:
        r0 = r1.f4784n;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean E() {
        /*
            r1 = this;
            android.content.res.ColorStateList r0 = r1.f4786o
            if (r0 == 0) goto L_0x000a
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x0014
        L_0x000a:
            android.content.res.ColorStateList r0 = r1.f4784n
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0016
        L_0x0014:
            r0 = 1
            goto L_0x0017
        L_0x0016:
            r0 = 0
        L_0x0017:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.internal.C0214a.E():boolean");
    }

    public void H(Configuration configuration) {
        if (Build.VERSION.SDK_INT >= 31) {
            Typeface typeface = this.f4801y;
            if (typeface != null) {
                this.f4800x = j.b(configuration, typeface);
            }
            Typeface typeface2 = this.f4733B;
            if (typeface2 != null) {
                this.f4732A = j.b(configuration, typeface2);
            }
            Typeface typeface3 = this.f4800x;
            if (typeface3 == null) {
                typeface3 = this.f4801y;
            }
            this.f4799w = typeface3;
            Typeface typeface4 = this.f4732A;
            if (typeface4 == null) {
                typeface4 = this.f4733B;
            }
            this.f4802z = typeface4;
            K(true);
        }
    }

    public void J() {
        K(false);
    }

    public void K(boolean z2) {
        if ((this.f4758a.getHeight() > 0 && this.f4758a.getWidth() > 0) || z2) {
            b(z2);
            c();
        }
    }

    public void M(ColorStateList colorStateList) {
        if (this.f4786o != colorStateList || this.f4784n != colorStateList) {
            this.f4786o = colorStateList;
            this.f4784n = colorStateList;
            J();
        }
    }

    public void N(int i2, int i3, int i4, int i5) {
        if (!L(this.f4772h, i2, i3, i4, i5)) {
            this.f4772h.set(i2, i3, i4, i5);
            this.f4752U = true;
        }
    }

    public void O(Rect rect) {
        N(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void P(int i2) {
        d dVar = new d(this.f4758a.getContext(), i2);
        if (dVar.i() != null) {
            this.f4786o = dVar.i();
        }
        if (dVar.j() != 0.0f) {
            this.f4782m = dVar.j();
        }
        ColorStateList colorStateList = dVar.f5501c;
        if (colorStateList != null) {
            this.f4763c0 = colorStateList;
        }
        this.f4759a0 = dVar.f5506h;
        this.f4761b0 = dVar.f5507i;
        this.f4757Z = dVar.f5508j;
        this.f4773h0 = dVar.f5510l;
        a aVar = this.f4736E;
        if (aVar != null) {
            aVar.c();
        }
        this.f4736E = new a(new C0068a(), dVar.e());
        dVar.h(this.f4758a.getContext(), this.f4736E);
        J();
    }

    public void R(ColorStateList colorStateList) {
        if (this.f4786o != colorStateList) {
            this.f4786o = colorStateList;
            J();
        }
    }

    public void S(int i2) {
        if (this.f4778k != i2) {
            this.f4778k = i2;
            J();
        }
    }

    public void T(Typeface typeface) {
        if (U(typeface)) {
            J();
        }
    }

    public void V(int i2, int i3, int i4, int i5) {
        if (!L(this.f4770g, i2, i3, i4, i5)) {
            this.f4770g.set(i2, i3, i4, i5);
            this.f4752U = true;
        }
    }

    public void W(Rect rect) {
        V(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void X(float f2) {
        if (this.f4775i0 != f2) {
            this.f4775i0 = f2;
            J();
        }
    }

    public void Z(int i2) {
        if (this.f4776j != i2) {
            this.f4776j = i2;
            J();
        }
    }

    public void a0(float f2) {
        if (this.f4780l != f2) {
            this.f4780l = f2;
            J();
        }
    }

    public void c0(float f2) {
        float a2 = C0288a.a(f2, 0.0f, 1.0f);
        if (a2 != this.f4760b) {
            this.f4760b = a2;
            c();
        }
    }

    public void e0(TimeInterpolator timeInterpolator) {
        this.f4755X = timeInterpolator;
        J();
    }

    public final boolean f0(int[] iArr) {
        this.f4751T = iArr;
        if (!E()) {
            return false;
        }
        J();
        return true;
    }

    public void g0(CharSequence charSequence) {
        if (charSequence == null || !TextUtils.equals(this.f4738G, charSequence)) {
            this.f4738G = charSequence;
            this.f4739H = null;
            j();
            J();
        }
    }

    public void h0(TimeInterpolator timeInterpolator) {
        this.f4756Y = timeInterpolator;
        J();
    }

    public void i0(Typeface typeface) {
        boolean U2 = U(typeface);
        boolean b02 = b0(typeface);
        if (U2 || b02) {
            J();
        }
    }

    public void l(Canvas canvas) {
        int save = canvas.save();
        if (this.f4739H != null && this.f4774i.width() > 0.0f && this.f4774i.height() > 0.0f) {
            this.f4753V.setTextSize(this.f4746O);
            float f2 = this.f4797u;
            float f3 = this.f4798v;
            boolean z2 = this.f4742K && this.f4743L != null;
            float f4 = this.f4745N;
            if (f4 != 1.0f && !this.f4762c) {
                canvas.scale(f4, f4, f2, f3);
            }
            if (z2) {
                canvas.drawBitmap(this.f4743L, f2, f3, this.f4744M);
                canvas.restoreToCount(save);
                return;
            }
            if (!j0() || (this.f4762c && this.f4760b <= this.f4766e)) {
                canvas.translate(f2, f3);
                this.f4779k0.draw(canvas);
            } else {
                m(canvas, this.f4797u - ((float) this.f4779k0.getLineStart(0)), f3);
            }
            canvas.restoreToCount(save);
        }
    }

    public void o(RectF rectF, int i2, int i3) {
        this.f4740I = f(this.f4738G);
        rectF.left = Math.max(r(i2, i3), (float) this.f4772h.left);
        rectF.top = (float) this.f4772h.top;
        rectF.right = Math.min(s(rectF, i2, i3), (float) this.f4772h.right);
        rectF.bottom = ((float) this.f4772h.top) + q();
    }

    public ColorStateList p() {
        return this.f4786o;
    }

    public float q() {
        z(this.f4754W);
        return -this.f4754W.ascent();
    }

    public int t() {
        return u(this.f4786o);
    }

    public float w() {
        A(this.f4754W);
        return -this.f4754W.ascent();
    }

    public float x() {
        return this.f4760b;
    }
}
