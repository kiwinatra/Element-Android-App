package com.google.android.material.internal;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import androidx.appcompat.widget.C0111p;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import e.C0233a;
import y.I;

public class CheckableImageButton extends C0111p implements Checkable {

    /* renamed from: g  reason: collision with root package name */
    private static final int[] f4708g = {16842912};

    /* renamed from: d  reason: collision with root package name */
    private boolean f4709d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f4710e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4711f;

    class a extends C0121a {
        a() {
        }

        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            accessibilityEvent.setChecked(CheckableImageButton.this.isChecked());
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.k0(CheckableImageButton.this.a());
            i2.l0(CheckableImageButton.this.isChecked());
        }
    }

    static class b extends C.a {
        public static final Parcelable.Creator<b> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        boolean f4713c;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public b createFromParcel(Parcel parcel) {
                return new b(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public b createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new b(parcel, classLoader);
            }

            /* renamed from: c */
            public b[] newArray(int i2) {
                return new b[i2];
            }
        }

        public b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            d(parcel);
        }

        private void d(Parcel parcel) {
            boolean z2 = true;
            if (parcel.readInt() != 1) {
                z2 = false;
            }
            this.f4713c = z2;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f4713c ? 1 : 0);
        }

        public b(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.imageButtonStyle);
    }

    public boolean a() {
        return this.f4710e;
    }

    public boolean isChecked() {
        return this.f4709d;
    }

    public int[] onCreateDrawableState(int i2) {
        if (!this.f4709d) {
            return super.onCreateDrawableState(i2);
        }
        int[] iArr = f4708g;
        return View.mergeDrawableStates(super.onCreateDrawableState(i2 + iArr.length), iArr);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        b bVar = (b) parcelable;
        super.onRestoreInstanceState(bVar.c());
        setChecked(bVar.f4713c);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        b bVar = new b(super.onSaveInstanceState());
        bVar.f4713c = this.f4709d;
        return bVar;
    }

    public void setCheckable(boolean z2) {
        if (this.f4710e != z2) {
            this.f4710e = z2;
            sendAccessibilityEvent(0);
        }
    }

    public void setChecked(boolean z2) {
        if (this.f4710e && this.f4709d != z2) {
            this.f4709d = z2;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public void setPressable(boolean z2) {
        this.f4711f = z2;
    }

    public void setPressed(boolean z2) {
        if (this.f4711f) {
            super.setPressed(z2);
        }
    }

    public void toggle() {
        setChecked(!this.f4709d);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f4710e = true;
        this.f4711f = true;
        W.q0(this, new a());
    }
}
