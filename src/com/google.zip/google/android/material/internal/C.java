package com.google.android.material.internal;

import android.widget.ImageButton;

public abstract class C extends ImageButton {
}
