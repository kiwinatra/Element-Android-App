package com.google.android.material.internal;

import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import java.lang.reflect.Constructor;
import x.h;

final class u {

    /* renamed from: n  reason: collision with root package name */
    static final int f4863n = (Build.VERSION.SDK_INT >= 23 ? 1 : 0);

    /* renamed from: o  reason: collision with root package name */
    private static boolean f4864o;

    /* renamed from: p  reason: collision with root package name */
    private static Constructor f4865p;

    /* renamed from: q  reason: collision with root package name */
    private static Object f4866q;

    /* renamed from: a  reason: collision with root package name */
    private CharSequence f4867a;

    /* renamed from: b  reason: collision with root package name */
    private final TextPaint f4868b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4869c;

    /* renamed from: d  reason: collision with root package name */
    private int f4870d = 0;

    /* renamed from: e  reason: collision with root package name */
    private int f4871e;

    /* renamed from: f  reason: collision with root package name */
    private Layout.Alignment f4872f;

    /* renamed from: g  reason: collision with root package name */
    private int f4873g;

    /* renamed from: h  reason: collision with root package name */
    private float f4874h;

    /* renamed from: i  reason: collision with root package name */
    private float f4875i;

    /* renamed from: j  reason: collision with root package name */
    private int f4876j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f4877k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f4878l;

    /* renamed from: m  reason: collision with root package name */
    private TextUtils.TruncateAt f4879m;

    static class a extends Exception {
        a(Throwable th) {
            super("Error thrown initializing StaticLayout " + th.getMessage(), th);
        }
    }

    private u(CharSequence charSequence, TextPaint textPaint, int i2) {
        this.f4867a = charSequence;
        this.f4868b = textPaint;
        this.f4869c = i2;
        this.f4871e = charSequence.length();
        this.f4872f = Layout.Alignment.ALIGN_NORMAL;
        this.f4873g = Integer.MAX_VALUE;
        this.f4874h = 0.0f;
        this.f4875i = 1.0f;
        this.f4876j = f4863n;
        this.f4877k = true;
        this.f4879m = null;
    }

    private void b() {
        if (!f4864o) {
            try {
                f4866q = this.f4878l && Build.VERSION.SDK_INT >= 23 ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR;
                Class cls = Integer.TYPE;
                Class cls2 = Float.TYPE;
                Constructor<StaticLayout> declaredConstructor = StaticLayout.class.getDeclaredConstructor(new Class[]{CharSequence.class, cls, cls, TextPaint.class, cls, Layout.Alignment.class, TextDirectionHeuristic.class, cls2, cls2, Boolean.TYPE, TextUtils.TruncateAt.class, cls, cls});
                f4865p = declaredConstructor;
                declaredConstructor.setAccessible(true);
                f4864o = true;
            } catch (Exception e2) {
                throw new a(e2);
            }
        }
    }

    public static u c(CharSequence charSequence, TextPaint textPaint, int i2) {
        return new u(charSequence, textPaint, i2);
    }

    public StaticLayout a() {
        if (this.f4867a == null) {
            this.f4867a = "";
        }
        int max = Math.max(0, this.f4869c);
        CharSequence charSequence = this.f4867a;
        if (this.f4873g == 1) {
            charSequence = TextUtils.ellipsize(charSequence, this.f4868b, (float) max, this.f4879m);
        }
        int min = Math.min(charSequence.length(), this.f4871e);
        this.f4871e = min;
        if (Build.VERSION.SDK_INT >= 23) {
            if (this.f4878l && this.f4873g == 1) {
                this.f4872f = Layout.Alignment.ALIGN_OPPOSITE;
            }
            StaticLayout.Builder a2 = StaticLayout.Builder.obtain(charSequence, this.f4870d, min, this.f4868b, max);
            StaticLayout.Builder unused = a2.setAlignment(this.f4872f);
            StaticLayout.Builder unused2 = a2.setIncludePad(this.f4877k);
            StaticLayout.Builder unused3 = a2.setTextDirection(this.f4878l ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR);
            TextUtils.TruncateAt truncateAt = this.f4879m;
            if (truncateAt != null) {
                StaticLayout.Builder unused4 = a2.setEllipsize(truncateAt);
            }
            StaticLayout.Builder unused5 = a2.setMaxLines(this.f4873g);
            float f2 = this.f4874h;
            if (!(f2 == 0.0f && this.f4875i == 1.0f)) {
                StaticLayout.Builder unused6 = a2.setLineSpacing(f2, this.f4875i);
            }
            if (this.f4873g > 1) {
                StaticLayout.Builder unused7 = a2.setHyphenationFrequency(this.f4876j);
            }
            return a2.build();
        }
        b();
        try {
            return (StaticLayout) ((Constructor) h.g(f4865p)).newInstance(new Object[]{charSequence, Integer.valueOf(this.f4870d), Integer.valueOf(this.f4871e), this.f4868b, Integer.valueOf(max), this.f4872f, h.g(f4866q), Float.valueOf(1.0f), Float.valueOf(0.0f), Boolean.valueOf(this.f4877k), null, Integer.valueOf(max), Integer.valueOf(this.f4873g)});
        } catch (Exception e2) {
            throw new a(e2);
        }
    }

    public u d(Layout.Alignment alignment) {
        this.f4872f = alignment;
        return this;
    }

    public u e(TextUtils.TruncateAt truncateAt) {
        this.f4879m = truncateAt;
        return this;
    }

    public u f(int i2) {
        this.f4876j = i2;
        return this;
    }

    public u g(boolean z2) {
        this.f4877k = z2;
        return this;
    }

    public u h(boolean z2) {
        this.f4878l = z2;
        return this;
    }

    public u i(float f2, float f3) {
        this.f4874h = f2;
        this.f4875i = f3;
        return this;
    }

    public u j(int i2) {
        this.f4873g = i2;
        return this;
    }

    public u k(v vVar) {
        return this;
    }
}
