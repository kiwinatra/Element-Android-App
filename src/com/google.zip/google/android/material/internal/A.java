package com.google.android.material.internal;

import android.view.View;

public final /* synthetic */ class A implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ View f4699a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ boolean f4700b;

    public /* synthetic */ A(View view, boolean z2) {
        this.f4699a = view;
        this.f4700b = z2;
    }

    public final void run() {
        B.l(this.f4699a, this.f4700b);
    }
}
