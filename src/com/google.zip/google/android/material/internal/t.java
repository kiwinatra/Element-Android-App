package com.google.android.material.internal;

public abstract /* synthetic */ class t {
}
