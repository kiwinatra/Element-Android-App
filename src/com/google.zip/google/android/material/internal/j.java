package com.google.android.material.internal;

import android.content.Context;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;

public class j extends m {
    public j(Context context, h hVar, g gVar) {
        super(context, hVar, gVar);
    }

    public void N(boolean z2) {
        super.N(z2);
        ((e) j0()).N(z2);
    }
}
