package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import androidx.core.view.C0165w0;
import androidx.core.view.F;
import androidx.core.view.V0;
import androidx.core.view.W;
import com.google.android.material.drawable.f;

public abstract class B {

    class a implements F {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ c f4701a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ d f4702b;

        a(c cVar, d dVar) {
            this.f4701a = cVar;
            this.f4702b = dVar;
        }

        public C0165w0 a(View view, C0165w0 w0Var) {
            return this.f4701a.a(view, w0Var, new d(this.f4702b));
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        public void onViewAttachedToWindow(View view) {
            view.removeOnAttachStateChangeListener(this);
            W.n0(view);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    public interface c {
        C0165w0 a(View view, C0165w0 w0Var, d dVar);
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public int f4703a;

        /* renamed from: b  reason: collision with root package name */
        public int f4704b;

        /* renamed from: c  reason: collision with root package name */
        public int f4705c;

        /* renamed from: d  reason: collision with root package name */
        public int f4706d;

        public d(int i2, int i3, int i4, int i5) {
            this.f4703a = i2;
            this.f4704b = i3;
            this.f4705c = i4;
            this.f4706d = i5;
        }

        public d(d dVar) {
            this.f4703a = dVar.f4703a;
            this.f4704b = dVar.f4704b;
            this.f4705c = dVar.f4705c;
            this.f4706d = dVar.f4706d;
        }
    }

    public static void b(View view, c cVar) {
        W.C0(view, new a(cVar, new d(W.H(view), view.getPaddingTop(), W.G(view), view.getPaddingBottom())));
        j(view);
    }

    public static float c(Context context, int i2) {
        return TypedValue.applyDimension(1, (float) i2, context.getResources().getDisplayMetrics());
    }

    public static Integer d(View view) {
        ColorStateList f2 = f.f(view.getBackground());
        if (f2 != null) {
            return Integer.valueOf(f2.getDefaultColor());
        }
        return null;
    }

    private static InputMethodManager e(View view) {
        return (InputMethodManager) androidx.core.content.a.d(view.getContext(), InputMethodManager.class);
    }

    public static float f(View view) {
        float f2 = 0.0f;
        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
            f2 += W.w((View) parent);
        }
        return f2;
    }

    public static boolean g(View view) {
        return W.C(view) == 1;
    }

    public static PorterDuff.Mode i(int i2, PorterDuff.Mode mode) {
        if (i2 == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i2 == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i2 == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        switch (i2) {
            case 14:
                return PorterDuff.Mode.MULTIPLY;
            case 15:
                return PorterDuff.Mode.SCREEN;
            case 16:
                return PorterDuff.Mode.ADD;
            default:
                return mode;
        }
    }

    public static void j(View view) {
        if (W.T(view)) {
            W.n0(view);
        } else {
            view.addOnAttachStateChangeListener(new b());
        }
    }

    public static void k(View view, boolean z2) {
        view.requestFocus();
        view.post(new A(view, z2));
    }

    public static void l(View view, boolean z2) {
        V0 M2;
        if (!z2 || (M2 = W.M(view)) == null) {
            e(view).showSoftInput(view, 1);
        } else {
            M2.e(C0165w0.m.a());
        }
    }
}
