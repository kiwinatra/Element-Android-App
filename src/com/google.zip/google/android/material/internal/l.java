package com.google.android.material.internal;

import T.i;
import T.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import androidx.core.view.C0165w0;
import androidx.core.view.F;
import androidx.core.view.W;

public abstract class l extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    Drawable f4855a;

    /* renamed from: b  reason: collision with root package name */
    Rect f4856b;

    /* renamed from: c  reason: collision with root package name */
    private Rect f4857c = new Rect();

    /* renamed from: d  reason: collision with root package name */
    private boolean f4858d = true;

    /* renamed from: e  reason: collision with root package name */
    private boolean f4859e = true;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4860f = true;

    /* renamed from: g  reason: collision with root package name */
    private boolean f4861g = true;

    class a implements F {
        a() {
        }

        public C0165w0 a(View view, C0165w0 w0Var) {
            l lVar = l.this;
            if (lVar.f4856b == null) {
                lVar.f4856b = new Rect();
            }
            l.this.f4856b.set(w0Var.j(), w0Var.l(), w0Var.k(), w0Var.i());
            l.this.e(w0Var);
            l.this.setWillNotDraw(!w0Var.m() || l.this.f4855a == null);
            W.h0(l.this);
            return w0Var.c();
        }
    }

    public l(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        TypedArray i3 = y.i(context, attributeSet, j.L4, i2, i.Widget_Design_ScrimInsetsFrameLayout, new int[0]);
        this.f4855a = i3.getDrawable(j.M4);
        i3.recycle();
        setWillNotDraw(true);
        W.C0(this, new a());
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f4856b != null && this.f4855a != null) {
            int save = canvas.save();
            canvas.translate((float) getScrollX(), (float) getScrollY());
            if (this.f4858d) {
                this.f4857c.set(0, 0, width, this.f4856b.top);
                this.f4855a.setBounds(this.f4857c);
                this.f4855a.draw(canvas);
            }
            if (this.f4859e) {
                this.f4857c.set(0, height - this.f4856b.bottom, width, height);
                this.f4855a.setBounds(this.f4857c);
                this.f4855a.draw(canvas);
            }
            if (this.f4860f) {
                Rect rect = this.f4857c;
                Rect rect2 = this.f4856b;
                rect.set(0, rect2.top, rect2.left, height - rect2.bottom);
                this.f4855a.setBounds(this.f4857c);
                this.f4855a.draw(canvas);
            }
            if (this.f4861g) {
                Rect rect3 = this.f4857c;
                Rect rect4 = this.f4856b;
                rect3.set(width - rect4.right, rect4.top, width, height - rect4.bottom);
                this.f4855a.setBounds(this.f4857c);
                this.f4855a.draw(canvas);
            }
            canvas.restoreToCount(save);
        }
    }

    /* access modifiers changed from: protected */
    public abstract void e(C0165w0 w0Var);

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable drawable = this.f4855a;
        if (drawable != null) {
            drawable.setCallback(this);
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Drawable drawable = this.f4855a;
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
    }

    public void setDrawBottomInsetForeground(boolean z2) {
        this.f4859e = z2;
    }

    public void setDrawLeftInsetForeground(boolean z2) {
        this.f4860f = z2;
    }

    public void setDrawRightInsetForeground(boolean z2) {
        this.f4861g = z2;
    }

    public void setDrawTopInsetForeground(boolean z2) {
        this.f4858d = z2;
    }

    public void setScrimInsetForeground(Drawable drawable) {
        this.f4855a = drawable;
    }
}
