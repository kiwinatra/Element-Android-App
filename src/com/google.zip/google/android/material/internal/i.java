package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.m;
import androidx.core.view.C0121a;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import y.I;

public class i implements androidx.appcompat.view.menu.j {

    /* renamed from: A  reason: collision with root package name */
    private int f4812A;

    /* renamed from: B  reason: collision with root package name */
    int f4813B;

    /* renamed from: C  reason: collision with root package name */
    private int f4814C = -1;

    /* renamed from: D  reason: collision with root package name */
    final View.OnClickListener f4815D = new a();

    /* renamed from: a  reason: collision with root package name */
    private NavigationMenuView f4816a;

    /* renamed from: b  reason: collision with root package name */
    LinearLayout f4817b;

    /* renamed from: c  reason: collision with root package name */
    private j.a f4818c;

    /* renamed from: d  reason: collision with root package name */
    androidx.appcompat.view.menu.e f4819d;

    /* renamed from: e  reason: collision with root package name */
    private int f4820e;

    /* renamed from: f  reason: collision with root package name */
    c f4821f;

    /* renamed from: g  reason: collision with root package name */
    LayoutInflater f4822g;

    /* renamed from: h  reason: collision with root package name */
    int f4823h = 0;

    /* renamed from: i  reason: collision with root package name */
    ColorStateList f4824i;

    /* renamed from: j  reason: collision with root package name */
    int f4825j = 0;

    /* renamed from: k  reason: collision with root package name */
    boolean f4826k = true;

    /* renamed from: l  reason: collision with root package name */
    ColorStateList f4827l;

    /* renamed from: m  reason: collision with root package name */
    ColorStateList f4828m;

    /* renamed from: n  reason: collision with root package name */
    Drawable f4829n;

    /* renamed from: o  reason: collision with root package name */
    RippleDrawable f4830o;

    /* renamed from: p  reason: collision with root package name */
    int f4831p;

    /* renamed from: q  reason: collision with root package name */
    int f4832q;

    /* renamed from: r  reason: collision with root package name */
    int f4833r;

    /* renamed from: s  reason: collision with root package name */
    int f4834s;

    /* renamed from: t  reason: collision with root package name */
    int f4835t;

    /* renamed from: u  reason: collision with root package name */
    int f4836u;

    /* renamed from: v  reason: collision with root package name */
    int f4837v;

    /* renamed from: w  reason: collision with root package name */
    int f4838w;

    /* renamed from: x  reason: collision with root package name */
    boolean f4839x;

    /* renamed from: y  reason: collision with root package name */
    boolean f4840y = true;
    /* access modifiers changed from: private */

    /* renamed from: z  reason: collision with root package name */
    public int f4841z;

    class a implements View.OnClickListener {
        a() {
        }

        public void onClick(View view) {
            boolean z2 = true;
            i.this.Z(true);
            androidx.appcompat.view.menu.g itemData = ((NavigationMenuItemView) view).getItemData();
            i iVar = i.this;
            boolean P2 = iVar.f4819d.P(itemData, iVar, 0);
            if (itemData == null || !itemData.isCheckable() || !P2) {
                z2 = false;
            } else {
                i.this.f4821f.G(itemData);
            }
            i.this.Z(false);
            if (z2) {
                i.this.n(false);
            }
        }
    }

    private static class b extends l {
        public b(View view) {
            super(view);
        }
    }

    private class c extends RecyclerView.g {

        /* renamed from: c  reason: collision with root package name */
        private final ArrayList f4843c = new ArrayList();

        /* renamed from: d  reason: collision with root package name */
        private androidx.appcompat.view.menu.g f4844d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f4845e;

        class a extends C0121a {

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ int f4847d;

            /* renamed from: e  reason: collision with root package name */
            final /* synthetic */ boolean f4848e;

            a(int i2, boolean z2) {
                this.f4847d = i2;
                this.f4848e = z2;
            }

            public void g(View view, I i2) {
                super.g(view, i2);
                i2.p0(I.f.a(c.this.v(this.f4847d), 1, 1, 1, this.f4848e, view.isSelected()));
            }
        }

        c() {
            D();
        }

        private void D() {
            if (!this.f4845e) {
                this.f4845e = true;
                this.f4843c.clear();
                this.f4843c.add(new d());
                int size = i.this.f4819d.G().size();
                int i2 = -1;
                boolean z2 = false;
                int i3 = 0;
                for (int i4 = 0; i4 < size; i4++) {
                    androidx.appcompat.view.menu.g gVar = (androidx.appcompat.view.menu.g) i.this.f4819d.G().get(i4);
                    if (gVar.isChecked()) {
                        G(gVar);
                    }
                    if (gVar.isCheckable()) {
                        gVar.t(false);
                    }
                    if (gVar.hasSubMenu()) {
                        SubMenu subMenu = gVar.getSubMenu();
                        if (subMenu.hasVisibleItems()) {
                            if (i4 != 0) {
                                this.f4843c.add(new f(i.this.f4813B, 0));
                            }
                            this.f4843c.add(new g(gVar));
                            int size2 = this.f4843c.size();
                            int size3 = subMenu.size();
                            boolean z3 = false;
                            for (int i5 = 0; i5 < size3; i5++) {
                                androidx.appcompat.view.menu.g gVar2 = (androidx.appcompat.view.menu.g) subMenu.getItem(i5);
                                if (gVar2.isVisible()) {
                                    if (!z3 && gVar2.getIcon() != null) {
                                        z3 = true;
                                    }
                                    if (gVar2.isCheckable()) {
                                        gVar2.t(false);
                                    }
                                    if (gVar.isChecked()) {
                                        G(gVar);
                                    }
                                    this.f4843c.add(new g(gVar2));
                                }
                            }
                            if (z3) {
                                w(size2, this.f4843c.size());
                            }
                        }
                    } else {
                        int groupId = gVar.getGroupId();
                        if (groupId != i2) {
                            i3 = this.f4843c.size();
                            z2 = gVar.getIcon() != null;
                            if (i4 != 0) {
                                i3++;
                                ArrayList arrayList = this.f4843c;
                                int i6 = i.this.f4813B;
                                arrayList.add(new f(i6, i6));
                            }
                        } else if (!z2 && gVar.getIcon() != null) {
                            w(i3, this.f4843c.size());
                            z2 = true;
                        }
                        g gVar3 = new g(gVar);
                        gVar3.f4853b = z2;
                        this.f4843c.add(gVar3);
                        i2 = groupId;
                    }
                }
                this.f4845e = false;
            }
        }

        private void F(View view, int i2, boolean z2) {
            W.q0(view, new a(i2, z2));
        }

        /* access modifiers changed from: private */
        public int v(int i2) {
            int i3 = i2;
            for (int i4 = 0; i4 < i2; i4++) {
                if (i.this.f4821f.e(i4) == 2 || i.this.f4821f.e(i4) == 3) {
                    i3--;
                }
            }
            return i3;
        }

        private void w(int i2, int i3) {
            while (i2 < i3) {
                ((g) this.f4843c.get(i2)).f4853b = true;
                i2++;
            }
        }

        /* renamed from: A */
        public void j(l lVar, int i2) {
            int e2 = e(i2);
            if (e2 == 0) {
                NavigationMenuItemView navigationMenuItemView = (NavigationMenuItemView) lVar.f3417a;
                navigationMenuItemView.setIconTintList(i.this.f4828m);
                navigationMenuItemView.setTextAppearance(i.this.f4825j);
                ColorStateList colorStateList = i.this.f4827l;
                if (colorStateList != null) {
                    navigationMenuItemView.setTextColor(colorStateList);
                }
                Drawable drawable = i.this.f4829n;
                W.u0(navigationMenuItemView, drawable != null ? drawable.getConstantState().newDrawable() : null);
                RippleDrawable rippleDrawable = i.this.f4830o;
                if (rippleDrawable != null) {
                    navigationMenuItemView.setForeground(rippleDrawable.getConstantState().newDrawable());
                }
                g gVar = (g) this.f4843c.get(i2);
                navigationMenuItemView.setNeedsEmptyIcon(gVar.f4853b);
                i iVar = i.this;
                int i3 = iVar.f4831p;
                int i4 = iVar.f4832q;
                navigationMenuItemView.setPadding(i3, i4, i3, i4);
                navigationMenuItemView.setIconPadding(i.this.f4833r);
                i iVar2 = i.this;
                if (iVar2.f4839x) {
                    navigationMenuItemView.setIconSize(iVar2.f4834s);
                }
                navigationMenuItemView.setMaxLines(i.this.f4841z);
                navigationMenuItemView.D(gVar.a(), i.this.f4826k);
                F(navigationMenuItemView, i2, false);
            } else if (e2 == 1) {
                TextView textView = (TextView) lVar.f3417a;
                textView.setText(((g) this.f4843c.get(i2)).a().getTitle());
                androidx.core.widget.j.o(textView, i.this.f4823h);
                textView.setPadding(i.this.f4837v, textView.getPaddingTop(), i.this.f4838w, textView.getPaddingBottom());
                ColorStateList colorStateList2 = i.this.f4824i;
                if (colorStateList2 != null) {
                    textView.setTextColor(colorStateList2);
                }
                F(textView, i2, true);
            } else if (e2 == 2) {
                f fVar = (f) this.f4843c.get(i2);
                lVar.f3417a.setPadding(i.this.f4835t, fVar.b(), i.this.f4836u, fVar.a());
            }
        }

        /* renamed from: B */
        public l l(ViewGroup viewGroup, int i2) {
            if (i2 == 0) {
                i iVar = i.this;
                return new C0069i(iVar.f4822g, viewGroup, iVar.f4815D);
            } else if (i2 == 1) {
                return new k(i.this.f4822g, viewGroup);
            } else {
                if (i2 == 2) {
                    return new j(i.this.f4822g, viewGroup);
                }
                if (i2 != 3) {
                    return null;
                }
                return new b(i.this.f4817b);
            }
        }

        /* renamed from: C */
        public void q(l lVar) {
            if (lVar instanceof C0069i) {
                ((NavigationMenuItemView) lVar.f3417a).E();
            }
        }

        public void E(Bundle bundle) {
            androidx.appcompat.view.menu.g a2;
            View actionView;
            k kVar;
            androidx.appcompat.view.menu.g a3;
            int i2 = bundle.getInt("android:menu:checked", 0);
            if (i2 != 0) {
                this.f4845e = true;
                int size = this.f4843c.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        break;
                    }
                    e eVar = (e) this.f4843c.get(i3);
                    if ((eVar instanceof g) && (a3 = ((g) eVar).a()) != null && a3.getItemId() == i2) {
                        G(a3);
                        break;
                    }
                    i3++;
                }
                this.f4845e = false;
                D();
            }
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:action_views");
            if (sparseParcelableArray != null) {
                int size2 = this.f4843c.size();
                for (int i4 = 0; i4 < size2; i4++) {
                    e eVar2 = (e) this.f4843c.get(i4);
                    if (!(!(eVar2 instanceof g) || (a2 = ((g) eVar2).a()) == null || (actionView = a2.getActionView()) == null || (kVar = (k) sparseParcelableArray.get(a2.getItemId())) == null)) {
                        actionView.restoreHierarchyState(kVar);
                    }
                }
            }
        }

        public void G(androidx.appcompat.view.menu.g gVar) {
            if (this.f4844d != gVar && gVar.isCheckable()) {
                androidx.appcompat.view.menu.g gVar2 = this.f4844d;
                if (gVar2 != null) {
                    gVar2.setChecked(false);
                }
                this.f4844d = gVar;
                gVar.setChecked(true);
            }
        }

        public void H(boolean z2) {
            this.f4845e = z2;
        }

        public void I() {
            D();
            h();
        }

        public int c() {
            return this.f4843c.size();
        }

        public long d(int i2) {
            return (long) i2;
        }

        public int e(int i2) {
            e eVar = (e) this.f4843c.get(i2);
            if (eVar instanceof f) {
                return 2;
            }
            if (eVar instanceof d) {
                return 3;
            }
            if (eVar instanceof g) {
                return ((g) eVar).a().hasSubMenu() ? 1 : 0;
            }
            throw new RuntimeException("Unknown item type.");
        }

        public Bundle x() {
            Bundle bundle = new Bundle();
            androidx.appcompat.view.menu.g gVar = this.f4844d;
            if (gVar != null) {
                bundle.putInt("android:menu:checked", gVar.getItemId());
            }
            SparseArray sparseArray = new SparseArray();
            int size = this.f4843c.size();
            for (int i2 = 0; i2 < size; i2++) {
                e eVar = (e) this.f4843c.get(i2);
                if (eVar instanceof g) {
                    androidx.appcompat.view.menu.g a2 = ((g) eVar).a();
                    View actionView = a2 != null ? a2.getActionView() : null;
                    if (actionView != null) {
                        k kVar = new k();
                        actionView.saveHierarchyState(kVar);
                        sparseArray.put(a2.getItemId(), kVar);
                    }
                }
            }
            bundle.putSparseParcelableArray("android:menu:action_views", sparseArray);
            return bundle;
        }

        public androidx.appcompat.view.menu.g y() {
            return this.f4844d;
        }

        /* access modifiers changed from: package-private */
        public int z() {
            int i2 = 0;
            for (int i3 = 0; i3 < i.this.f4821f.c(); i3++) {
                int e2 = i.this.f4821f.e(i3);
                if (e2 == 0 || e2 == 1) {
                    i2++;
                }
            }
            return i2;
        }
    }

    private static class d implements e {
        d() {
        }
    }

    private interface e {
    }

    private static class f implements e {

        /* renamed from: a  reason: collision with root package name */
        private final int f4850a;

        /* renamed from: b  reason: collision with root package name */
        private final int f4851b;

        public f(int i2, int i3) {
            this.f4850a = i2;
            this.f4851b = i3;
        }

        public int a() {
            return this.f4851b;
        }

        public int b() {
            return this.f4850a;
        }
    }

    private static class g implements e {

        /* renamed from: a  reason: collision with root package name */
        private final androidx.appcompat.view.menu.g f4852a;

        /* renamed from: b  reason: collision with root package name */
        boolean f4853b;

        g(androidx.appcompat.view.menu.g gVar) {
            this.f4852a = gVar;
        }

        public androidx.appcompat.view.menu.g a() {
            return this.f4852a;
        }
    }

    private class h extends androidx.recyclerview.widget.l {
        h(RecyclerView recyclerView) {
            super(recyclerView);
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.o0(I.e.a(i.this.f4821f.z(), 1, false));
        }
    }

    /* renamed from: com.google.android.material.internal.i$i  reason: collision with other inner class name */
    private static class C0069i extends l {
        public C0069i(LayoutInflater layoutInflater, ViewGroup viewGroup, View.OnClickListener onClickListener) {
            super(layoutInflater.inflate(T.g.design_navigation_item, viewGroup, false));
            this.f3417a.setOnClickListener(onClickListener);
        }
    }

    private static class j extends l {
        public j(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(T.g.design_navigation_item_separator, viewGroup, false));
        }
    }

    private static class k extends l {
        public k(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(T.g.design_navigation_item_subheader, viewGroup, false));
        }
    }

    private static abstract class l extends RecyclerView.C {
        public l(View view) {
            super(view);
        }
    }

    private boolean C() {
        return r() > 0;
    }

    private void a0() {
        int i2 = (C() || !this.f4840y) ? 0 : this.f4812A;
        NavigationMenuView navigationMenuView = this.f4816a;
        navigationMenuView.setPadding(0, i2, 0, navigationMenuView.getPaddingBottom());
    }

    public int A() {
        return this.f4838w;
    }

    public int B() {
        return this.f4837v;
    }

    public View D(int i2) {
        View inflate = this.f4822g.inflate(i2, this.f4817b, false);
        f(inflate);
        return inflate;
    }

    public void E(boolean z2) {
        if (this.f4840y != z2) {
            this.f4840y = z2;
            a0();
        }
    }

    public void F(androidx.appcompat.view.menu.g gVar) {
        this.f4821f.G(gVar);
    }

    public void G(int i2) {
        this.f4836u = i2;
        n(false);
    }

    public void H(int i2) {
        this.f4835t = i2;
        n(false);
    }

    public void I(int i2) {
        this.f4820e = i2;
    }

    public void J(Drawable drawable) {
        this.f4829n = drawable;
        n(false);
    }

    public void K(RippleDrawable rippleDrawable) {
        this.f4830o = rippleDrawable;
        n(false);
    }

    public void L(int i2) {
        this.f4831p = i2;
        n(false);
    }

    public void M(int i2) {
        this.f4833r = i2;
        n(false);
    }

    public void N(int i2) {
        if (this.f4834s != i2) {
            this.f4834s = i2;
            this.f4839x = true;
            n(false);
        }
    }

    public void O(ColorStateList colorStateList) {
        this.f4828m = colorStateList;
        n(false);
    }

    public void P(int i2) {
        this.f4841z = i2;
        n(false);
    }

    public void Q(int i2) {
        this.f4825j = i2;
        n(false);
    }

    public void R(boolean z2) {
        this.f4826k = z2;
        n(false);
    }

    public void S(ColorStateList colorStateList) {
        this.f4827l = colorStateList;
        n(false);
    }

    public void T(int i2) {
        this.f4832q = i2;
        n(false);
    }

    public void U(int i2) {
        this.f4814C = i2;
        NavigationMenuView navigationMenuView = this.f4816a;
        if (navigationMenuView != null) {
            navigationMenuView.setOverScrollMode(i2);
        }
    }

    public void V(ColorStateList colorStateList) {
        this.f4824i = colorStateList;
        n(false);
    }

    public void W(int i2) {
        this.f4838w = i2;
        n(false);
    }

    public void X(int i2) {
        this.f4837v = i2;
        n(false);
    }

    public void Y(int i2) {
        this.f4823h = i2;
        n(false);
    }

    public void Z(boolean z2) {
        c cVar = this.f4821f;
        if (cVar != null) {
            cVar.H(z2);
        }
    }

    public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
        j.a aVar = this.f4818c;
        if (aVar != null) {
            aVar.a(eVar, z2);
        }
    }

    public int c() {
        return this.f4820e;
    }

    public boolean d() {
        return false;
    }

    public Parcelable e() {
        Bundle bundle = new Bundle();
        if (this.f4816a != null) {
            SparseArray sparseArray = new SparseArray();
            this.f4816a.saveHierarchyState(sparseArray);
            bundle.putSparseParcelableArray("android:menu:list", sparseArray);
        }
        c cVar = this.f4821f;
        if (cVar != null) {
            bundle.putBundle("android:menu:adapter", cVar.x());
        }
        if (this.f4817b != null) {
            SparseArray sparseArray2 = new SparseArray();
            this.f4817b.saveHierarchyState(sparseArray2);
            bundle.putSparseParcelableArray("android:menu:header", sparseArray2);
        }
        return bundle;
    }

    public void f(View view) {
        this.f4817b.addView(view);
        NavigationMenuView navigationMenuView = this.f4816a;
        navigationMenuView.setPadding(0, 0, 0, navigationMenuView.getPaddingBottom());
    }

    public void g(Context context, androidx.appcompat.view.menu.e eVar) {
        this.f4822g = LayoutInflater.from(context);
        this.f4819d = eVar;
        this.f4813B = context.getResources().getDimensionPixelOffset(T.c.design_navigation_separator_vertical_padding);
    }

    public void h(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:list");
            if (sparseParcelableArray != null) {
                this.f4816a.restoreHierarchyState(sparseParcelableArray);
            }
            Bundle bundle2 = bundle.getBundle("android:menu:adapter");
            if (bundle2 != null) {
                this.f4821f.E(bundle2);
            }
            SparseArray sparseParcelableArray2 = bundle.getSparseParcelableArray("android:menu:header");
            if (sparseParcelableArray2 != null) {
                this.f4817b.restoreHierarchyState(sparseParcelableArray2);
            }
        }
    }

    public boolean i(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
        return false;
    }

    public boolean j(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
        return false;
    }

    public void k(C0165w0 w0Var) {
        int l2 = w0Var.l();
        if (this.f4812A != l2) {
            this.f4812A = l2;
            a0();
        }
        NavigationMenuView navigationMenuView = this.f4816a;
        navigationMenuView.setPadding(0, navigationMenuView.getPaddingTop(), 0, w0Var.i());
        W.i(this.f4817b, w0Var);
    }

    public boolean m(m mVar) {
        return false;
    }

    public void n(boolean z2) {
        c cVar = this.f4821f;
        if (cVar != null) {
            cVar.I();
        }
    }

    public androidx.appcompat.view.menu.g o() {
        return this.f4821f.y();
    }

    public int p() {
        return this.f4836u;
    }

    public int q() {
        return this.f4835t;
    }

    public int r() {
        return this.f4817b.getChildCount();
    }

    public Drawable s() {
        return this.f4829n;
    }

    public int t() {
        return this.f4831p;
    }

    public int u() {
        return this.f4833r;
    }

    public int v() {
        return this.f4841z;
    }

    public ColorStateList w() {
        return this.f4827l;
    }

    public ColorStateList x() {
        return this.f4828m;
    }

    public int y() {
        return this.f4832q;
    }

    public androidx.appcompat.view.menu.k z(ViewGroup viewGroup) {
        if (this.f4816a == null) {
            NavigationMenuView navigationMenuView = (NavigationMenuView) this.f4822g.inflate(T.g.design_navigation_menu, viewGroup, false);
            this.f4816a = navigationMenuView;
            navigationMenuView.setAccessibilityDelegateCompat(new h(this.f4816a));
            if (this.f4821f == null) {
                c cVar = new c();
                this.f4821f = cVar;
                cVar.s(true);
            }
            int i2 = this.f4814C;
            if (i2 != -1) {
                this.f4816a.setOverScrollMode(i2);
            }
            LinearLayout linearLayout = (LinearLayout) this.f4822g.inflate(T.g.design_navigation_item_header, this.f4816a, false);
            this.f4817b = linearLayout;
            W.y0(linearLayout, 2);
            this.f4816a.setAdapter(this.f4821f);
        }
        return this.f4816a;
    }
}
