package com.google.android.material.internal;

import a0.C0087a;
import android.content.Context;
import android.os.Build;
import android.view.Window;
import androidx.core.graphics.a;
import androidx.core.view.C0138i0;

/* renamed from: com.google.android.material.internal.d  reason: case insensitive filesystem */
public abstract class C0217d {
    public static void a(Window window, boolean z2, Integer num, Integer num2) {
        boolean z3 = false;
        boolean z4 = num == null || num.intValue() == 0;
        if (num2 == null || num2.intValue() == 0) {
            z3 = true;
        }
        if (z4 || z3) {
            int b2 = C0087a.b(window.getContext(), 16842801, -16777216);
            if (z4) {
                num = Integer.valueOf(b2);
            }
            if (z3) {
                num2 = Integer.valueOf(b2);
            }
        }
        C0138i0.b(window, !z2);
        int c2 = c(window.getContext(), z2);
        int b3 = b(window.getContext(), z2);
        window.setStatusBarColor(c2);
        window.setNavigationBarColor(b3);
        f(window, d(c2, C0087a.i(num.intValue())));
        e(window, d(b3, C0087a.i(num2.intValue())));
    }

    private static int b(Context context, boolean z2) {
        if (z2 && Build.VERSION.SDK_INT < 27) {
            return a.k(C0087a.b(context, 16843858, -16777216), 128);
        }
        if (z2) {
            return 0;
        }
        return C0087a.b(context, 16843858, -16777216);
    }

    private static int c(Context context, boolean z2) {
        if (z2 && Build.VERSION.SDK_INT < 23) {
            return a.k(C0087a.b(context, 16843857, -16777216), 128);
        }
        if (z2) {
            return 0;
        }
        return C0087a.b(context, 16843857, -16777216);
    }

    private static boolean d(int i2, boolean z2) {
        return C0087a.i(i2) || (i2 == 0 && z2);
    }

    public static void e(Window window, boolean z2) {
        C0138i0.a(window, window.getDecorView()).b(z2);
    }

    public static void f(Window window, boolean z2) {
        C0138i0.a(window, window.getDecorView()).c(z2);
    }
}
