package com.google.android.material.internal;

import T.c;
import T.d;
import T.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.widget.S;
import androidx.appcompat.widget.j0;
import androidx.core.content.res.h;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import androidx.core.widget.j;
import e.C0233a;
import y.I;

public class NavigationMenuItemView extends C0218e implements k.a {

    /* renamed from: G  reason: collision with root package name */
    private static final int[] f4716G = {16842912};

    /* renamed from: A  reason: collision with root package name */
    private FrameLayout f4717A;

    /* renamed from: B  reason: collision with root package name */
    private g f4718B;

    /* renamed from: C  reason: collision with root package name */
    private ColorStateList f4719C;

    /* renamed from: D  reason: collision with root package name */
    private boolean f4720D;

    /* renamed from: E  reason: collision with root package name */
    private Drawable f4721E;

    /* renamed from: F  reason: collision with root package name */
    private final C0121a f4722F;

    /* renamed from: v  reason: collision with root package name */
    private int f4723v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f4724w;

    /* renamed from: x  reason: collision with root package name */
    boolean f4725x;

    /* renamed from: y  reason: collision with root package name */
    boolean f4726y;

    /* renamed from: z  reason: collision with root package name */
    private final CheckedTextView f4727z;

    class a extends C0121a {
        a() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.k0(NavigationMenuItemView.this.f4725x);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private void B() {
        S.a aVar;
        int i2;
        if (F()) {
            this.f4727z.setVisibility(8);
            FrameLayout frameLayout = this.f4717A;
            if (frameLayout != null) {
                aVar = (S.a) frameLayout.getLayoutParams();
                i2 = -1;
            } else {
                return;
            }
        } else {
            this.f4727z.setVisibility(0);
            FrameLayout frameLayout2 = this.f4717A;
            if (frameLayout2 != null) {
                aVar = (S.a) frameLayout2.getLayoutParams();
                i2 = -2;
            } else {
                return;
            }
        }
        aVar.width = i2;
        this.f4717A.setLayoutParams(aVar);
    }

    private StateListDrawable C() {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(C0233a.f5290t, typedValue, true)) {
            return null;
        }
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(f4716G, new ColorDrawable(typedValue.data));
        stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
        return stateListDrawable;
    }

    private boolean F() {
        return this.f4718B.getTitle() == null && this.f4718B.getIcon() == null && this.f4718B.getActionView() != null;
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f4717A == null) {
                this.f4717A = (FrameLayout) ((ViewStub) findViewById(e.design_menu_item_action_area_stub)).inflate();
            }
            if (view.getParent() != null) {
                ((ViewGroup) view.getParent()).removeView(view);
            }
            this.f4717A.removeAllViews();
            this.f4717A.addView(view);
        }
    }

    public void D(g gVar, boolean z2) {
        this.f4726y = z2;
        e(gVar, 0);
    }

    public void E() {
        FrameLayout frameLayout = this.f4717A;
        if (frameLayout != null) {
            frameLayout.removeAllViews();
        }
        this.f4727z.setCompoundDrawables((Drawable) null, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public boolean d() {
        return false;
    }

    public void e(g gVar, int i2) {
        this.f4718B = gVar;
        if (gVar.getItemId() > 0) {
            setId(gVar.getItemId());
        }
        setVisibility(gVar.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            W.u0(this, C());
        }
        setCheckable(gVar.isCheckable());
        setChecked(gVar.isChecked());
        setEnabled(gVar.isEnabled());
        setTitle(gVar.getTitle());
        setIcon(gVar.getIcon());
        setActionView(gVar.getActionView());
        setContentDescription(gVar.getContentDescription());
        j0.a(this, gVar.getTooltipText());
        B();
    }

    public g getItemData() {
        return this.f4718B;
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 1);
        g gVar = this.f4718B;
        if (gVar != null && gVar.isCheckable() && this.f4718B.isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, f4716G);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z2) {
        refreshDrawableState();
        if (this.f4725x != z2) {
            this.f4725x = z2;
            this.f4722F.l(this.f4727z, 2048);
        }
    }

    public void setChecked(boolean z2) {
        refreshDrawableState();
        this.f4727z.setChecked(z2);
        CheckedTextView checkedTextView = this.f4727z;
        checkedTextView.setTypeface(checkedTextView.getTypeface(), (!z2 || !this.f4726y) ? 0 : 1);
    }

    public void setHorizontalPadding(int i2) {
        setPadding(i2, getPaddingTop(), i2, getPaddingBottom());
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.f4720D) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = androidx.core.graphics.drawable.a.r(drawable).mutate();
                androidx.core.graphics.drawable.a.o(drawable, this.f4719C);
            }
            int i2 = this.f4723v;
            drawable.setBounds(0, 0, i2, i2);
        } else if (this.f4724w) {
            if (this.f4721E == null) {
                Drawable e2 = h.e(getResources(), d.navigation_empty_icon, getContext().getTheme());
                this.f4721E = e2;
                if (e2 != null) {
                    int i3 = this.f4723v;
                    e2.setBounds(0, 0, i3, i3);
                }
            }
            drawable = this.f4721E;
        }
        j.i(this.f4727z, drawable, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public void setIconPadding(int i2) {
        this.f4727z.setCompoundDrawablePadding(i2);
    }

    public void setIconSize(int i2) {
        this.f4723v = i2;
    }

    /* access modifiers changed from: package-private */
    public void setIconTintList(ColorStateList colorStateList) {
        this.f4719C = colorStateList;
        this.f4720D = colorStateList != null;
        g gVar = this.f4718B;
        if (gVar != null) {
            setIcon(gVar.getIcon());
        }
    }

    public void setMaxLines(int i2) {
        this.f4727z.setMaxLines(i2);
    }

    public void setNeedsEmptyIcon(boolean z2) {
        this.f4724w = z2;
    }

    public void setTextAppearance(int i2) {
        j.o(this.f4727z, i2);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f4727z.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.f4727z.setText(charSequence);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f4726y = true;
        a aVar = new a();
        this.f4722F = aVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(T.g.design_navigation_menu_item, this, true);
        setIconSize(context.getResources().getDimensionPixelSize(c.design_navigation_icon_size));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(e.design_menu_item_text);
        this.f4727z = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        W.q0(checkedTextView, aVar);
    }
}
