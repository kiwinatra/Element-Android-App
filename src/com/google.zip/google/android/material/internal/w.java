package com.google.android.material.internal;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextPaint;
import h0.d;
import h0.f;
import java.lang.ref.WeakReference;

public class w {

    /* renamed from: a  reason: collision with root package name */
    private final TextPaint f4880a = new TextPaint(1);

    /* renamed from: b  reason: collision with root package name */
    private final f f4881b = new a();

    /* renamed from: c  reason: collision with root package name */
    private float f4882c;

    /* renamed from: d  reason: collision with root package name */
    private float f4883d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public boolean f4884e = true;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public WeakReference f4885f = new WeakReference((Object) null);

    /* renamed from: g  reason: collision with root package name */
    private d f4886g;

    class a extends f {
        a() {
        }

        public void a(int i2) {
            boolean unused = w.this.f4884e = true;
            b bVar = (b) w.this.f4885f.get();
            if (bVar != null) {
                bVar.a();
            }
        }

        public void b(Typeface typeface, boolean z2) {
            if (!z2) {
                boolean unused = w.this.f4884e = true;
                b bVar = (b) w.this.f4885f.get();
                if (bVar != null) {
                    bVar.a();
                }
            }
        }
    }

    public interface b {
        void a();

        int[] getState();

        boolean onStateChange(int[] iArr);
    }

    public w(b bVar) {
        i(bVar);
    }

    private float c(String str) {
        if (str == null) {
            return 0.0f;
        }
        return Math.abs(this.f4880a.getFontMetrics().ascent);
    }

    private float d(CharSequence charSequence) {
        if (charSequence == null) {
            return 0.0f;
        }
        return this.f4880a.measureText(charSequence, 0, charSequence.length());
    }

    private void h(String str) {
        this.f4882c = d(str);
        this.f4883d = c(str);
        this.f4884e = false;
    }

    public d e() {
        return this.f4886g;
    }

    public TextPaint f() {
        return this.f4880a;
    }

    public float g(String str) {
        if (!this.f4884e) {
            return this.f4882c;
        }
        h(str);
        return this.f4882c;
    }

    public void i(b bVar) {
        this.f4885f = new WeakReference(bVar);
    }

    public void j(d dVar, Context context) {
        if (this.f4886g != dVar) {
            this.f4886g = dVar;
            if (dVar != null) {
                dVar.o(context, this.f4880a, this.f4881b);
                b bVar = (b) this.f4885f.get();
                if (bVar != null) {
                    this.f4880a.drawableState = bVar.getState();
                }
                dVar.n(context, this.f4880a, this.f4881b);
                this.f4884e = true;
            }
            b bVar2 = (b) this.f4885f.get();
            if (bVar2 != null) {
                bVar2.a();
                bVar2.onStateChange(bVar2.getState());
            }
        }
    }

    public void k(boolean z2) {
        this.f4884e = z2;
    }

    public void l(Context context) {
        this.f4886g.n(context, this.f4880a, this.f4881b);
    }
}
