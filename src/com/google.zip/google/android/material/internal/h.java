package com.google.android.material.internal;

import android.content.Context;
import android.view.SubMenu;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;

public class h extends e {
    public h(Context context) {
        super(context);
    }

    public SubMenu addSubMenu(int i2, int i3, int i4, CharSequence charSequence) {
        g gVar = (g) a(i2, i3, i4, charSequence);
        j jVar = new j(w(), this, gVar);
        gVar.x(jVar);
        return jVar;
    }
}
