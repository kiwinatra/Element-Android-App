package com.google.android.material.internal;

import android.text.TextWatcher;

public abstract class x implements TextWatcher {
    public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
    }

    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
    }
}
