package com.google.android.material.internal;

import android.os.Build;
import java.util.Locale;

/* renamed from: com.google.android.material.internal.f  reason: case insensitive filesystem */
public abstract class C0219f {
    private static String a() {
        String str = Build.MANUFACTURER;
        return str != null ? str.toLowerCase(Locale.ENGLISH) : "";
    }

    public static boolean b() {
        return a().equals("meizu");
    }
}
