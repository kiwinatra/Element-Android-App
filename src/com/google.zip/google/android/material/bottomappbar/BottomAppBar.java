package com.google.android.material.bottomappbar;

import T.a;
import T.i;
import android.content.Context;
import android.graphics.Rect;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.W;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import java.lang.ref.WeakReference;

public abstract class BottomAppBar extends Toolbar {

    /* renamed from: U  reason: collision with root package name */
    private static final int f4271U = i.Widget_MaterialComponents_BottomAppBar;

    /* renamed from: V  reason: collision with root package name */
    private static final int f4272V = a.motionDurationLong2;

    /* renamed from: W  reason: collision with root package name */
    private static final int f4273W = a.motionEasingEmphasizedInterpolator;

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: m  reason: collision with root package name */
        private final Rect f4274m = new Rect();
        /* access modifiers changed from: private */

        /* renamed from: n  reason: collision with root package name */
        public WeakReference f4275n;

        /* renamed from: o  reason: collision with root package name */
        private int f4276o;

        /* renamed from: p  reason: collision with root package name */
        private final View.OnLayoutChangeListener f4277p = new a();

        class a implements View.OnLayoutChangeListener {
            a() {
            }

            public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                b.a(Behavior.this.f4275n.get());
                view.removeOnLayoutChangeListener(this);
            }
        }

        public Behavior() {
        }

        public /* bridge */ /* synthetic */ boolean E(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
            b.a(view);
            return T(coordinatorLayout, (BottomAppBar) null, view2, view3, i2, i3);
        }

        public boolean S(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i2) {
            this.f4275n = new WeakReference(bottomAppBar);
            View V2 = BottomAppBar.V(bottomAppBar);
            if (V2 != null && !W.U(V2)) {
                BottomAppBar.X(bottomAppBar, V2);
                this.f4276o = ((CoordinatorLayout.e) V2.getLayoutParams()).bottomMargin;
                V2.addOnLayoutChangeListener(this.f4277p);
                BottomAppBar.U(bottomAppBar);
            }
            coordinatorLayout.G(bottomAppBar, i2);
            return super.p(coordinatorLayout, bottomAppBar, i2);
        }

        public boolean T(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i2, int i3) {
            throw null;
        }

        public /* bridge */ /* synthetic */ boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            b.a(view);
            return S(coordinatorLayout, (BottomAppBar) null, i2);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    static /* synthetic */ void U(BottomAppBar bottomAppBar) {
        throw null;
    }

    static /* synthetic */ View V(BottomAppBar bottomAppBar) {
        throw null;
    }

    /* access modifiers changed from: private */
    public static void X(BottomAppBar bottomAppBar, View view) {
        ((CoordinatorLayout.e) view.getLayoutParams()).f2060d = 17;
        throw null;
    }
}
