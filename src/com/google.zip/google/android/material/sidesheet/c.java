package com.google.android.material.sidesheet;

import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

abstract class c {
    c() {
    }

    /* access modifiers changed from: package-private */
    public abstract int a(ViewGroup.MarginLayoutParams marginLayoutParams);

    /* access modifiers changed from: package-private */
    public abstract float b(int i2);

    /* access modifiers changed from: package-private */
    public abstract int c(ViewGroup.MarginLayoutParams marginLayoutParams);

    /* access modifiers changed from: package-private */
    public abstract int d();

    /* access modifiers changed from: package-private */
    public abstract int e();

    /* access modifiers changed from: package-private */
    public abstract int f();

    /* access modifiers changed from: package-private */
    public abstract int g();

    /* access modifiers changed from: package-private */
    public abstract int h(View view);

    /* access modifiers changed from: package-private */
    public abstract int i(CoordinatorLayout coordinatorLayout);

    /* access modifiers changed from: package-private */
    public abstract int j();

    /* access modifiers changed from: package-private */
    public abstract boolean k(float f2);

    /* access modifiers changed from: package-private */
    public abstract boolean l(View view);

    /* access modifiers changed from: package-private */
    public abstract boolean m(float f2, float f3);

    /* access modifiers changed from: package-private */
    public abstract boolean n(View view, float f2);

    /* access modifiers changed from: package-private */
    public abstract void o(ViewGroup.MarginLayoutParams marginLayoutParams, int i2);

    /* access modifiers changed from: package-private */
    public abstract void p(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, int i3);
}
