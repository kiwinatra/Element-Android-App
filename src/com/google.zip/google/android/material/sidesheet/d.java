package com.google.android.material.sidesheet;

abstract class d {
    static boolean a(float f2, float f3) {
        return Math.abs(f2) > Math.abs(f3);
    }
}
