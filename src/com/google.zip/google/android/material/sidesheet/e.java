package com.google.android.material.sidesheet;

import com.google.android.material.sidesheet.SideSheetBehavior;

public final /* synthetic */ class e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SideSheetBehavior.d f4957a;

    public /* synthetic */ e(SideSheetBehavior.d dVar) {
        this.f4957a = dVar;
    }

    public final void run() {
        this.f4957a.c();
    }
}
