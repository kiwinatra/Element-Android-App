package com.google.android.material.sidesheet;

import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

final class a extends c {

    /* renamed from: a  reason: collision with root package name */
    final SideSheetBehavior f4955a;

    a(SideSheetBehavior sideSheetBehavior) {
        this.f4955a = sideSheetBehavior;
    }

    /* access modifiers changed from: package-private */
    public int a(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return marginLayoutParams.leftMargin;
    }

    /* access modifiers changed from: package-private */
    public float b(int i2) {
        float e2 = (float) e();
        return (((float) i2) - e2) / (((float) d()) - e2);
    }

    /* access modifiers changed from: package-private */
    public int c(ViewGroup.MarginLayoutParams marginLayoutParams) {
        return marginLayoutParams.leftMargin;
    }

    /* access modifiers changed from: package-private */
    public int d() {
        return Math.max(0, this.f4955a.m0() + this.f4955a.k0());
    }

    /* access modifiers changed from: package-private */
    public int e() {
        return (-this.f4955a.d0()) - this.f4955a.k0();
    }

    /* access modifiers changed from: package-private */
    public int f() {
        return this.f4955a.k0();
    }

    /* access modifiers changed from: package-private */
    public int g() {
        return -this.f4955a.d0();
    }

    /* access modifiers changed from: package-private */
    public int h(View view) {
        return view.getRight() + this.f4955a.k0();
    }

    public int i(CoordinatorLayout coordinatorLayout) {
        return coordinatorLayout.getLeft();
    }

    /* access modifiers changed from: package-private */
    public int j() {
        return 1;
    }

    /* access modifiers changed from: package-private */
    public boolean k(float f2) {
        return f2 > 0.0f;
    }

    /* access modifiers changed from: package-private */
    public boolean l(View view) {
        return view.getRight() < (d() - e()) / 2;
    }

    /* access modifiers changed from: package-private */
    public boolean m(float f2, float f3) {
        return d.a(f2, f3) && Math.abs(f2) > ((float) this.f4955a.o0());
    }

    /* access modifiers changed from: package-private */
    public boolean n(View view, float f2) {
        return Math.abs(((float) view.getLeft()) + (f2 * this.f4955a.i0())) > this.f4955a.j0();
    }

    /* access modifiers changed from: package-private */
    public void o(ViewGroup.MarginLayoutParams marginLayoutParams, int i2) {
        marginLayoutParams.leftMargin = i2;
    }

    /* access modifiers changed from: package-private */
    public void p(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, int i3) {
        if (i2 <= this.f4955a.n0()) {
            marginLayoutParams.leftMargin = i3;
        }
    }
}
