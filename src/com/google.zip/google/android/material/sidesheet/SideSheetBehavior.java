package com.google.android.material.sidesheet;

import D.c;
import T.h;
import T.i;
import T.j;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.C0156s;
import androidx.core.view.W;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import k0.g;
import k0.k;
import v.C0288a;
import y.I;
import y.L;

public class SideSheetBehavior<V extends View> extends CoordinatorLayout.b implements f0.b {

    /* renamed from: A  reason: collision with root package name */
    private static final int f4921A = i.Widget_Material3_SideSheet;

    /* renamed from: z  reason: collision with root package name */
    private static final int f4922z = h.side_sheet_accessibility_pane_title;
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public c f4923a;

    /* renamed from: b  reason: collision with root package name */
    private float f4924b;

    /* renamed from: c  reason: collision with root package name */
    private g f4925c;

    /* renamed from: d  reason: collision with root package name */
    private ColorStateList f4926d;

    /* renamed from: e  reason: collision with root package name */
    private k f4927e;

    /* renamed from: f  reason: collision with root package name */
    private final d f4928f = new d();

    /* renamed from: g  reason: collision with root package name */
    private float f4929g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public boolean f4930h = true;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public int f4931i = 5;

    /* renamed from: j  reason: collision with root package name */
    private int f4932j = 5;
    /* access modifiers changed from: private */

    /* renamed from: k  reason: collision with root package name */
    public D.c f4933k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f4934l;

    /* renamed from: m  reason: collision with root package name */
    private float f4935m = 0.1f;
    /* access modifiers changed from: private */

    /* renamed from: n  reason: collision with root package name */
    public int f4936n;

    /* renamed from: o  reason: collision with root package name */
    private int f4937o;

    /* renamed from: p  reason: collision with root package name */
    private int f4938p;

    /* renamed from: q  reason: collision with root package name */
    private int f4939q;
    /* access modifiers changed from: private */

    /* renamed from: r  reason: collision with root package name */
    public WeakReference f4940r;

    /* renamed from: s  reason: collision with root package name */
    private WeakReference f4941s;

    /* renamed from: t  reason: collision with root package name */
    private int f4942t = -1;

    /* renamed from: u  reason: collision with root package name */
    private VelocityTracker f4943u;

    /* renamed from: v  reason: collision with root package name */
    private f0.g f4944v;

    /* renamed from: w  reason: collision with root package name */
    private int f4945w;

    /* renamed from: x  reason: collision with root package name */
    private final Set f4946x = new LinkedHashSet();

    /* renamed from: y  reason: collision with root package name */
    private final c.C0004c f4947y = new a();

    class a extends c.C0004c {
        a() {
        }

        public int a(View view, int i2, int i3) {
            return C0288a.b(i2, SideSheetBehavior.this.f4923a.g(), SideSheetBehavior.this.f4923a.f());
        }

        public int b(View view, int i2, int i3) {
            return view.getTop();
        }

        public int d(View view) {
            return SideSheetBehavior.this.f4936n + SideSheetBehavior.this.k0();
        }

        public void j(int i2) {
            if (i2 == 1 && SideSheetBehavior.this.f4930h) {
                SideSheetBehavior.this.J0(1);
            }
        }

        public void k(View view, int i2, int i3, int i4, int i5) {
            ViewGroup.MarginLayoutParams marginLayoutParams;
            View f02 = SideSheetBehavior.this.f0();
            if (!(f02 == null || (marginLayoutParams = (ViewGroup.MarginLayoutParams) f02.getLayoutParams()) == null)) {
                SideSheetBehavior.this.f4923a.p(marginLayoutParams, view.getLeft(), view.getRight());
                f02.setLayoutParams(marginLayoutParams);
            }
            SideSheetBehavior.this.a0(view, i2);
        }

        public void l(View view, float f2, float f3) {
            int Q2 = SideSheetBehavior.this.W(view, f2, f3);
            SideSheetBehavior sideSheetBehavior = SideSheetBehavior.this;
            sideSheetBehavior.O0(view, Q2, sideSheetBehavior.N0());
        }

        public boolean m(View view, int i2) {
            return (SideSheetBehavior.this.f4931i == 1 || SideSheetBehavior.this.f4940r == null || SideSheetBehavior.this.f4940r.get() != view) ? false : true;
        }
    }

    class b extends AnimatorListenerAdapter {
        b() {
        }

        public void onAnimationEnd(Animator animator) {
            SideSheetBehavior.this.J0(5);
            if (SideSheetBehavior.this.f4940r != null && SideSheetBehavior.this.f4940r.get() != null) {
                ((View) SideSheetBehavior.this.f4940r.get()).requestLayout();
            }
        }
    }

    protected static class c extends C.a {
        public static final Parcelable.Creator<c> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        final int f4950c;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public c createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new c(parcel, classLoader);
            }

            /* renamed from: c */
            public c[] newArray(int i2) {
                return new c[i2];
            }
        }

        public c(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f4950c = parcel.readInt();
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f4950c);
        }

        public c(Parcelable parcelable, SideSheetBehavior sideSheetBehavior) {
            super(parcelable);
            this.f4950c = sideSheetBehavior.f4931i;
        }
    }

    class d {

        /* renamed from: a  reason: collision with root package name */
        private int f4951a;

        /* renamed from: b  reason: collision with root package name */
        private boolean f4952b;

        /* renamed from: c  reason: collision with root package name */
        private final Runnable f4953c = new e(this);

        d() {
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void c() {
            this.f4952b = false;
            if (SideSheetBehavior.this.f4933k != null && SideSheetBehavior.this.f4933k.m(true)) {
                b(this.f4951a);
            } else if (SideSheetBehavior.this.f4931i == 2) {
                SideSheetBehavior.this.J0(this.f4951a);
            }
        }

        /* access modifiers changed from: package-private */
        public void b(int i2) {
            if (SideSheetBehavior.this.f4940r != null && SideSheetBehavior.this.f4940r.get() != null) {
                this.f4951a = i2;
                if (!this.f4952b) {
                    W.i0((View) SideSheetBehavior.this.f4940r.get(), this.f4953c);
                    this.f4952b = true;
                }
            }
        }
    }

    public SideSheetBehavior() {
    }

    private void A0(CoordinatorLayout coordinatorLayout) {
        int i2;
        View findViewById;
        if (this.f4941s == null && (i2 = this.f4942t) != -1 && (findViewById = coordinatorLayout.findViewById(i2)) != null) {
            this.f4941s = new WeakReference(findViewById);
        }
    }

    private void B0(View view, I.a aVar, int i2) {
        W.m0(view, aVar, (CharSequence) null, Y(i2));
    }

    private void C0() {
        VelocityTracker velocityTracker = this.f4943u;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f4943u = null;
        }
    }

    private void D0(View view, Runnable runnable) {
        if (v0(view)) {
            view.post(runnable);
        } else {
            runnable.run();
        }
    }

    private void G0(int i2) {
        c cVar = this.f4923a;
        if (cVar != null && cVar.j() == i2) {
            return;
        }
        if (i2 == 0) {
            this.f4923a = new b(this);
            if (this.f4927e != null && !s0()) {
                k.b v2 = this.f4927e.v();
                v2.E(0.0f).w(0.0f);
                R0(v2.m());
            }
        } else if (i2 == 1) {
            this.f4923a = new a(this);
            if (this.f4927e != null && !r0()) {
                k.b v3 = this.f4927e.v();
                v3.A(0.0f).s(0.0f);
                R0(v3.m());
            }
        } else {
            throw new IllegalArgumentException("Invalid sheet edge position value: " + i2 + ". Must be " + 0 + " or " + 1 + ".");
        }
    }

    private void H0(View view, int i2) {
        G0(C0156s.b(((CoordinatorLayout.e) view.getLayoutParams()).f2059c, i2) == 3 ? 1 : 0);
    }

    private boolean K0() {
        return this.f4933k != null && (this.f4930h || this.f4931i == 1);
    }

    private boolean M0(View view) {
        return (view.isShown() || W.q(view) != null) && this.f4930h;
    }

    /* access modifiers changed from: private */
    public void O0(View view, int i2, boolean z2) {
        if (w0(view, i2, z2)) {
            J0(2);
            this.f4928f.b(i2);
            return;
        }
        J0(i2);
    }

    private void P0() {
        View view;
        WeakReference weakReference = this.f4940r;
        if (weakReference != null && (view = (View) weakReference.get()) != null) {
            W.k0(view, 262144);
            W.k0(view, 1048576);
            if (this.f4931i != 5) {
                B0(view, I.a.f6382y, 5);
            }
            if (this.f4931i != 3) {
                B0(view, I.a.f6380w, 3);
            }
        }
    }

    private void Q0() {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        WeakReference weakReference = this.f4940r;
        if (weakReference != null && weakReference.get() != null) {
            View view = (View) this.f4940r.get();
            View f02 = f0();
            if (f02 != null && (marginLayoutParams = (ViewGroup.MarginLayoutParams) f02.getLayoutParams()) != null) {
                this.f4923a.o(marginLayoutParams, (int) ((((float) this.f4936n) * view.getScaleX()) + ((float) this.f4939q)));
                f02.requestLayout();
            }
        }
    }

    private void R0(k kVar) {
        g gVar = this.f4925c;
        if (gVar != null) {
            gVar.setShapeAppearanceModel(kVar);
        }
    }

    private void S0(View view) {
        int i2 = this.f4931i == 5 ? 4 : 0;
        if (view.getVisibility() != i2) {
            view.setVisibility(i2);
        }
    }

    private int U(int i2, View view) {
        int i3 = this.f4931i;
        if (i3 == 1 || i3 == 2) {
            return i2 - this.f4923a.h(view);
        }
        if (i3 == 3) {
            return 0;
        }
        if (i3 == 5) {
            return this.f4923a.e();
        }
        throw new IllegalStateException("Unexpected value: " + this.f4931i);
    }

    private float V(float f2, float f3) {
        return Math.abs(f2 - f3);
    }

    /* access modifiers changed from: private */
    public int W(View view, float f2, float f3) {
        if (u0(f2)) {
            return 3;
        }
        if (L0(view, f2)) {
            return (this.f4923a.m(f2, f3) || this.f4923a.l(view)) ? 5 : 3;
        }
        if (f2 == 0.0f || !d.a(f2, f3)) {
            int left = view.getLeft();
            if (Math.abs(left - g0()) < Math.abs(left - this.f4923a.e())) {
                return 3;
            }
        }
    }

    private void X() {
        WeakReference weakReference = this.f4941s;
        if (weakReference != null) {
            weakReference.clear();
        }
        this.f4941s = null;
    }

    private L Y(int i2) {
        return new l0.a(this, i2);
    }

    private void Z(Context context) {
        if (this.f4927e != null) {
            g gVar = new g(this.f4927e);
            this.f4925c = gVar;
            gVar.J(context);
            ColorStateList colorStateList = this.f4926d;
            if (colorStateList != null) {
                this.f4925c.T(colorStateList);
                return;
            }
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(16842801, typedValue, true);
            this.f4925c.setTint(typedValue.data);
        }
    }

    /* access modifiers changed from: private */
    public void a0(View view, int i2) {
        if (!this.f4946x.isEmpty()) {
            this.f4923a.b(i2);
            Iterator it = this.f4946x.iterator();
            if (it.hasNext()) {
                android.support.v4.media.session.b.a(it.next());
                throw null;
            }
        }
    }

    private void b0(View view) {
        if (W.q(view) == null) {
            W.t0(view, view.getResources().getString(f4922z));
        }
    }

    private int c0(int i2, int i3, int i4, int i5) {
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, i3, i5);
        if (i4 == -1) {
            return childMeasureSpec;
        }
        int mode = View.MeasureSpec.getMode(childMeasureSpec);
        int size = View.MeasureSpec.getSize(childMeasureSpec);
        if (mode == 1073741824) {
            return View.MeasureSpec.makeMeasureSpec(Math.min(size, i4), 1073741824);
        }
        if (size != 0) {
            i4 = Math.min(size, i4);
        }
        return View.MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE);
    }

    private ValueAnimator.AnimatorUpdateListener e0() {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        View f02 = f0();
        if (f02 == null || (marginLayoutParams = (ViewGroup.MarginLayoutParams) f02.getLayoutParams()) == null) {
            return null;
        }
        return new l0.c(this, marginLayoutParams, this.f4923a.c(marginLayoutParams), f02);
    }

    private int h0() {
        c cVar = this.f4923a;
        return (cVar == null || cVar.j() == 0) ? 5 : 3;
    }

    private CoordinatorLayout.e q0() {
        View view;
        WeakReference weakReference = this.f4940r;
        if (weakReference == null || (view = (View) weakReference.get()) == null || !(view.getLayoutParams() instanceof CoordinatorLayout.e)) {
            return null;
        }
        return (CoordinatorLayout.e) view.getLayoutParams();
    }

    private boolean r0() {
        CoordinatorLayout.e q02 = q0();
        return q02 != null && q02.leftMargin > 0;
    }

    private boolean s0() {
        CoordinatorLayout.e q02 = q0();
        return q02 != null && q02.rightMargin > 0;
    }

    private boolean t0(MotionEvent motionEvent) {
        return K0() && V((float) this.f4945w, motionEvent.getX()) > ((float) this.f4933k.z());
    }

    private boolean u0(float f2) {
        return this.f4923a.k(f2);
    }

    private boolean v0(View view) {
        ViewParent parent = view.getParent();
        return parent != null && parent.isLayoutRequested() && W.T(view);
    }

    private boolean w0(View view, int i2, boolean z2) {
        int l02 = l0(i2);
        D.c p02 = p0();
        return p02 != null && (!z2 ? p02.Q(view, l02, view.getTop()) : p02.O(l02, view.getTop()));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean x0(int i2, View view, L.a aVar) {
        I0(i2);
        return true;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void y0(ViewGroup.MarginLayoutParams marginLayoutParams, int i2, View view, ValueAnimator valueAnimator) {
        this.f4923a.o(marginLayoutParams, U.a.c(i2, 0, valueAnimator.getAnimatedFraction()));
        view.requestLayout();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void z0(int i2) {
        View view = (View) this.f4940r.get();
        if (view != null) {
            O0(view, i2, false);
        }
    }

    public void B(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
        c cVar = (c) parcelable;
        if (cVar.c() != null) {
            super.B(coordinatorLayout, view, cVar.c());
        }
        int i2 = cVar.f4950c;
        if (i2 == 1 || i2 == 2) {
            i2 = 5;
        }
        this.f4931i = i2;
        this.f4932j = i2;
    }

    public Parcelable C(CoordinatorLayout coordinatorLayout, View view) {
        return new c(super.C(coordinatorLayout, view), this);
    }

    public void E0(int i2) {
        this.f4942t = i2;
        X();
        WeakReference weakReference = this.f4940r;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            if (i2 != -1 && W.U(view)) {
                view.requestLayout();
            }
        }
    }

    public void F0(boolean z2) {
        this.f4930h = z2;
    }

    public boolean H(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        if (!view.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f4931i == 1 && actionMasked == 0) {
            return true;
        }
        if (K0()) {
            this.f4933k.F(motionEvent);
        }
        if (actionMasked == 0) {
            C0();
        }
        if (this.f4943u == null) {
            this.f4943u = VelocityTracker.obtain();
        }
        this.f4943u.addMovement(motionEvent);
        if (K0() && actionMasked == 2 && !this.f4934l && t0(motionEvent)) {
            this.f4933k.b(view, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.f4934l;
    }

    public void I0(int i2) {
        if (i2 == 1 || i2 == 2) {
            StringBuilder sb = new StringBuilder();
            sb.append("STATE_");
            sb.append(i2 == 1 ? "DRAGGING" : "SETTLING");
            sb.append(" should not be set externally.");
            throw new IllegalArgumentException(sb.toString());
        }
        WeakReference weakReference = this.f4940r;
        if (weakReference == null || weakReference.get() == null) {
            J0(i2);
        } else {
            D0((View) this.f4940r.get(), new l0.b(this, i2));
        }
    }

    /* access modifiers changed from: package-private */
    public void J0(int i2) {
        View view;
        if (this.f4931i != i2) {
            this.f4931i = i2;
            if (i2 == 3 || i2 == 5) {
                this.f4932j = i2;
            }
            WeakReference weakReference = this.f4940r;
            if (weakReference != null && (view = (View) weakReference.get()) != null) {
                S0(view);
                Iterator it = this.f4946x.iterator();
                if (!it.hasNext()) {
                    P0();
                } else {
                    android.support.v4.media.session.b.a(it.next());
                    throw null;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean L0(View view, float f2) {
        return this.f4923a.n(view, f2);
    }

    public boolean N0() {
        return true;
    }

    public void a() {
        f0.g gVar = this.f4944v;
        if (gVar != null) {
            androidx.activity.b c2 = gVar.c();
            if (c2 == null || Build.VERSION.SDK_INT < 34) {
                I0(5);
            } else {
                this.f4944v.h(c2, h0(), new b(), e0());
            }
        }
    }

    public void b(androidx.activity.b bVar) {
        f0.g gVar = this.f4944v;
        if (gVar != null) {
            gVar.j(bVar);
        }
    }

    public void c(androidx.activity.b bVar) {
        f0.g gVar = this.f4944v;
        if (gVar != null) {
            gVar.l(bVar, h0());
            Q0();
        }
    }

    public void d() {
        f0.g gVar = this.f4944v;
        if (gVar != null) {
            gVar.f();
        }
    }

    /* access modifiers changed from: package-private */
    public int d0() {
        return this.f4936n;
    }

    public View f0() {
        WeakReference weakReference = this.f4941s;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    public int g0() {
        return this.f4923a.d();
    }

    public float i0() {
        return this.f4935m;
    }

    /* access modifiers changed from: package-private */
    public float j0() {
        return 0.5f;
    }

    public void k(CoordinatorLayout.e eVar) {
        super.k(eVar);
        this.f4940r = null;
        this.f4933k = null;
        this.f4944v = null;
    }

    /* access modifiers changed from: package-private */
    public int k0() {
        return this.f4939q;
    }

    /* access modifiers changed from: package-private */
    public int l0(int i2) {
        if (i2 == 3) {
            return g0();
        }
        if (i2 == 5) {
            return this.f4923a.e();
        }
        throw new IllegalArgumentException("Invalid state to get outer edge offset: " + i2);
    }

    /* access modifiers changed from: package-private */
    public int m0() {
        return this.f4938p;
    }

    public void n() {
        super.n();
        this.f4940r = null;
        this.f4933k = null;
        this.f4944v = null;
    }

    /* access modifiers changed from: package-private */
    public int n0() {
        return this.f4937o;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x003d, code lost:
        r3 = r2.f4933k;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean o(androidx.coordinatorlayout.widget.CoordinatorLayout r3, android.view.View r4, android.view.MotionEvent r5) {
        /*
            r2 = this;
            boolean r3 = r2.M0(r4)
            r4 = 1
            r0 = 0
            if (r3 != 0) goto L_0x000b
            r2.f4934l = r4
            return r0
        L_0x000b:
            int r3 = r5.getActionMasked()
            if (r3 != 0) goto L_0x0014
            r2.C0()
        L_0x0014:
            android.view.VelocityTracker r1 = r2.f4943u
            if (r1 != 0) goto L_0x001e
            android.view.VelocityTracker r1 = android.view.VelocityTracker.obtain()
            r2.f4943u = r1
        L_0x001e:
            android.view.VelocityTracker r1 = r2.f4943u
            r1.addMovement(r5)
            if (r3 == 0) goto L_0x0032
            if (r3 == r4) goto L_0x002b
            r1 = 3
            if (r3 == r1) goto L_0x002b
            goto L_0x0039
        L_0x002b:
            boolean r3 = r2.f4934l
            if (r3 == 0) goto L_0x0039
            r2.f4934l = r0
            return r0
        L_0x0032:
            float r3 = r5.getX()
            int r3 = (int) r3
            r2.f4945w = r3
        L_0x0039:
            boolean r3 = r2.f4934l
            if (r3 != 0) goto L_0x0048
            D.c r3 = r2.f4933k
            if (r3 == 0) goto L_0x0048
            boolean r3 = r3.P(r5)
            if (r3 == 0) goto L_0x0048
            goto L_0x0049
        L_0x0048:
            r4 = 0
        L_0x0049:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.sidesheet.SideSheetBehavior.o(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    public int o0() {
        return 500;
    }

    public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
        if (W.z(coordinatorLayout) && !W.z(view)) {
            view.setFitsSystemWindows(true);
        }
        if (this.f4940r == null) {
            this.f4940r = new WeakReference(view);
            this.f4944v = new f0.g(view);
            g gVar = this.f4925c;
            if (gVar != null) {
                W.u0(view, gVar);
                g gVar2 = this.f4925c;
                float f2 = this.f4929g;
                if (f2 == -1.0f) {
                    f2 = W.w(view);
                }
                gVar2.S(f2);
            } else {
                ColorStateList colorStateList = this.f4926d;
                if (colorStateList != null) {
                    W.v0(view, colorStateList);
                }
            }
            S0(view);
            P0();
            if (W.A(view) == 0) {
                W.y0(view, 1);
            }
            b0(view);
        }
        H0(view, i2);
        if (this.f4933k == null) {
            this.f4933k = D.c.o(coordinatorLayout, this.f4947y);
        }
        int h2 = this.f4923a.h(view);
        coordinatorLayout.G(view, i2);
        this.f4937o = coordinatorLayout.getWidth();
        this.f4938p = this.f4923a.i(coordinatorLayout);
        this.f4936n = view.getWidth();
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        this.f4939q = marginLayoutParams != null ? this.f4923a.a(marginLayoutParams) : 0;
        W.a0(view, U(h2, view));
        A0(coordinatorLayout);
        for (Object a2 : this.f4946x) {
            android.support.v4.media.session.b.a(a2);
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public D.c p0() {
        return this.f4933k;
    }

    public boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(c0(i2, coordinatorLayout.getPaddingLeft() + coordinatorLayout.getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, -1, marginLayoutParams.width), c0(i4, coordinatorLayout.getPaddingTop() + coordinatorLayout.getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, -1, marginLayoutParams.height));
        return true;
    }

    public SideSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.d5);
        int i2 = j.f5;
        if (obtainStyledAttributes.hasValue(i2)) {
            this.f4926d = h0.c.a(context, obtainStyledAttributes, i2);
        }
        if (obtainStyledAttributes.hasValue(j.i5)) {
            this.f4927e = k.e(context, attributeSet, 0, f4921A).m();
        }
        int i3 = j.h5;
        if (obtainStyledAttributes.hasValue(i3)) {
            E0(obtainStyledAttributes.getResourceId(i3, -1));
        }
        Z(context);
        this.f4929g = obtainStyledAttributes.getDimension(j.e5, -1.0f);
        F0(obtainStyledAttributes.getBoolean(j.g5, true));
        obtainStyledAttributes.recycle();
        this.f4924b = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }
}
