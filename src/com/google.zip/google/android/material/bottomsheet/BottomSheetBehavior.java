package com.google.android.material.bottomsheet;

import D.c;
import T.i;
import T.j;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.RoundedCorner;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import com.google.android.material.internal.B;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import k0.k;
import v.C0288a;
import y.I;
import y.L;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.b implements f0.b {

    /* renamed from: i0  reason: collision with root package name */
    private static final int f4279i0 = i.Widget_Design_BottomSheet_Modal;

    /* renamed from: A  reason: collision with root package name */
    private boolean f4280A;

    /* renamed from: B  reason: collision with root package name */
    private final h f4281B = new h(this, (a) null);

    /* renamed from: C  reason: collision with root package name */
    private ValueAnimator f4282C;

    /* renamed from: D  reason: collision with root package name */
    int f4283D;

    /* renamed from: E  reason: collision with root package name */
    int f4284E;

    /* renamed from: F  reason: collision with root package name */
    int f4285F;

    /* renamed from: G  reason: collision with root package name */
    float f4286G = 0.5f;

    /* renamed from: H  reason: collision with root package name */
    int f4287H;

    /* renamed from: I  reason: collision with root package name */
    float f4288I = -1.0f;

    /* renamed from: J  reason: collision with root package name */
    boolean f4289J;
    /* access modifiers changed from: private */

    /* renamed from: K  reason: collision with root package name */
    public boolean f4290K;
    /* access modifiers changed from: private */

    /* renamed from: L  reason: collision with root package name */
    public boolean f4291L = true;

    /* renamed from: M  reason: collision with root package name */
    int f4292M = 4;

    /* renamed from: N  reason: collision with root package name */
    int f4293N = 4;

    /* renamed from: O  reason: collision with root package name */
    D.c f4294O;

    /* renamed from: P  reason: collision with root package name */
    private boolean f4295P;

    /* renamed from: Q  reason: collision with root package name */
    private int f4296Q;

    /* renamed from: R  reason: collision with root package name */
    private boolean f4297R;

    /* renamed from: S  reason: collision with root package name */
    private float f4298S = 0.1f;

    /* renamed from: T  reason: collision with root package name */
    private int f4299T;

    /* renamed from: U  reason: collision with root package name */
    int f4300U;

    /* renamed from: V  reason: collision with root package name */
    int f4301V;

    /* renamed from: W  reason: collision with root package name */
    WeakReference f4302W;

    /* renamed from: X  reason: collision with root package name */
    WeakReference f4303X;

    /* renamed from: Y  reason: collision with root package name */
    WeakReference f4304Y;

    /* renamed from: Z  reason: collision with root package name */
    private final ArrayList f4305Z = new ArrayList();

    /* renamed from: a  reason: collision with root package name */
    private int f4306a = 0;

    /* renamed from: a0  reason: collision with root package name */
    private VelocityTracker f4307a0;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public boolean f4308b = true;

    /* renamed from: b0  reason: collision with root package name */
    f0.f f4309b0;

    /* renamed from: c  reason: collision with root package name */
    private boolean f4310c = false;

    /* renamed from: c0  reason: collision with root package name */
    int f4311c0;

    /* renamed from: d  reason: collision with root package name */
    private float f4312d;

    /* renamed from: d0  reason: collision with root package name */
    private int f4313d0 = -1;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public int f4314e;

    /* renamed from: e0  reason: collision with root package name */
    boolean f4315e0;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public int f4316f;

    /* renamed from: f0  reason: collision with root package name */
    private Map f4317f0;

    /* renamed from: g  reason: collision with root package name */
    private boolean f4318g;

    /* renamed from: g0  reason: collision with root package name */
    final SparseIntArray f4319g0 = new SparseIntArray();

    /* renamed from: h  reason: collision with root package name */
    private int f4320h;

    /* renamed from: h0  reason: collision with root package name */
    private final c.C0004c f4321h0 = new e();

    /* renamed from: i  reason: collision with root package name */
    private int f4322i;
    /* access modifiers changed from: private */

    /* renamed from: j  reason: collision with root package name */
    public k0.g f4323j;

    /* renamed from: k  reason: collision with root package name */
    private ColorStateList f4324k;

    /* renamed from: l  reason: collision with root package name */
    private int f4325l = -1;

    /* renamed from: m  reason: collision with root package name */
    private int f4326m = -1;
    /* access modifiers changed from: private */

    /* renamed from: n  reason: collision with root package name */
    public int f4327n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f4328o;
    /* access modifiers changed from: private */

    /* renamed from: p  reason: collision with root package name */
    public boolean f4329p;
    /* access modifiers changed from: private */

    /* renamed from: q  reason: collision with root package name */
    public boolean f4330q;
    /* access modifiers changed from: private */

    /* renamed from: r  reason: collision with root package name */
    public boolean f4331r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f4332s;
    /* access modifiers changed from: private */

    /* renamed from: t  reason: collision with root package name */
    public boolean f4333t;
    /* access modifiers changed from: private */

    /* renamed from: u  reason: collision with root package name */
    public boolean f4334u;
    /* access modifiers changed from: private */

    /* renamed from: v  reason: collision with root package name */
    public boolean f4335v;
    /* access modifiers changed from: private */

    /* renamed from: w  reason: collision with root package name */
    public int f4336w;
    /* access modifiers changed from: private */

    /* renamed from: x  reason: collision with root package name */
    public int f4337x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f4338y;

    /* renamed from: z  reason: collision with root package name */
    private k f4339z;

    class a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f4340a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f4341b;

        a(View view, int i2) {
            this.f4340a = view;
            this.f4341b = i2;
        }

        public void run() {
            BottomSheetBehavior.this.Z0(this.f4340a, this.f4341b, false);
        }
    }

    class b extends AnimatorListenerAdapter {
        b() {
        }

        public void onAnimationEnd(Animator animator) {
            BottomSheetBehavior.this.S0(5);
            WeakReference weakReference = BottomSheetBehavior.this.f4302W;
            if (weakReference != null && weakReference.get() != null) {
                ((View) BottomSheetBehavior.this.f4302W.get()).requestLayout();
            }
        }
    }

    class c implements ValueAnimator.AnimatorUpdateListener {
        c() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            if (BottomSheetBehavior.this.f4323j != null) {
                BottomSheetBehavior.this.f4323j.U(floatValue);
            }
        }
    }

    class d implements B.c {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ boolean f4345a;

        d(boolean z2) {
            this.f4345a = z2;
        }

        public C0165w0 a(View view, C0165w0 w0Var, B.d dVar) {
            boolean z2;
            int i2;
            int i3;
            int i4;
            androidx.core.graphics.f f2 = w0Var.f(C0165w0.m.d());
            androidx.core.graphics.f f3 = w0Var.f(C0165w0.m.c());
            int unused = BottomSheetBehavior.this.f4337x = f2.f2206b;
            boolean g2 = B.g(view);
            int paddingBottom = view.getPaddingBottom();
            int paddingLeft = view.getPaddingLeft();
            int paddingRight = view.getPaddingRight();
            if (BottomSheetBehavior.this.f4329p) {
                int unused2 = BottomSheetBehavior.this.f4336w = w0Var.i();
                paddingBottom = dVar.f4706d + BottomSheetBehavior.this.f4336w;
            }
            if (BottomSheetBehavior.this.f4330q) {
                paddingLeft = (g2 ? dVar.f4705c : dVar.f4703a) + f2.f2205a;
            }
            if (BottomSheetBehavior.this.f4331r) {
                paddingRight = (g2 ? dVar.f4703a : dVar.f4705c) + f2.f2207c;
            }
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            boolean z3 = true;
            if (!BottomSheetBehavior.this.f4333t || marginLayoutParams.leftMargin == (i4 = f2.f2205a)) {
                z2 = false;
            } else {
                marginLayoutParams.leftMargin = i4;
                z2 = true;
            }
            if (BottomSheetBehavior.this.f4334u && marginLayoutParams.rightMargin != (i3 = f2.f2207c)) {
                marginLayoutParams.rightMargin = i3;
                z2 = true;
            }
            if (!BottomSheetBehavior.this.f4335v || marginLayoutParams.topMargin == (i2 = f2.f2206b)) {
                z3 = z2;
            } else {
                marginLayoutParams.topMargin = i2;
            }
            if (z3) {
                view.setLayoutParams(marginLayoutParams);
            }
            view.setPadding(paddingLeft, view.getPaddingTop(), paddingRight, paddingBottom);
            if (this.f4345a) {
                int unused3 = BottomSheetBehavior.this.f4327n = f3.f2208d;
            }
            if (BottomSheetBehavior.this.f4329p || this.f4345a) {
                BottomSheetBehavior.this.e1(false);
            }
            return w0Var;
        }
    }

    class e extends c.C0004c {

        /* renamed from: a  reason: collision with root package name */
        private long f4347a;

        e() {
        }

        private boolean n(View view) {
            int top = view.getTop();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return top > (bottomSheetBehavior.f4301V + bottomSheetBehavior.q0()) / 2;
        }

        public int a(View view, int i2, int i3) {
            return view.getLeft();
        }

        public int b(View view, int i2, int i3) {
            return C0288a.b(i2, BottomSheetBehavior.this.q0(), e(view));
        }

        public int e(View view) {
            return BottomSheetBehavior.this.i0() ? BottomSheetBehavior.this.f4301V : BottomSheetBehavior.this.f4287H;
        }

        public void j(int i2) {
            if (i2 == 1 && BottomSheetBehavior.this.f4291L) {
                BottomSheetBehavior.this.S0(1);
            }
        }

        public void k(View view, int i2, int i3, int i4, int i5) {
            BottomSheetBehavior.this.n0(i3);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x003c, code lost:
            if (r9 > r7.f4348b.f4285F) goto L_0x012b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:25:0x0091, code lost:
            if (java.lang.Math.abs(r8.getTop() - r7.f4348b.q0()) < java.lang.Math.abs(r8.getTop() - r7.f4348b.f4285F)) goto L_0x0010;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:36:0x00d0, code lost:
            if (r7.f4348b.X0() == false) goto L_0x012b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:40:0x00f2, code lost:
            if (java.lang.Math.abs(r9 - r7.f4348b.f4284E) < java.lang.Math.abs(r9 - r7.f4348b.f4287H)) goto L_0x0010;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:46:0x010e, code lost:
            if (r7.f4348b.X0() != false) goto L_0x00ae;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:50:0x0128, code lost:
            if (r7.f4348b.X0() == false) goto L_0x012b;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:8:0x0035, code lost:
            if (r10.U0(r3, (((float) r9) * 100.0f) / ((float) r10.f4301V)) != false) goto L_0x0010;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void l(android.view.View r8, float r9, float r10) {
            /*
                r7 = this;
                r0 = 6
                r1 = 3
                r2 = 4
                r3 = 0
                int r4 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1))
                if (r4 >= 0) goto L_0x0040
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.f4308b
                if (r9 == 0) goto L_0x0013
            L_0x0010:
                r0 = 3
                goto L_0x012b
            L_0x0013:
                int r9 = r8.getTop()
                long r3 = java.lang.System.currentTimeMillis()
                long r5 = r7.f4347a
                long r3 = r3 - r5
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r10 = r10.X0()
                if (r10 == 0) goto L_0x0038
                float r9 = (float) r9
                r10 = 1120403456(0x42c80000, float:100.0)
                float r9 = r9 * r10
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r10.f4301V
                float r0 = (float) r0
                float r9 = r9 / r0
                boolean r9 = r10.U0(r3, r9)
                if (r9 == 0) goto L_0x00ae
                goto L_0x0010
            L_0x0038:
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r10 = r10.f4285F
                if (r9 <= r10) goto L_0x0010
                goto L_0x012b
            L_0x0040:
                com.google.android.material.bottomsheet.BottomSheetBehavior r4 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r5 = r4.f4289J
                if (r5 == 0) goto L_0x0095
                boolean r4 = r4.W0(r8, r10)
                if (r4 == 0) goto L_0x0095
                float r9 = java.lang.Math.abs(r9)
                float r2 = java.lang.Math.abs(r10)
                int r9 = (r9 > r2 ? 1 : (r9 == r2 ? 0 : -1))
                if (r9 >= 0) goto L_0x0063
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r9 = r9.f4314e
                float r9 = (float) r9
                int r9 = (r10 > r9 ? 1 : (r10 == r9 ? 0 : -1))
                if (r9 > 0) goto L_0x0069
            L_0x0063:
                boolean r9 = r7.n(r8)
                if (r9 == 0) goto L_0x006c
            L_0x0069:
                r0 = 5
                goto L_0x012b
            L_0x006c:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.f4308b
                if (r9 == 0) goto L_0x0075
                goto L_0x0010
            L_0x0075:
                int r9 = r8.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r10 = r10.q0()
                int r9 = r9 - r10
                int r9 = java.lang.Math.abs(r9)
                int r10 = r8.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r2 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r2 = r2.f4285F
                int r10 = r10 - r2
                int r10 = java.lang.Math.abs(r10)
                if (r9 >= r10) goto L_0x012b
                goto L_0x0010
            L_0x0095:
                int r3 = (r10 > r3 ? 1 : (r10 == r3 ? 0 : -1))
                if (r3 == 0) goto L_0x00d3
                float r9 = java.lang.Math.abs(r9)
                float r10 = java.lang.Math.abs(r10)
                int r9 = (r9 > r10 ? 1 : (r9 == r10 ? 0 : -1))
                if (r9 <= 0) goto L_0x00a6
                goto L_0x00d3
            L_0x00a6:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.f4308b
                if (r9 == 0) goto L_0x00b1
            L_0x00ae:
                r0 = 4
                goto L_0x012b
            L_0x00b1:
                int r9 = r8.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r10 = r10.f4285F
                int r10 = r9 - r10
                int r10 = java.lang.Math.abs(r10)
                com.google.android.material.bottomsheet.BottomSheetBehavior r1 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r1 = r1.f4287H
                int r9 = r9 - r1
                int r9 = java.lang.Math.abs(r9)
                if (r10 >= r9) goto L_0x00ae
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.X0()
                if (r9 == 0) goto L_0x012b
                goto L_0x00ae
            L_0x00d3:
                int r9 = r8.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r10 = r10.f4308b
                if (r10 == 0) goto L_0x00f6
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r10 = r10.f4284E
                int r10 = r9 - r10
                int r10 = java.lang.Math.abs(r10)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.f4287H
                int r9 = r9 - r0
                int r9 = java.lang.Math.abs(r9)
                if (r10 >= r9) goto L_0x00ae
                goto L_0x0010
            L_0x00f6:
                com.google.android.material.bottomsheet.BottomSheetBehavior r10 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r3 = r10.f4285F
                if (r9 >= r3) goto L_0x0111
                int r10 = r10.f4287H
                int r10 = r9 - r10
                int r10 = java.lang.Math.abs(r10)
                if (r9 >= r10) goto L_0x0108
                goto L_0x0010
            L_0x0108:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.X0()
                if (r9 == 0) goto L_0x012b
                goto L_0x00ae
            L_0x0111:
                int r10 = r9 - r3
                int r10 = java.lang.Math.abs(r10)
                com.google.android.material.bottomsheet.BottomSheetBehavior r1 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r1 = r1.f4287H
                int r9 = r9 - r1
                int r9 = java.lang.Math.abs(r9)
                if (r10 >= r9) goto L_0x00ae
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r9.X0()
                if (r9 == 0) goto L_0x012b
                goto L_0x00ae
            L_0x012b:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r10 = r9.Y0()
                r9.Z0(r8, r0, r10)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.e.l(android.view.View, float, float):void");
        }

        public boolean m(View view, int i2) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i3 = bottomSheetBehavior.f4292M;
            if (i3 == 1 || bottomSheetBehavior.f4315e0) {
                return false;
            }
            if (i3 == 3 && bottomSheetBehavior.f4311c0 == i2) {
                WeakReference weakReference = bottomSheetBehavior.f4304Y;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            this.f4347a = System.currentTimeMillis();
            WeakReference weakReference2 = BottomSheetBehavior.this.f4302W;
            return weakReference2 != null && weakReference2.get() == view;
        }
    }

    class f implements L {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f4349a;

        f(int i2) {
            this.f4349a = i2;
        }

        public boolean a(View view, L.a aVar) {
            BottomSheetBehavior.this.R0(this.f4349a);
            return true;
        }
    }

    protected static class g extends C.a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        final int f4351c;

        /* renamed from: d  reason: collision with root package name */
        int f4352d;

        /* renamed from: e  reason: collision with root package name */
        boolean f4353e;

        /* renamed from: f  reason: collision with root package name */
        boolean f4354f;

        /* renamed from: g  reason: collision with root package name */
        boolean f4355g;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            /* renamed from: c */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f4351c = parcel.readInt();
            this.f4352d = parcel.readInt();
            boolean z2 = false;
            this.f4353e = parcel.readInt() == 1;
            this.f4354f = parcel.readInt() == 1;
            this.f4355g = parcel.readInt() == 1 ? true : z2;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f4351c);
            parcel.writeInt(this.f4352d);
            parcel.writeInt(this.f4353e ? 1 : 0);
            parcel.writeInt(this.f4354f ? 1 : 0);
            parcel.writeInt(this.f4355g ? 1 : 0);
        }

        public g(Parcelable parcelable, BottomSheetBehavior bottomSheetBehavior) {
            super(parcelable);
            this.f4351c = bottomSheetBehavior.f4292M;
            this.f4352d = bottomSheetBehavior.f4316f;
            this.f4353e = bottomSheetBehavior.f4308b;
            this.f4354f = bottomSheetBehavior.f4289J;
            this.f4355g = bottomSheetBehavior.f4290K;
        }
    }

    private class h {
        /* access modifiers changed from: private */

        /* renamed from: a  reason: collision with root package name */
        public int f4356a;
        /* access modifiers changed from: private */

        /* renamed from: b  reason: collision with root package name */
        public boolean f4357b;

        /* renamed from: c  reason: collision with root package name */
        private final Runnable f4358c;

        class a implements Runnable {
            a() {
            }

            public void run() {
                boolean unused = h.this.f4357b = false;
                D.c cVar = BottomSheetBehavior.this.f4294O;
                if (cVar == null || !cVar.m(true)) {
                    h hVar = h.this;
                    BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                    if (bottomSheetBehavior.f4292M == 2) {
                        bottomSheetBehavior.S0(hVar.f4356a);
                        return;
                    }
                    return;
                }
                h hVar2 = h.this;
                hVar2.c(hVar2.f4356a);
            }
        }

        private h() {
            this.f4358c = new a();
        }

        /* access modifiers changed from: package-private */
        public void c(int i2) {
            WeakReference weakReference = BottomSheetBehavior.this.f4302W;
            if (weakReference != null && weakReference.get() != null) {
                this.f4356a = i2;
                if (!this.f4357b) {
                    W.i0((View) BottomSheetBehavior.this.f4302W.get(), this.f4358c);
                    this.f4357b = true;
                }
            }
        }

        /* synthetic */ h(BottomSheetBehavior bottomSheetBehavior, a aVar) {
            this();
        }
    }

    public BottomSheetBehavior() {
    }

    private void A0(View view, I.a aVar, int i2) {
        W.m0(view, aVar, (CharSequence) null, k0(i2));
    }

    private void B0() {
        this.f4311c0 = -1;
        this.f4313d0 = -1;
        VelocityTracker velocityTracker = this.f4307a0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f4307a0 = null;
        }
    }

    private void C0(g gVar) {
        int i2 = this.f4306a;
        if (i2 != 0) {
            if (i2 == -1 || (i2 & 1) == 1) {
                this.f4316f = gVar.f4352d;
            }
            if (i2 == -1 || (i2 & 2) == 2) {
                this.f4308b = gVar.f4353e;
            }
            if (i2 == -1 || (i2 & 4) == 4) {
                this.f4289J = gVar.f4354f;
            }
            if (i2 == -1 || (i2 & 8) == 8) {
                this.f4290K = gVar.f4355g;
            }
        }
    }

    private void D0(View view, Runnable runnable) {
        if (y0(view)) {
            view.post(runnable);
        } else {
            runnable.run();
        }
    }

    private void T0(View view) {
        boolean z2 = Build.VERSION.SDK_INT >= 29 && !v0() && !this.f4318g;
        if (this.f4329p || this.f4330q || this.f4331r || this.f4333t || this.f4334u || this.f4335v || z2) {
            B.b(view, new d(z2));
        }
    }

    private boolean V0() {
        return this.f4294O != null && (this.f4291L || this.f4292M == 1);
    }

    /* access modifiers changed from: private */
    public void Z0(View view, int i2, boolean z2) {
        int r02 = r0(i2);
        D.c cVar = this.f4294O;
        if (cVar == null || (!z2 ? !cVar.Q(view, view.getLeft(), r02) : !cVar.O(view.getLeft(), r02))) {
            S0(i2);
            return;
        }
        S0(2);
        c1(i2, true);
        this.f4281B.c(i2);
    }

    private void a1() {
        WeakReference weakReference = this.f4302W;
        if (weakReference != null) {
            b1((View) weakReference.get(), 0);
        }
        WeakReference weakReference2 = this.f4303X;
        if (weakReference2 != null) {
            b1((View) weakReference2.get(), 1);
        }
    }

    private int b0(View view, int i2, int i3) {
        return W.c(view, view.getResources().getString(i2), k0(i3));
    }

    private void b1(View view, int i2) {
        I.a aVar;
        if (view != null) {
            j0(view, i2);
            int i3 = 6;
            if (!this.f4308b && this.f4292M != 6) {
                this.f4319g0.put(i2, b0(view, T.h.bottomsheet_action_expand_halfway, 6));
            }
            if (this.f4289J && x0() && this.f4292M != 5) {
                A0(view, I.a.f6382y, 5);
            }
            int i4 = this.f4292M;
            if (i4 == 3) {
                if (this.f4308b) {
                    i3 = 4;
                }
                aVar = I.a.f6381x;
            } else if (i4 == 4) {
                if (this.f4308b) {
                    i3 = 3;
                }
                aVar = I.a.f6380w;
            } else if (i4 == 6) {
                A0(view, I.a.f6381x, 4);
                A0(view, I.a.f6380w, 3);
                return;
            } else {
                return;
            }
            A0(view, aVar, i3);
        }
    }

    private void c0() {
        int g02 = g0();
        if (this.f4308b) {
            this.f4287H = Math.max(this.f4301V - g02, this.f4284E);
        } else {
            this.f4287H = this.f4301V - g02;
        }
    }

    private void c1(int i2, boolean z2) {
        boolean u02;
        ValueAnimator valueAnimator;
        if (i2 != 2 && this.f4280A != (u02 = u0()) && this.f4323j != null) {
            this.f4280A = u02;
            float f2 = 1.0f;
            if (!z2 || (valueAnimator = this.f4282C) == null) {
                ValueAnimator valueAnimator2 = this.f4282C;
                if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                    this.f4282C.cancel();
                }
                k0.g gVar = this.f4323j;
                if (this.f4280A) {
                    f2 = f0();
                }
                gVar.U(f2);
            } else if (valueAnimator.isRunning()) {
                this.f4282C.reverse();
            } else {
                float w2 = this.f4323j.w();
                if (u02) {
                    f2 = f0();
                }
                this.f4282C.setFloatValues(new float[]{w2, f2});
                this.f4282C.start();
            }
        }
    }

    private float d0(float f2, RoundedCorner roundedCorner) {
        if (roundedCorner != null) {
            float a2 = (float) roundedCorner.getRadius();
            if (a2 > 0.0f && f2 > 0.0f) {
                return a2 / f2;
            }
        }
        return 0.0f;
    }

    private void d1(boolean z2) {
        Map map;
        int intValue;
        WeakReference weakReference = this.f4302W;
        if (weakReference != null) {
            ViewParent parent = ((View) weakReference.get()).getParent();
            if (parent instanceof CoordinatorLayout) {
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
                int childCount = coordinatorLayout.getChildCount();
                if (z2) {
                    if (this.f4317f0 == null) {
                        this.f4317f0 = new HashMap(childCount);
                    } else {
                        return;
                    }
                }
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = coordinatorLayout.getChildAt(i2);
                    if (childAt != this.f4302W.get()) {
                        if (z2) {
                            this.f4317f0.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                            if (this.f4310c) {
                                intValue = 4;
                            }
                        } else if (this.f4310c && (map = this.f4317f0) != null && map.containsKey(childAt)) {
                            intValue = ((Integer) this.f4317f0.get(childAt)).intValue();
                        }
                        W.y0(childAt, intValue);
                    }
                }
                if (!z2) {
                    this.f4317f0 = null;
                } else if (this.f4310c) {
                    ((View) this.f4302W.get()).sendAccessibilityEvent(8);
                }
            }
        }
    }

    private void e0() {
        this.f4285F = (int) (((float) this.f4301V) * (1.0f - this.f4286G));
    }

    /* access modifiers changed from: private */
    public void e1(boolean z2) {
        View view;
        if (this.f4302W != null) {
            c0();
            if (this.f4292M == 4 && (view = (View) this.f4302W.get()) != null) {
                if (z2) {
                    R0(4);
                } else {
                    view.requestLayout();
                }
            }
        }
    }

    private float f0() {
        WeakReference weakReference;
        WindowInsets a2;
        if (this.f4323j == null || (weakReference = this.f4302W) == null || weakReference.get() == null || Build.VERSION.SDK_INT < 31) {
            return 0.0f;
        }
        View view = (View) this.f4302W.get();
        if (!t0() || (a2 = view.getRootWindowInsets()) == null) {
            return 0.0f;
        }
        return Math.max(d0(this.f4323j.C(), a2.getRoundedCorner(0)), d0(this.f4323j.D(), a2.getRoundedCorner(1)));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0025, code lost:
        r0 = r3.f4327n;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int g0() {
        /*
            r3 = this;
            boolean r0 = r3.f4318g
            if (r0 == 0) goto L_0x001d
            int r0 = r3.f4320h
            int r1 = r3.f4301V
            int r2 = r3.f4300U
            int r2 = r2 * 9
            int r2 = r2 / 16
            int r1 = r1 - r2
            int r0 = java.lang.Math.max(r0, r1)
            int r1 = r3.f4299T
            int r0 = java.lang.Math.min(r0, r1)
            int r1 = r3.f4336w
            int r0 = r0 + r1
            return r0
        L_0x001d:
            boolean r0 = r3.f4328o
            if (r0 != 0) goto L_0x0033
            boolean r0 = r3.f4329p
            if (r0 != 0) goto L_0x0033
            int r0 = r3.f4327n
            if (r0 <= 0) goto L_0x0033
            int r1 = r3.f4316f
            int r2 = r3.f4322i
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r1, r0)
            return r0
        L_0x0033:
            int r0 = r3.f4316f
            int r1 = r3.f4336w
            int r0 = r0 + r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.g0():int");
    }

    private float h0(int i2) {
        float f2;
        float f3;
        int i3 = this.f4287H;
        if (i2 > i3 || i3 == q0()) {
            int i4 = this.f4287H;
            f2 = (float) (i4 - i2);
            f3 = (float) (this.f4301V - i4);
        } else {
            int i5 = this.f4287H;
            f2 = (float) (i5 - i2);
            f3 = (float) (i5 - q0());
        }
        return f2 / f3;
    }

    /* access modifiers changed from: private */
    public boolean i0() {
        return w0() && x0();
    }

    private void j0(View view, int i2) {
        if (view != null) {
            W.k0(view, 524288);
            W.k0(view, 262144);
            W.k0(view, 1048576);
            int i3 = this.f4319g0.get(i2, -1);
            if (i3 != -1) {
                W.k0(view, i3);
                this.f4319g0.delete(i2);
            }
        }
    }

    private L k0(int i2) {
        return new f(i2);
    }

    private void l0(Context context) {
        if (this.f4339z != null) {
            k0.g gVar = new k0.g(this.f4339z);
            this.f4323j = gVar;
            gVar.J(context);
            ColorStateList colorStateList = this.f4324k;
            if (colorStateList != null) {
                this.f4323j.T(colorStateList);
                return;
            }
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(16842801, typedValue, true);
            this.f4323j.setTint(typedValue.data);
        }
    }

    private void m0() {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(new float[]{f0(), 1.0f});
        this.f4282C = ofFloat;
        ofFloat.setDuration(500);
        this.f4282C.addUpdateListener(new c());
    }

    private int p0(int i2, int i3, int i4, int i5) {
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, i3, i5);
        if (i4 == -1) {
            return childMeasureSpec;
        }
        int mode = View.MeasureSpec.getMode(childMeasureSpec);
        int size = View.MeasureSpec.getSize(childMeasureSpec);
        if (mode == 1073741824) {
            return View.MeasureSpec.makeMeasureSpec(Math.min(size, i4), 1073741824);
        }
        if (size != 0) {
            i4 = Math.min(size, i4);
        }
        return View.MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE);
    }

    private int r0(int i2) {
        if (i2 == 3) {
            return q0();
        }
        if (i2 == 4) {
            return this.f4287H;
        }
        if (i2 == 5) {
            return this.f4301V;
        }
        if (i2 == 6) {
            return this.f4285F;
        }
        throw new IllegalArgumentException("Invalid state to get top offset: " + i2);
    }

    private float s0() {
        VelocityTracker velocityTracker = this.f4307a0;
        if (velocityTracker == null) {
            return 0.0f;
        }
        velocityTracker.computeCurrentVelocity(1000, this.f4312d);
        return this.f4307a0.getYVelocity(this.f4311c0);
    }

    private boolean t0() {
        WeakReference weakReference = this.f4302W;
        if (weakReference == null || weakReference.get() == null) {
            return false;
        }
        int[] iArr = new int[2];
        ((View) this.f4302W.get()).getLocationOnScreen(iArr);
        return iArr[1] == 0;
    }

    private boolean u0() {
        return this.f4292M == 3 && (this.f4338y || t0());
    }

    private boolean y0(View view) {
        ViewParent parent = view.getParent();
        return parent != null && parent.isLayoutRequested() && W.T(view);
    }

    public void B(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
        g gVar = (g) parcelable;
        super.B(coordinatorLayout, view, gVar.c());
        C0(gVar);
        int i2 = gVar.f4351c;
        if (i2 == 1 || i2 == 2) {
            i2 = 4;
        }
        this.f4292M = i2;
        this.f4293N = i2;
    }

    public Parcelable C(CoordinatorLayout coordinatorLayout, View view) {
        return new g(super.C(coordinatorLayout, view), this);
    }

    public boolean E(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
        this.f4296Q = 0;
        this.f4297R = false;
        return (i2 & 2) != 0;
    }

    public void E0(boolean z2) {
        this.f4291L = z2;
    }

    public void F0(int i2) {
        if (i2 >= 0) {
            this.f4283D = i2;
            c1(this.f4292M, true);
            return;
        }
        throw new IllegalArgumentException("offset must be greater than or equal to 0");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0035, code lost:
        if (r4.getTop() <= r2.f4285F) goto L_0x00aa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0065, code lost:
        if (java.lang.Math.abs(r3 - r2.f4284E) < java.lang.Math.abs(r3 - r2.f4287H)) goto L_0x00aa;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x007b, code lost:
        if (X0() != false) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x008b, code lost:
        if (java.lang.Math.abs(r3 - r1) < java.lang.Math.abs(r3 - r2.f4287H)) goto L_0x00a9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00a7, code lost:
        if (java.lang.Math.abs(r3 - r2.f4285F) < java.lang.Math.abs(r3 - r2.f4287H)) goto L_0x00a9;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void G(androidx.coordinatorlayout.widget.CoordinatorLayout r3, android.view.View r4, android.view.View r5, int r6) {
        /*
            r2 = this;
            int r3 = r4.getTop()
            int r6 = r2.q0()
            r0 = 3
            if (r3 != r6) goto L_0x000f
            r2.S0(r0)
            return
        L_0x000f:
            boolean r3 = r2.z0()
            if (r3 == 0) goto L_0x0024
            java.lang.ref.WeakReference r3 = r2.f4304Y
            if (r3 == 0) goto L_0x0023
            java.lang.Object r3 = r3.get()
            if (r5 != r3) goto L_0x0023
            boolean r3 = r2.f4297R
            if (r3 != 0) goto L_0x0024
        L_0x0023:
            return
        L_0x0024:
            int r3 = r2.f4296Q
            r5 = 6
            if (r3 <= 0) goto L_0x0039
            boolean r3 = r2.f4308b
            if (r3 == 0) goto L_0x002f
            goto L_0x00aa
        L_0x002f:
            int r3 = r4.getTop()
            int r6 = r2.f4285F
            if (r3 <= r6) goto L_0x00aa
            goto L_0x00a9
        L_0x0039:
            boolean r3 = r2.f4289J
            if (r3 == 0) goto L_0x0049
            float r3 = r2.s0()
            boolean r3 = r2.W0(r4, r3)
            if (r3 == 0) goto L_0x0049
            r0 = 5
            goto L_0x00aa
        L_0x0049:
            int r3 = r2.f4296Q
            r6 = 4
            if (r3 != 0) goto L_0x008e
            int r3 = r4.getTop()
            boolean r1 = r2.f4308b
            if (r1 == 0) goto L_0x0068
            int r5 = r2.f4284E
            int r5 = r3 - r5
            int r5 = java.lang.Math.abs(r5)
            int r1 = r2.f4287H
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r5 >= r3) goto L_0x0092
            goto L_0x00aa
        L_0x0068:
            int r1 = r2.f4285F
            if (r3 >= r1) goto L_0x007e
            int r1 = r2.f4287H
            int r1 = r3 - r1
            int r1 = java.lang.Math.abs(r1)
            if (r3 >= r1) goto L_0x0077
            goto L_0x00aa
        L_0x0077:
            boolean r3 = r2.X0()
            if (r3 == 0) goto L_0x00a9
            goto L_0x0092
        L_0x007e:
            int r0 = r3 - r1
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.f4287H
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L_0x0092
            goto L_0x00a9
        L_0x008e:
            boolean r3 = r2.f4308b
            if (r3 == 0) goto L_0x0094
        L_0x0092:
            r0 = 4
            goto L_0x00aa
        L_0x0094:
            int r3 = r4.getTop()
            int r0 = r2.f4285F
            int r0 = r3 - r0
            int r0 = java.lang.Math.abs(r0)
            int r1 = r2.f4287H
            int r3 = r3 - r1
            int r3 = java.lang.Math.abs(r3)
            if (r0 >= r3) goto L_0x0092
        L_0x00a9:
            r0 = 6
        L_0x00aa:
            r3 = 0
            r2.Z0(r4, r0, r3)
            r2.f4297R = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.G(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    public void G0(boolean z2) {
        if (this.f4308b != z2) {
            this.f4308b = z2;
            if (this.f4302W != null) {
                c0();
            }
            S0((!this.f4308b || this.f4292M != 6) ? this.f4292M : 3);
            c1(this.f4292M, true);
            a1();
        }
    }

    public boolean H(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        if (!view.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f4292M == 1 && actionMasked == 0) {
            return true;
        }
        if (V0()) {
            this.f4294O.F(motionEvent);
        }
        if (actionMasked == 0) {
            B0();
        }
        if (this.f4307a0 == null) {
            this.f4307a0 = VelocityTracker.obtain();
        }
        this.f4307a0.addMovement(motionEvent);
        if (V0() && actionMasked == 2 && !this.f4295P && Math.abs(((float) this.f4313d0) - motionEvent.getY()) > ((float) this.f4294O.z())) {
            this.f4294O.b(view, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.f4295P;
    }

    public void H0(boolean z2) {
        this.f4328o = z2;
    }

    public void I0(float f2) {
        if (f2 <= 0.0f || f2 >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.f4286G = f2;
        if (this.f4302W != null) {
            e0();
        }
    }

    public void J0(boolean z2) {
        if (this.f4289J != z2) {
            this.f4289J = z2;
            if (!z2 && this.f4292M == 5) {
                R0(4);
            }
            a1();
        }
    }

    public void K0(int i2) {
        this.f4326m = i2;
    }

    public void L0(int i2) {
        this.f4325l = i2;
    }

    public void M0(int i2) {
        N0(i2, false);
    }

    public final void N0(int i2, boolean z2) {
        if (i2 == -1) {
            if (!this.f4318g) {
                this.f4318g = true;
            } else {
                return;
            }
        } else if (this.f4318g || this.f4316f != i2) {
            this.f4318g = false;
            this.f4316f = Math.max(0, i2);
        } else {
            return;
        }
        e1(z2);
    }

    public void O0(int i2) {
        this.f4306a = i2;
    }

    public void P0(int i2) {
        this.f4314e = i2;
    }

    public void Q0(boolean z2) {
        this.f4290K = z2;
    }

    public void R0(int i2) {
        if (i2 == 1 || i2 == 2) {
            StringBuilder sb = new StringBuilder();
            sb.append("STATE_");
            sb.append(i2 == 1 ? "DRAGGING" : "SETTLING");
            sb.append(" should not be set externally.");
            throw new IllegalArgumentException(sb.toString());
        } else if (this.f4289J || i2 != 5) {
            int i3 = (i2 != 6 || !this.f4308b || r0(i2) > this.f4284E) ? i2 : 3;
            WeakReference weakReference = this.f4302W;
            if (weakReference == null || weakReference.get() == null) {
                S0(i2);
                return;
            }
            View view = (View) this.f4302W.get();
            D0(view, new a(view, i3));
        } else {
            Log.w("BottomSheetBehavior", "Cannot set state: " + i2);
        }
    }

    /* access modifiers changed from: package-private */
    public void S0(int i2) {
        if (this.f4292M != i2) {
            this.f4292M = i2;
            if (i2 == 4 || i2 == 3 || i2 == 6 || (this.f4289J && i2 == 5)) {
                this.f4293N = i2;
            }
            WeakReference weakReference = this.f4302W;
            if (weakReference != null && ((View) weakReference.get()) != null) {
                if (i2 == 3) {
                    d1(true);
                } else if (i2 == 6 || i2 == 5 || i2 == 4) {
                    d1(false);
                }
                c1(i2, true);
                if (this.f4305Z.size() <= 0) {
                    a1();
                } else {
                    android.support.v4.media.session.b.a(this.f4305Z.get(0));
                    throw null;
                }
            }
        }
    }

    public boolean U0(long j2, float f2) {
        return false;
    }

    /* access modifiers changed from: package-private */
    public boolean W0(View view, float f2) {
        if (this.f4290K) {
            return true;
        }
        if (!x0() || view.getTop() < this.f4287H) {
            return false;
        }
        return Math.abs((((float) view.getTop()) + (f2 * this.f4298S)) - ((float) this.f4287H)) / ((float) g0()) > 0.5f;
    }

    public boolean X0() {
        return false;
    }

    public boolean Y0() {
        return true;
    }

    public void a() {
        f0.f fVar = this.f4309b0;
        if (fVar != null) {
            androidx.activity.b c2 = fVar.c();
            int i2 = 4;
            if (c2 == null || Build.VERSION.SDK_INT < 34) {
                if (this.f4289J) {
                    i2 = 5;
                }
                R0(i2);
            } else if (this.f4289J) {
                this.f4309b0.h(c2, new b());
            } else {
                this.f4309b0.i(c2, (Animator.AnimatorListener) null);
                R0(4);
            }
        }
    }

    public void b(androidx.activity.b bVar) {
        f0.f fVar = this.f4309b0;
        if (fVar != null) {
            fVar.j(bVar);
        }
    }

    public void c(androidx.activity.b bVar) {
        f0.f fVar = this.f4309b0;
        if (fVar != null) {
            fVar.l(bVar);
        }
    }

    public void d() {
        f0.f fVar = this.f4309b0;
        if (fVar != null) {
            fVar.f();
        }
    }

    public void k(CoordinatorLayout.e eVar) {
        super.k(eVar);
        this.f4302W = null;
        this.f4294O = null;
        this.f4309b0 = null;
    }

    public void n() {
        super.n();
        this.f4302W = null;
        this.f4294O = null;
        this.f4309b0 = null;
    }

    /* access modifiers changed from: package-private */
    public void n0(int i2) {
        if (((View) this.f4302W.get()) != null && !this.f4305Z.isEmpty()) {
            h0(i2);
            if (this.f4305Z.size() > 0) {
                android.support.v4.media.session.b.a(this.f4305Z.get(0));
                throw null;
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v11, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean o(androidx.coordinatorlayout.widget.CoordinatorLayout r10, android.view.View r11, android.view.MotionEvent r12) {
        /*
            r9 = this;
            boolean r0 = r11.isShown()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x00d4
            boolean r0 = r9.f4291L
            if (r0 != 0) goto L_0x000e
            goto L_0x00d4
        L_0x000e:
            int r0 = r12.getActionMasked()
            if (r0 != 0) goto L_0x0017
            r9.B0()
        L_0x0017:
            android.view.VelocityTracker r3 = r9.f4307a0
            if (r3 != 0) goto L_0x0021
            android.view.VelocityTracker r3 = android.view.VelocityTracker.obtain()
            r9.f4307a0 = r3
        L_0x0021:
            android.view.VelocityTracker r3 = r9.f4307a0
            r3.addMovement(r12)
            r3 = 0
            r4 = 2
            r5 = -1
            if (r0 == 0) goto L_0x003c
            if (r0 == r2) goto L_0x0031
            r11 = 3
            if (r0 == r11) goto L_0x0031
            goto L_0x007f
        L_0x0031:
            r9.f4315e0 = r1
            r9.f4311c0 = r5
            boolean r11 = r9.f4295P
            if (r11 == 0) goto L_0x007f
            r9.f4295P = r1
            return r1
        L_0x003c:
            float r6 = r12.getX()
            int r6 = (int) r6
            float r7 = r12.getY()
            int r7 = (int) r7
            r9.f4313d0 = r7
            int r7 = r9.f4292M
            if (r7 == r4) goto L_0x006e
            java.lang.ref.WeakReference r7 = r9.f4304Y
            if (r7 == 0) goto L_0x0057
            java.lang.Object r7 = r7.get()
            android.view.View r7 = (android.view.View) r7
            goto L_0x0058
        L_0x0057:
            r7 = r3
        L_0x0058:
            if (r7 == 0) goto L_0x006e
            int r8 = r9.f4313d0
            boolean r7 = r10.z(r7, r6, r8)
            if (r7 == 0) goto L_0x006e
            int r7 = r12.getActionIndex()
            int r7 = r12.getPointerId(r7)
            r9.f4311c0 = r7
            r9.f4315e0 = r2
        L_0x006e:
            int r7 = r9.f4311c0
            if (r7 != r5) goto L_0x007c
            int r7 = r9.f4313d0
            boolean r11 = r10.z(r11, r6, r7)
            if (r11 != 0) goto L_0x007c
            r11 = 1
            goto L_0x007d
        L_0x007c:
            r11 = 0
        L_0x007d:
            r9.f4295P = r11
        L_0x007f:
            boolean r11 = r9.f4295P
            if (r11 != 0) goto L_0x008e
            D.c r11 = r9.f4294O
            if (r11 == 0) goto L_0x008e
            boolean r11 = r11.P(r12)
            if (r11 == 0) goto L_0x008e
            return r2
        L_0x008e:
            java.lang.ref.WeakReference r11 = r9.f4304Y
            if (r11 == 0) goto L_0x0099
            java.lang.Object r11 = r11.get()
            r3 = r11
            android.view.View r3 = (android.view.View) r3
        L_0x0099:
            if (r0 != r4) goto L_0x00d3
            if (r3 == 0) goto L_0x00d3
            boolean r11 = r9.f4295P
            if (r11 != 0) goto L_0x00d3
            int r11 = r9.f4292M
            if (r11 == r2) goto L_0x00d3
            float r11 = r12.getX()
            int r11 = (int) r11
            float r0 = r12.getY()
            int r0 = (int) r0
            boolean r10 = r10.z(r3, r11, r0)
            if (r10 != 0) goto L_0x00d3
            D.c r10 = r9.f4294O
            if (r10 == 0) goto L_0x00d3
            int r10 = r9.f4313d0
            if (r10 == r5) goto L_0x00d3
            float r10 = (float) r10
            float r11 = r12.getY()
            float r10 = r10 - r11
            float r10 = java.lang.Math.abs(r10)
            D.c r11 = r9.f4294O
            int r11 = r11.z()
            float r11 = (float) r11
            int r10 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r10 <= 0) goto L_0x00d3
            r1 = 1
        L_0x00d3:
            return r1
        L_0x00d4:
            r9.f4295P = r2
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.o(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    public View o0(View view) {
        if (view.getVisibility() != 0) {
            return null;
        }
        if (W.V(view)) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View o02 = o0(viewGroup.getChildAt(i2));
                if (o02 != null) {
                    return o02;
                }
            }
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0099, code lost:
        if (r5 == -1) goto L_0x00a0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00a6, code lost:
        if (r5 == -1) goto L_0x00a0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0103 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0104  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean p(androidx.coordinatorlayout.widget.CoordinatorLayout r5, android.view.View r6, int r7) {
        /*
            r4 = this;
            boolean r0 = androidx.core.view.W.z(r5)
            r1 = 1
            if (r0 == 0) goto L_0x0010
            boolean r0 = androidx.core.view.W.z(r6)
            if (r0 != 0) goto L_0x0010
            r6.setFitsSystemWindows(r1)
        L_0x0010:
            java.lang.ref.WeakReference r0 = r4.f4302W
            if (r0 != 0) goto L_0x0065
            android.content.res.Resources r0 = r5.getResources()
            int r2 = T.c.design_bottom_sheet_peek_height_min
            int r0 = r0.getDimensionPixelSize(r2)
            r4.f4320h = r0
            r4.T0(r6)
            com.google.android.material.bottomsheet.a r0 = new com.google.android.material.bottomsheet.a
            r0.<init>(r6)
            androidx.core.view.W.H0(r6, r0)
            java.lang.ref.WeakReference r0 = new java.lang.ref.WeakReference
            r0.<init>(r6)
            r4.f4302W = r0
            f0.f r0 = new f0.f
            r0.<init>(r6)
            r4.f4309b0 = r0
            k0.g r0 = r4.f4323j
            if (r0 == 0) goto L_0x0052
            androidx.core.view.W.u0(r6, r0)
            k0.g r0 = r4.f4323j
            float r2 = r4.f4288I
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r3 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r3 != 0) goto L_0x004e
            float r2 = androidx.core.view.W.w(r6)
        L_0x004e:
            r0.S(r2)
            goto L_0x0059
        L_0x0052:
            android.content.res.ColorStateList r0 = r4.f4324k
            if (r0 == 0) goto L_0x0059
            androidx.core.view.W.v0(r6, r0)
        L_0x0059:
            r4.a1()
            int r0 = androidx.core.view.W.A(r6)
            if (r0 != 0) goto L_0x0065
            androidx.core.view.W.y0(r6, r1)
        L_0x0065:
            D.c r0 = r4.f4294O
            if (r0 != 0) goto L_0x0071
            D.c$c r0 = r4.f4321h0
            D.c r0 = D.c.o(r5, r0)
            r4.f4294O = r0
        L_0x0071:
            int r0 = r6.getTop()
            r5.G(r6, r7)
            int r7 = r5.getWidth()
            r4.f4300U = r7
            int r5 = r5.getHeight()
            r4.f4301V = r5
            int r5 = r6.getHeight()
            r4.f4299T = r5
            int r7 = r4.f4301V
            int r5 = r7 - r5
            int r2 = r4.f4337x
            if (r5 >= r2) goto L_0x00a9
            boolean r5 = r4.f4332s
            r3 = -1
            if (r5 == 0) goto L_0x00a3
            int r5 = r4.f4326m
            if (r5 != r3) goto L_0x009c
            goto L_0x00a0
        L_0x009c:
            int r7 = java.lang.Math.min(r7, r5)
        L_0x00a0:
            r4.f4299T = r7
            goto L_0x00a9
        L_0x00a3:
            int r7 = r7 - r2
            int r5 = r4.f4326m
            if (r5 != r3) goto L_0x009c
            goto L_0x00a0
        L_0x00a9:
            int r5 = r4.f4301V
            int r7 = r4.f4299T
            int r5 = r5 - r7
            r7 = 0
            int r5 = java.lang.Math.max(r7, r5)
            r4.f4284E = r5
            r4.e0()
            r4.c0()
            int r5 = r4.f4292M
            r2 = 3
            if (r5 != r2) goto L_0x00c8
            int r5 = r4.q0()
        L_0x00c4:
            androidx.core.view.W.b0(r6, r5)
            goto L_0x00eb
        L_0x00c8:
            r2 = 6
            if (r5 != r2) goto L_0x00ce
            int r5 = r4.f4285F
            goto L_0x00c4
        L_0x00ce:
            boolean r2 = r4.f4289J
            if (r2 == 0) goto L_0x00d8
            r2 = 5
            if (r5 != r2) goto L_0x00d8
            int r5 = r4.f4301V
            goto L_0x00c4
        L_0x00d8:
            r2 = 4
            if (r5 != r2) goto L_0x00de
            int r5 = r4.f4287H
            goto L_0x00c4
        L_0x00de:
            if (r5 == r1) goto L_0x00e3
            r2 = 2
            if (r5 != r2) goto L_0x00eb
        L_0x00e3:
            int r5 = r6.getTop()
            int r0 = r0 - r5
            androidx.core.view.W.b0(r6, r0)
        L_0x00eb:
            int r5 = r4.f4292M
            r4.c1(r5, r7)
            java.lang.ref.WeakReference r5 = new java.lang.ref.WeakReference
            android.view.View r6 = r4.o0(r6)
            r5.<init>(r6)
            r4.f4304Y = r5
            java.util.ArrayList r5 = r4.f4305Z
            int r5 = r5.size()
            if (r5 > 0) goto L_0x0104
            return r1
        L_0x0104:
            java.util.ArrayList r5 = r4.f4305Z
            java.lang.Object r5 = r5.get(r7)
            android.support.v4.media.session.b.a(r5)
            r5 = 0
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.p(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, int):boolean");
    }

    public boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(p0(i2, coordinatorLayout.getPaddingLeft() + coordinatorLayout.getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, this.f4325l, marginLayoutParams.width), p0(i4, coordinatorLayout.getPaddingTop() + coordinatorLayout.getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, this.f4326m, marginLayoutParams.height));
        return true;
    }

    public int q0() {
        if (this.f4308b) {
            return this.f4284E;
        }
        return Math.max(this.f4283D, this.f4332s ? 0 : this.f4337x);
    }

    public boolean s(CoordinatorLayout coordinatorLayout, View view, View view2, float f2, float f3) {
        WeakReference weakReference;
        if (!z0() || (weakReference = this.f4304Y) == null || view2 != weakReference.get()) {
            return false;
        }
        return this.f4292M != 3 || super.s(coordinatorLayout, view, view2, f2, f3);
    }

    public void u(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int[] iArr, int i4) {
        int i5;
        if (i4 != 1) {
            WeakReference weakReference = this.f4304Y;
            View view3 = weakReference != null ? (View) weakReference.get() : null;
            if (!z0() || view2 == view3) {
                int top = view.getTop();
                int i6 = top - i3;
                if (i3 <= 0) {
                    if (i3 < 0 && !view2.canScrollVertically(-1)) {
                        if (i6 > this.f4287H && !i0()) {
                            int i7 = top - this.f4287H;
                            iArr[1] = i7;
                            W.b0(view, -i7);
                            i5 = 4;
                        } else if (this.f4291L) {
                            iArr[1] = i3;
                            W.b0(view, -i3);
                            S0(1);
                        } else {
                            return;
                        }
                    }
                    n0(view.getTop());
                    this.f4296Q = i3;
                    this.f4297R = true;
                } else if (i6 < q0()) {
                    int q02 = top - q0();
                    iArr[1] = q02;
                    W.b0(view, -q02);
                    i5 = 3;
                } else if (this.f4291L) {
                    iArr[1] = i3;
                    W.b0(view, -i3);
                    S0(1);
                    n0(view.getTop());
                    this.f4296Q = i3;
                    this.f4297R = true;
                } else {
                    return;
                }
                S0(i5);
                n0(view.getTop());
                this.f4296Q = i3;
                this.f4297R = true;
            }
        }
    }

    public boolean v0() {
        return this.f4328o;
    }

    public boolean w0() {
        return this.f4289J;
    }

    public void x(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
    }

    public boolean x0() {
        return true;
    }

    public boolean z0() {
        return true;
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i2;
        this.f4322i = context.getResources().getDimensionPixelSize(T.c.mtrl_min_touch_target_size);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.f249x);
        int i3 = j.f176B;
        if (obtainStyledAttributes.hasValue(i3)) {
            this.f4324k = h0.c.a(context, obtainStyledAttributes, i3);
        }
        if (obtainStyledAttributes.hasValue(j.f196T)) {
            this.f4339z = k.e(context, attributeSet, T.a.bottomSheetStyle, f4279i0).m();
        }
        l0(context);
        m0();
        this.f4288I = obtainStyledAttributes.getDimension(j.f174A, -1.0f);
        int i4 = j.f251y;
        if (obtainStyledAttributes.hasValue(i4)) {
            L0(obtainStyledAttributes.getDimensionPixelSize(i4, -1));
        }
        int i5 = j.f253z;
        if (obtainStyledAttributes.hasValue(i5)) {
            K0(obtainStyledAttributes.getDimensionPixelSize(i5, -1));
        }
        int i6 = j.f184H;
        TypedValue peekValue = obtainStyledAttributes.peekValue(i6);
        if (peekValue == null || (i2 = peekValue.data) != -1) {
            M0(obtainStyledAttributes.getDimensionPixelSize(i6, -1));
        } else {
            M0(i2);
        }
        J0(obtainStyledAttributes.getBoolean(j.f183G, false));
        H0(obtainStyledAttributes.getBoolean(j.f188L, false));
        G0(obtainStyledAttributes.getBoolean(j.f181E, true));
        Q0(obtainStyledAttributes.getBoolean(j.f187K, false));
        E0(obtainStyledAttributes.getBoolean(j.f178C, true));
        O0(obtainStyledAttributes.getInt(j.f185I, 0));
        I0(obtainStyledAttributes.getFloat(j.f182F, 0.5f));
        int i7 = j.f180D;
        TypedValue peekValue2 = obtainStyledAttributes.peekValue(i7);
        F0((peekValue2 == null || peekValue2.type != 16) ? obtainStyledAttributes.getDimensionPixelOffset(i7, 0) : peekValue2.data);
        P0(obtainStyledAttributes.getInt(j.f186J, 500));
        this.f4329p = obtainStyledAttributes.getBoolean(j.f192P, false);
        this.f4330q = obtainStyledAttributes.getBoolean(j.f193Q, false);
        this.f4331r = obtainStyledAttributes.getBoolean(j.f194R, false);
        this.f4332s = obtainStyledAttributes.getBoolean(j.f195S, true);
        this.f4333t = obtainStyledAttributes.getBoolean(j.f189M, false);
        this.f4334u = obtainStyledAttributes.getBoolean(j.f190N, false);
        this.f4335v = obtainStyledAttributes.getBoolean(j.f191O, false);
        this.f4338y = obtainStyledAttributes.getBoolean(j.f197U, true);
        obtainStyledAttributes.recycle();
        this.f4312d = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }
}
