package com.google.android.material.bottomsheet;

import android.view.View;
import androidx.core.view.C0140j0;
import androidx.core.view.C0165w0;
import java.util.Iterator;
import java.util.List;

class a extends C0140j0.b {

    /* renamed from: c  reason: collision with root package name */
    private final View f4361c;

    /* renamed from: d  reason: collision with root package name */
    private int f4362d;

    /* renamed from: e  reason: collision with root package name */
    private int f4363e;

    /* renamed from: f  reason: collision with root package name */
    private final int[] f4364f = new int[2];

    public a(View view) {
        super(0);
        this.f4361c = view;
    }

    public void b(C0140j0 j0Var) {
        this.f4361c.setTranslationY(0.0f);
    }

    public void c(C0140j0 j0Var) {
        this.f4361c.getLocationOnScreen(this.f4364f);
        this.f4362d = this.f4364f[1];
    }

    public C0165w0 d(C0165w0 w0Var, List list) {
        Iterator it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            C0140j0 j0Var = (C0140j0) it.next();
            if ((j0Var.c() & C0165w0.m.a()) != 0) {
                this.f4361c.setTranslationY((float) U.a.c(this.f4363e, 0, j0Var.b()));
                break;
            }
        }
        return w0Var;
    }

    public C0140j0.a e(C0140j0 j0Var, C0140j0.a aVar) {
        this.f4361c.getLocationOnScreen(this.f4364f);
        int i2 = this.f4362d - this.f4364f[1];
        this.f4363e = i2;
        this.f4361c.setTranslationY((float) i2);
        return aVar;
    }
}
