package com.google.android.material.navigation;

import W.a;
import android.graphics.Canvas;

public final /* synthetic */ class c implements a.C0008a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ NavigationView f4918a;

    public /* synthetic */ c(NavigationView navigationView) {
        this.f4918a = navigationView;
    }

    public final void a(Canvas canvas) {
        this.f4918a.s(canvas);
    }
}
