package com.google.android.material.navigation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.view.View;
import androidx.drawerlayout.widget.DrawerLayout;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    private static final int f4915a = Color.alpha(-1728053248);

    class a extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ DrawerLayout f4916a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f4917b;

        a(DrawerLayout drawerLayout, View view) {
            this.f4916a = drawerLayout;
            this.f4917b = view;
        }

        public void onAnimationEnd(Animator animator) {
            this.f4916a.g(this.f4917b, false);
            this.f4916a.setScrimColor(-1728053248);
        }
    }

    public static Animator.AnimatorListener b(DrawerLayout drawerLayout, View view) {
        return new a(drawerLayout, view);
    }

    public static ValueAnimator.AnimatorUpdateListener c(DrawerLayout drawerLayout) {
        return new a(drawerLayout);
    }
}
