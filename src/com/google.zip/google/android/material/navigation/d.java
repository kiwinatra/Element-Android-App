package com.google.android.material.navigation;

import f0.c;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ c f4919a;

    public /* synthetic */ d(c cVar) {
        this.f4919a = cVar;
    }

    public final void run() {
        this.f4919a.d();
    }
}
