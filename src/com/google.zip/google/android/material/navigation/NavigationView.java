package com.google.android.material.navigation;

import T.i;
import T.j;
import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.e0;
import androidx.core.view.C0156s;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.internal.C0215b;
import com.google.android.material.internal.D;
import com.google.android.material.internal.h;
import com.google.android.material.internal.l;
import e.C0233a;
import f.C0236a;
import f0.g;
import java.util.Objects;
import k0.k;
import k0.o;

public class NavigationView extends l implements f0.b {

    /* renamed from: x  reason: collision with root package name */
    private static final int[] f4891x = {16842912};

    /* renamed from: y  reason: collision with root package name */
    private static final int[] f4892y = {-16842910};

    /* renamed from: z  reason: collision with root package name */
    private static final int f4893z = i.Widget_Design_NavigationView;

    /* renamed from: h  reason: collision with root package name */
    private final h f4894h;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public final com.google.android.material.internal.i f4895i;

    /* renamed from: j  reason: collision with root package name */
    d f4896j;

    /* renamed from: k  reason: collision with root package name */
    private final int f4897k;
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public final int[] f4898l;

    /* renamed from: m  reason: collision with root package name */
    private MenuInflater f4899m;

    /* renamed from: n  reason: collision with root package name */
    private ViewTreeObserver.OnGlobalLayoutListener f4900n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f4901o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f4902p;

    /* renamed from: q  reason: collision with root package name */
    private int f4903q;

    /* renamed from: r  reason: collision with root package name */
    private final boolean f4904r;

    /* renamed from: s  reason: collision with root package name */
    private final int f4905s;

    /* renamed from: t  reason: collision with root package name */
    private final o f4906t;

    /* renamed from: u  reason: collision with root package name */
    private final g f4907u;
    /* access modifiers changed from: private */

    /* renamed from: v  reason: collision with root package name */
    public final f0.c f4908v;

    /* renamed from: w  reason: collision with root package name */
    private final DrawerLayout.e f4909w;

    class a extends DrawerLayout.h {
        a() {
        }

        public void b(View view) {
            NavigationView navigationView = NavigationView.this;
            if (view == navigationView) {
                f0.c g2 = navigationView.f4908v;
                Objects.requireNonNull(g2);
                view.post(new d(g2));
            }
        }

        public void d(View view) {
            NavigationView navigationView = NavigationView.this;
            if (view == navigationView) {
                navigationView.f4908v.e();
                NavigationView.this.t();
            }
        }
    }

    class b implements e.a {
        b() {
        }

        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            d dVar = NavigationView.this.f4896j;
            return dVar != null && dVar.m(menuItem);
        }

        public void b(androidx.appcompat.view.menu.e eVar) {
        }
    }

    class c implements ViewTreeObserver.OnGlobalLayoutListener {
        c() {
        }

        public void onGlobalLayout() {
            NavigationView navigationView = NavigationView.this;
            navigationView.getLocationOnScreen(navigationView.f4898l);
            boolean z2 = true;
            boolean z3 = NavigationView.this.f4898l[1] == 0;
            NavigationView.this.f4895i.E(z3);
            NavigationView navigationView2 = NavigationView.this;
            navigationView2.setDrawTopInsetForeground(z3 && navigationView2.r());
            NavigationView.this.setDrawLeftInsetForeground(NavigationView.this.f4898l[0] == 0 || NavigationView.this.f4898l[0] + NavigationView.this.getWidth() == 0);
            Activity a2 = C0215b.a(NavigationView.this.getContext());
            if (a2 != null) {
                Rect a3 = D.a(a2);
                boolean z4 = a3.height() - NavigationView.this.getHeight() == NavigationView.this.f4898l[1];
                boolean z5 = Color.alpha(a2.getWindow().getNavigationBarColor()) != 0;
                NavigationView navigationView3 = NavigationView.this;
                navigationView3.setDrawBottomInsetForeground(z4 && z5 && navigationView3.q());
                if (!(a3.width() == NavigationView.this.f4898l[0] || a3.width() - NavigationView.this.getWidth() == NavigationView.this.f4898l[0])) {
                    z2 = false;
                }
                NavigationView.this.setDrawRightInsetForeground(z2);
            }
        }
    }

    public interface d {
        boolean m(MenuItem menuItem);
    }

    public static class e extends C.a {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        public Bundle f4913c;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public e createFromParcel(Parcel parcel) {
                return new e(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public e createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new e(parcel, classLoader);
            }

            /* renamed from: c */
            public e[] newArray(int i2) {
                return new e[i2];
            }
        }

        public e(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f4913c = parcel.readBundle(classLoader);
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeBundle(this.f4913c);
        }

        public e(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public NavigationView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, T.a.navigationViewStyle);
    }

    private MenuInflater getMenuInflater() {
        if (this.f4899m == null) {
            this.f4899m = new androidx.appcompat.view.g(getContext());
        }
        return this.f4899m;
    }

    private ColorStateList k(int i2) {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(i2, typedValue, true)) {
            return null;
        }
        ColorStateList a2 = C0236a.a(getContext(), typedValue.resourceId);
        if (!getContext().getTheme().resolveAttribute(C0233a.f5291v, typedValue, true)) {
            return null;
        }
        int i3 = typedValue.data;
        int defaultColor = a2.getDefaultColor();
        int[] iArr = f4892y;
        return new ColorStateList(new int[][]{iArr, f4891x, FrameLayout.EMPTY_STATE_SET}, new int[]{a2.getColorForState(iArr, defaultColor), i3, defaultColor});
    }

    private Drawable l(e0 e0Var) {
        return m(e0Var, h0.c.b(getContext(), e0Var, j.l4));
    }

    private Drawable m(e0 e0Var, ColorStateList colorStateList) {
        k0.g gVar = new k0.g(k.b(getContext(), e0Var.n(j.j4, 0), e0Var.n(j.k4, 0)).m());
        gVar.T(colorStateList);
        return new InsetDrawable(gVar, e0Var.f(j.o4, 0), e0Var.f(j.p4, 0), e0Var.f(j.n4, 0), e0Var.f(j.m4, 0));
    }

    private boolean n(e0 e0Var) {
        return e0Var.s(j.j4) || e0Var.s(j.k4);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void s(Canvas canvas) {
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: private */
    public void t() {
        if (this.f4904r && this.f4903q != 0) {
            this.f4903q = 0;
            u(getWidth(), getHeight());
        }
    }

    private void u(int i2, int i3) {
        if ((getParent() instanceof DrawerLayout) && (getLayoutParams() instanceof DrawerLayout.f)) {
            if ((this.f4903q > 0 || this.f4904r) && (getBackground() instanceof k0.g)) {
                boolean z2 = C0156s.b(((DrawerLayout.f) getLayoutParams()).f2580a, W.C(this)) == 3;
                k0.g gVar = (k0.g) getBackground();
                k.b o2 = gVar.A().v().o((float) this.f4903q);
                if (z2) {
                    o2.A(0.0f);
                    o2.s(0.0f);
                } else {
                    o2.E(0.0f);
                    o2.w(0.0f);
                }
                k m2 = o2.m();
                gVar.setShapeAppearanceModel(m2);
                this.f4906t.f(this, m2);
                this.f4906t.e(this, new RectF(0.0f, 0.0f, (float) i2, (float) i3));
                this.f4906t.h(this, true);
            }
        }
    }

    private Pair v() {
        ViewParent parent = getParent();
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if ((parent instanceof DrawerLayout) && (layoutParams instanceof DrawerLayout.f)) {
            return new Pair((DrawerLayout) parent, (DrawerLayout.f) layoutParams);
        }
        throw new IllegalStateException("NavigationView back progress requires the direct parent view to be a DrawerLayout.");
    }

    private void w() {
        this.f4900n = new c();
        getViewTreeObserver().addOnGlobalLayoutListener(this.f4900n);
    }

    public void a() {
        Pair v2 = v();
        DrawerLayout drawerLayout = (DrawerLayout) v2.first;
        androidx.activity.b c2 = this.f4907u.c();
        if (c2 == null || Build.VERSION.SDK_INT < 34) {
            drawerLayout.f(this);
            return;
        }
        this.f4907u.h(c2, ((DrawerLayout.f) v2.second).f2580a, b.b(drawerLayout, this), b.c(drawerLayout));
    }

    public void b(androidx.activity.b bVar) {
        v();
        this.f4907u.j(bVar);
    }

    public void c(androidx.activity.b bVar) {
        this.f4907u.l(bVar, ((DrawerLayout.f) v().second).f2580a);
        if (this.f4904r) {
            this.f4903q = U.a.c(0, this.f4905s, this.f4907u.a(bVar.a()));
            u(getWidth(), getHeight());
        }
    }

    public void d() {
        v();
        this.f4907u.f();
        t();
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        this.f4906t.d(canvas, new c(this));
    }

    /* access modifiers changed from: protected */
    public void e(C0165w0 w0Var) {
        this.f4895i.k(w0Var);
    }

    /* access modifiers changed from: package-private */
    public g getBackHelper() {
        return this.f4907u;
    }

    public MenuItem getCheckedItem() {
        return this.f4895i.o();
    }

    public int getDividerInsetEnd() {
        return this.f4895i.p();
    }

    public int getDividerInsetStart() {
        return this.f4895i.q();
    }

    public int getHeaderCount() {
        return this.f4895i.r();
    }

    public Drawable getItemBackground() {
        return this.f4895i.s();
    }

    public int getItemHorizontalPadding() {
        return this.f4895i.t();
    }

    public int getItemIconPadding() {
        return this.f4895i.u();
    }

    public ColorStateList getItemIconTintList() {
        return this.f4895i.x();
    }

    public int getItemMaxLines() {
        return this.f4895i.v();
    }

    public ColorStateList getItemTextColor() {
        return this.f4895i.w();
    }

    public int getItemVerticalPadding() {
        return this.f4895i.y();
    }

    public Menu getMenu() {
        return this.f4894h;
    }

    public int getSubheaderInsetEnd() {
        return this.f4895i.A();
    }

    public int getSubheaderInsetStart() {
        return this.f4895i.B();
    }

    public View o(int i2) {
        return this.f4895i.D(i2);
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        k0.h.e(this);
        ViewParent parent = getParent();
        if ((parent instanceof DrawerLayout) && this.f4908v.b()) {
            DrawerLayout drawerLayout = (DrawerLayout) parent;
            drawerLayout.O(this.f4909w);
            drawerLayout.a(this.f4909w);
            if (drawerLayout.D(this)) {
                this.f4908v.d();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getViewTreeObserver().removeOnGlobalLayoutListener(this.f4900n);
        ViewParent parent = getParent();
        if (parent instanceof DrawerLayout) {
            ((DrawerLayout) parent).O(this.f4909w);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int min;
        int mode = View.MeasureSpec.getMode(i2);
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                min = this.f4897k;
            }
            super.onMeasure(i2, i3);
        }
        min = Math.min(View.MeasureSpec.getSize(i2), this.f4897k);
        i2 = View.MeasureSpec.makeMeasureSpec(min, 1073741824);
        super.onMeasure(i2, i3);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e eVar = (e) parcelable;
        super.onRestoreInstanceState(eVar.c());
        this.f4894h.T(eVar.f4913c);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        e eVar = new e(super.onSaveInstanceState());
        Bundle bundle = new Bundle();
        eVar.f4913c = bundle;
        this.f4894h.V(bundle);
        return eVar;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        u(i2, i3);
    }

    public void p(int i2) {
        this.f4895i.Z(true);
        getMenuInflater().inflate(i2, this.f4894h);
        this.f4895i.Z(false);
        this.f4895i.n(false);
    }

    public boolean q() {
        return this.f4902p;
    }

    public boolean r() {
        return this.f4901o;
    }

    public void setBottomInsetScrimEnabled(boolean z2) {
        this.f4902p = z2;
    }

    public void setCheckedItem(int i2) {
        MenuItem findItem = this.f4894h.findItem(i2);
        if (findItem != null) {
            this.f4895i.F((androidx.appcompat.view.menu.g) findItem);
        }
    }

    public void setDividerInsetEnd(int i2) {
        this.f4895i.G(i2);
    }

    public void setDividerInsetStart(int i2) {
        this.f4895i.H(i2);
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        k0.h.d(this, f2);
    }

    public void setForceCompatClippingEnabled(boolean z2) {
        this.f4906t.g(this, z2);
    }

    public void setItemBackground(Drawable drawable) {
        this.f4895i.J(drawable);
    }

    public void setItemBackgroundResource(int i2) {
        setItemBackground(androidx.core.content.a.c(getContext(), i2));
    }

    public void setItemHorizontalPadding(int i2) {
        this.f4895i.L(i2);
    }

    public void setItemHorizontalPaddingResource(int i2) {
        this.f4895i.L(getResources().getDimensionPixelSize(i2));
    }

    public void setItemIconPadding(int i2) {
        this.f4895i.M(i2);
    }

    public void setItemIconPaddingResource(int i2) {
        this.f4895i.M(getResources().getDimensionPixelSize(i2));
    }

    public void setItemIconSize(int i2) {
        this.f4895i.N(i2);
    }

    public void setItemIconTintList(ColorStateList colorStateList) {
        this.f4895i.O(colorStateList);
    }

    public void setItemMaxLines(int i2) {
        this.f4895i.P(i2);
    }

    public void setItemTextAppearance(int i2) {
        this.f4895i.Q(i2);
    }

    public void setItemTextAppearanceActiveBoldEnabled(boolean z2) {
        this.f4895i.R(z2);
    }

    public void setItemTextColor(ColorStateList colorStateList) {
        this.f4895i.S(colorStateList);
    }

    public void setItemVerticalPadding(int i2) {
        this.f4895i.T(i2);
    }

    public void setItemVerticalPaddingResource(int i2) {
        this.f4895i.T(getResources().getDimensionPixelSize(i2));
    }

    public void setNavigationItemSelectedListener(d dVar) {
        this.f4896j = dVar;
    }

    public void setOverScrollMode(int i2) {
        super.setOverScrollMode(i2);
        com.google.android.material.internal.i iVar = this.f4895i;
        if (iVar != null) {
            iVar.U(i2);
        }
    }

    public void setSubheaderInsetEnd(int i2) {
        this.f4895i.W(i2);
    }

    public void setSubheaderInsetStart(int i2) {
        this.f4895i.X(i2);
    }

    public void setTopInsetScrimEnabled(boolean z2) {
        this.f4901o = z2;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NavigationView(android.content.Context r17, android.util.AttributeSet r18, int r19) {
        /*
            r16 = this;
            r0 = r16
            r7 = r18
            r8 = r19
            int r9 = f4893z
            r1 = r17
            android.content.Context r1 = n0.a.c(r1, r7, r8, r9)
            r0.<init>(r1, r7, r8)
            com.google.android.material.internal.i r10 = new com.google.android.material.internal.i
            r10.<init>()
            r0.f4895i = r10
            r1 = 2
            int[] r1 = new int[r1]
            r0.f4898l = r1
            r11 = 1
            r0.f4901o = r11
            r0.f4902p = r11
            r12 = 0
            r0.f4903q = r12
            k0.o r1 = k0.o.a(r16)
            r0.f4906t = r1
            f0.g r1 = new f0.g
            r1.<init>(r0)
            r0.f4907u = r1
            f0.c r1 = new f0.c
            r1.<init>(r0)
            r0.f4908v = r1
            com.google.android.material.navigation.NavigationView$a r1 = new com.google.android.material.navigation.NavigationView$a
            r1.<init>()
            r0.f4909w = r1
            android.content.Context r13 = r16.getContext()
            com.google.android.material.internal.h r14 = new com.google.android.material.internal.h
            r14.<init>(r13)
            r0.f4894h = r14
            int[] r3 = T.j.S3
            int[] r6 = new int[r12]
            r1 = r13
            r2 = r18
            r4 = r19
            r5 = r9
            androidx.appcompat.widget.e0 r1 = com.google.android.material.internal.y.j(r1, r2, r3, r4, r5, r6)
            int r2 = T.j.T3
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0068
            android.graphics.drawable.Drawable r2 = r1.g(r2)
            androidx.core.view.W.u0(r0, r2)
        L_0x0068:
            int r2 = T.j.Z3
            int r2 = r1.f(r2, r12)
            r0.f4903q = r2
            if (r2 != 0) goto L_0x0074
            r2 = 1
            goto L_0x0075
        L_0x0074:
            r2 = 0
        L_0x0075:
            r0.f4904r = r2
            android.content.res.Resources r2 = r16.getResources()
            int r3 = T.c.m3_navigation_drawer_layout_corner_size
            int r2 = r2.getDimensionPixelSize(r3)
            r0.f4905s = r2
            android.graphics.drawable.Drawable r2 = r16.getBackground()
            android.content.res.ColorStateList r3 = com.google.android.material.drawable.f.f(r2)
            if (r2 == 0) goto L_0x008f
            if (r3 == 0) goto L_0x00a7
        L_0x008f:
            k0.k$b r2 = k0.k.e(r13, r7, r8, r9)
            k0.k r2 = r2.m()
            k0.g r4 = new k0.g
            r4.<init>((k0.k) r2)
            if (r3 == 0) goto L_0x00a1
            r4.T(r3)
        L_0x00a1:
            r4.J(r13)
            androidx.core.view.W.u0(r0, r4)
        L_0x00a7:
            int r2 = T.j.a4
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x00b7
            int r2 = r1.f(r2, r12)
            float r2 = (float) r2
            r0.setElevation(r2)
        L_0x00b7:
            int r2 = T.j.U3
            boolean r2 = r1.a(r2, r12)
            r0.setFitsSystemWindows(r2)
            int r2 = T.j.V3
            int r2 = r1.f(r2, r12)
            r0.f4897k = r2
            int r2 = T.j.v4
            boolean r3 = r1.s(r2)
            r4 = 0
            if (r3 == 0) goto L_0x00d6
            android.content.res.ColorStateList r2 = r1.c(r2)
            goto L_0x00d7
        L_0x00d6:
            r2 = r4
        L_0x00d7:
            int r3 = T.j.y4
            boolean r5 = r1.s(r3)
            if (r5 == 0) goto L_0x00e4
            int r3 = r1.n(r3, r12)
            goto L_0x00e5
        L_0x00e4:
            r3 = 0
        L_0x00e5:
            r5 = 16842808(0x1010038, float:2.3693715E-38)
            if (r3 != 0) goto L_0x00f0
            if (r2 != 0) goto L_0x00f0
            android.content.res.ColorStateList r2 = r0.k(r5)
        L_0x00f0:
            int r6 = T.j.g4
            boolean r7 = r1.s(r6)
            if (r7 == 0) goto L_0x00fd
            android.content.res.ColorStateList r5 = r1.c(r6)
            goto L_0x0101
        L_0x00fd:
            android.content.res.ColorStateList r5 = r0.k(r5)
        L_0x0101:
            int r6 = T.j.q4
            boolean r7 = r1.s(r6)
            if (r7 == 0) goto L_0x010e
            int r6 = r1.n(r6, r12)
            goto L_0x010f
        L_0x010e:
            r6 = 0
        L_0x010f:
            int r7 = T.j.r4
            boolean r7 = r1.a(r7, r11)
            int r8 = T.j.f4
            boolean r9 = r1.s(r8)
            if (r9 == 0) goto L_0x0124
            int r8 = r1.f(r8, r12)
            r0.setItemIconSize(r8)
        L_0x0124:
            int r8 = T.j.s4
            boolean r9 = r1.s(r8)
            if (r9 == 0) goto L_0x0131
            android.content.res.ColorStateList r8 = r1.c(r8)
            goto L_0x0132
        L_0x0131:
            r8 = r4
        L_0x0132:
            if (r6 != 0) goto L_0x013d
            if (r8 != 0) goto L_0x013d
            r8 = 16842806(0x1010036, float:2.369371E-38)
            android.content.res.ColorStateList r8 = r0.k(r8)
        L_0x013d:
            int r9 = T.j.c4
            android.graphics.drawable.Drawable r9 = r1.g(r9)
            if (r9 != 0) goto L_0x0167
            boolean r15 = r0.n(r1)
            if (r15 == 0) goto L_0x0167
            android.graphics.drawable.Drawable r9 = r0.l(r1)
            int r15 = T.j.i4
            android.content.res.ColorStateList r15 = h0.c.b(r13, r1, r15)
            if (r15 == 0) goto L_0x0167
            android.graphics.drawable.Drawable r11 = r0.m(r1, r4)
            android.graphics.drawable.RippleDrawable r12 = new android.graphics.drawable.RippleDrawable
            android.content.res.ColorStateList r15 = i0.b.b(r15)
            r12.<init>(r15, r4, r11)
            r10.K(r12)
        L_0x0167:
            int r4 = T.j.d4
            boolean r11 = r1.s(r4)
            if (r11 == 0) goto L_0x0178
            r11 = 0
            int r4 = r1.f(r4, r11)
            r0.setItemHorizontalPadding(r4)
            goto L_0x0179
        L_0x0178:
            r11 = 0
        L_0x0179:
            int r4 = T.j.t4
            boolean r12 = r1.s(r4)
            if (r12 == 0) goto L_0x0188
            int r4 = r1.f(r4, r11)
            r0.setItemVerticalPadding(r4)
        L_0x0188:
            int r4 = T.j.Y3
            int r4 = r1.f(r4, r11)
            r0.setDividerInsetStart(r4)
            int r4 = T.j.X3
            int r4 = r1.f(r4, r11)
            r0.setDividerInsetEnd(r4)
            int r4 = T.j.x4
            int r4 = r1.f(r4, r11)
            r0.setSubheaderInsetStart(r4)
            int r4 = T.j.w4
            int r4 = r1.f(r4, r11)
            r0.setSubheaderInsetEnd(r4)
            int r4 = T.j.z4
            boolean r12 = r0.f4901o
            boolean r4 = r1.a(r4, r12)
            r0.setTopInsetScrimEnabled(r4)
            int r4 = T.j.W3
            boolean r12 = r0.f4902p
            boolean r4 = r1.a(r4, r12)
            r0.setBottomInsetScrimEnabled(r4)
            int r4 = T.j.e4
            int r4 = r1.f(r4, r11)
            int r11 = T.j.h4
            r12 = 1
            int r11 = r1.k(r11, r12)
            r0.setItemMaxLines(r11)
            com.google.android.material.navigation.NavigationView$b r11 = new com.google.android.material.navigation.NavigationView$b
            r11.<init>()
            r14.W(r11)
            r10.I(r12)
            r10.g(r13, r14)
            if (r3 == 0) goto L_0x01e5
            r10.Y(r3)
        L_0x01e5:
            r10.V(r2)
            r10.O(r5)
            int r2 = r16.getOverScrollMode()
            r10.U(r2)
            if (r6 == 0) goto L_0x01f7
            r10.Q(r6)
        L_0x01f7:
            r10.R(r7)
            r10.S(r8)
            r10.J(r9)
            r10.M(r4)
            r14.b(r10)
            androidx.appcompat.view.menu.k r2 = r10.z(r0)
            android.view.View r2 = (android.view.View) r2
            r0.addView(r2)
            int r2 = T.j.u4
            boolean r3 = r1.s(r2)
            if (r3 == 0) goto L_0x0220
            r3 = 0
            int r2 = r1.n(r2, r3)
            r0.p(r2)
            goto L_0x0221
        L_0x0220:
            r3 = 0
        L_0x0221:
            int r2 = T.j.b4
            boolean r4 = r1.s(r2)
            if (r4 == 0) goto L_0x0230
            int r2 = r1.n(r2, r3)
            r0.o(r2)
        L_0x0230:
            r1.x()
            r16.w()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.navigation.NavigationView.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public void setCheckedItem(MenuItem menuItem) {
        MenuItem findItem = this.f4894h.findItem(menuItem.getItemId());
        if (findItem != null) {
            this.f4895i.F((androidx.appcompat.view.menu.g) findItem);
            return;
        }
        throw new IllegalArgumentException("Called setCheckedItem(MenuItem) with an item that is not in the current menu.");
    }
}
