package com.google.android.material.navigation;

import android.animation.ValueAnimator;
import androidx.drawerlayout.widget.DrawerLayout;

public final /* synthetic */ class a implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ DrawerLayout f4914a;

    public /* synthetic */ a(DrawerLayout drawerLayout) {
        this.f4914a = drawerLayout;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f4914a.setScrimColor(androidx.core.graphics.a.k(-1728053248, U.a.c(b.f4915a, 0, valueAnimator.getAnimatedFraction())));
    }
}
