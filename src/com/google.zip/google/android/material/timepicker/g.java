package com.google.android.material.timepicker;

import com.google.android.material.button.MaterialButtonToggleGroup;

public final /* synthetic */ class g implements MaterialButtonToggleGroup.d {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TimePickerView f5276a;

    public /* synthetic */ g(TimePickerView timePickerView) {
        this.f5276a = timePickerView;
    }

    public final void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i2, boolean z2) {
        this.f5276a.E(materialButtonToggleGroup, i2, z2);
    }
}
