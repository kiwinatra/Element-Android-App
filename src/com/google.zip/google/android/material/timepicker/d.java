package com.google.android.material.timepicker;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f5265a;

    public /* synthetic */ d(e eVar) {
        this.f5265a = eVar;
    }

    public final void run() {
        this.f5265a.H();
    }
}
