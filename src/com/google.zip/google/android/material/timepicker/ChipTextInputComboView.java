package com.google.android.material.timepicker;

import T.e;
import T.g;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.core.view.W;
import com.google.android.material.chip.Chip;
import com.google.android.material.internal.B;
import com.google.android.material.internal.x;
import com.google.android.material.textfield.TextInputLayout;

class ChipTextInputComboView extends FrameLayout implements Checkable {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final Chip f5209a;

    /* renamed from: b  reason: collision with root package name */
    private final TextInputLayout f5210b;

    /* renamed from: c  reason: collision with root package name */
    private final EditText f5211c;

    /* renamed from: d  reason: collision with root package name */
    private TextWatcher f5212d;

    /* renamed from: e  reason: collision with root package name */
    private TextView f5213e;

    private class b extends x {
        private b() {
        }

        public void afterTextChanged(Editable editable) {
            if (TextUtils.isEmpty(editable)) {
                ChipTextInputComboView.this.f5209a.setText(ChipTextInputComboView.this.c("00"));
                return;
            }
            String a2 = ChipTextInputComboView.this.c(editable);
            Chip b2 = ChipTextInputComboView.this.f5209a;
            if (TextUtils.isEmpty(a2)) {
                a2 = ChipTextInputComboView.this.c("00");
            }
            b2.setText(a2);
        }
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* access modifiers changed from: private */
    public String c(CharSequence charSequence) {
        return f.c(getResources(), charSequence);
    }

    private void d() {
        if (Build.VERSION.SDK_INT >= 24) {
            this.f5211c.setImeHintLocales(getContext().getResources().getConfiguration().getLocales());
        }
    }

    public boolean isChecked() {
        return this.f5209a.isChecked();
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        d();
    }

    public void setChecked(boolean z2) {
        this.f5209a.setChecked(z2);
        this.f5211c.setVisibility(z2 ? 0 : 4);
        this.f5209a.setVisibility(z2 ? 8 : 0);
        if (isChecked()) {
            B.k(this.f5211c, false);
        }
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.f5209a.setOnClickListener(onClickListener);
    }

    public void setTag(int i2, Object obj) {
        this.f5209a.setTag(i2, obj);
    }

    public void toggle() {
        this.f5209a.toggle();
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        LayoutInflater from = LayoutInflater.from(context);
        Chip chip = (Chip) from.inflate(g.material_time_chip, this, false);
        this.f5209a = chip;
        chip.setAccessibilityClassName("android.view.View");
        TextInputLayout textInputLayout = (TextInputLayout) from.inflate(g.material_time_input, this, false);
        this.f5210b = textInputLayout;
        EditText editText = textInputLayout.getEditText();
        this.f5211c = editText;
        editText.setVisibility(4);
        b bVar = new b();
        this.f5212d = bVar;
        editText.addTextChangedListener(bVar);
        d();
        addView(chip);
        addView(textInputLayout);
        this.f5213e = (TextView) findViewById(e.material_label);
        editText.setId(W.m());
        W.B0(this.f5213e, editText.getId());
        editText.setSaveEnabled(false);
        editText.setLongClickable(false);
    }
}
