package com.google.android.material.timepicker;

import T.e;
import T.g;
import T.i;
import T.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import com.google.android.material.timepicker.ClockHandView;
import f.C0236a;
import h0.c;
import java.util.Arrays;
import y.I;

class ClockFaceView extends e implements ClockHandView.b {
    /* access modifiers changed from: private */

    /* renamed from: B  reason: collision with root package name */
    public final ClockHandView f5215B;
    /* access modifiers changed from: private */

    /* renamed from: C  reason: collision with root package name */
    public final Rect f5216C;

    /* renamed from: D  reason: collision with root package name */
    private final RectF f5217D;

    /* renamed from: E  reason: collision with root package name */
    private final Rect f5218E;
    /* access modifiers changed from: private */

    /* renamed from: F  reason: collision with root package name */
    public final SparseArray f5219F;

    /* renamed from: G  reason: collision with root package name */
    private final C0121a f5220G;

    /* renamed from: H  reason: collision with root package name */
    private final int[] f5221H;

    /* renamed from: I  reason: collision with root package name */
    private final float[] f5222I;
    /* access modifiers changed from: private */

    /* renamed from: J  reason: collision with root package name */
    public final int f5223J;

    /* renamed from: K  reason: collision with root package name */
    private final int f5224K;

    /* renamed from: L  reason: collision with root package name */
    private final int f5225L;

    /* renamed from: M  reason: collision with root package name */
    private final int f5226M;

    /* renamed from: N  reason: collision with root package name */
    private String[] f5227N;

    /* renamed from: O  reason: collision with root package name */
    private float f5228O;

    /* renamed from: P  reason: collision with root package name */
    private final ColorStateList f5229P;

    class a implements ViewTreeObserver.OnPreDrawListener {
        a() {
        }

        public boolean onPreDraw() {
            if (!ClockFaceView.this.isShown()) {
                return true;
            }
            ClockFaceView.this.getViewTreeObserver().removeOnPreDrawListener(this);
            ClockFaceView.this.F(((ClockFaceView.this.getHeight() / 2) - ClockFaceView.this.f5215B.i()) - ClockFaceView.this.f5223J);
            return true;
        }
    }

    class b extends C0121a {
        b() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            int intValue = ((Integer) view.getTag(e.material_value_index)).intValue();
            if (intValue > 0) {
                i2.L0((View) ClockFaceView.this.f5219F.get(intValue - 1));
            }
            i2.p0(I.f.a(0, 1, intValue, 1, false, view.isSelected()));
            i2.n0(true);
            i2.b(I.a.f6366i);
        }

        public boolean j(View view, int i2, Bundle bundle) {
            if (i2 != 16) {
                return super.j(view, i2, bundle);
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            view.getHitRect(ClockFaceView.this.f5216C);
            long j2 = uptimeMillis;
            float centerX = (float) ClockFaceView.this.f5216C.centerX();
            float centerY = (float) ClockFaceView.this.f5216C.centerY();
            ClockFaceView.this.f5215B.onTouchEvent(MotionEvent.obtain(uptimeMillis, j2, 0, centerX, centerY, 0));
            ClockFaceView.this.f5215B.onTouchEvent(MotionEvent.obtain(uptimeMillis, j2, 1, centerX, centerY, 0));
            return true;
        }
    }

    public ClockFaceView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, T.a.materialClockStyle);
    }

    private void N() {
        RectF e2 = this.f5215B.e();
        TextView P2 = P(e2);
        for (int i2 = 0; i2 < this.f5219F.size(); i2++) {
            TextView textView = (TextView) this.f5219F.get(i2);
            if (textView != null) {
                textView.setSelected(textView == P2);
                textView.getPaint().setShader(O(e2, textView));
                textView.invalidate();
            }
        }
    }

    private RadialGradient O(RectF rectF, TextView textView) {
        textView.getHitRect(this.f5216C);
        this.f5217D.set(this.f5216C);
        textView.getLineBounds(0, this.f5218E);
        RectF rectF2 = this.f5217D;
        Rect rect = this.f5218E;
        rectF2.inset((float) rect.left, (float) rect.top);
        if (!RectF.intersects(rectF, this.f5217D)) {
            return null;
        }
        return new RadialGradient(rectF.centerX() - this.f5217D.left, rectF.centerY() - this.f5217D.top, rectF.width() * 0.5f, this.f5221H, this.f5222I, Shader.TileMode.CLAMP);
    }

    private TextView P(RectF rectF) {
        float f2 = Float.MAX_VALUE;
        TextView textView = null;
        for (int i2 = 0; i2 < this.f5219F.size(); i2++) {
            TextView textView2 = (TextView) this.f5219F.get(i2);
            if (textView2 != null) {
                textView2.getHitRect(this.f5216C);
                this.f5217D.set(this.f5216C);
                this.f5217D.union(rectF);
                float width = this.f5217D.width() * this.f5217D.height();
                if (width < f2) {
                    textView = textView2;
                    f2 = width;
                }
            }
        }
        return textView;
    }

    private static float Q(float f2, float f3, float f4) {
        return Math.max(Math.max(f2, f3), f4);
    }

    private void S(int i2) {
        LayoutInflater from = LayoutInflater.from(getContext());
        int size = this.f5219F.size();
        boolean z2 = false;
        for (int i3 = 0; i3 < Math.max(this.f5227N.length, size); i3++) {
            TextView textView = (TextView) this.f5219F.get(i3);
            if (i3 >= this.f5227N.length) {
                removeView(textView);
                this.f5219F.remove(i3);
            } else {
                if (textView == null) {
                    textView = (TextView) from.inflate(g.material_clockface_textview, this, false);
                    this.f5219F.put(i3, textView);
                    addView(textView);
                }
                textView.setText(this.f5227N[i3]);
                textView.setTag(e.material_value_index, Integer.valueOf(i3));
                int i4 = (i3 / 12) + 1;
                textView.setTag(e.material_clock_level, Integer.valueOf(i4));
                if (i4 > 1) {
                    z2 = true;
                }
                W.q0(textView, this.f5220G);
                textView.setTextColor(this.f5229P);
                if (i2 != 0) {
                    textView.setContentDescription(getResources().getString(i2, new Object[]{this.f5227N[i3]}));
                }
            }
        }
        this.f5215B.q(z2);
    }

    public void F(int i2) {
        if (i2 != E()) {
            super.F(i2);
            this.f5215B.m(E());
        }
    }

    /* access modifiers changed from: protected */
    public void H() {
        super.H();
        for (int i2 = 0; i2 < this.f5219F.size(); i2++) {
            ((TextView) this.f5219F.get(i2)).setVisibility(0);
        }
    }

    public void R(String[] strArr, int i2) {
        this.f5227N = strArr;
        S(i2);
    }

    public void a(float f2, boolean z2) {
        if (Math.abs(this.f5228O - f2) > 0.001f) {
            this.f5228O = f2;
            N();
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        I.O0(accessibilityNodeInfo).o0(I.e.b(1, this.f5227N.length, false, 1));
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        N();
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int Q2 = (int) (((float) this.f5226M) / Q(((float) this.f5224K) / ((float) displayMetrics.heightPixels), ((float) this.f5225L) / ((float) displayMetrics.widthPixels), 1.0f));
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Q2, 1073741824);
        setMeasuredDimension(Q2, Q2);
        super.onMeasure(makeMeasureSpec, makeMeasureSpec);
    }

    public ClockFaceView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f5216C = new Rect();
        this.f5217D = new RectF();
        this.f5218E = new Rect();
        this.f5219F = new SparseArray();
        this.f5222I = new float[]{0.0f, 0.9f, 1.0f};
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.T0, i2, i.Widget_MaterialComponents_TimePicker_Clock);
        Resources resources = getResources();
        ColorStateList a2 = c.a(context, obtainStyledAttributes, j.V0);
        this.f5229P = a2;
        LayoutInflater.from(context).inflate(g.material_clockface_view, this, true);
        ClockHandView clockHandView = (ClockHandView) findViewById(e.material_clock_hand);
        this.f5215B = clockHandView;
        this.f5223J = resources.getDimensionPixelSize(T.c.material_clock_hand_padding);
        int colorForState = a2.getColorForState(new int[]{16842913}, a2.getDefaultColor());
        this.f5221H = new int[]{colorForState, colorForState, a2.getDefaultColor()};
        clockHandView.b(this);
        int defaultColor = C0236a.a(context, T.b.material_timepicker_clockface).getDefaultColor();
        ColorStateList a3 = c.a(context, obtainStyledAttributes, j.U0);
        setBackgroundColor(a3 != null ? a3.getDefaultColor() : defaultColor);
        getViewTreeObserver().addOnPreDrawListener(new a());
        setFocusable(true);
        obtainStyledAttributes.recycle();
        this.f5220G = new b();
        String[] strArr = new String[12];
        Arrays.fill(strArr, "");
        R(strArr, 0);
        this.f5224K = resources.getDimensionPixelSize(T.c.material_time_picker_minimum_screen_height);
        this.f5225L = resources.getDimensionPixelSize(T.c.material_time_picker_minimum_screen_width);
        this.f5226M = resources.getDimensionPixelSize(T.c.material_clock_size);
    }
}
