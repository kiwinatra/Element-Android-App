package com.google.android.material.timepicker;

import T.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.W;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import k0.g;
import k0.i;

abstract class e extends ConstraintLayout {

    /* renamed from: A  reason: collision with root package name */
    private g f5266A;

    /* renamed from: y  reason: collision with root package name */
    private final Runnable f5267y = new d(this);

    /* renamed from: z  reason: collision with root package name */
    private int f5268z;

    public e(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        LayoutInflater.from(context).inflate(T.g.material_radial_view_group, this);
        W.u0(this, C());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.F4, i2, 0);
        this.f5268z = obtainStyledAttributes.getDimensionPixelSize(j.G4, 0);
        obtainStyledAttributes.recycle();
    }

    private void B(List list, androidx.constraintlayout.widget.e eVar, int i2) {
        Iterator it = list.iterator();
        float f2 = 0.0f;
        while (it.hasNext()) {
            eVar.g(((View) it.next()).getId(), T.e.circle_center, i2, f2);
            f2 += 360.0f / ((float) list.size());
        }
    }

    private Drawable C() {
        g gVar = new g();
        this.f5266A = gVar;
        gVar.R(new i(0.5f));
        this.f5266A.T(ColorStateList.valueOf(-1));
        return this.f5266A;
    }

    private static boolean G(View view) {
        return "skip".equals(view.getTag());
    }

    private void I() {
        Handler handler = getHandler();
        if (handler != null) {
            handler.removeCallbacks(this.f5267y);
            handler.post(this.f5267y);
        }
    }

    /* access modifiers changed from: package-private */
    public int D(int i2) {
        return i2 == 2 ? Math.round(((float) this.f5268z) * 0.66f) : this.f5268z;
    }

    public int E() {
        return this.f5268z;
    }

    public void F(int i2) {
        this.f5268z = i2;
        H();
    }

    /* access modifiers changed from: protected */
    public void H() {
        androidx.constraintlayout.widget.e eVar = new androidx.constraintlayout.widget.e();
        eVar.f(this);
        HashMap hashMap = new HashMap();
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getId() != T.e.circle_center && !G(childAt)) {
                int i3 = (Integer) childAt.getTag(T.e.material_clock_level);
                if (i3 == null) {
                    i3 = 1;
                }
                if (!hashMap.containsKey(i3)) {
                    hashMap.put(i3, new ArrayList());
                }
                ((List) hashMap.get(i3)).add(childAt);
            }
        }
        for (Map.Entry entry : hashMap.entrySet()) {
            B((List) entry.getValue(), eVar, D(((Integer) entry.getKey()).intValue()));
        }
        eVar.c(this);
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i2, layoutParams);
        if (view.getId() == -1) {
            view.setId(W.m());
        }
        I();
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        H();
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        I();
    }

    public void setBackgroundColor(int i2) {
        this.f5266A.T(ColorStateList.valueOf(i2));
    }
}
