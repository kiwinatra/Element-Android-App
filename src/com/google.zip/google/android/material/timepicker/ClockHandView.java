package com.google.android.material.timepicker;

import T.c;
import T.i;
import T.j;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.view.W;
import com.google.android.material.internal.B;
import f0.h;
import java.util.ArrayList;
import java.util.List;

class ClockHandView extends View {

    /* renamed from: a  reason: collision with root package name */
    private final int f5232a;

    /* renamed from: b  reason: collision with root package name */
    private final TimeInterpolator f5233b;

    /* renamed from: c  reason: collision with root package name */
    private final ValueAnimator f5234c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f5235d;

    /* renamed from: e  reason: collision with root package name */
    private float f5236e;

    /* renamed from: f  reason: collision with root package name */
    private float f5237f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f5238g;

    /* renamed from: h  reason: collision with root package name */
    private final int f5239h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f5240i;

    /* renamed from: j  reason: collision with root package name */
    private final List f5241j;

    /* renamed from: k  reason: collision with root package name */
    private final int f5242k;

    /* renamed from: l  reason: collision with root package name */
    private final float f5243l;

    /* renamed from: m  reason: collision with root package name */
    private final Paint f5244m;

    /* renamed from: n  reason: collision with root package name */
    private final RectF f5245n;

    /* renamed from: o  reason: collision with root package name */
    private final int f5246o;

    /* renamed from: p  reason: collision with root package name */
    private float f5247p;

    /* renamed from: q  reason: collision with root package name */
    private boolean f5248q;

    /* renamed from: r  reason: collision with root package name */
    private double f5249r;

    /* renamed from: s  reason: collision with root package name */
    private int f5250s;

    /* renamed from: t  reason: collision with root package name */
    private int f5251t;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        public void onAnimationCancel(Animator animator) {
            animator.end();
        }
    }

    public interface b {
        void a(float f2, boolean z2);
    }

    public ClockHandView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, T.a.materialClockStyle);
    }

    private void c(float f2, float f3) {
        int i2 = 2;
        if (e0.a.a((float) (getWidth() / 2), (float) (getHeight() / 2), f2, f3) > ((float) h(2)) + B.c(getContext(), 12)) {
            i2 = 1;
        }
        this.f5251t = i2;
    }

    private void d(Canvas canvas) {
        int height = getHeight() / 2;
        int width = getWidth() / 2;
        int h2 = h(this.f5251t);
        float f2 = (float) width;
        float f3 = (float) h2;
        float f4 = (float) height;
        this.f5244m.setStrokeWidth(0.0f);
        canvas.drawCircle((((float) Math.cos(this.f5249r)) * f3) + f2, (f3 * ((float) Math.sin(this.f5249r))) + f4, (float) this.f5242k, this.f5244m);
        double sin = Math.sin(this.f5249r);
        double cos = Math.cos(this.f5249r);
        double d2 = (double) ((float) (h2 - this.f5242k));
        float f5 = (float) (width + ((int) (cos * d2)));
        float f6 = (float) (height + ((int) (d2 * sin)));
        this.f5244m.setStrokeWidth((float) this.f5246o);
        canvas.drawLine(f2, f4, f5, f6, this.f5244m);
        canvas.drawCircle(f2, f4, this.f5243l, this.f5244m);
    }

    private int f(float f2, float f3) {
        int degrees = (int) Math.toDegrees(Math.atan2((double) (f3 - ((float) (getHeight() / 2))), (double) (f2 - ((float) (getWidth() / 2)))));
        int i2 = degrees + 90;
        return i2 < 0 ? degrees + 450 : i2;
    }

    private int h(int i2) {
        return i2 == 2 ? Math.round(((float) this.f5250s) * 0.66f) : this.f5250s;
    }

    private Pair j(float f2) {
        float g2 = g();
        if (Math.abs(g2 - f2) > 180.0f) {
            if (g2 > 180.0f && f2 < 180.0f) {
                f2 += 360.0f;
            }
            if (g2 < 180.0f && f2 > 180.0f) {
                g2 += 360.0f;
            }
        }
        return new Pair(Float.valueOf(g2), Float.valueOf(f2));
    }

    private boolean k(float f2, float f3, boolean z2, boolean z3, boolean z4) {
        float f4 = (float) f(f2, f3);
        boolean z5 = false;
        boolean z6 = g() != f4;
        if (z3 && z6) {
            return true;
        }
        if (!z6 && !z2) {
            return false;
        }
        if (z4 && this.f5235d) {
            z5 = true;
        }
        o(f4, z5);
        return true;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void l(ValueAnimator valueAnimator) {
        p(((Float) valueAnimator.getAnimatedValue()).floatValue(), true);
    }

    private void p(float f2, boolean z2) {
        float f3 = f2 % 360.0f;
        this.f5247p = f3;
        this.f5249r = Math.toRadians((double) (f3 - 90.0f));
        float h2 = (float) h(this.f5251t);
        float width = ((float) (getWidth() / 2)) + (((float) Math.cos(this.f5249r)) * h2);
        float height = ((float) (getHeight() / 2)) + (h2 * ((float) Math.sin(this.f5249r)));
        RectF rectF = this.f5245n;
        int i2 = this.f5242k;
        rectF.set(width - ((float) i2), height - ((float) i2), width + ((float) i2), height + ((float) i2));
        for (b a2 : this.f5241j) {
            a2.a(f3, z2);
        }
        invalidate();
    }

    public void b(b bVar) {
        this.f5241j.add(bVar);
    }

    public RectF e() {
        return this.f5245n;
    }

    public float g() {
        return this.f5247p;
    }

    public int i() {
        return this.f5242k;
    }

    public void m(int i2) {
        this.f5250s = i2;
        invalidate();
    }

    public void n(float f2) {
        o(f2, false);
    }

    public void o(float f2, boolean z2) {
        ValueAnimator valueAnimator = this.f5234c;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        if (!z2) {
            p(f2, false);
            return;
        }
        Pair j2 = j(f2);
        this.f5234c.setFloatValues(new float[]{((Float) j2.first).floatValue(), ((Float) j2.second).floatValue()});
        this.f5234c.setDuration((long) this.f5232a);
        this.f5234c.setInterpolator(this.f5233b);
        this.f5234c.addUpdateListener(new b(this));
        this.f5234c.addListener(new a());
        this.f5234c.start();
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        d(canvas);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (!this.f5234c.isRunning()) {
            n(g());
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        boolean z3;
        boolean z4;
        int actionMasked = motionEvent.getActionMasked();
        float x2 = motionEvent.getX();
        float y2 = motionEvent.getY();
        if (actionMasked == 0) {
            this.f5236e = x2;
            this.f5237f = y2;
            this.f5238g = true;
            this.f5248q = false;
            z4 = false;
            z3 = true;
        } else if (actionMasked == 1 || actionMasked == 2) {
            int i2 = (int) (x2 - this.f5236e);
            int i3 = (int) (y2 - this.f5237f);
            this.f5238g = (i2 * i2) + (i3 * i3) > this.f5239h;
            z4 = this.f5248q;
            boolean z5 = actionMasked == 1;
            if (this.f5240i) {
                c(x2, y2);
            }
            z2 = z5;
            z3 = false;
            this.f5248q |= k(x2, y2, z4, z3, z2);
            return true;
        } else {
            z4 = false;
            z3 = false;
        }
        z2 = false;
        this.f5248q |= k(x2, y2, z4, z3, z2);
        return true;
    }

    /* access modifiers changed from: package-private */
    public void q(boolean z2) {
        if (this.f5240i && !z2) {
            this.f5251t = 1;
        }
        this.f5240i = z2;
        invalidate();
    }

    public ClockHandView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f5234c = new ValueAnimator();
        this.f5241j = new ArrayList();
        Paint paint = new Paint();
        this.f5244m = paint;
        this.f5245n = new RectF();
        this.f5251t = 1;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.W0, i2, i.Widget_MaterialComponents_TimePicker_Clock);
        this.f5232a = h.f(context, T.a.motionDurationLong2, 200);
        this.f5233b = h.g(context, T.a.motionEasingEmphasizedInterpolator, U.a.f256b);
        this.f5250s = obtainStyledAttributes.getDimensionPixelSize(j.Y0, 0);
        this.f5242k = obtainStyledAttributes.getDimensionPixelSize(j.Z0, 0);
        Resources resources = getResources();
        this.f5246o = resources.getDimensionPixelSize(c.material_clock_hand_stroke_width);
        this.f5243l = (float) resources.getDimensionPixelSize(c.material_clock_hand_center_dot_radius);
        int color = obtainStyledAttributes.getColor(j.X0, 0);
        paint.setAntiAlias(true);
        paint.setColor(color);
        n(0.0f);
        this.f5239h = ViewConfiguration.get(context).getScaledTouchSlop();
        W.y0(this, 2);
        obtainStyledAttributes.recycle();
    }
}
