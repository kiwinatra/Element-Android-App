package com.google.android.material.timepicker;

import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

class f implements Parcelable {
    public static final Parcelable.Creator<f> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    private final c f5269a;

    /* renamed from: b  reason: collision with root package name */
    private final c f5270b;

    /* renamed from: c  reason: collision with root package name */
    final int f5271c;

    /* renamed from: d  reason: collision with root package name */
    int f5272d;

    /* renamed from: e  reason: collision with root package name */
    int f5273e;

    /* renamed from: f  reason: collision with root package name */
    int f5274f;

    /* renamed from: g  reason: collision with root package name */
    int f5275g;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public f createFromParcel(Parcel parcel) {
            return new f(parcel);
        }

        /* renamed from: b */
        public f[] newArray(int i2) {
            return new f[i2];
        }
    }

    public f(int i2, int i3, int i4, int i5) {
        this.f5272d = i2;
        this.f5273e = i3;
        this.f5274f = i4;
        this.f5271c = i5;
        this.f5275g = e(i2);
        this.f5269a = new c(59);
        this.f5270b = new c(i5 == 1 ? 23 : 12);
    }

    public static String c(Resources resources, CharSequence charSequence) {
        return d(resources, charSequence, "%02d");
    }

    public static String d(Resources resources, CharSequence charSequence, String str) {
        try {
            return String.format(resources.getConfiguration().locale, str, new Object[]{Integer.valueOf(Integer.parseInt(String.valueOf(charSequence)))});
        } catch (NumberFormatException unused) {
            return null;
        }
    }

    private static int e(int i2) {
        return i2 >= 12 ? 1 : 0;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return this.f5272d == fVar.f5272d && this.f5273e == fVar.f5273e && this.f5271c == fVar.f5271c && this.f5274f == fVar.f5274f;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f5271c), Integer.valueOf(this.f5272d), Integer.valueOf(this.f5273e), Integer.valueOf(this.f5274f)});
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f5272d);
        parcel.writeInt(this.f5273e);
        parcel.writeInt(this.f5274f);
        parcel.writeInt(this.f5271c);
    }

    protected f(Parcel parcel) {
        this(parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readInt());
    }
}
