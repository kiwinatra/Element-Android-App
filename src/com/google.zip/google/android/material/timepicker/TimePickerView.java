package com.google.android.material.timepicker;

import T.g;
import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Checkable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;

class TimePickerView extends ConstraintLayout {

    /* renamed from: A  reason: collision with root package name */
    private final ClockHandView f5253A;

    /* renamed from: B  reason: collision with root package name */
    private final ClockFaceView f5254B;

    /* renamed from: C  reason: collision with root package name */
    private final MaterialButtonToggleGroup f5255C;

    /* renamed from: D  reason: collision with root package name */
    private final View.OnClickListener f5256D;

    /* renamed from: y  reason: collision with root package name */
    private final Chip f5257y;

    /* renamed from: z  reason: collision with root package name */
    private final Chip f5258z;

    class a implements View.OnClickListener {
        a() {
        }

        public void onClick(View view) {
            e unused = TimePickerView.this.getClass();
        }
    }

    class b extends GestureDetector.SimpleOnGestureListener {
        b() {
        }

        public boolean onDoubleTap(MotionEvent motionEvent) {
            d unused = TimePickerView.this.getClass();
            return false;
        }
    }

    class c implements View.OnTouchListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ GestureDetector f5261a;

        c(GestureDetector gestureDetector) {
            this.f5261a = gestureDetector;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (((Checkable) view).isChecked()) {
                return this.f5261a.onTouchEvent(motionEvent);
            }
            return false;
        }
    }

    interface d {
    }

    interface e {
    }

    public TimePickerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void E(MaterialButtonToggleGroup materialButtonToggleGroup, int i2, boolean z2) {
    }

    private void F() {
        Chip chip = this.f5257y;
        int i2 = T.e.selection_type;
        chip.setTag(i2, 12);
        this.f5258z.setTag(i2, 10);
        this.f5257y.setOnClickListener(this.f5256D);
        this.f5258z.setOnClickListener(this.f5256D);
        this.f5257y.setAccessibilityClassName("android.view.View");
        this.f5258z.setAccessibilityClassName("android.view.View");
    }

    private void G() {
        c cVar = new c(new GestureDetector(getContext(), new b()));
        this.f5257y.setOnTouchListener(cVar);
        this.f5258z.setOnTouchListener(cVar);
    }

    /* access modifiers changed from: protected */
    public void onVisibilityChanged(View view, int i2) {
        super.onVisibilityChanged(view, i2);
        if (view == this && i2 == 0) {
            this.f5258z.sendAccessibilityEvent(8);
        }
    }

    public TimePickerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f5256D = new a();
        LayoutInflater.from(context).inflate(g.material_timepicker, this);
        this.f5254B = (ClockFaceView) findViewById(T.e.material_clock_face);
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) findViewById(T.e.material_clock_period_toggle);
        this.f5255C = materialButtonToggleGroup;
        materialButtonToggleGroup.b(new g(this));
        this.f5257y = (Chip) findViewById(T.e.material_minute_tv);
        this.f5258z = (Chip) findViewById(T.e.material_hour_tv);
        this.f5253A = (ClockHandView) findViewById(T.e.material_clock_hand);
        G();
        F();
    }
}
