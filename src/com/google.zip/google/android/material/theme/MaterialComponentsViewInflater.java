package com.google.android.material.theme;

import Y.e;
import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.app.z;
import androidx.appcompat.widget.C0099d;
import androidx.appcompat.widget.C0101f;
import androidx.appcompat.widget.C0102g;
import androidx.appcompat.widget.C0116v;
import androidx.appcompat.widget.F;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.w;
import g0.a;

public class MaterialComponentsViewInflater extends z {
    /* access modifiers changed from: protected */
    public C0099d c(Context context, AttributeSet attributeSet) {
        return new w(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0101f d(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0102g e(Context context, AttributeSet attributeSet) {
        return new e(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0116v k(Context context, AttributeSet attributeSet) {
        return new a(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public F o(Context context, AttributeSet attributeSet) {
        return new m0.a(context, attributeSet);
    }
}
