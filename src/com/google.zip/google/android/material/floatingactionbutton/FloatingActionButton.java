package com.google.android.material.floatingactionbutton;

import T.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.internal.C;
import d0.a;
import java.util.List;
import k0.n;

public abstract class FloatingActionButton extends C implements a, n {

    protected static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.b {

        /* renamed from: a  reason: collision with root package name */
        private boolean f4698a;

        public BaseBehavior() {
            this.f4698a = true;
        }

        private static boolean J(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.e) {
                return ((CoordinatorLayout.e) layoutParams).e() instanceof BottomSheetBehavior;
            }
            return false;
        }

        private void K(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton) {
            throw null;
        }

        private boolean N(View view, FloatingActionButton floatingActionButton) {
            throw null;
        }

        private boolean O(View view, FloatingActionButton floatingActionButton) {
            if (!N(view, floatingActionButton)) {
                return false;
            }
            throw null;
        }

        public boolean I(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            throw null;
        }

        public boolean L(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (!J(view)) {
                return false;
            }
            O(view, floatingActionButton);
            return false;
        }

        public boolean M(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i2) {
            List q2 = coordinatorLayout.q(floatingActionButton);
            int size = q2.size();
            for (int i3 = 0; i3 < size; i3++) {
                View view = (View) q2.get(i3);
                if (J(view) && O(view, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.G(floatingActionButton, i2);
            K(coordinatorLayout, floatingActionButton);
            return true;
        }

        public /* bridge */ /* synthetic */ boolean f(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            b.a(view);
            return I(coordinatorLayout, (FloatingActionButton) null, rect);
        }

        public void k(CoordinatorLayout.e eVar) {
            if (eVar.f2064h == 0) {
                eVar.f2064h = 80;
            }
        }

        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, View view, View view2) {
            b.a(view);
            return L(coordinatorLayout, (FloatingActionButton) null, view2);
        }

        public /* bridge */ /* synthetic */ boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            b.a(view);
            return M(coordinatorLayout, (FloatingActionButton) null, i2);
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.s1);
            this.f4698a = obtainStyledAttributes.getBoolean(j.t1, true);
            obtainStyledAttributes.recycle();
        }
    }

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public /* bridge */ /* synthetic */ boolean I(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            return super.I(coordinatorLayout, floatingActionButton, rect);
        }

        public /* bridge */ /* synthetic */ boolean L(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            return super.L(coordinatorLayout, floatingActionButton, view);
        }

        public /* bridge */ /* synthetic */ boolean M(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i2) {
            return super.M(coordinatorLayout, floatingActionButton, i2);
        }

        public /* bridge */ /* synthetic */ void k(CoordinatorLayout.e eVar) {
            super.k(eVar);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }
}
