package com.google.android.material.floatingactionbutton;

import T.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public abstract class ExtendedFloatingActionButton extends MaterialButton {

    protected static class ExtendedFloatingActionButtonBehavior<T extends ExtendedFloatingActionButton> extends CoordinatorLayout.b {

        /* renamed from: a  reason: collision with root package name */
        private boolean f4696a;

        /* renamed from: b  reason: collision with root package name */
        private boolean f4697b;

        public ExtendedFloatingActionButtonBehavior() {
            this.f4696a = false;
            this.f4697b = true;
        }

        private static boolean J(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.e) {
                return ((CoordinatorLayout.e) layoutParams).e() instanceof BottomSheetBehavior;
            }
            return false;
        }

        private boolean M(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            throw null;
        }

        private boolean N(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!M(view, extendedFloatingActionButton)) {
                return false;
            }
            throw null;
        }

        public boolean I(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, Rect rect) {
            return super.f(coordinatorLayout, extendedFloatingActionButton, rect);
        }

        public boolean K(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, View view) {
            if (!J(view)) {
                return false;
            }
            N(view, extendedFloatingActionButton);
            return false;
        }

        public boolean L(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, int i2) {
            List q2 = coordinatorLayout.q(extendedFloatingActionButton);
            int size = q2.size();
            for (int i3 = 0; i3 < size; i3++) {
                View view = (View) q2.get(i3);
                if (J(view) && N(view, extendedFloatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.G(extendedFloatingActionButton, i2);
            return true;
        }

        public /* bridge */ /* synthetic */ boolean f(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            b.a(view);
            return I(coordinatorLayout, (ExtendedFloatingActionButton) null, rect);
        }

        public void k(CoordinatorLayout.e eVar) {
            if (eVar.f2064h == 0) {
                eVar.f2064h = 80;
            }
        }

        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, View view, View view2) {
            b.a(view);
            return K(coordinatorLayout, (ExtendedFloatingActionButton) null, view2);
        }

        public /* bridge */ /* synthetic */ boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            b.a(view);
            return L(coordinatorLayout, (ExtendedFloatingActionButton) null, i2);
        }

        public ExtendedFloatingActionButtonBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.o1);
            this.f4696a = obtainStyledAttributes.getBoolean(j.p1, false);
            this.f4697b = obtainStyledAttributes.getBoolean(j.q1, true);
            obtainStyledAttributes.recycle();
        }
    }
}
