package com.google.android.material.appbar;

import T.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import java.lang.ref.WeakReference;
import java.util.List;
import v.C0288a;
import y.I;

public abstract class AppBarLayout extends LinearLayout {

    protected static class BaseBehavior<T extends AppBarLayout> extends a {
        /* access modifiers changed from: private */

        /* renamed from: k  reason: collision with root package name */
        public int f4199k;

        /* renamed from: l  reason: collision with root package name */
        private int f4200l;

        /* renamed from: m  reason: collision with root package name */
        private b f4201m;

        /* renamed from: n  reason: collision with root package name */
        private WeakReference f4202n;

        class a extends C0121a {

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ CoordinatorLayout f4203d;

            a(AppBarLayout appBarLayout, CoordinatorLayout coordinatorLayout) {
                this.f4203d = coordinatorLayout;
            }

            public void g(View view, I i2) {
                super.g(view, i2);
                i2.m0(ScrollView.class.getName());
                throw null;
            }

            public boolean j(View view, int i2, Bundle bundle) {
                if (i2 == 4096) {
                    throw null;
                } else if (i2 != 8192) {
                    return super.j(view, i2, bundle);
                } else {
                    if (BaseBehavior.this.P() == 0) {
                        return false;
                    }
                    boolean canScrollVertically = BaseBehavior.this.Y(this.f4203d).canScrollVertically(-1);
                    throw null;
                }
            }
        }

        protected static class b extends C.a {
            public static final Parcelable.Creator<b> CREATOR = new a();

            /* renamed from: c  reason: collision with root package name */
            boolean f4205c;

            /* renamed from: d  reason: collision with root package name */
            boolean f4206d;

            /* renamed from: e  reason: collision with root package name */
            int f4207e;

            /* renamed from: f  reason: collision with root package name */
            float f4208f;

            /* renamed from: g  reason: collision with root package name */
            boolean f4209g;

            class a implements Parcelable.ClassLoaderCreator {
                a() {
                }

                /* renamed from: a */
                public b createFromParcel(Parcel parcel) {
                    return new b(parcel, (ClassLoader) null);
                }

                /* renamed from: b */
                public b createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return new b(parcel, classLoader);
                }

                /* renamed from: c */
                public b[] newArray(int i2) {
                    return new b[i2];
                }
            }

            public b(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                boolean z2 = false;
                this.f4205c = parcel.readByte() != 0;
                this.f4206d = parcel.readByte() != 0;
                this.f4207e = parcel.readInt();
                this.f4208f = parcel.readFloat();
                this.f4209g = parcel.readByte() != 0 ? true : z2;
            }

            public void writeToParcel(Parcel parcel, int i2) {
                super.writeToParcel(parcel, i2);
                parcel.writeByte(this.f4205c ? (byte) 1 : 0);
                parcel.writeByte(this.f4206d ? (byte) 1 : 0);
                parcel.writeInt(this.f4207e);
                parcel.writeFloat(this.f4208f);
                parcel.writeByte(this.f4209g ? (byte) 1 : 0);
            }
        }

        public BaseBehavior() {
        }

        private void W(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            if (!W.P(coordinatorLayout)) {
                W.q0(coordinatorLayout, new a(appBarLayout, coordinatorLayout));
            }
        }

        /* access modifiers changed from: private */
        public View Y(CoordinatorLayout coordinatorLayout) {
            int childCount = coordinatorLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                if (((CoordinatorLayout.e) childAt.getLayoutParams()).e() instanceof ScrollingViewBehavior) {
                    return childAt;
                }
            }
            return null;
        }

        private void n0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            throw null;
        }

        public /* bridge */ /* synthetic */ void B(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
            android.support.v4.media.session.b.a(view);
            g0(coordinatorLayout, (AppBarLayout) null, parcelable);
        }

        public /* bridge */ /* synthetic */ Parcelable C(CoordinatorLayout coordinatorLayout, View view) {
            android.support.v4.media.session.b.a(view);
            return h0(coordinatorLayout, (AppBarLayout) null);
        }

        public /* bridge */ /* synthetic */ boolean E(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
            android.support.v4.media.session.b.a(view);
            return i0(coordinatorLayout, (AppBarLayout) null, view2, view3, i2, i3);
        }

        public /* bridge */ /* synthetic */ void G(CoordinatorLayout coordinatorLayout, View view, View view2, int i2) {
            android.support.v4.media.session.b.a(view);
            j0(coordinatorLayout, (AppBarLayout) null, view2, i2);
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ boolean K(View view) {
            android.support.v4.media.session.b.a(view);
            return X((AppBarLayout) null);
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ int N(View view) {
            android.support.v4.media.session.b.a(view);
            return Z((AppBarLayout) null);
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ int O(View view) {
            android.support.v4.media.session.b.a(view);
            return a0((AppBarLayout) null);
        }

        /* access modifiers changed from: package-private */
        public int P() {
            return I() + this.f4199k;
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ void Q(CoordinatorLayout coordinatorLayout, View view) {
            android.support.v4.media.session.b.a(view);
            b0(coordinatorLayout, (AppBarLayout) null);
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ int T(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4) {
            android.support.v4.media.session.b.a(view);
            return m0(coordinatorLayout, (AppBarLayout) null, i2, i3, i4);
        }

        /* access modifiers changed from: package-private */
        public boolean X(AppBarLayout appBarLayout) {
            WeakReference weakReference = this.f4202n;
            if (weakReference == null) {
                return true;
            }
            View view = (View) weakReference.get();
            return view != null && view.isShown() && !view.canScrollVertically(-1);
        }

        /* access modifiers changed from: package-private */
        public int Z(AppBarLayout appBarLayout) {
            throw null;
        }

        /* access modifiers changed from: package-private */
        public int a0(AppBarLayout appBarLayout) {
            throw null;
        }

        /* access modifiers changed from: package-private */
        public void b0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            n0(coordinatorLayout, appBarLayout);
            throw null;
        }

        public boolean c0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2) {
            super.p(coordinatorLayout, appBarLayout, i2);
            throw null;
        }

        public boolean d0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2, int i3, int i4, int i5) {
            throw null;
        }

        public void e0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int[] iArr, int i4) {
            throw null;
        }

        public void f0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            if (i5 < 0) {
                throw null;
            } else if (i5 == 0) {
                W(coordinatorLayout, appBarLayout);
            }
        }

        public void g0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Parcelable parcelable) {
            if (parcelable instanceof b) {
                k0((b) parcelable, true);
                super.B(coordinatorLayout, appBarLayout, this.f4201m.c());
                return;
            }
            super.B(coordinatorLayout, appBarLayout, parcelable);
            this.f4201m = null;
        }

        public Parcelable h0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            Parcelable C2 = super.C(coordinatorLayout, appBarLayout);
            b l02 = l0(C2, appBarLayout);
            return l02 == null ? C2 : l02;
        }

        public boolean i0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, View view2, int i2, int i3) {
            if ((i2 & 2) == 0) {
                this.f4202n = null;
                this.f4200l = i3;
                return false;
            }
            throw null;
        }

        public void j0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2) {
            if (this.f4200l == 0 || i2 == 1) {
                n0(coordinatorLayout, appBarLayout);
                throw null;
            } else {
                this.f4202n = new WeakReference(view);
            }
        }

        /* access modifiers changed from: package-private */
        public void k0(b bVar, boolean z2) {
            if (this.f4201m == null || z2) {
                this.f4201m = bVar;
            }
        }

        /* access modifiers changed from: package-private */
        public b l0(Parcelable parcelable, AppBarLayout appBarLayout) {
            I();
            throw null;
        }

        /* access modifiers changed from: package-private */
        public int m0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2, int i3, int i4) {
            int P2 = P();
            if (i3 == 0 || P2 < i3 || P2 > i4) {
                this.f4199k = 0;
            } else if (P2 != C0288a.b(i2, i3, i4)) {
                throw null;
            }
            W(coordinatorLayout, appBarLayout);
            return 0;
        }

        public /* bridge */ /* synthetic */ boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            android.support.v4.media.session.b.a(view);
            return c0(coordinatorLayout, (AppBarLayout) null, i2);
        }

        public /* bridge */ /* synthetic */ boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
            android.support.v4.media.session.b.a(view);
            return d0(coordinatorLayout, (AppBarLayout) null, i2, i3, i4, i5);
        }

        public /* bridge */ /* synthetic */ void u(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int[] iArr, int i4) {
            android.support.v4.media.session.b.a(view);
            e0(coordinatorLayout, (AppBarLayout) null, view2, i2, i3, iArr, i4);
        }

        public /* bridge */ /* synthetic */ void x(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            android.support.v4.media.session.b.a(view);
            f0(coordinatorLayout, (AppBarLayout) null, view2, i2, i3, i4, i5, i6, iArr);
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public static class Behavior extends BaseBehavior<AppBarLayout> {
        public Behavior() {
        }

        public /* bridge */ /* synthetic */ boolean H(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return super.H(coordinatorLayout, view, motionEvent);
        }

        public /* bridge */ /* synthetic */ int I() {
            return super.I();
        }

        public /* bridge */ /* synthetic */ boolean c0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2) {
            return super.c0(coordinatorLayout, appBarLayout, i2);
        }

        public /* bridge */ /* synthetic */ boolean d0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2, int i3, int i4, int i5) {
            return super.d0(coordinatorLayout, appBarLayout, i2, i3, i4, i5);
        }

        public /* bridge */ /* synthetic */ void e0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int[] iArr, int i4) {
            super.e0(coordinatorLayout, appBarLayout, view, i2, i3, iArr, i4);
        }

        public /* bridge */ /* synthetic */ void f0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            super.f0(coordinatorLayout, appBarLayout, view, i2, i3, i4, i5, i6, iArr);
        }

        public /* bridge */ /* synthetic */ void g0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Parcelable parcelable) {
            super.g0(coordinatorLayout, appBarLayout, parcelable);
        }

        public /* bridge */ /* synthetic */ Parcelable h0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            return super.h0(coordinatorLayout, appBarLayout);
        }

        public /* bridge */ /* synthetic */ boolean i0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, View view2, int i2, int i3) {
            return super.i0(coordinatorLayout, appBarLayout, view, view2, i2, i3);
        }

        public /* bridge */ /* synthetic */ void j0(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2) {
            super.j0(coordinatorLayout, appBarLayout, view, i2);
        }

        public /* bridge */ /* synthetic */ boolean o(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return super.o(coordinatorLayout, view, motionEvent);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public static class ScrollingViewBehavior extends b {
        public ScrollingViewBehavior() {
        }

        private void T(View view, View view2) {
            CoordinatorLayout.b e2 = ((CoordinatorLayout.e) view2.getLayoutParams()).e();
            if (e2 instanceof BaseBehavior) {
                W.b0(view, (((view2.getBottom() - view.getTop()) + ((BaseBehavior) e2).f4199k) + O()) - L(view2));
            }
        }

        private void U(View view, View view2) {
        }

        public boolean A(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z2) {
            S(coordinatorLayout.q(view));
            return false;
        }

        /* access modifiers changed from: package-private */
        public /* bridge */ /* synthetic */ View K(List list) {
            S(list);
            return null;
        }

        /* access modifiers changed from: package-private */
        public float M(View view) {
            return 0.0f;
        }

        /* access modifiers changed from: package-private */
        public int N(View view) {
            return super.N(view);
        }

        /* access modifiers changed from: package-private */
        public AppBarLayout S(List list) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = (View) list.get(i2);
            }
            return null;
        }

        public boolean i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return false;
        }

        public boolean l(CoordinatorLayout coordinatorLayout, View view, View view2) {
            T(view, view2);
            U(view, view2);
            return false;
        }

        public void m(CoordinatorLayout coordinatorLayout, View view, View view2) {
        }

        public /* bridge */ /* synthetic */ boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            return super.p(coordinatorLayout, view, i2);
        }

        public /* bridge */ /* synthetic */ boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
            return super.q(coordinatorLayout, view, i2, i3, i4, i5);
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.N4);
            Q(obtainStyledAttributes.getDimensionPixelSize(j.O4, 0));
            obtainStyledAttributes.recycle();
        }
    }
}
