package com.google.android.material.appbar;

import android.view.View;
import androidx.core.view.W;

class d {

    /* renamed from: a  reason: collision with root package name */
    private final View f4234a;

    /* renamed from: b  reason: collision with root package name */
    private int f4235b;

    /* renamed from: c  reason: collision with root package name */
    private int f4236c;

    /* renamed from: d  reason: collision with root package name */
    private int f4237d;

    /* renamed from: e  reason: collision with root package name */
    private int f4238e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4239f = true;

    /* renamed from: g  reason: collision with root package name */
    private boolean f4240g = true;

    public d(View view) {
        this.f4234a = view;
    }

    /* access modifiers changed from: package-private */
    public void a() {
        View view = this.f4234a;
        W.b0(view, this.f4237d - (view.getTop() - this.f4235b));
        View view2 = this.f4234a;
        W.a0(view2, this.f4238e - (view2.getLeft() - this.f4236c));
    }

    public int b() {
        return this.f4237d;
    }

    /* access modifiers changed from: package-private */
    public void c() {
        this.f4235b = this.f4234a.getTop();
        this.f4236c = this.f4234a.getLeft();
    }

    public boolean d(int i2) {
        if (!this.f4240g || this.f4238e == i2) {
            return false;
        }
        this.f4238e = i2;
        a();
        return true;
    }

    public boolean e(int i2) {
        if (!this.f4239f || this.f4237d == i2) {
            return false;
        }
        this.f4237d = i2;
        a();
        return true;
    }
}
