package com.google.android.material.appbar;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.C0156s;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import java.util.List;
import v.C0288a;

abstract class b extends c {

    /* renamed from: d  reason: collision with root package name */
    final Rect f4227d = new Rect();

    /* renamed from: e  reason: collision with root package name */
    final Rect f4228e = new Rect();

    /* renamed from: f  reason: collision with root package name */
    private int f4229f = 0;

    /* renamed from: g  reason: collision with root package name */
    private int f4230g;

    public b() {
    }

    private static int P(int i2) {
        if (i2 == 0) {
            return 8388659;
        }
        return i2;
    }

    /* access modifiers changed from: protected */
    public void J(CoordinatorLayout coordinatorLayout, View view, int i2) {
        int i3;
        View K2 = K(coordinatorLayout.q(view));
        if (K2 != null) {
            CoordinatorLayout.e eVar = (CoordinatorLayout.e) view.getLayoutParams();
            Rect rect = this.f4227d;
            rect.set(coordinatorLayout.getPaddingLeft() + eVar.leftMargin, K2.getBottom() + eVar.topMargin, (coordinatorLayout.getWidth() - coordinatorLayout.getPaddingRight()) - eVar.rightMargin, ((coordinatorLayout.getHeight() + K2.getBottom()) - coordinatorLayout.getPaddingBottom()) - eVar.bottomMargin);
            C0165w0 lastWindowInsets = coordinatorLayout.getLastWindowInsets();
            if (lastWindowInsets != null && W.z(coordinatorLayout) && !W.z(view)) {
                rect.left += lastWindowInsets.j();
                rect.right -= lastWindowInsets.k();
            }
            Rect rect2 = this.f4228e;
            C0156s.a(P(eVar.f2059c), view.getMeasuredWidth(), view.getMeasuredHeight(), rect, rect2, i2);
            int L2 = L(K2);
            view.layout(rect2.left, rect2.top - L2, rect2.right, rect2.bottom - L2);
            i3 = rect2.top - K2.getBottom();
        } else {
            super.J(coordinatorLayout, view, i2);
            i3 = 0;
        }
        this.f4229f = i3;
    }

    /* access modifiers changed from: package-private */
    public abstract View K(List list);

    /* access modifiers changed from: package-private */
    public final int L(View view) {
        if (this.f4230g == 0) {
            return 0;
        }
        float M2 = M(view);
        int i2 = this.f4230g;
        return C0288a.b((int) (M2 * ((float) i2)), 0, i2);
    }

    /* access modifiers changed from: package-private */
    public abstract float M(View view);

    /* access modifiers changed from: package-private */
    public int N(View view) {
        return view.getMeasuredHeight();
    }

    /* access modifiers changed from: package-private */
    public final int O() {
        return this.f4229f;
    }

    public final void Q(int i2) {
        this.f4230g = i2;
    }

    /* access modifiers changed from: protected */
    public boolean R() {
        return false;
    }

    public boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
        View K2;
        C0165w0 lastWindowInsets;
        int i6 = view.getLayoutParams().height;
        if ((i6 != -1 && i6 != -2) || (K2 = K(coordinatorLayout.q(view))) == null) {
            return false;
        }
        int size = View.MeasureSpec.getSize(i4);
        if (size <= 0) {
            size = coordinatorLayout.getHeight();
        } else if (W.z(K2) && (lastWindowInsets = coordinatorLayout.getLastWindowInsets()) != null) {
            size += lastWindowInsets.l() + lastWindowInsets.i();
        }
        int N2 = size + N(K2);
        int measuredHeight = K2.getMeasuredHeight();
        if (R()) {
            view.setTranslationY((float) (-measuredHeight));
        } else {
            view.setTranslationY(0.0f);
            N2 -= measuredHeight;
        }
        coordinatorLayout.H(view, i2, i3, View.MeasureSpec.makeMeasureSpec(N2, i6 == -1 ? 1073741824 : Integer.MIN_VALUE), i5);
        return true;
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
