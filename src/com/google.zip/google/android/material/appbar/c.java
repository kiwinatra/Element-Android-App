package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

abstract class c extends CoordinatorLayout.b {

    /* renamed from: a  reason: collision with root package name */
    private d f4231a;

    /* renamed from: b  reason: collision with root package name */
    private int f4232b = 0;

    /* renamed from: c  reason: collision with root package name */
    private int f4233c = 0;

    public c() {
    }

    public int I() {
        d dVar = this.f4231a;
        if (dVar != null) {
            return dVar.b();
        }
        return 0;
    }

    /* access modifiers changed from: protected */
    public void J(CoordinatorLayout coordinatorLayout, View view, int i2) {
        coordinatorLayout.G(view, i2);
    }

    public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
        J(coordinatorLayout, view, i2);
        if (this.f4231a == null) {
            this.f4231a = new d(view);
        }
        this.f4231a.c();
        this.f4231a.a();
        int i3 = this.f4232b;
        if (i3 != 0) {
            this.f4231a.e(i3);
            this.f4232b = 0;
        }
        int i4 = this.f4233c;
        if (i4 == 0) {
            return true;
        }
        this.f4231a.d(i4);
        this.f4233c = 0;
        return true;
    }

    public c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
