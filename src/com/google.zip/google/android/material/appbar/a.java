package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.W;

abstract class a extends c {

    /* renamed from: d  reason: collision with root package name */
    private Runnable f4217d;

    /* renamed from: e  reason: collision with root package name */
    OverScroller f4218e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4219f;

    /* renamed from: g  reason: collision with root package name */
    private int f4220g = -1;

    /* renamed from: h  reason: collision with root package name */
    private int f4221h;

    /* renamed from: i  reason: collision with root package name */
    private int f4222i = -1;

    /* renamed from: j  reason: collision with root package name */
    private VelocityTracker f4223j;

    /* renamed from: com.google.android.material.appbar.a$a  reason: collision with other inner class name */
    private class C0064a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final CoordinatorLayout f4224a;

        /* renamed from: b  reason: collision with root package name */
        private final View f4225b;

        C0064a(CoordinatorLayout coordinatorLayout, View view) {
            this.f4224a = coordinatorLayout;
            this.f4225b = view;
        }

        public void run() {
            OverScroller overScroller;
            if (this.f4225b != null && (overScroller = a.this.f4218e) != null) {
                if (overScroller.computeScrollOffset()) {
                    a aVar = a.this;
                    aVar.S(this.f4224a, this.f4225b, aVar.f4218e.getCurrY());
                    W.i0(this.f4225b, this);
                    return;
                }
                a.this.Q(this.f4224a, this.f4225b);
            }
        }
    }

    public a() {
    }

    private void L() {
        if (this.f4223j == null) {
            this.f4223j = VelocityTracker.obtain();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x007b  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x008c A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:32:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean H(androidx.coordinatorlayout.widget.CoordinatorLayout r12, android.view.View r13, android.view.MotionEvent r14) {
        /*
            r11 = this;
            int r0 = r14.getActionMasked()
            r1 = -1
            r2 = 1
            r3 = 0
            if (r0 == r2) goto L_0x004e
            r4 = 2
            if (r0 == r4) goto L_0x002d
            r12 = 3
            if (r0 == r12) goto L_0x0072
            r12 = 6
            if (r0 == r12) goto L_0x0013
            goto L_0x004c
        L_0x0013:
            int r12 = r14.getActionIndex()
            if (r12 != 0) goto L_0x001b
            r12 = 1
            goto L_0x001c
        L_0x001b:
            r12 = 0
        L_0x001c:
            int r13 = r14.getPointerId(r12)
            r11.f4220g = r13
            float r12 = r14.getY(r12)
            r13 = 1056964608(0x3f000000, float:0.5)
            float r12 = r12 + r13
            int r12 = (int) r12
            r11.f4221h = r12
            goto L_0x004c
        L_0x002d:
            int r0 = r11.f4220g
            int r0 = r14.findPointerIndex(r0)
            if (r0 != r1) goto L_0x0036
            return r3
        L_0x0036:
            float r0 = r14.getY(r0)
            int r0 = (int) r0
            int r1 = r11.f4221h
            int r7 = r1 - r0
            r11.f4221h = r0
            int r8 = r11.N(r13)
            r9 = 0
            r4 = r11
            r5 = r12
            r6 = r13
            r4.R(r5, r6, r7, r8, r9)
        L_0x004c:
            r12 = 0
            goto L_0x0081
        L_0x004e:
            android.view.VelocityTracker r0 = r11.f4223j
            if (r0 == 0) goto L_0x0072
            r0.addMovement(r14)
            android.view.VelocityTracker r0 = r11.f4223j
            r4 = 1000(0x3e8, float:1.401E-42)
            r0.computeCurrentVelocity(r4)
            android.view.VelocityTracker r0 = r11.f4223j
            int r4 = r11.f4220g
            float r10 = r0.getYVelocity(r4)
            int r0 = r11.O(r13)
            int r8 = -r0
            r9 = 0
            r5 = r11
            r6 = r12
            r7 = r13
            r5.M(r6, r7, r8, r9, r10)
            r12 = 1
            goto L_0x0073
        L_0x0072:
            r12 = 0
        L_0x0073:
            r11.f4219f = r3
            r11.f4220g = r1
            android.view.VelocityTracker r13 = r11.f4223j
            if (r13 == 0) goto L_0x0081
            r13.recycle()
            r13 = 0
            r11.f4223j = r13
        L_0x0081:
            android.view.VelocityTracker r13 = r11.f4223j
            if (r13 == 0) goto L_0x0088
            r13.addMovement(r14)
        L_0x0088:
            boolean r13 = r11.f4219f
            if (r13 != 0) goto L_0x0090
            if (r12 == 0) goto L_0x008f
            goto L_0x0090
        L_0x008f:
            r2 = 0
        L_0x0090:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.a.H(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    public abstract boolean K(View view);

    /* access modifiers changed from: package-private */
    public final boolean M(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, float f2) {
        View view2 = view;
        Runnable runnable = this.f4217d;
        if (runnable != null) {
            view.removeCallbacks(runnable);
            this.f4217d = null;
        }
        if (this.f4218e == null) {
            this.f4218e = new OverScroller(view.getContext());
        }
        this.f4218e.fling(0, I(), 0, Math.round(f2), 0, 0, i2, i3);
        if (this.f4218e.computeScrollOffset()) {
            CoordinatorLayout coordinatorLayout2 = coordinatorLayout;
            C0064a aVar = new C0064a(coordinatorLayout, view);
            this.f4217d = aVar;
            W.i0(view, aVar);
            return true;
        }
        CoordinatorLayout coordinatorLayout3 = coordinatorLayout;
        Q(coordinatorLayout, view);
        return false;
    }

    /* access modifiers changed from: package-private */
    public abstract int N(View view);

    /* access modifiers changed from: package-private */
    public abstract int O(View view);

    /* access modifiers changed from: package-private */
    public abstract int P();

    /* access modifiers changed from: package-private */
    public abstract void Q(CoordinatorLayout coordinatorLayout, View view);

    /* access modifiers changed from: package-private */
    public final int R(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4) {
        return T(coordinatorLayout, view, P() - i2, i3, i4);
    }

    /* access modifiers changed from: package-private */
    public int S(CoordinatorLayout coordinatorLayout, View view, int i2) {
        return T(coordinatorLayout, view, i2, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    /* access modifiers changed from: package-private */
    public abstract int T(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4);

    public boolean o(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        int findPointerIndex;
        if (this.f4222i < 0) {
            this.f4222i = ViewConfiguration.get(coordinatorLayout.getContext()).getScaledTouchSlop();
        }
        if (motionEvent.getActionMasked() == 2 && this.f4219f) {
            int i2 = this.f4220g;
            if (i2 == -1 || (findPointerIndex = motionEvent.findPointerIndex(i2)) == -1) {
                return false;
            }
            int y2 = (int) motionEvent.getY(findPointerIndex);
            if (Math.abs(y2 - this.f4221h) > this.f4222i) {
                this.f4221h = y2;
                return true;
            }
        }
        if (motionEvent.getActionMasked() == 0) {
            this.f4220g = -1;
            int x2 = (int) motionEvent.getX();
            int y3 = (int) motionEvent.getY();
            boolean z2 = K(view) && coordinatorLayout.z(view, x2, y3);
            this.f4219f = z2;
            if (z2) {
                this.f4221h = y3;
                this.f4220g = motionEvent.getPointerId(0);
                L();
                OverScroller overScroller = this.f4218e;
                if (overScroller != null && !overScroller.isFinished()) {
                    this.f4218e.abortAnimation();
                    return true;
                }
            }
        }
        VelocityTracker velocityTracker = this.f4223j;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEvent);
        }
        return false;
    }

    public a(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
