package com.google.android.material.appbar;

import T.a;
import T.i;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.W;
import com.google.android.material.drawable.f;
import com.google.android.material.internal.z;
import k0.g;
import k0.h;

public class MaterialToolbar extends Toolbar {

    /* renamed from: c0  reason: collision with root package name */
    private static final int f4210c0 = i.Widget_MaterialComponents_Toolbar;

    /* renamed from: d0  reason: collision with root package name */
    private static final ImageView.ScaleType[] f4211d0 = {ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE};

    /* renamed from: U  reason: collision with root package name */
    private Integer f4212U;

    /* renamed from: V  reason: collision with root package name */
    private boolean f4213V;

    /* renamed from: W  reason: collision with root package name */
    private boolean f4214W;

    /* renamed from: a0  reason: collision with root package name */
    private ImageView.ScaleType f4215a0;

    /* renamed from: b0  reason: collision with root package name */
    private Boolean f4216b0;

    public MaterialToolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.f167P);
    }

    private Pair U(TextView textView, TextView textView2) {
        int measuredWidth = getMeasuredWidth();
        int i2 = measuredWidth / 2;
        int paddingLeft = getPaddingLeft();
        int paddingRight = measuredWidth - getPaddingRight();
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if (!(childAt.getVisibility() == 8 || childAt == textView || childAt == textView2)) {
                if (childAt.getRight() < i2 && childAt.getRight() > paddingLeft) {
                    paddingLeft = childAt.getRight();
                }
                if (childAt.getLeft() > i2 && childAt.getLeft() < paddingRight) {
                    paddingRight = childAt.getLeft();
                }
            }
        }
        return new Pair(Integer.valueOf(paddingLeft), Integer.valueOf(paddingRight));
    }

    private void V(Context context) {
        Drawable background = getBackground();
        ColorStateList valueOf = background == null ? ColorStateList.valueOf(0) : f.f(background);
        if (valueOf != null) {
            g gVar = new g();
            gVar.T(valueOf);
            gVar.J(context);
            gVar.S(W.w(this));
            W.u0(this, gVar);
        }
    }

    private void W(View view, Pair pair) {
        int measuredWidth = getMeasuredWidth();
        int measuredWidth2 = view.getMeasuredWidth();
        int i2 = (measuredWidth / 2) - (measuredWidth2 / 2);
        int i3 = measuredWidth2 + i2;
        int max = Math.max(Math.max(((Integer) pair.first).intValue() - i2, 0), Math.max(i3 - ((Integer) pair.second).intValue(), 0));
        if (max > 0) {
            i2 += max;
            i3 -= max;
            view.measure(View.MeasureSpec.makeMeasureSpec(i3 - i2, 1073741824), view.getMeasuredHeightAndState());
        }
        view.layout(i2, view.getTop(), i3, view.getBottom());
    }

    private void X() {
        if (this.f4213V || this.f4214W) {
            TextView e2 = z.e(this);
            TextView c2 = z.c(this);
            if (e2 != null || c2 != null) {
                Pair U2 = U(e2, c2);
                if (this.f4213V && e2 != null) {
                    W(e2, U2);
                }
                if (this.f4214W && c2 != null) {
                    W(c2, U2);
                }
            }
        }
    }

    private Drawable Y(Drawable drawable) {
        if (drawable == null || this.f4212U == null) {
            return drawable;
        }
        Drawable r2 = androidx.core.graphics.drawable.a.r(drawable.mutate());
        androidx.core.graphics.drawable.a.n(r2, this.f4212U.intValue());
        return r2;
    }

    private void Z() {
        ImageView b2 = z.b(this);
        if (b2 != null) {
            Boolean bool = this.f4216b0;
            if (bool != null) {
                b2.setAdjustViewBounds(bool.booleanValue());
            }
            ImageView.ScaleType scaleType = this.f4215a0;
            if (scaleType != null) {
                b2.setScaleType(scaleType);
            }
        }
    }

    public ImageView.ScaleType getLogoScaleType() {
        return this.f4215a0;
    }

    public Integer getNavigationIconTint() {
        return this.f4212U;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.e(this);
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        X();
        Z();
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        h.d(this, f2);
    }

    public void setLogoAdjustViewBounds(boolean z2) {
        Boolean bool = this.f4216b0;
        if (bool == null || bool.booleanValue() != z2) {
            this.f4216b0 = Boolean.valueOf(z2);
            requestLayout();
        }
    }

    public void setLogoScaleType(ImageView.ScaleType scaleType) {
        if (this.f4215a0 != scaleType) {
            this.f4215a0 = scaleType;
            requestLayout();
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        super.setNavigationIcon(Y(drawable));
    }

    public void setNavigationIconTint(int i2) {
        this.f4212U = Integer.valueOf(i2);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }

    public void setSubtitleCentered(boolean z2) {
        if (this.f4214W != z2) {
            this.f4214W = z2;
            requestLayout();
        }
    }

    public void setTitleCentered(boolean z2) {
        if (this.f4213V != z2) {
            this.f4213V = z2;
            requestLayout();
        }
    }

    public void z(int i2) {
        Menu menu = getMenu();
        boolean z2 = menu instanceof e;
        if (z2) {
            ((e) menu).i0();
        }
        super.z(i2);
        if (z2) {
            ((e) menu).h0();
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MaterialToolbar(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = f4210c0
            android.content.Context r8 = n0.a.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            android.content.Context r8 = r7.getContext()
            int[] r2 = T.j.A3
            r6 = 0
            int[] r5 = new int[r6]
            r0 = r8
            r1 = r9
            r3 = r10
            android.content.res.TypedArray r9 = com.google.android.material.internal.y.i(r0, r1, r2, r3, r4, r5)
            int r10 = T.j.D3
            boolean r0 = r9.hasValue(r10)
            r1 = -1
            if (r0 == 0) goto L_0x0029
            int r10 = r9.getColor(r10, r1)
            r7.setNavigationIconTint(r10)
        L_0x0029:
            int r10 = T.j.F3
            boolean r10 = r9.getBoolean(r10, r6)
            r7.f4213V = r10
            int r10 = T.j.E3
            boolean r10 = r9.getBoolean(r10, r6)
            r7.f4214W = r10
            int r10 = T.j.C3
            int r10 = r9.getInt(r10, r1)
            if (r10 < 0) goto L_0x004a
            android.widget.ImageView$ScaleType[] r0 = f4211d0
            int r1 = r0.length
            if (r10 >= r1) goto L_0x004a
            r10 = r0[r10]
            r7.f4215a0 = r10
        L_0x004a:
            int r10 = T.j.B3
            boolean r0 = r9.hasValue(r10)
            if (r0 == 0) goto L_0x005c
            boolean r10 = r9.getBoolean(r10, r6)
            java.lang.Boolean r10 = java.lang.Boolean.valueOf(r10)
            r7.f4216b0 = r10
        L_0x005c:
            r9.recycle()
            r7.V(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.MaterialToolbar.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }
}
