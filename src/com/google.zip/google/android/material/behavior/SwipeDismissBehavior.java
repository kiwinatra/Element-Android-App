package com.google.android.material.behavior;

import D.c;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.W;
import y.I;
import y.L;

public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.b {

    /* renamed from: a  reason: collision with root package name */
    D.c f4254a;

    /* renamed from: b  reason: collision with root package name */
    private boolean f4255b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public boolean f4256c;

    /* renamed from: d  reason: collision with root package name */
    private float f4257d = 0.0f;

    /* renamed from: e  reason: collision with root package name */
    private boolean f4258e;

    /* renamed from: f  reason: collision with root package name */
    int f4259f = 2;

    /* renamed from: g  reason: collision with root package name */
    float f4260g = 0.5f;

    /* renamed from: h  reason: collision with root package name */
    float f4261h = 0.0f;

    /* renamed from: i  reason: collision with root package name */
    float f4262i = 0.5f;

    /* renamed from: j  reason: collision with root package name */
    private final c.C0004c f4263j = new a();

    class a extends c.C0004c {

        /* renamed from: a  reason: collision with root package name */
        private int f4264a;

        /* renamed from: b  reason: collision with root package name */
        private int f4265b = -1;

        a() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:13:0x0020 A[RETURN, SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x002c A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private boolean n(android.view.View r7, float r8) {
            /*
                r6 = this;
                r0 = 0
                r1 = 1
                r2 = 0
                int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
                if (r3 == 0) goto L_0x0034
                int r7 = androidx.core.view.W.C(r7)
                if (r7 != r1) goto L_0x000f
                r7 = 1
                goto L_0x0010
            L_0x000f:
                r7 = 0
            L_0x0010:
                com.google.android.material.behavior.SwipeDismissBehavior r4 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r4 = r4.f4259f
                r5 = 2
                if (r4 != r5) goto L_0x0018
                return r1
            L_0x0018:
                if (r4 != 0) goto L_0x0026
                if (r7 == 0) goto L_0x0022
                int r7 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
                if (r7 >= 0) goto L_0x0025
            L_0x0020:
                r0 = 1
                goto L_0x0025
            L_0x0022:
                if (r3 <= 0) goto L_0x0025
                goto L_0x0020
            L_0x0025:
                return r0
            L_0x0026:
                if (r4 != r1) goto L_0x0033
                if (r7 == 0) goto L_0x002e
                if (r3 <= 0) goto L_0x0033
            L_0x002c:
                r0 = 1
                goto L_0x0033
            L_0x002e:
                int r7 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
                if (r7 >= 0) goto L_0x0033
                goto L_0x002c
            L_0x0033:
                return r0
            L_0x0034:
                int r8 = r7.getLeft()
                int r2 = r6.f4264a
                int r8 = r8 - r2
                int r7 = r7.getWidth()
                float r7 = (float) r7
                com.google.android.material.behavior.SwipeDismissBehavior r2 = com.google.android.material.behavior.SwipeDismissBehavior.this
                float r2 = r2.f4260g
                float r7 = r7 * r2
                int r7 = java.lang.Math.round(r7)
                int r8 = java.lang.Math.abs(r8)
                if (r8 < r7) goto L_0x0051
                r0 = 1
            L_0x0051:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.n(android.view.View, float):boolean");
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
            if (r5 != false) goto L_0x001c;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0010, code lost:
            if (r5 != false) goto L_0x0012;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:8:0x001c, code lost:
            r5 = r2.f4264a;
            r3 = r3.getWidth() + r5;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int a(android.view.View r3, int r4, int r5) {
            /*
                r2 = this;
                int r5 = androidx.core.view.W.C(r3)
                r0 = 1
                if (r5 != r0) goto L_0x0009
                r5 = 1
                goto L_0x000a
            L_0x0009:
                r5 = 0
            L_0x000a:
                com.google.android.material.behavior.SwipeDismissBehavior r1 = com.google.android.material.behavior.SwipeDismissBehavior.this
                int r1 = r1.f4259f
                if (r1 != 0) goto L_0x0024
                if (r5 == 0) goto L_0x001c
            L_0x0012:
                int r5 = r2.f4264a
                int r3 = r3.getWidth()
                int r5 = r5 - r3
                int r3 = r2.f4264a
                goto L_0x0037
            L_0x001c:
                int r5 = r2.f4264a
                int r3 = r3.getWidth()
                int r3 = r3 + r5
                goto L_0x0037
            L_0x0024:
                if (r1 != r0) goto L_0x0029
                if (r5 == 0) goto L_0x0012
                goto L_0x001c
            L_0x0029:
                int r5 = r2.f4264a
                int r0 = r3.getWidth()
                int r5 = r5 - r0
                int r0 = r2.f4264a
                int r3 = r3.getWidth()
                int r3 = r3 + r0
            L_0x0037:
                int r3 = com.google.android.material.behavior.SwipeDismissBehavior.L(r5, r4, r3)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.a(android.view.View, int, int):int");
        }

        public int b(View view, int i2, int i3) {
            return view.getTop();
        }

        public int d(View view) {
            return view.getWidth();
        }

        public void i(View view, int i2) {
            this.f4265b = i2;
            this.f4264a = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                boolean unused = SwipeDismissBehavior.this.f4256c = true;
                parent.requestDisallowInterceptTouchEvent(true);
                boolean unused2 = SwipeDismissBehavior.this.f4256c = false;
            }
        }

        public void j(int i2) {
            SwipeDismissBehavior.this.getClass();
        }

        public void k(View view, int i2, int i3, int i4, int i5) {
            float width = ((float) view.getWidth()) * SwipeDismissBehavior.this.f4261h;
            float width2 = ((float) view.getWidth()) * SwipeDismissBehavior.this.f4262i;
            float abs = (float) Math.abs(i2 - this.f4264a);
            if (abs <= width) {
                view.setAlpha(1.0f);
            } else if (abs >= width2) {
                view.setAlpha(0.0f);
            } else {
                view.setAlpha(SwipeDismissBehavior.K(0.0f, 1.0f - SwipeDismissBehavior.N(width, width2, abs), 1.0f));
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x0012, code lost:
            r4 = r3.getLeft();
            r0 = r2.f4264a;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void l(android.view.View r3, float r4, float r5) {
            /*
                r2 = this;
                r5 = -1
                r2.f4265b = r5
                int r5 = r3.getWidth()
                boolean r0 = r2.n(r3, r4)
                if (r0 == 0) goto L_0x0023
                r0 = 0
                int r4 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
                if (r4 < 0) goto L_0x001d
                int r4 = r3.getLeft()
                int r0 = r2.f4264a
                if (r4 >= r0) goto L_0x001b
                goto L_0x001d
            L_0x001b:
                int r0 = r0 + r5
                goto L_0x0021
            L_0x001d:
                int r4 = r2.f4264a
                int r0 = r4 - r5
            L_0x0021:
                r4 = 1
                goto L_0x0026
            L_0x0023:
                int r0 = r2.f4264a
                r4 = 0
            L_0x0026:
                com.google.android.material.behavior.SwipeDismissBehavior r5 = com.google.android.material.behavior.SwipeDismissBehavior.this
                D.c r5 = r5.f4254a
                int r1 = r3.getTop()
                boolean r5 = r5.O(r0, r1)
                if (r5 == 0) goto L_0x003f
                com.google.android.material.behavior.SwipeDismissBehavior$c r5 = new com.google.android.material.behavior.SwipeDismissBehavior$c
                com.google.android.material.behavior.SwipeDismissBehavior r0 = com.google.android.material.behavior.SwipeDismissBehavior.this
                r5.<init>(r3, r4)
                androidx.core.view.W.i0(r3, r5)
                goto L_0x0046
            L_0x003f:
                if (r4 == 0) goto L_0x0046
                com.google.android.material.behavior.SwipeDismissBehavior r3 = com.google.android.material.behavior.SwipeDismissBehavior.this
                r3.getClass()
            L_0x0046:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.behavior.SwipeDismissBehavior.a.l(android.view.View, float, float):void");
        }

        public boolean m(View view, int i2) {
            int i3 = this.f4265b;
            return (i3 == -1 || i3 == i2) && SwipeDismissBehavior.this.J(view);
        }
    }

    class b implements L {
        b() {
        }

        public boolean a(View view, L.a aVar) {
            int i2;
            boolean z2 = false;
            if (!SwipeDismissBehavior.this.J(view)) {
                return false;
            }
            if (W.C(view) == 1) {
                z2 = true;
            }
            int i3 = SwipeDismissBehavior.this.f4259f;
            if ((i3 != 0 || !z2) && (i3 != 1 || z2)) {
                i2 = view.getWidth();
            } else {
                i2 = -view.getWidth();
            }
            W.a0(view, i2);
            view.setAlpha(0.0f);
            SwipeDismissBehavior.this.getClass();
            return true;
        }
    }

    private class c implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final View f4268a;

        /* renamed from: b  reason: collision with root package name */
        private final boolean f4269b;

        c(View view, boolean z2) {
            this.f4268a = view;
            this.f4269b = z2;
        }

        public void run() {
            D.c cVar = SwipeDismissBehavior.this.f4254a;
            if (cVar != null && cVar.m(true)) {
                W.i0(this.f4268a, this);
            } else if (this.f4269b) {
                SwipeDismissBehavior.this.getClass();
            }
        }
    }

    static float K(float f2, float f3, float f4) {
        return Math.min(Math.max(f2, f3), f4);
    }

    static int L(int i2, int i3, int i4) {
        return Math.min(Math.max(i2, i3), i4);
    }

    private void M(ViewGroup viewGroup) {
        if (this.f4254a == null) {
            this.f4254a = this.f4258e ? D.c.n(viewGroup, this.f4257d, this.f4263j) : D.c.o(viewGroup, this.f4263j);
        }
    }

    static float N(float f2, float f3, float f4) {
        return (f4 - f2) / (f3 - f2);
    }

    private void R(View view) {
        W.k0(view, 1048576);
        if (J(view)) {
            W.m0(view, I.a.f6382y, (CharSequence) null, new b());
        }
    }

    public boolean H(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        if (this.f4254a == null) {
            return false;
        }
        if (this.f4256c && motionEvent.getActionMasked() == 3) {
            return true;
        }
        this.f4254a.F(motionEvent);
        return true;
    }

    public boolean J(View view) {
        return true;
    }

    public void O(float f2) {
        this.f4262i = K(0.0f, f2, 1.0f);
    }

    public void P(float f2) {
        this.f4261h = K(0.0f, f2, 1.0f);
    }

    public void Q(int i2) {
        this.f4259f = i2;
    }

    public boolean o(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        boolean z2 = this.f4255b;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            z2 = coordinatorLayout.z(view, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.f4255b = z2;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f4255b = false;
        }
        if (!z2) {
            return false;
        }
        M(coordinatorLayout);
        return !this.f4256c && this.f4254a.P(motionEvent);
    }

    public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
        boolean p2 = super.p(coordinatorLayout, view, i2);
        if (W.A(view) == 0) {
            W.y0(view, 1);
            R(view);
        }
        return p2;
    }
}
