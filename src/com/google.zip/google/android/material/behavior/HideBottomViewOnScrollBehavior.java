package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.support.v4.media.session.b;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import f0.h;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class HideBottomViewOnScrollBehavior<V extends View> extends CoordinatorLayout.b {

    /* renamed from: j  reason: collision with root package name */
    private static final int f4241j = T.a.motionDurationLong2;

    /* renamed from: k  reason: collision with root package name */
    private static final int f4242k = T.a.motionDurationMedium4;

    /* renamed from: l  reason: collision with root package name */
    private static final int f4243l = T.a.motionEasingEmphasizedInterpolator;

    /* renamed from: a  reason: collision with root package name */
    private final LinkedHashSet f4244a = new LinkedHashSet();

    /* renamed from: b  reason: collision with root package name */
    private int f4245b;

    /* renamed from: c  reason: collision with root package name */
    private int f4246c;

    /* renamed from: d  reason: collision with root package name */
    private TimeInterpolator f4247d;

    /* renamed from: e  reason: collision with root package name */
    private TimeInterpolator f4248e;

    /* renamed from: f  reason: collision with root package name */
    private int f4249f = 0;

    /* renamed from: g  reason: collision with root package name */
    private int f4250g = 2;

    /* renamed from: h  reason: collision with root package name */
    private int f4251h = 0;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public ViewPropertyAnimator f4252i;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        public void onAnimationEnd(Animator animator) {
            ViewPropertyAnimator unused = HideBottomViewOnScrollBehavior.this.f4252i = null;
        }
    }

    public HideBottomViewOnScrollBehavior() {
    }

    private void J(View view, int i2, long j2, TimeInterpolator timeInterpolator) {
        this.f4252i = view.animate().translationY((float) i2).setInterpolator(timeInterpolator).setDuration(j2).setListener(new a());
    }

    private void Q(View view, int i2) {
        this.f4250g = i2;
        Iterator it = this.f4244a.iterator();
        if (it.hasNext()) {
            b.a(it.next());
            throw null;
        }
    }

    public boolean E(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
        return i2 == 2;
    }

    public boolean K() {
        return this.f4250g == 1;
    }

    public boolean L() {
        return this.f4250g == 2;
    }

    public void M(View view) {
        N(view, true);
    }

    public void N(View view, boolean z2) {
        if (!K()) {
            ViewPropertyAnimator viewPropertyAnimator = this.f4252i;
            if (viewPropertyAnimator != null) {
                viewPropertyAnimator.cancel();
                view.clearAnimation();
            }
            Q(view, 1);
            int i2 = this.f4249f + this.f4251h;
            if (z2) {
                J(view, i2, (long) this.f4246c, this.f4248e);
                return;
            }
            view.setTranslationY((float) i2);
        }
    }

    public void O(View view) {
        P(view, true);
    }

    public void P(View view, boolean z2) {
        if (!L()) {
            ViewPropertyAnimator viewPropertyAnimator = this.f4252i;
            if (viewPropertyAnimator != null) {
                viewPropertyAnimator.cancel();
                view.clearAnimation();
            }
            Q(view, 2);
            if (z2) {
                J(view, 0, (long) this.f4245b, this.f4247d);
                return;
            }
            view.setTranslationY((float) 0);
        }
    }

    public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
        this.f4249f = view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).bottomMargin;
        this.f4245b = h.f(view.getContext(), f4241j, 225);
        this.f4246c = h.f(view.getContext(), f4242k, 175);
        Context context = view.getContext();
        int i3 = f4243l;
        this.f4247d = h.g(context, i3, U.a.f258d);
        this.f4248e = h.g(view.getContext(), i3, U.a.f257c);
        return super.p(coordinatorLayout, view, i2);
    }

    public void x(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i3 > 0) {
            M(view);
        } else if (i3 < 0) {
            O(view);
        }
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
