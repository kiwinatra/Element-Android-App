package com.google.android.material.datepicker;

import T.g;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Locale;

class A extends RecyclerView.g {

    /* renamed from: c  reason: collision with root package name */
    private final j f4573c;

    public static class a extends RecyclerView.C {

        /* renamed from: t  reason: collision with root package name */
        final TextView f4574t;

        a(TextView textView) {
            super(textView);
            this.f4574t = textView;
        }
    }

    A(j jVar) {
        this.f4573c = jVar;
    }

    public int c() {
        return this.f4573c.G1().n();
    }

    /* access modifiers changed from: package-private */
    public int u(int i2) {
        return i2 - this.f4573c.G1().m().f4670c;
    }

    /* access modifiers changed from: package-private */
    public int v(int i2) {
        return this.f4573c.G1().m().f4670c + i2;
    }

    /* renamed from: w */
    public void j(a aVar, int i2) {
        int v2 = v(i2);
        aVar.f4574t.setText(String.format(Locale.getDefault(), "%d", new Object[]{Integer.valueOf(v2)}));
        TextView textView = aVar.f4574t;
        textView.setContentDescription(f.e(textView.getContext(), v2));
        c H1 = this.f4573c.H1();
        if (z.i().get(1) == v2) {
            b bVar = H1.f4603f;
        } else {
            b bVar2 = H1.f4601d;
        }
        this.f4573c.J1();
        throw null;
    }

    /* renamed from: x */
    public a l(ViewGroup viewGroup, int i2) {
        return new a((TextView) LayoutInflater.from(viewGroup.getContext()).inflate(g.mtrl_calendar_year, viewGroup, false));
    }
}
