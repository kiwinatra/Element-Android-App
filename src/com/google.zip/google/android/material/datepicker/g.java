package com.google.android.material.datepicker;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.material.datepicker.C0213a;
import java.util.Arrays;

public class g implements C0213a.c {
    public static final Parcelable.Creator<g> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    private final long f4606a;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public g createFromParcel(Parcel parcel) {
            return new g(parcel.readLong(), (a) null);
        }

        /* renamed from: b */
        public g[] newArray(int i2) {
            return new g[i2];
        }
    }

    private g(long j2) {
        this.f4606a = j2;
    }

    public static g c(long j2) {
        return new g(j2);
    }

    public boolean a(long j2) {
        return j2 >= this.f4606a;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof g) && this.f4606a == ((g) obj).f4606a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f4606a)});
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeLong(this.f4606a);
    }

    /* synthetic */ g(long j2, a aVar) {
        this(j2);
    }
}
