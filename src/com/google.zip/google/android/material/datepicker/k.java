package com.google.android.material.datepicker;

import android.view.View;

public final /* synthetic */ class k implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f4648a;

    public /* synthetic */ k(l lVar) {
        this.f4648a = lVar;
    }

    public final void onClick(View view) {
        this.f4648a.W1(view);
    }
}
