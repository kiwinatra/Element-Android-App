package com.google.android.material.datepicker;

import T.e;
import T.g;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.core.view.W;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.datepicker.j;

class p extends RecyclerView.g {

    /* renamed from: c  reason: collision with root package name */
    private final C0213a f4681c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final j.m f4682d;

    /* renamed from: e  reason: collision with root package name */
    private final int f4683e;

    class a implements AdapterView.OnItemClickListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ MaterialCalendarGridView f4684a;

        a(MaterialCalendarGridView materialCalendarGridView) {
            this.f4684a = materialCalendarGridView;
        }

        public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
            if (this.f4684a.getAdapter().p(i2)) {
                p.this.f4682d.a(this.f4684a.getAdapter().getItem(i2).longValue());
            }
        }
    }

    public static class b extends RecyclerView.C {

        /* renamed from: t  reason: collision with root package name */
        final TextView f4686t;

        /* renamed from: u  reason: collision with root package name */
        final MaterialCalendarGridView f4687u;

        b(LinearLayout linearLayout, boolean z2) {
            super(linearLayout);
            TextView textView = (TextView) linearLayout.findViewById(e.month_title);
            this.f4686t = textView;
            W.r0(textView, true);
            this.f4687u = (MaterialCalendarGridView) linearLayout.findViewById(e.month_grid);
            if (!z2) {
                textView.setVisibility(8);
            }
        }
    }

    p(Context context, d dVar, C0213a aVar, h hVar, j.m mVar) {
        n m2 = aVar.m();
        n i2 = aVar.i();
        n l2 = aVar.l();
        if (m2.compareTo(l2) > 0) {
            throw new IllegalArgumentException("firstPage cannot be after currentPage");
        } else if (l2.compareTo(i2) <= 0) {
            this.f4683e = (o.f4675e * j.K1(context)) + (l.T1(context) ? j.K1(context) : 0);
            this.f4681c = aVar;
            this.f4682d = mVar;
            s(true);
        } else {
            throw new IllegalArgumentException("currentPage cannot be after lastPage");
        }
    }

    public int c() {
        return this.f4681c.k();
    }

    public long d(int i2) {
        return this.f4681c.m().l(i2).k();
    }

    /* access modifiers changed from: package-private */
    public n v(int i2) {
        return this.f4681c.m().l(i2);
    }

    /* access modifiers changed from: package-private */
    public CharSequence w(int i2) {
        return v(i2).j();
    }

    /* access modifiers changed from: package-private */
    public int x(n nVar) {
        return this.f4681c.m().m(nVar);
    }

    /* renamed from: y */
    public void j(b bVar, int i2) {
        n l2 = this.f4681c.m().l(i2);
        bVar.f4686t.setText(l2.j());
        MaterialCalendarGridView materialCalendarGridView = (MaterialCalendarGridView) bVar.f4687u.findViewById(e.month_grid);
        if (materialCalendarGridView.getAdapter() == null || !l2.equals(materialCalendarGridView.getAdapter().f4677a)) {
            o oVar = new o(l2, (d) null, this.f4681c, (h) null);
            materialCalendarGridView.setNumColumns(l2.f4671d);
            materialCalendarGridView.setAdapter((ListAdapter) oVar);
        } else {
            materialCalendarGridView.invalidate();
            materialCalendarGridView.getAdapter().o(materialCalendarGridView);
        }
        materialCalendarGridView.setOnItemClickListener(new a(materialCalendarGridView));
    }

    /* renamed from: z */
    public b l(ViewGroup viewGroup, int i2) {
        LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(viewGroup.getContext()).inflate(g.mtrl_calendar_month_labeled, viewGroup, false);
        if (!l.T1(viewGroup.getContext())) {
            return new b(linearLayout, false);
        }
        linearLayout.setLayoutParams(new RecyclerView.p(-1, this.f4683e));
        return new b(linearLayout, true);
    }
}
