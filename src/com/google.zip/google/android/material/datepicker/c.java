package com.google.android.material.datepicker;

import T.a;
import T.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import h0.b;

final class c {

    /* renamed from: a  reason: collision with root package name */
    final b f4598a;

    /* renamed from: b  reason: collision with root package name */
    final b f4599b;

    /* renamed from: c  reason: collision with root package name */
    final b f4600c;

    /* renamed from: d  reason: collision with root package name */
    final b f4601d;

    /* renamed from: e  reason: collision with root package name */
    final b f4602e;

    /* renamed from: f  reason: collision with root package name */
    final b f4603f;

    /* renamed from: g  reason: collision with root package name */
    final b f4604g;

    /* renamed from: h  reason: collision with root package name */
    final Paint f4605h;

    c(Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(b.d(context, a.materialCalendarStyle, j.class.getCanonicalName()), j.B2);
        this.f4598a = b.a(context, obtainStyledAttributes.getResourceId(j.F2, 0));
        this.f4604g = b.a(context, obtainStyledAttributes.getResourceId(j.D2, 0));
        this.f4599b = b.a(context, obtainStyledAttributes.getResourceId(j.E2, 0));
        this.f4600c = b.a(context, obtainStyledAttributes.getResourceId(j.G2, 0));
        ColorStateList a2 = h0.c.a(context, obtainStyledAttributes, j.H2);
        this.f4601d = b.a(context, obtainStyledAttributes.getResourceId(j.J2, 0));
        this.f4602e = b.a(context, obtainStyledAttributes.getResourceId(j.I2, 0));
        this.f4603f = b.a(context, obtainStyledAttributes.getResourceId(j.K2, 0));
        Paint paint = new Paint();
        this.f4605h = paint;
        paint.setColor(a2.getDefaultColor());
        obtainStyledAttributes.recycle();
    }
}
