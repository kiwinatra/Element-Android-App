package com.google.android.material.datepicker;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import java.util.Objects;

/* renamed from: com.google.android.material.datepicker.a  reason: case insensitive filesystem */
public final class C0213a implements Parcelable {
    public static final Parcelable.Creator<C0213a> CREATOR = new C0066a();
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final n f4578a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final n f4579b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final c f4580c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public n f4581d;
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public final int f4582e;

    /* renamed from: f  reason: collision with root package name */
    private final int f4583f;

    /* renamed from: g  reason: collision with root package name */
    private final int f4584g;

    /* renamed from: com.google.android.material.datepicker.a$a  reason: collision with other inner class name */
    class C0066a implements Parcelable.Creator {
        C0066a() {
        }

        /* renamed from: a */
        public C0213a createFromParcel(Parcel parcel) {
            Class<n> cls = n.class;
            return new C0213a((n) parcel.readParcelable(cls.getClassLoader()), (n) parcel.readParcelable(cls.getClassLoader()), (c) parcel.readParcelable(c.class.getClassLoader()), (n) parcel.readParcelable(cls.getClassLoader()), parcel.readInt(), (C0066a) null);
        }

        /* renamed from: b */
        public C0213a[] newArray(int i2) {
            return new C0213a[i2];
        }
    }

    /* renamed from: com.google.android.material.datepicker.a$b */
    public static final class b {

        /* renamed from: f  reason: collision with root package name */
        static final long f4585f = z.a(n.d(1900, 0).f4673f);

        /* renamed from: g  reason: collision with root package name */
        static final long f4586g = z.a(n.d(2100, 11).f4673f);

        /* renamed from: a  reason: collision with root package name */
        private long f4587a = f4585f;

        /* renamed from: b  reason: collision with root package name */
        private long f4588b = f4586g;

        /* renamed from: c  reason: collision with root package name */
        private Long f4589c;

        /* renamed from: d  reason: collision with root package name */
        private int f4590d;

        /* renamed from: e  reason: collision with root package name */
        private c f4591e = g.c(Long.MIN_VALUE);

        b(C0213a aVar) {
            this.f4587a = aVar.f4578a.f4673f;
            this.f4588b = aVar.f4579b.f4673f;
            this.f4589c = Long.valueOf(aVar.f4581d.f4673f);
            this.f4590d = aVar.f4582e;
            this.f4591e = aVar.f4580c;
        }

        public C0213a a() {
            Bundle bundle = new Bundle();
            bundle.putParcelable("DEEP_COPY_VALIDATOR_KEY", this.f4591e);
            n e2 = n.e(this.f4587a);
            n e3 = n.e(this.f4588b);
            c cVar = (c) bundle.getParcelable("DEEP_COPY_VALIDATOR_KEY");
            Long l2 = this.f4589c;
            return new C0213a(e2, e3, cVar, l2 == null ? null : n.e(l2.longValue()), this.f4590d, (C0066a) null);
        }

        public b b(long j2) {
            this.f4589c = Long.valueOf(j2);
            return this;
        }
    }

    /* renamed from: com.google.android.material.datepicker.a$c */
    public interface c extends Parcelable {
        boolean a(long j2);
    }

    private C0213a(n nVar, n nVar2, c cVar, n nVar3, int i2) {
        Objects.requireNonNull(nVar, "start cannot be null");
        Objects.requireNonNull(nVar2, "end cannot be null");
        Objects.requireNonNull(cVar, "validator cannot be null");
        this.f4578a = nVar;
        this.f4579b = nVar2;
        this.f4581d = nVar3;
        this.f4582e = i2;
        this.f4580c = cVar;
        if (nVar3 != null && nVar.compareTo(nVar3) > 0) {
            throw new IllegalArgumentException("start Month cannot be after current Month");
        } else if (nVar3 != null && nVar3.compareTo(nVar2) > 0) {
            throw new IllegalArgumentException("current Month cannot be after end Month");
        } else if (i2 < 0 || i2 > z.k().getMaximum(7)) {
            throw new IllegalArgumentException("firstDayOfWeek is not valid");
        } else {
            this.f4584g = nVar.m(nVar2) + 1;
            this.f4583f = (nVar2.f4670c - nVar.f4670c) + 1;
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0213a)) {
            return false;
        }
        C0213a aVar = (C0213a) obj;
        return this.f4578a.equals(aVar.f4578a) && this.f4579b.equals(aVar.f4579b) && x.c.a(this.f4581d, aVar.f4581d) && this.f4582e == aVar.f4582e && this.f4580c.equals(aVar.f4580c);
    }

    public c h() {
        return this.f4580c;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f4578a, this.f4579b, this.f4581d, Integer.valueOf(this.f4582e), this.f4580c});
    }

    /* access modifiers changed from: package-private */
    public n i() {
        return this.f4579b;
    }

    /* access modifiers changed from: package-private */
    public int j() {
        return this.f4582e;
    }

    /* access modifiers changed from: package-private */
    public int k() {
        return this.f4584g;
    }

    /* access modifiers changed from: package-private */
    public n l() {
        return this.f4581d;
    }

    /* access modifiers changed from: package-private */
    public n m() {
        return this.f4578a;
    }

    /* access modifiers changed from: package-private */
    public int n() {
        return this.f4583f;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f4578a, 0);
        parcel.writeParcelable(this.f4579b, 0);
        parcel.writeParcelable(this.f4581d, 0);
        parcel.writeParcelable(this.f4580c, 0);
        parcel.writeInt(this.f4582e);
    }

    /* synthetic */ C0213a(n nVar, n nVar2, c cVar, n nVar3, int i2, C0066a aVar) {
        this(nVar, nVar2, cVar, nVar3, i2);
    }
}
