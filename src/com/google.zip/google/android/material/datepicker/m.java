package com.google.android.material.datepicker;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.session.b;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public final class m<S> extends r {

    /* renamed from: d0  reason: collision with root package name */
    private int f4665d0;

    /* renamed from: e0  reason: collision with root package name */
    private C0213a f4666e0;

    class a extends q {
        a() {
        }
    }

    static m z1(d dVar, int i2, C0213a aVar) {
        m mVar = new m();
        Bundle bundle = new Bundle();
        bundle.putInt("THEME_RES_ID_KEY", i2);
        bundle.putParcelable("DATE_SELECTOR_KEY", dVar);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", aVar);
        mVar.q1(bundle);
        return mVar;
    }

    public void F0(Bundle bundle) {
        super.F0(bundle);
        bundle.putInt("THEME_RES_ID_KEY", this.f4665d0);
        bundle.putParcelable("DATE_SELECTOR_KEY", (Parcelable) null);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", this.f4666e0);
    }

    public void j0(Bundle bundle) {
        super.j0(bundle);
        if (bundle == null) {
            bundle = m();
        }
        this.f4665d0 = bundle.getInt("THEME_RES_ID_KEY");
        b.a(bundle.getParcelable("DATE_SELECTOR_KEY"));
        this.f4666e0 = (C0213a) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
    }

    public View n0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater.cloneInContext(new ContextThemeWrapper(o(), this.f4665d0));
        new a();
        throw null;
    }
}
