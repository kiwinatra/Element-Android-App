package com.google.android.material.datepicker;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.Calendar;
import y.I;

public final class j<S> extends r {

    /* renamed from: o0  reason: collision with root package name */
    static final Object f4611o0 = "MONTHS_VIEW_GROUP_TAG";

    /* renamed from: p0  reason: collision with root package name */
    static final Object f4612p0 = "NAVIGATION_PREV_TAG";

    /* renamed from: q0  reason: collision with root package name */
    static final Object f4613q0 = "NAVIGATION_NEXT_TAG";

    /* renamed from: r0  reason: collision with root package name */
    static final Object f4614r0 = "SELECTOR_TOGGLE_TAG";

    /* renamed from: d0  reason: collision with root package name */
    private int f4615d0;
    /* access modifiers changed from: private */

    /* renamed from: e0  reason: collision with root package name */
    public C0213a f4616e0;
    /* access modifiers changed from: private */

    /* renamed from: f0  reason: collision with root package name */
    public n f4617f0;

    /* renamed from: g0  reason: collision with root package name */
    private l f4618g0;

    /* renamed from: h0  reason: collision with root package name */
    private c f4619h0;

    /* renamed from: i0  reason: collision with root package name */
    private RecyclerView f4620i0;
    /* access modifiers changed from: private */

    /* renamed from: j0  reason: collision with root package name */
    public RecyclerView f4621j0;

    /* renamed from: k0  reason: collision with root package name */
    private View f4622k0;

    /* renamed from: l0  reason: collision with root package name */
    private View f4623l0;

    /* renamed from: m0  reason: collision with root package name */
    private View f4624m0;
    /* access modifiers changed from: private */

    /* renamed from: n0  reason: collision with root package name */
    public View f4625n0;

    class a implements View.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ p f4626a;

        a(p pVar) {
            this.f4626a = pVar;
        }

        public void onClick(View view) {
            int g2 = j.this.M1().g2() - 1;
            if (g2 >= 0) {
                j.this.P1(this.f4626a.v(g2));
            }
        }
    }

    class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f4628a;

        b(int i2) {
            this.f4628a = i2;
        }

        public void run() {
            j.this.f4621j0.o1(this.f4628a);
        }
    }

    class c extends C0121a {
        c() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.o0((Object) null);
        }
    }

    class d extends s {

        /* renamed from: I  reason: collision with root package name */
        final /* synthetic */ int f4631I;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(Context context, int i2, boolean z2, int i3) {
            super(context, i2, z2);
            this.f4631I = i3;
        }

        /* access modifiers changed from: protected */
        public void Q1(RecyclerView.z zVar, int[] iArr) {
            if (this.f4631I == 0) {
                iArr[0] = j.this.f4621j0.getWidth();
                iArr[1] = j.this.f4621j0.getWidth();
                return;
            }
            iArr[0] = j.this.f4621j0.getHeight();
            iArr[1] = j.this.f4621j0.getHeight();
        }
    }

    class e implements m {
        e() {
        }

        public void a(long j2) {
            if (j.this.f4616e0.h().a(j2)) {
                d unused = j.this.getClass();
                throw null;
            }
        }
    }

    class f extends C0121a {
        f() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.E0(false);
        }
    }

    class g extends RecyclerView.n {

        /* renamed from: a  reason: collision with root package name */
        private final Calendar f4635a = z.k();

        /* renamed from: b  reason: collision with root package name */
        private final Calendar f4636b = z.k();

        g() {
        }

        public void g(Canvas canvas, RecyclerView recyclerView, RecyclerView.z zVar) {
            if ((recyclerView.getAdapter() instanceof A) && (recyclerView.getLayoutManager() instanceof GridLayoutManager)) {
                A a2 = (A) recyclerView.getAdapter();
                GridLayoutManager gridLayoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
                d unused = j.this.getClass();
                throw null;
            }
        }
    }

    class h extends C0121a {
        h() {
        }

        public void g(View view, I i2) {
            j jVar;
            int i3;
            super.g(view, i2);
            if (j.this.f4625n0.getVisibility() == 0) {
                jVar = j.this;
                i3 = T.h.mtrl_picker_toggle_to_year_selection;
            } else {
                jVar = j.this;
                i3 = T.h.mtrl_picker_toggle_to_day_selection;
            }
            i2.w0(jVar.P(i3));
        }
    }

    class i extends RecyclerView.s {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ p f4639a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ MaterialButton f4640b;

        i(p pVar, MaterialButton materialButton) {
            this.f4639a = pVar;
            this.f4640b = materialButton;
        }

        public void a(RecyclerView recyclerView, int i2) {
            if (i2 == 0) {
                recyclerView.announceForAccessibility(this.f4640b.getText());
            }
        }

        public void b(RecyclerView recyclerView, int i2, int i3) {
            LinearLayoutManager M1 = j.this.M1();
            int d2 = i2 < 0 ? M1.d2() : M1.g2();
            n unused = j.this.f4617f0 = this.f4639a.v(d2);
            this.f4640b.setText(this.f4639a.w(d2));
        }
    }

    /* renamed from: com.google.android.material.datepicker.j$j  reason: collision with other inner class name */
    class C0067j implements View.OnClickListener {
        C0067j() {
        }

        public void onClick(View view) {
            j.this.S1();
        }
    }

    class k implements View.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ p f4643a;

        k(p pVar) {
            this.f4643a = pVar;
        }

        public void onClick(View view) {
            int d2 = j.this.M1().d2() + 1;
            if (d2 < j.this.f4621j0.getAdapter().c()) {
                j.this.P1(this.f4643a.v(d2));
            }
        }
    }

    enum l {
        DAY,
        YEAR
    }

    interface m {
        void a(long j2);
    }

    private void E1(View view, p pVar) {
        MaterialButton materialButton = (MaterialButton) view.findViewById(T.e.month_navigation_fragment_toggle);
        materialButton.setTag(f4614r0);
        W.q0(materialButton, new h());
        View findViewById = view.findViewById(T.e.month_navigation_previous);
        this.f4622k0 = findViewById;
        findViewById.setTag(f4612p0);
        View findViewById2 = view.findViewById(T.e.month_navigation_next);
        this.f4623l0 = findViewById2;
        findViewById2.setTag(f4613q0);
        this.f4624m0 = view.findViewById(T.e.mtrl_calendar_year_selector_frame);
        this.f4625n0 = view.findViewById(T.e.mtrl_calendar_day_selector_frame);
        Q1(l.DAY);
        materialButton.setText(this.f4617f0.j());
        this.f4621j0.k(new i(pVar, materialButton));
        materialButton.setOnClickListener(new C0067j());
        this.f4623l0.setOnClickListener(new k(pVar));
        this.f4622k0.setOnClickListener(new a(pVar));
    }

    private RecyclerView.n F1() {
        return new g();
    }

    static int K1(Context context) {
        return context.getResources().getDimensionPixelSize(T.c.mtrl_calendar_day_height);
    }

    private static int L1(Context context) {
        Resources resources = context.getResources();
        int dimensionPixelSize = resources.getDimensionPixelSize(T.c.mtrl_calendar_navigation_height) + resources.getDimensionPixelOffset(T.c.mtrl_calendar_navigation_top_padding) + resources.getDimensionPixelOffset(T.c.mtrl_calendar_navigation_bottom_padding);
        int dimensionPixelSize2 = resources.getDimensionPixelSize(T.c.mtrl_calendar_days_of_week_height);
        int i2 = o.f4675e;
        return dimensionPixelSize + dimensionPixelSize2 + (resources.getDimensionPixelSize(T.c.mtrl_calendar_day_height) * i2) + ((i2 - 1) * resources.getDimensionPixelOffset(T.c.mtrl_calendar_month_vertical_padding)) + resources.getDimensionPixelOffset(T.c.mtrl_calendar_bottom_padding);
    }

    public static j N1(d dVar, int i2, C0213a aVar, h hVar) {
        j jVar = new j();
        Bundle bundle = new Bundle();
        bundle.putInt("THEME_RES_ID_KEY", i2);
        bundle.putParcelable("GRID_SELECTOR_KEY", dVar);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", aVar);
        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", hVar);
        bundle.putParcelable("CURRENT_MONTH_KEY", aVar.l());
        jVar.q1(bundle);
        return jVar;
    }

    private void O1(int i2) {
        this.f4621j0.post(new b(i2));
    }

    private void R1() {
        W.q0(this.f4621j0, new f());
    }

    public void F0(Bundle bundle) {
        super.F0(bundle);
        bundle.putInt("THEME_RES_ID_KEY", this.f4615d0);
        bundle.putParcelable("GRID_SELECTOR_KEY", (Parcelable) null);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", this.f4616e0);
        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", (Parcelable) null);
        bundle.putParcelable("CURRENT_MONTH_KEY", this.f4617f0);
    }

    /* access modifiers changed from: package-private */
    public C0213a G1() {
        return this.f4616e0;
    }

    /* access modifiers changed from: package-private */
    public c H1() {
        return this.f4619h0;
    }

    /* access modifiers changed from: package-private */
    public n I1() {
        return this.f4617f0;
    }

    public d J1() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public LinearLayoutManager M1() {
        return (LinearLayoutManager) this.f4621j0.getLayoutManager();
    }

    /* access modifiers changed from: package-private */
    public void P1(n nVar) {
        RecyclerView recyclerView;
        int i2;
        p pVar = (p) this.f4621j0.getAdapter();
        int x2 = pVar.x(nVar);
        int x3 = x2 - pVar.x(this.f4617f0);
        boolean z2 = false;
        boolean z3 = Math.abs(x3) > 3;
        if (x3 > 0) {
            z2 = true;
        }
        this.f4617f0 = nVar;
        if (!z3 || !z2) {
            if (z3) {
                recyclerView = this.f4621j0;
                i2 = x2 + 3;
            }
            O1(x2);
        }
        recyclerView = this.f4621j0;
        i2 = x2 - 3;
        recyclerView.g1(i2);
        O1(x2);
    }

    /* access modifiers changed from: package-private */
    public void Q1(l lVar) {
        this.f4618g0 = lVar;
        if (lVar == l.YEAR) {
            this.f4620i0.getLayoutManager().B1(((A) this.f4620i0.getAdapter()).u(this.f4617f0.f4670c));
            this.f4624m0.setVisibility(0);
            this.f4625n0.setVisibility(8);
            this.f4622k0.setVisibility(8);
            this.f4623l0.setVisibility(8);
        } else if (lVar == l.DAY) {
            this.f4624m0.setVisibility(8);
            this.f4625n0.setVisibility(0);
            this.f4622k0.setVisibility(0);
            this.f4623l0.setVisibility(0);
            P1(this.f4617f0);
        }
    }

    /* access modifiers changed from: package-private */
    public void S1() {
        l lVar = this.f4618g0;
        l lVar2 = l.YEAR;
        if (lVar == lVar2) {
            Q1(l.DAY);
        } else if (lVar == l.DAY) {
            Q1(lVar2);
        }
    }

    public void j0(Bundle bundle) {
        super.j0(bundle);
        if (bundle == null) {
            bundle = m();
        }
        this.f4615d0 = bundle.getInt("THEME_RES_ID_KEY");
        android.support.v4.media.session.b.a(bundle.getParcelable("GRID_SELECTOR_KEY"));
        this.f4616e0 = (C0213a) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
        android.support.v4.media.session.b.a(bundle.getParcelable("DAY_VIEW_DECORATOR_KEY"));
        this.f4617f0 = (n) bundle.getParcelable("CURRENT_MONTH_KEY");
    }

    public View n0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2;
        int i3;
        i iVar;
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(o(), this.f4615d0);
        this.f4619h0 = new c(contextThemeWrapper);
        LayoutInflater cloneInContext = layoutInflater.cloneInContext(contextThemeWrapper);
        n m2 = this.f4616e0.m();
        if (l.T1(contextThemeWrapper)) {
            i3 = T.g.mtrl_calendar_vertical;
            i2 = 1;
        } else {
            i3 = T.g.mtrl_calendar_horizontal;
            i2 = 0;
        }
        View inflate = cloneInContext.inflate(i3, viewGroup, false);
        inflate.setMinimumHeight(L1(k1()));
        GridView gridView = (GridView) inflate.findViewById(T.e.mtrl_calendar_days_of_week);
        W.q0(gridView, new c());
        int j2 = this.f4616e0.j();
        if (j2 <= 0) {
            iVar = new i();
        }
        gridView.setAdapter(iVar);
        gridView.setNumColumns(m2.f4671d);
        gridView.setEnabled(false);
        this.f4621j0 = (RecyclerView) inflate.findViewById(T.e.mtrl_calendar_months);
        this.f4621j0.setLayoutManager(new d(o(), i2, false, i2));
        this.f4621j0.setTag(f4611o0);
        p pVar = new p(contextThemeWrapper, (d) null, this.f4616e0, (h) null, new e());
        this.f4621j0.setAdapter(pVar);
        int integer = contextThemeWrapper.getResources().getInteger(T.f.mtrl_calendar_year_selector_span);
        RecyclerView recyclerView = (RecyclerView) inflate.findViewById(T.e.mtrl_calendar_year_selector_frame);
        this.f4620i0 = recyclerView;
        if (recyclerView != null) {
            recyclerView.setHasFixedSize(true);
            this.f4620i0.setLayoutManager(new GridLayoutManager((Context) contextThemeWrapper, integer, 1, false));
            this.f4620i0.setAdapter(new A(this));
            this.f4620i0.h(F1());
        }
        if (inflate.findViewById(T.e.month_navigation_fragment_toggle) != null) {
            E1(inflate, pVar);
        }
        if (!l.T1(contextThemeWrapper)) {
            new androidx.recyclerview.widget.j().b(this.f4621j0);
        }
        this.f4621j0.g1(pVar.x(this.f4617f0));
        R1();
        return inflate;
    }

    public boolean x1(q qVar) {
        return super.x1(qVar);
    }
}
