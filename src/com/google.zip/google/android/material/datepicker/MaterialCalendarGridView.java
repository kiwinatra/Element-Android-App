package com.google.android.material.datepicker;

import T.e;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.ListAdapter;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import java.util.Calendar;
import y.I;

final class MaterialCalendarGridView extends GridView {

    /* renamed from: a  reason: collision with root package name */
    private final Calendar f4575a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f4576b;

    class a extends C0121a {
        a() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            i2.o0((Object) null);
        }
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private void a(int i2, Rect rect) {
        int b2;
        if (i2 == 33) {
            b2 = getAdapter().k();
        } else if (i2 == 130) {
            b2 = getAdapter().b();
        } else {
            super.onFocusChanged(true, i2, rect);
            return;
        }
        setSelection(b2);
    }

    /* renamed from: b */
    public o getAdapter() {
        return (o) super.getAdapter();
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getAdapter().notifyDataSetChanged();
    }

    /* access modifiers changed from: protected */
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        o b2 = getAdapter();
        b2.getClass();
        int max = Math.max(b2.b(), getFirstVisiblePosition());
        int min = Math.min(b2.k(), getLastVisiblePosition());
        b2.getItem(max);
        b2.getItem(min);
        throw null;
    }

    /* access modifiers changed from: protected */
    public void onFocusChanged(boolean z2, int i2, Rect rect) {
        if (z2) {
            a(i2, rect);
        } else {
            super.onFocusChanged(false, i2, rect);
        }
    }

    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (!super.onKeyDown(i2, keyEvent)) {
            return false;
        }
        if (getSelectedItemPosition() == -1 || getSelectedItemPosition() >= getAdapter().b()) {
            return true;
        }
        if (19 != i2) {
            return false;
        }
        setSelection(getAdapter().b());
        return true;
    }

    public void onMeasure(int i2, int i3) {
        if (this.f4576b) {
            super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(16777215, Integer.MIN_VALUE));
            getLayoutParams().height = getMeasuredHeight();
            return;
        }
        super.onMeasure(i2, i3);
    }

    public void setSelection(int i2) {
        if (i2 < getAdapter().b()) {
            i2 = getAdapter().b();
        }
        super.setSelection(i2);
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f4575a = z.k();
        if (l.T1(getContext())) {
            setNextFocusLeftId(e.cancel_button);
            setNextFocusRightId(e.confirm_button);
        }
        this.f4576b = l.V1(getContext());
        W.q0(this, new a());
    }

    public final void setAdapter(ListAdapter listAdapter) {
        if (listAdapter instanceof o) {
            super.setAdapter(listAdapter);
            return;
        }
        throw new IllegalArgumentException(String.format("%1$s must have its Adapter set to a %2$s", new Object[]{MaterialCalendarGridView.class.getCanonicalName(), o.class.getCanonicalName()}));
    }
}
