package com.google.android.material.datepicker;

import java.util.Calendar;
import java.util.TimeZone;

class t {

    /* renamed from: c  reason: collision with root package name */
    private static final t f4690c = new t((Long) null, (TimeZone) null);

    /* renamed from: a  reason: collision with root package name */
    private final Long f4691a;

    /* renamed from: b  reason: collision with root package name */
    private final TimeZone f4692b;

    private t(Long l2, TimeZone timeZone) {
        this.f4691a = l2;
        this.f4692b = timeZone;
    }

    static t c() {
        return f4690c;
    }

    /* access modifiers changed from: package-private */
    public Calendar a() {
        return b(this.f4692b);
    }

    /* access modifiers changed from: package-private */
    public Calendar b(TimeZone timeZone) {
        Calendar instance = timeZone == null ? Calendar.getInstance() : Calendar.getInstance(timeZone);
        Long l2 = this.f4691a;
        if (l2 != null) {
            instance.setTimeInMillis(l2.longValue());
        }
        return instance;
    }
}
