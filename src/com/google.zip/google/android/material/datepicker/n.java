package com.google.android.material.datepicker;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;

final class n implements Comparable, Parcelable {
    public static final Parcelable.Creator<n> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    private final Calendar f4668a;

    /* renamed from: b  reason: collision with root package name */
    final int f4669b;

    /* renamed from: c  reason: collision with root package name */
    final int f4670c;

    /* renamed from: d  reason: collision with root package name */
    final int f4671d;

    /* renamed from: e  reason: collision with root package name */
    final int f4672e;

    /* renamed from: f  reason: collision with root package name */
    final long f4673f;

    /* renamed from: g  reason: collision with root package name */
    private String f4674g;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public n createFromParcel(Parcel parcel) {
            return n.d(parcel.readInt(), parcel.readInt());
        }

        /* renamed from: b */
        public n[] newArray(int i2) {
            return new n[i2];
        }
    }

    private n(Calendar calendar) {
        calendar.set(5, 1);
        Calendar c2 = z.c(calendar);
        this.f4668a = c2;
        this.f4669b = c2.get(2);
        this.f4670c = c2.get(1);
        this.f4671d = c2.getMaximum(7);
        this.f4672e = c2.getActualMaximum(5);
        this.f4673f = c2.getTimeInMillis();
    }

    static n d(int i2, int i3) {
        Calendar k2 = z.k();
        k2.set(1, i2);
        k2.set(2, i3);
        return new n(k2);
    }

    static n e(long j2) {
        Calendar k2 = z.k();
        k2.setTimeInMillis(j2);
        return new n(k2);
    }

    static n f() {
        return new n(z.i());
    }

    /* renamed from: c */
    public int compareTo(n nVar) {
        return this.f4668a.compareTo(nVar.f4668a);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        return this.f4669b == nVar.f4669b && this.f4670c == nVar.f4670c;
    }

    /* access modifiers changed from: package-private */
    public int g(int i2) {
        int i3 = this.f4668a.get(7);
        if (i2 <= 0) {
            i2 = this.f4668a.getFirstDayOfWeek();
        }
        int i4 = i3 - i2;
        return i4 < 0 ? i4 + this.f4671d : i4;
    }

    /* access modifiers changed from: package-private */
    public long h(int i2) {
        Calendar c2 = z.c(this.f4668a);
        c2.set(5, i2);
        return c2.getTimeInMillis();
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f4669b), Integer.valueOf(this.f4670c)});
    }

    /* access modifiers changed from: package-private */
    public int i(long j2) {
        Calendar c2 = z.c(this.f4668a);
        c2.setTimeInMillis(j2);
        return c2.get(5);
    }

    /* access modifiers changed from: package-private */
    public String j() {
        if (this.f4674g == null) {
            this.f4674g = f.f(this.f4668a.getTimeInMillis());
        }
        return this.f4674g;
    }

    /* access modifiers changed from: package-private */
    public long k() {
        return this.f4668a.getTimeInMillis();
    }

    /* access modifiers changed from: package-private */
    public n l(int i2) {
        Calendar c2 = z.c(this.f4668a);
        c2.add(2, i2);
        return new n(c2);
    }

    /* access modifiers changed from: package-private */
    public int m(n nVar) {
        if (this.f4668a instanceof GregorianCalendar) {
            return ((nVar.f4670c - this.f4670c) * 12) + (nVar.f4669b - this.f4669b);
        }
        throw new IllegalArgumentException("Only Gregorian calendars are supported.");
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f4670c);
        parcel.writeInt(this.f4669b);
    }
}
