package com.google.android.material.datepicker;

import androidx.fragment.app.Fragment;
import java.util.LinkedHashSet;

abstract class r extends Fragment {

    /* renamed from: c0  reason: collision with root package name */
    protected final LinkedHashSet f4688c0 = new LinkedHashSet();

    r() {
    }

    /* access modifiers changed from: package-private */
    public boolean x1(q qVar) {
        return this.f4688c0.add(qVar);
    }

    /* access modifiers changed from: package-private */
    public void y1() {
        this.f4688c0.clear();
    }
}
