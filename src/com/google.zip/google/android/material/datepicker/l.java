package com.google.android.material.datepicker;

import T.c;
import T.d;
import T.e;
import T.h;
import T.i;
import T.j;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.view.C0121a;
import androidx.core.view.C0165w0;
import androidx.core.view.F;
import androidx.core.view.W;
import androidx.fragment.app.C0175e;
import androidx.fragment.app.E;
import b0.C0210a;
import com.google.android.material.datepicker.C0213a;
import com.google.android.material.internal.B;
import com.google.android.material.internal.C0217d;
import com.google.android.material.internal.CheckableImageButton;
import f.C0236a;
import java.util.Iterator;
import java.util.LinkedHashSet;
import k0.g;

public final class l<S> extends C0175e {
    static final Object U0 = "CONFIRM_BUTTON_TAG";
    static final Object V0 = "CANCEL_BUTTON_TAG";
    static final Object W0 = "TOGGLE_BUTTON_TAG";

    /* renamed from: A0  reason: collision with root package name */
    private int f4649A0;

    /* renamed from: B0  reason: collision with root package name */
    private CharSequence f4650B0;

    /* renamed from: C0  reason: collision with root package name */
    private boolean f4651C0;
    private int D0;
    private int E0;
    private CharSequence F0;
    private int G0;
    private CharSequence H0;
    private int I0;
    private CharSequence J0;
    private int K0;
    private CharSequence L0;
    private TextView M0;
    private TextView N0;
    private CheckableImageButton O0;
    private g P0;
    private Button Q0;
    private boolean R0;
    private CharSequence S0;
    private CharSequence T0;

    /* renamed from: s0  reason: collision with root package name */
    private final LinkedHashSet f4652s0 = new LinkedHashSet();

    /* renamed from: t0  reason: collision with root package name */
    private final LinkedHashSet f4653t0 = new LinkedHashSet();

    /* renamed from: u0  reason: collision with root package name */
    private final LinkedHashSet f4654u0 = new LinkedHashSet();

    /* renamed from: v0  reason: collision with root package name */
    private final LinkedHashSet f4655v0 = new LinkedHashSet();

    /* renamed from: w0  reason: collision with root package name */
    private int f4656w0;

    /* renamed from: x0  reason: collision with root package name */
    private r f4657x0;

    /* renamed from: y0  reason: collision with root package name */
    private C0213a f4658y0;

    /* renamed from: z0  reason: collision with root package name */
    private j f4659z0;

    class a implements F {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f4660a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f4661b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ int f4662c;

        a(int i2, View view, int i3) {
            this.f4660a = i2;
            this.f4661b = view;
            this.f4662c = i3;
        }

        public C0165w0 a(View view, C0165w0 w0Var) {
            int i2 = w0Var.f(C0165w0.m.d()).f2206b;
            if (this.f4660a >= 0) {
                this.f4661b.getLayoutParams().height = this.f4660a + i2;
                View view2 = this.f4661b;
                view2.setLayoutParams(view2.getLayoutParams());
            }
            View view3 = this.f4661b;
            view3.setPadding(view3.getPaddingLeft(), this.f4662c + i2, this.f4661b.getPaddingRight(), this.f4661b.getPaddingBottom());
            return w0Var;
        }
    }

    class b extends q {
        b() {
        }
    }

    private static Drawable K1(Context context) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{16842912}, C0236a.b(context, d.material_ic_calendar_black_24dp));
        stateListDrawable.addState(new int[0], C0236a.b(context, d.material_ic_edit_black_24dp));
        return stateListDrawable;
    }

    private void L1(Window window) {
        if (!this.R0) {
            View findViewById = l1().findViewById(e.fullscreen_header);
            C0217d.a(window, true, B.d(findViewById), (Integer) null);
            W.C0(findViewById, new a(findViewById.getLayoutParams().height, findViewById, findViewById.getPaddingTop()));
            this.R0 = true;
        }
    }

    private d M1() {
        android.support.v4.media.session.b.a(m().getParcelable("DATE_SELECTOR_KEY"));
        return null;
    }

    private static CharSequence N1(CharSequence charSequence) {
        if (charSequence == null) {
            return null;
        }
        String[] split = TextUtils.split(String.valueOf(charSequence), "\n");
        return split.length > 1 ? split[0] : charSequence;
    }

    private String O1() {
        M1();
        k1();
        throw null;
    }

    private static int Q1(Context context) {
        Resources resources = context.getResources();
        int dimensionPixelOffset = resources.getDimensionPixelOffset(c.mtrl_calendar_content_padding);
        int i2 = n.f().f4671d;
        return (dimensionPixelOffset * 2) + (resources.getDimensionPixelSize(c.mtrl_calendar_day_width) * i2) + ((i2 - 1) * resources.getDimensionPixelOffset(c.mtrl_calendar_month_horizontal_padding));
    }

    private int R1(Context context) {
        int i2 = this.f4656w0;
        if (i2 != 0) {
            return i2;
        }
        M1();
        throw null;
    }

    private void S1(Context context) {
        this.O0.setTag(W0);
        this.O0.setImageDrawable(K1(context));
        this.O0.setChecked(this.D0 != 0);
        W.q0(this.O0, (C0121a) null);
        b2(this.O0);
        this.O0.setOnClickListener(new k(this));
    }

    static boolean T1(Context context) {
        return X1(context, 16843277);
    }

    private boolean U1() {
        return J().getConfiguration().orientation == 2;
    }

    static boolean V1(Context context) {
        return X1(context, T.a.nestedScrollable);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void W1(View view) {
        M1();
        throw null;
    }

    static boolean X1(Context context, int i2) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(h0.b.d(context, T.a.materialCalendarStyle, j.class.getCanonicalName()), new int[]{i2});
        boolean z2 = obtainStyledAttributes.getBoolean(0, false);
        obtainStyledAttributes.recycle();
        return z2;
    }

    private void Y1() {
        int R1 = R1(k1());
        M1();
        j N1 = j.N1((d) null, R1, this.f4658y0, (h) null);
        this.f4659z0 = N1;
        r rVar = N1;
        if (this.D0 == 1) {
            M1();
            rVar = m.z1((d) null, R1, this.f4658y0);
        }
        this.f4657x0 = rVar;
        a2();
        Z1(P1());
        E o2 = n().o();
        o2.l(e.mtrl_calendar_frame, this.f4657x0);
        o2.g();
        this.f4657x0.x1(new b());
    }

    private void a2() {
        this.M0.setText((this.D0 != 1 || !U1()) ? this.S0 : this.T0);
    }

    private void b2(CheckableImageButton checkableImageButton) {
        this.O0.setContentDescription(checkableImageButton.getContext().getString(this.D0 == 1 ? h.mtrl_picker_toggle_to_calendar_input_mode : h.mtrl_picker_toggle_to_text_input_mode));
    }

    public final Dialog D1(Bundle bundle) {
        Dialog dialog = new Dialog(k1(), R1(k1()));
        Context context = dialog.getContext();
        this.f4651C0 = T1(context);
        int i2 = T.a.materialCalendarStyle;
        int i3 = i.Widget_MaterialComponents_MaterialCalendar;
        this.P0 = new g(context, (AttributeSet) null, i2, i3);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, j.B2, i2, i3);
        int color = obtainStyledAttributes.getColor(j.C2, 0);
        obtainStyledAttributes.recycle();
        this.P0.J(context);
        this.P0.T(ColorStateList.valueOf(color));
        this.P0.S(W.w(dialog.getWindow().getDecorView()));
        return dialog;
    }

    public final void F0(Bundle bundle) {
        super.F0(bundle);
        bundle.putInt("OVERRIDE_THEME_RES_ID", this.f4656w0);
        bundle.putParcelable("DATE_SELECTOR_KEY", (Parcelable) null);
        C0213a.b bVar = new C0213a.b(this.f4658y0);
        j jVar = this.f4659z0;
        n I1 = jVar == null ? null : jVar.I1();
        if (I1 != null) {
            bVar.b(I1.f4673f);
        }
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", bVar.a());
        bundle.putParcelable("DAY_VIEW_DECORATOR_KEY", (Parcelable) null);
        bundle.putInt("TITLE_TEXT_RES_ID_KEY", this.f4649A0);
        bundle.putCharSequence("TITLE_TEXT_KEY", this.f4650B0);
        bundle.putInt("INPUT_MODE_KEY", this.D0);
        bundle.putInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY", this.E0);
        bundle.putCharSequence("POSITIVE_BUTTON_TEXT_KEY", this.F0);
        bundle.putInt("POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", this.G0);
        bundle.putCharSequence("POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY", this.H0);
        bundle.putInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY", this.I0);
        bundle.putCharSequence("NEGATIVE_BUTTON_TEXT_KEY", this.J0);
        bundle.putInt("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY", this.K0);
        bundle.putCharSequence("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY", this.L0);
    }

    public void G0() {
        super.G0();
        Window window = H1().getWindow();
        if (this.f4651C0) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawable(this.P0);
            L1(window);
        } else {
            window.setLayout(-2, -2);
            int dimensionPixelOffset = J().getDimensionPixelOffset(c.mtrl_calendar_dialog_background_inset);
            Rect rect = new Rect(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset);
            window.setBackgroundDrawable(new InsetDrawable(this.P0, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset));
            window.getDecorView().setOnTouchListener(new C0210a(H1(), rect));
        }
        Y1();
    }

    public void H0() {
        this.f4657x0.y1();
        super.H0();
    }

    public String P1() {
        M1();
        o();
        throw null;
    }

    /* access modifiers changed from: package-private */
    public void Z1(String str) {
        this.N0.setContentDescription(O1());
        this.N0.setText(str);
    }

    public final void j0(Bundle bundle) {
        super.j0(bundle);
        if (bundle == null) {
            bundle = m();
        }
        this.f4656w0 = bundle.getInt("OVERRIDE_THEME_RES_ID");
        android.support.v4.media.session.b.a(bundle.getParcelable("DATE_SELECTOR_KEY"));
        this.f4658y0 = (C0213a) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
        android.support.v4.media.session.b.a(bundle.getParcelable("DAY_VIEW_DECORATOR_KEY"));
        this.f4649A0 = bundle.getInt("TITLE_TEXT_RES_ID_KEY");
        this.f4650B0 = bundle.getCharSequence("TITLE_TEXT_KEY");
        this.D0 = bundle.getInt("INPUT_MODE_KEY");
        this.E0 = bundle.getInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY");
        this.F0 = bundle.getCharSequence("POSITIVE_BUTTON_TEXT_KEY");
        this.G0 = bundle.getInt("POSITIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY");
        this.H0 = bundle.getCharSequence("POSITIVE_BUTTON_CONTENT_DESCRIPTION_KEY");
        this.I0 = bundle.getInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY");
        this.J0 = bundle.getCharSequence("NEGATIVE_BUTTON_TEXT_KEY");
        this.K0 = bundle.getInt("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_RES_ID_KEY");
        this.L0 = bundle.getCharSequence("NEGATIVE_BUTTON_CONTENT_DESCRIPTION_KEY");
        CharSequence charSequence = this.f4650B0;
        if (charSequence == null) {
            charSequence = k1().getResources().getText(this.f4649A0);
        }
        this.S0 = charSequence;
        this.T0 = N1(charSequence);
    }

    public final View n0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View findViewById;
        LinearLayout.LayoutParams layoutParams;
        View inflate = layoutInflater.inflate(this.f4651C0 ? T.g.mtrl_picker_fullscreen : T.g.mtrl_picker_dialog, viewGroup);
        Context context = inflate.getContext();
        if (this.f4651C0) {
            findViewById = inflate.findViewById(e.mtrl_calendar_frame);
            layoutParams = new LinearLayout.LayoutParams(Q1(context), -2);
        } else {
            findViewById = inflate.findViewById(e.mtrl_calendar_main_pane);
            layoutParams = new LinearLayout.LayoutParams(Q1(context), -1);
        }
        findViewById.setLayoutParams(layoutParams);
        TextView textView = (TextView) inflate.findViewById(e.mtrl_picker_header_selection_text);
        this.N0 = textView;
        W.s0(textView, 1);
        this.O0 = (CheckableImageButton) inflate.findViewById(e.mtrl_picker_header_toggle);
        this.M0 = (TextView) inflate.findViewById(e.mtrl_picker_title_text);
        S1(context);
        this.Q0 = (Button) inflate.findViewById(e.confirm_button);
        M1();
        throw null;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        Iterator it = this.f4654u0.iterator();
        while (it.hasNext()) {
            ((DialogInterface.OnCancelListener) it.next()).onCancel(dialogInterface);
        }
        super.onCancel(dialogInterface);
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        Iterator it = this.f4655v0.iterator();
        while (it.hasNext()) {
            ((DialogInterface.OnDismissListener) it.next()).onDismiss(dialogInterface);
        }
        ViewGroup viewGroup = (ViewGroup) R();
        if (viewGroup != null) {
            viewGroup.removeAllViews();
        }
        super.onDismiss(dialogInterface);
    }
}
