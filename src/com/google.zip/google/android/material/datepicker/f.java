package com.google.android.material.datepicker;

import T.h;
import android.content.Context;
import android.os.Build;
import android.text.format.DateUtils;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

abstract class f {
    static String a(Context context, long j2, boolean z2, boolean z3, boolean z4) {
        String d2 = d(j2);
        if (z2) {
            d2 = String.format(context.getString(h.mtrl_picker_today_description), new Object[]{d2});
        }
        if (z3) {
            return String.format(context.getString(h.mtrl_picker_start_date_description), new Object[]{d2});
        } else if (!z4) {
            return d2;
        } else {
            return String.format(context.getString(h.mtrl_picker_end_date_description), new Object[]{d2});
        }
    }

    static String b(long j2) {
        return c(j2, Locale.getDefault());
    }

    static String c(long j2, Locale locale) {
        return Build.VERSION.SDK_INT >= 24 ? z.f(locale).format(new Date(j2)) : z.e(locale).format(new Date(j2));
    }

    static String d(long j2) {
        return i(j2) ? b(j2) : g(j2);
    }

    static String e(Context context, int i2) {
        if (z.i().get(1) == i2) {
            return String.format(context.getString(h.mtrl_picker_navigate_to_current_year_description), new Object[]{Integer.valueOf(i2)});
        }
        return String.format(context.getString(h.mtrl_picker_navigate_to_year_description), new Object[]{Integer.valueOf(i2)});
    }

    static String f(long j2) {
        return Build.VERSION.SDK_INT >= 24 ? z.m(Locale.getDefault()).format(new Date(j2)) : DateUtils.formatDateTime((Context) null, j2, 8228);
    }

    static String g(long j2) {
        return h(j2, Locale.getDefault());
    }

    static String h(long j2, Locale locale) {
        return Build.VERSION.SDK_INT >= 24 ? z.n(locale).format(new Date(j2)) : z.e(locale).format(new Date(j2));
    }

    private static boolean i(long j2) {
        Calendar i2 = z.i();
        Calendar k2 = z.k();
        k2.setTimeInMillis(j2);
        return i2.get(1) == k2.get(1);
    }
}
