package com.google.android.material.datepicker;

import android.os.Parcelable;
import java.util.Collection;

public interface d extends Parcelable {
    Collection b();
}
