package com.google.android.material.datepicker;

import android.content.Context;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.Collection;

class o extends BaseAdapter {

    /* renamed from: e  reason: collision with root package name */
    static final int f4675e = z.k().getMaximum(4);

    /* renamed from: f  reason: collision with root package name */
    private static final int f4676f = ((z.k().getMaximum(5) + z.k().getMaximum(7)) - 1);

    /* renamed from: a  reason: collision with root package name */
    final n f4677a;

    /* renamed from: b  reason: collision with root package name */
    private Collection f4678b;

    /* renamed from: c  reason: collision with root package name */
    c f4679c;

    /* renamed from: d  reason: collision with root package name */
    final C0213a f4680d;

    o(n nVar, d dVar, C0213a aVar, h hVar) {
        this.f4677a = nVar;
        this.f4680d = aVar;
        this.f4678b = dVar.b();
    }

    private String c(Context context, long j2) {
        return f.a(context, j2, j(j2), i(j2), g(j2));
    }

    private void f(Context context) {
        if (this.f4679c == null) {
            this.f4679c = new c(context);
        }
    }

    private boolean h(long j2) {
        throw null;
    }

    private boolean j(long j2) {
        return z.i().getTimeInMillis() == j2;
    }

    private void m(TextView textView, long j2, int i2) {
        b bVar;
        if (textView != null) {
            textView.setContentDescription(c(textView.getContext(), j2));
            if (this.f4680d.h().a(j2)) {
                textView.setEnabled(true);
                boolean h2 = h(j2);
                textView.setSelected(h2);
                bVar = h2 ? this.f4679c.f4599b : j(j2) ? this.f4679c.f4600c : this.f4679c.f4598a;
            } else {
                textView.setEnabled(false);
                bVar = this.f4679c.f4604g;
            }
            bVar.b(textView);
        }
    }

    private void n(MaterialCalendarGridView materialCalendarGridView, long j2) {
        if (n.e(j2).equals(this.f4677a)) {
            int i2 = this.f4677a.i(j2);
            m((TextView) materialCalendarGridView.getChildAt(materialCalendarGridView.getAdapter().a(i2) - materialCalendarGridView.getFirstVisiblePosition()), j2, i2);
        }
    }

    /* access modifiers changed from: package-private */
    public int a(int i2) {
        return b() + (i2 - 1);
    }

    /* access modifiers changed from: package-private */
    public int b() {
        return this.f4677a.g(this.f4680d.j());
    }

    /* renamed from: d */
    public Long getItem(int i2) {
        if (i2 < b() || i2 > k()) {
            return null;
        }
        return Long.valueOf(this.f4677a.h(l(i2)));
    }

    /* JADX WARNING: type inference failed for: r7v9, types: [android.view.View] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0063 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0064  */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.widget.TextView getView(int r6, android.view.View r7, android.view.ViewGroup r8) {
        /*
            r5 = this;
            r0 = 1
            android.content.Context r1 = r8.getContext()
            r5.f(r1)
            r1 = r7
            android.widget.TextView r1 = (android.widget.TextView) r1
            r2 = 0
            if (r7 != 0) goto L_0x001f
            android.content.Context r7 = r8.getContext()
            android.view.LayoutInflater r7 = android.view.LayoutInflater.from(r7)
            int r1 = T.g.mtrl_calendar_day
            android.view.View r7 = r7.inflate(r1, r8, r2)
            r1 = r7
            android.widget.TextView r1 = (android.widget.TextView) r1
        L_0x001f:
            int r7 = r5.b()
            int r7 = r6 - r7
            if (r7 < 0) goto L_0x0054
            com.google.android.material.datepicker.n r8 = r5.f4677a
            int r3 = r8.f4672e
            if (r7 < r3) goto L_0x002e
            goto L_0x0054
        L_0x002e:
            int r7 = r7 + r0
            r1.setTag(r8)
            android.content.res.Resources r8 = r1.getResources()
            android.content.res.Configuration r8 = r8.getConfiguration()
            java.util.Locale r8 = r8.locale
            java.lang.Integer r3 = java.lang.Integer.valueOf(r7)
            java.lang.Object[] r4 = new java.lang.Object[r0]
            r4[r2] = r3
            java.lang.String r3 = "%d"
            java.lang.String r8 = java.lang.String.format(r8, r3, r4)
            r1.setText(r8)
            r1.setVisibility(r2)
            r1.setEnabled(r0)
            goto L_0x005d
        L_0x0054:
            r7 = 8
            r1.setVisibility(r7)
            r1.setEnabled(r2)
            r7 = -1
        L_0x005d:
            java.lang.Long r6 = r5.getItem(r6)
            if (r6 != 0) goto L_0x0064
            return r1
        L_0x0064:
            long r2 = r6.longValue()
            r5.m(r1, r2, r7)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.datepicker.o.getView(int, android.view.View, android.view.ViewGroup):android.widget.TextView");
    }

    /* access modifiers changed from: package-private */
    public boolean g(long j2) {
        throw null;
    }

    public int getCount() {
        return f4676f;
    }

    public long getItemId(int i2) {
        return (long) (i2 / this.f4677a.f4671d);
    }

    public boolean hasStableIds() {
        return true;
    }

    /* access modifiers changed from: package-private */
    public boolean i(long j2) {
        throw null;
    }

    /* access modifiers changed from: package-private */
    public int k() {
        return (b() + this.f4677a.f4672e) - 1;
    }

    /* access modifiers changed from: package-private */
    public int l(int i2) {
        return (i2 - b()) + 1;
    }

    public void o(MaterialCalendarGridView materialCalendarGridView) {
        for (Long longValue : this.f4678b) {
            n(materialCalendarGridView, longValue.longValue());
        }
    }

    /* access modifiers changed from: package-private */
    public boolean p(int i2) {
        return i2 >= b() && i2 <= k();
    }
}
