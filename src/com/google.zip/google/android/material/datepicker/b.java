package com.google.android.material.datepicker;

import T.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.widget.TextView;
import androidx.core.view.W;
import h0.c;
import k0.g;
import k0.k;
import x.h;

final class b {

    /* renamed from: a  reason: collision with root package name */
    private final Rect f4592a;

    /* renamed from: b  reason: collision with root package name */
    private final ColorStateList f4593b;

    /* renamed from: c  reason: collision with root package name */
    private final ColorStateList f4594c;

    /* renamed from: d  reason: collision with root package name */
    private final ColorStateList f4595d;

    /* renamed from: e  reason: collision with root package name */
    private final int f4596e;

    /* renamed from: f  reason: collision with root package name */
    private final k f4597f;

    private b(ColorStateList colorStateList, ColorStateList colorStateList2, ColorStateList colorStateList3, int i2, k kVar, Rect rect) {
        h.d(rect.left);
        h.d(rect.top);
        h.d(rect.right);
        h.d(rect.bottom);
        this.f4592a = rect;
        this.f4593b = colorStateList2;
        this.f4594c = colorStateList;
        this.f4595d = colorStateList3;
        this.f4596e = i2;
        this.f4597f = kVar;
    }

    static b a(Context context, int i2) {
        h.b(i2 != 0, "Cannot create a CalendarItemStyle with a styleResId of 0");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(i2, j.L2);
        Rect rect = new Rect(obtainStyledAttributes.getDimensionPixelOffset(j.M2, 0), obtainStyledAttributes.getDimensionPixelOffset(j.O2, 0), obtainStyledAttributes.getDimensionPixelOffset(j.N2, 0), obtainStyledAttributes.getDimensionPixelOffset(j.P2, 0));
        ColorStateList a2 = c.a(context, obtainStyledAttributes, j.Q2);
        ColorStateList a3 = c.a(context, obtainStyledAttributes, j.V2);
        ColorStateList a4 = c.a(context, obtainStyledAttributes, j.T2);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(j.U2, 0);
        k m2 = k.b(context, obtainStyledAttributes.getResourceId(j.R2, 0), obtainStyledAttributes.getResourceId(j.S2, 0)).m();
        obtainStyledAttributes.recycle();
        return new b(a2, a3, a4, dimensionPixelSize, m2, rect);
    }

    /* access modifiers changed from: package-private */
    public void b(TextView textView) {
        c(textView, (ColorStateList) null, (ColorStateList) null);
    }

    /* access modifiers changed from: package-private */
    public void c(TextView textView, ColorStateList colorStateList, ColorStateList colorStateList2) {
        g gVar = new g();
        g gVar2 = new g();
        gVar.setShapeAppearanceModel(this.f4597f);
        gVar2.setShapeAppearanceModel(this.f4597f);
        if (colorStateList == null) {
            colorStateList = this.f4594c;
        }
        gVar.T(colorStateList);
        gVar.Y((float) this.f4596e, this.f4595d);
        if (colorStateList2 == null) {
            colorStateList2 = this.f4593b;
        }
        textView.setTextColor(colorStateList2);
        RippleDrawable rippleDrawable = new RippleDrawable(this.f4593b.withAlpha(30), gVar, gVar2);
        Rect rect = this.f4592a;
        W.u0(textView, new InsetDrawable(rippleDrawable, rect.left, rect.top, rect.right, rect.bottom));
    }
}
