package com.google.android.material.datepicker;

import android.content.Context;
import android.util.DisplayMetrics;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.g;

abstract class s extends LinearLayoutManager {

    class a extends g {
        a(Context context) {
            super(context);
        }

        /* access modifiers changed from: protected */
        public float v(DisplayMetrics displayMetrics) {
            return 100.0f / ((float) displayMetrics.densityDpi);
        }
    }

    s(Context context, int i2, boolean z2) {
        super(context, i2, z2);
    }

    public void M1(RecyclerView recyclerView, RecyclerView.z zVar, int i2) {
        a aVar = new a(recyclerView.getContext());
        aVar.p(i2);
        N1(aVar);
    }
}
