package com.google.android.material.chip;

import U.c;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.core.graphics.drawable.b;
import com.google.android.material.drawable.f;
import com.google.android.material.internal.B;
import com.google.android.material.internal.w;
import f.C0236a;
import h0.d;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import k0.g;

public class a extends g implements b, Drawable.Callback, w.b {
    private static final int[] J0 = {16842910};
    private static final ShapeDrawable K0 = new ShapeDrawable(new OvalShape());

    /* renamed from: A  reason: collision with root package name */
    private ColorStateList f4517A;

    /* renamed from: A0  reason: collision with root package name */
    private PorterDuff.Mode f4518A0 = PorterDuff.Mode.SRC_IN;

    /* renamed from: B  reason: collision with root package name */
    private float f4519B;

    /* renamed from: B0  reason: collision with root package name */
    private int[] f4520B0;

    /* renamed from: C  reason: collision with root package name */
    private float f4521C = -1.0f;

    /* renamed from: C0  reason: collision with root package name */
    private boolean f4522C0;

    /* renamed from: D  reason: collision with root package name */
    private ColorStateList f4523D;
    private ColorStateList D0;

    /* renamed from: E  reason: collision with root package name */
    private float f4524E;
    private WeakReference E0 = new WeakReference((Object) null);

    /* renamed from: F  reason: collision with root package name */
    private ColorStateList f4525F;
    private TextUtils.TruncateAt F0;

    /* renamed from: G  reason: collision with root package name */
    private CharSequence f4526G;
    private boolean G0;

    /* renamed from: H  reason: collision with root package name */
    private boolean f4527H;
    private int H0;

    /* renamed from: I  reason: collision with root package name */
    private Drawable f4528I;
    private boolean I0;

    /* renamed from: J  reason: collision with root package name */
    private ColorStateList f4529J;

    /* renamed from: K  reason: collision with root package name */
    private float f4530K;

    /* renamed from: L  reason: collision with root package name */
    private boolean f4531L;

    /* renamed from: M  reason: collision with root package name */
    private boolean f4532M;

    /* renamed from: N  reason: collision with root package name */
    private Drawable f4533N;

    /* renamed from: O  reason: collision with root package name */
    private Drawable f4534O;

    /* renamed from: P  reason: collision with root package name */
    private ColorStateList f4535P;

    /* renamed from: Q  reason: collision with root package name */
    private float f4536Q;

    /* renamed from: R  reason: collision with root package name */
    private CharSequence f4537R;

    /* renamed from: S  reason: collision with root package name */
    private boolean f4538S;

    /* renamed from: T  reason: collision with root package name */
    private boolean f4539T;

    /* renamed from: U  reason: collision with root package name */
    private Drawable f4540U;

    /* renamed from: V  reason: collision with root package name */
    private ColorStateList f4541V;

    /* renamed from: W  reason: collision with root package name */
    private c f4542W;

    /* renamed from: X  reason: collision with root package name */
    private c f4543X;

    /* renamed from: Y  reason: collision with root package name */
    private float f4544Y;

    /* renamed from: Z  reason: collision with root package name */
    private float f4545Z;

    /* renamed from: a0  reason: collision with root package name */
    private float f4546a0;

    /* renamed from: b0  reason: collision with root package name */
    private float f4547b0;

    /* renamed from: c0  reason: collision with root package name */
    private float f4548c0;

    /* renamed from: d0  reason: collision with root package name */
    private float f4549d0;

    /* renamed from: e0  reason: collision with root package name */
    private float f4550e0;

    /* renamed from: f0  reason: collision with root package name */
    private float f4551f0;

    /* renamed from: g0  reason: collision with root package name */
    private final Context f4552g0;

    /* renamed from: h0  reason: collision with root package name */
    private final Paint f4553h0 = new Paint(1);

    /* renamed from: i0  reason: collision with root package name */
    private final Paint f4554i0;

    /* renamed from: j0  reason: collision with root package name */
    private final Paint.FontMetrics f4555j0 = new Paint.FontMetrics();

    /* renamed from: k0  reason: collision with root package name */
    private final RectF f4556k0 = new RectF();

    /* renamed from: l0  reason: collision with root package name */
    private final PointF f4557l0 = new PointF();

    /* renamed from: m0  reason: collision with root package name */
    private final Path f4558m0 = new Path();

    /* renamed from: n0  reason: collision with root package name */
    private final w f4559n0;

    /* renamed from: o0  reason: collision with root package name */
    private int f4560o0;

    /* renamed from: p0  reason: collision with root package name */
    private int f4561p0;

    /* renamed from: q0  reason: collision with root package name */
    private int f4562q0;

    /* renamed from: r0  reason: collision with root package name */
    private int f4563r0;

    /* renamed from: s0  reason: collision with root package name */
    private int f4564s0;

    /* renamed from: t0  reason: collision with root package name */
    private int f4565t0;

    /* renamed from: u0  reason: collision with root package name */
    private boolean f4566u0;

    /* renamed from: v0  reason: collision with root package name */
    private int f4567v0;

    /* renamed from: w0  reason: collision with root package name */
    private int f4568w0 = 255;

    /* renamed from: x0  reason: collision with root package name */
    private ColorFilter f4569x0;

    /* renamed from: y0  reason: collision with root package name */
    private PorterDuffColorFilter f4570y0;

    /* renamed from: z  reason: collision with root package name */
    private ColorStateList f4571z;

    /* renamed from: z0  reason: collision with root package name */
    private ColorStateList f4572z0;

    /* renamed from: com.google.android.material.chip.a$a  reason: collision with other inner class name */
    public interface C0065a {
        void a();
    }

    private a(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        J(context);
        this.f4552g0 = context;
        w wVar = new w(this);
        this.f4559n0 = wVar;
        this.f4526G = "";
        wVar.f().density = context.getResources().getDisplayMetrics().density;
        this.f4554i0 = null;
        int[] iArr = J0;
        setState(iArr);
        f2(iArr);
        this.G0 = true;
        if (i0.b.f5560a) {
            K0.setTint(-1);
        }
    }

    private boolean H2() {
        return this.f4539T && this.f4540U != null && this.f4566u0;
    }

    private boolean I2() {
        return this.f4527H && this.f4528I != null;
    }

    private boolean J2() {
        return this.f4532M && this.f4533N != null;
    }

    private void K2(Drawable drawable) {
        if (drawable != null) {
            drawable.setCallback((Drawable.Callback) null);
        }
    }

    private void L2() {
        this.D0 = this.f4522C0 ? i0.b.b(this.f4525F) : null;
    }

    private void M2() {
        this.f4534O = new RippleDrawable(i0.b.b(Z0()), this.f4533N, K0);
    }

    private float T0() {
        Drawable drawable = this.f4566u0 ? this.f4540U : this.f4528I;
        float f2 = this.f4530K;
        if (f2 <= 0.0f && drawable != null) {
            f2 = (float) Math.ceil((double) B.c(this.f4552g0, 24));
            if (((float) drawable.getIntrinsicHeight()) <= f2) {
                return (float) drawable.getIntrinsicHeight();
            }
        }
        return f2;
    }

    private float U0() {
        Drawable drawable = this.f4566u0 ? this.f4540U : this.f4528I;
        float f2 = this.f4530K;
        return (f2 > 0.0f || drawable == null) ? f2 : (float) drawable.getIntrinsicWidth();
    }

    private void V1(ColorStateList colorStateList) {
        if (this.f4571z != colorStateList) {
            this.f4571z = colorStateList;
            onStateChange(getState());
        }
    }

    private void e0(Drawable drawable) {
        if (drawable != null) {
            drawable.setCallback(this);
            androidx.core.graphics.drawable.a.m(drawable, androidx.core.graphics.drawable.a.f(this));
            drawable.setLevel(getLevel());
            drawable.setVisible(isVisible(), false);
            if (drawable == this.f4533N) {
                if (drawable.isStateful()) {
                    drawable.setState(Q0());
                }
                androidx.core.graphics.drawable.a.o(drawable, this.f4535P);
                return;
            }
            Drawable drawable2 = this.f4528I;
            if (drawable == drawable2 && this.f4531L) {
                androidx.core.graphics.drawable.a.o(drawable2, this.f4529J);
            }
            if (drawable.isStateful()) {
                drawable.setState(getState());
            }
        }
    }

    private void f0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (I2() || H2()) {
            float f2 = this.f4544Y + this.f4545Z;
            float U0 = U0();
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                float f3 = ((float) rect.left) + f2;
                rectF.left = f3;
                rectF.right = f3 + U0;
            } else {
                float f4 = ((float) rect.right) - f2;
                rectF.right = f4;
                rectF.left = f4 - U0;
            }
            float T0 = T0();
            float exactCenterY = rect.exactCenterY() - (T0 / 2.0f);
            rectF.top = exactCenterY;
            rectF.bottom = exactCenterY + T0;
        }
    }

    private ColorFilter f1() {
        ColorFilter colorFilter = this.f4569x0;
        return colorFilter != null ? colorFilter : this.f4570y0;
    }

    private void h0(Rect rect, RectF rectF) {
        rectF.set(rect);
        if (J2()) {
            float f2 = this.f4551f0 + this.f4550e0 + this.f4536Q + this.f4549d0 + this.f4548c0;
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                rectF.right = ((float) rect.right) - f2;
            } else {
                rectF.left = ((float) rect.left) + f2;
            }
        }
    }

    private static boolean h1(int[] iArr, int i2) {
        if (iArr == null) {
            return false;
        }
        for (int i3 : iArr) {
            if (i3 == i2) {
                return true;
            }
        }
        return false;
    }

    private void i0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (J2()) {
            float f2 = this.f4551f0 + this.f4550e0;
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                float f3 = ((float) rect.right) - f2;
                rectF.right = f3;
                rectF.left = f3 - this.f4536Q;
            } else {
                float f4 = ((float) rect.left) + f2;
                rectF.left = f4;
                rectF.right = f4 + this.f4536Q;
            }
            float exactCenterY = rect.exactCenterY();
            float f5 = this.f4536Q;
            float f6 = exactCenterY - (f5 / 2.0f);
            rectF.top = f6;
            rectF.bottom = f6 + f5;
        }
    }

    private void j0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (J2()) {
            float f2 = this.f4551f0 + this.f4550e0 + this.f4536Q + this.f4549d0 + this.f4548c0;
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                float f3 = (float) rect.right;
                rectF.right = f3;
                rectF.left = f3 - f2;
            } else {
                int i2 = rect.left;
                rectF.left = (float) i2;
                rectF.right = ((float) i2) + f2;
            }
            rectF.top = (float) rect.top;
            rectF.bottom = (float) rect.bottom;
        }
    }

    private void l0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (this.f4526G != null) {
            float g02 = this.f4544Y + g0() + this.f4547b0;
            float k02 = this.f4551f0 + k0() + this.f4548c0;
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                rectF.left = ((float) rect.left) + g02;
                rectF.right = ((float) rect.right) - k02;
            } else {
                rectF.left = ((float) rect.left) + k02;
                rectF.right = ((float) rect.right) - g02;
            }
            rectF.top = (float) rect.top;
            rectF.bottom = (float) rect.bottom;
        }
    }

    private static boolean l1(ColorStateList colorStateList) {
        return colorStateList != null && colorStateList.isStateful();
    }

    private float m0() {
        this.f4559n0.f().getFontMetrics(this.f4555j0);
        Paint.FontMetrics fontMetrics = this.f4555j0;
        return (fontMetrics.descent + fontMetrics.ascent) / 2.0f;
    }

    private static boolean m1(Drawable drawable) {
        return drawable != null && drawable.isStateful();
    }

    private static boolean n1(d dVar) {
        if (dVar == null || dVar.i() == null || !dVar.i().isStateful()) {
            return false;
        }
        return true;
    }

    private boolean o0() {
        return this.f4539T && this.f4540U != null && this.f4538S;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x00eb  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x0182  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void o1(android.util.AttributeSet r8, int r9, int r10) {
        /*
            r7 = this;
            android.content.Context r0 = r7.f4552g0
            int[] r2 = T.j.f206b0
            r6 = 0
            int[] r5 = new int[r6]
            r1 = r8
            r3 = r9
            r4 = r10
            android.content.res.TypedArray r9 = com.google.android.material.internal.y.i(r0, r1, r2, r3, r4, r5)
            int r10 = T.j.N0
            boolean r10 = r9.hasValue(r10)
            r7.I0 = r10
            android.content.Context r10 = r7.f4552g0
            int r0 = T.j.f175A0
            android.content.res.ColorStateList r10 = h0.c.a(r10, r9, r0)
            r7.V1(r10)
            android.content.Context r10 = r7.f4552g0
            int r0 = T.j.f230n0
            android.content.res.ColorStateList r10 = h0.c.a(r10, r9, r0)
            r7.z1(r10)
            int r10 = T.j.f246v0
            r0 = 0
            float r10 = r9.getDimension(r10, r0)
            r7.N1(r10)
            int r10 = T.j.f232o0
            boolean r1 = r9.hasValue(r10)
            if (r1 == 0) goto L_0x0045
            float r10 = r9.getDimension(r10, r0)
            r7.B1(r10)
        L_0x0045:
            android.content.Context r10 = r7.f4552g0
            int r1 = T.j.f252y0
            android.content.res.ColorStateList r10 = h0.c.a(r10, r9, r1)
            r7.R1(r10)
            int r10 = T.j.f254z0
            float r10 = r9.getDimension(r10, r0)
            r7.T1(r10)
            android.content.Context r10 = r7.f4552g0
            int r1 = T.j.M0
            android.content.res.ColorStateList r10 = h0.c.a(r10, r9, r1)
            r7.s2(r10)
            int r10 = T.j.f218h0
            java.lang.CharSequence r10 = r9.getText(r10)
            r7.x2(r10)
            android.content.Context r10 = r7.f4552g0
            int r1 = T.j.f208c0
            h0.d r10 = h0.c.f(r10, r9, r1)
            int r1 = T.j.f210d0
            float r2 = r10.j()
            float r1 = r9.getDimension(r1, r2)
            r10.l(r1)
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 23
            if (r1 >= r2) goto L_0x0093
            android.content.Context r1 = r7.f4552g0
            int r2 = T.j.f212e0
            android.content.res.ColorStateList r1 = h0.c.a(r1, r9, r2)
            r10.k(r1)
        L_0x0093:
            r7.y2(r10)
            int r10 = T.j.f214f0
            int r10 = r9.getInt(r10, r6)
            r1 = 1
            if (r10 == r1) goto L_0x00af
            r1 = 2
            if (r10 == r1) goto L_0x00ac
            r1 = 3
            if (r10 == r1) goto L_0x00a6
            goto L_0x00b2
        L_0x00a6:
            android.text.TextUtils$TruncateAt r10 = android.text.TextUtils.TruncateAt.END
        L_0x00a8:
            r7.k2(r10)
            goto L_0x00b2
        L_0x00ac:
            android.text.TextUtils$TruncateAt r10 = android.text.TextUtils.TruncateAt.MIDDLE
            goto L_0x00a8
        L_0x00af:
            android.text.TextUtils$TruncateAt r10 = android.text.TextUtils.TruncateAt.START
            goto L_0x00a8
        L_0x00b2:
            int r10 = T.j.f244u0
            boolean r10 = r9.getBoolean(r10, r6)
            r7.M1(r10)
            java.lang.String r10 = "http://schemas.android.com/apk/res-auto"
            if (r8 == 0) goto L_0x00d8
            java.lang.String r1 = "chipIconEnabled"
            java.lang.String r1 = r8.getAttributeValue(r10, r1)
            if (r1 == 0) goto L_0x00d8
            java.lang.String r1 = "chipIconVisible"
            java.lang.String r1 = r8.getAttributeValue(r10, r1)
            if (r1 != 0) goto L_0x00d8
            int r1 = T.j.f238r0
            boolean r1 = r9.getBoolean(r1, r6)
            r7.M1(r1)
        L_0x00d8:
            android.content.Context r1 = r7.f4552g0
            int r2 = T.j.f236q0
            android.graphics.drawable.Drawable r1 = h0.c.d(r1, r9, r2)
            r7.F1(r1)
            int r1 = T.j.f242t0
            boolean r2 = r9.hasValue(r1)
            if (r2 == 0) goto L_0x00f4
            android.content.Context r2 = r7.f4552g0
            android.content.res.ColorStateList r1 = h0.c.a(r2, r9, r1)
            r7.J1(r1)
        L_0x00f4:
            int r1 = T.j.f240s0
            r2 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r1 = r9.getDimension(r1, r2)
            r7.H1(r1)
            int r1 = T.j.H0
            boolean r1 = r9.getBoolean(r1, r6)
            r7.i2(r1)
            if (r8 == 0) goto L_0x0123
            java.lang.String r1 = "closeIconEnabled"
            java.lang.String r1 = r8.getAttributeValue(r10, r1)
            if (r1 == 0) goto L_0x0123
            java.lang.String r1 = "closeIconVisible"
            java.lang.String r1 = r8.getAttributeValue(r10, r1)
            if (r1 != 0) goto L_0x0123
            int r1 = T.j.f179C0
            boolean r1 = r9.getBoolean(r1, r6)
            r7.i2(r1)
        L_0x0123:
            android.content.Context r1 = r7.f4552g0
            int r2 = T.j.f177B0
            android.graphics.drawable.Drawable r1 = h0.c.d(r1, r9, r2)
            r7.W1(r1)
            android.content.Context r1 = r7.f4552g0
            int r2 = T.j.G0
            android.content.res.ColorStateList r1 = h0.c.a(r1, r9, r2)
            r7.g2(r1)
            int r1 = T.j.E0
            float r1 = r9.getDimension(r1, r0)
            r7.b2(r1)
            int r1 = T.j.f220i0
            boolean r1 = r9.getBoolean(r1, r6)
            r7.r1(r1)
            int r1 = T.j.f228m0
            boolean r1 = r9.getBoolean(r1, r6)
            r7.y1(r1)
            if (r8 == 0) goto L_0x016f
            java.lang.String r1 = "checkedIconEnabled"
            java.lang.String r1 = r8.getAttributeValue(r10, r1)
            if (r1 == 0) goto L_0x016f
            java.lang.String r1 = "checkedIconVisible"
            java.lang.String r8 = r8.getAttributeValue(r10, r1)
            if (r8 != 0) goto L_0x016f
            int r8 = T.j.f224k0
            boolean r8 = r9.getBoolean(r8, r6)
            r7.y1(r8)
        L_0x016f:
            android.content.Context r8 = r7.f4552g0
            int r10 = T.j.f222j0
            android.graphics.drawable.Drawable r8 = h0.c.d(r8, r9, r10)
            r7.t1(r8)
            int r8 = T.j.f226l0
            boolean r10 = r9.hasValue(r8)
            if (r10 == 0) goto L_0x018b
            android.content.Context r10 = r7.f4552g0
            android.content.res.ColorStateList r8 = h0.c.a(r10, r9, r8)
            r7.v1(r8)
        L_0x018b:
            android.content.Context r8 = r7.f4552g0
            int r10 = T.j.O0
            U.c r8 = U.c.b(r8, r9, r10)
            r7.v2(r8)
            android.content.Context r8 = r7.f4552g0
            int r10 = T.j.J0
            U.c r8 = U.c.b(r8, r9, r10)
            r7.l2(r8)
            int r8 = T.j.f250x0
            float r8 = r9.getDimension(r8, r0)
            r7.P1(r8)
            int r8 = T.j.L0
            float r8 = r9.getDimension(r8, r0)
            r7.p2(r8)
            int r8 = T.j.K0
            float r8 = r9.getDimension(r8, r0)
            r7.n2(r8)
            int r8 = T.j.Q0
            float r8 = r9.getDimension(r8, r0)
            r7.D2(r8)
            int r8 = T.j.P0
            float r8 = r9.getDimension(r8, r0)
            r7.A2(r8)
            int r8 = T.j.F0
            float r8 = r9.getDimension(r8, r0)
            r7.d2(r8)
            int r8 = T.j.D0
            float r8 = r9.getDimension(r8, r0)
            r7.Y1(r8)
            int r8 = T.j.f234p0
            float r8 = r9.getDimension(r8, r0)
            r7.D1(r8)
            int r8 = T.j.f216g0
            r10 = 2147483647(0x7fffffff, float:NaN)
            int r8 = r9.getDimensionPixelSize(r8, r10)
            r7.r2(r8)
            r9.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.a.o1(android.util.AttributeSet, int, int):void");
    }

    public static a p0(Context context, AttributeSet attributeSet, int i2, int i3) {
        a aVar = new a(context, attributeSet, i2, i3);
        aVar.o1(attributeSet, i2, i3);
        return aVar;
    }

    private void q0(Canvas canvas, Rect rect) {
        if (H2()) {
            f0(rect, this.f4556k0);
            RectF rectF = this.f4556k0;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f4540U.setBounds(0, 0, (int) this.f4556k0.width(), (int) this.f4556k0.height());
            this.f4540U.draw(canvas);
            canvas.translate(-f2, -f3);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:69:0x00e7  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x00ee  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0100  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0109  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0118  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0127  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0151  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x0156  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean q1(int[] r7, int[] r8) {
        /*
            r6 = this;
            boolean r0 = super.onStateChange(r7)
            android.content.res.ColorStateList r1 = r6.f4571z
            r2 = 0
            if (r1 == 0) goto L_0x0010
            int r3 = r6.f4560o0
            int r1 = r1.getColorForState(r7, r3)
            goto L_0x0011
        L_0x0010:
            r1 = 0
        L_0x0011:
            int r1 = r6.l(r1)
            int r3 = r6.f4560o0
            r4 = 1
            if (r3 == r1) goto L_0x001d
            r6.f4560o0 = r1
            r0 = 1
        L_0x001d:
            android.content.res.ColorStateList r3 = r6.f4517A
            if (r3 == 0) goto L_0x0028
            int r5 = r6.f4561p0
            int r3 = r3.getColorForState(r7, r5)
            goto L_0x0029
        L_0x0028:
            r3 = 0
        L_0x0029:
            int r3 = r6.l(r3)
            int r5 = r6.f4561p0
            if (r5 == r3) goto L_0x0034
            r6.f4561p0 = r3
            r0 = 1
        L_0x0034:
            int r1 = a0.C0087a.j(r1, r3)
            int r3 = r6.f4562q0
            if (r3 == r1) goto L_0x003e
            r3 = 1
            goto L_0x003f
        L_0x003e:
            r3 = 0
        L_0x003f:
            android.content.res.ColorStateList r5 = r6.v()
            if (r5 != 0) goto L_0x0047
            r5 = 1
            goto L_0x0048
        L_0x0047:
            r5 = 0
        L_0x0048:
            r3 = r3 | r5
            if (r3 == 0) goto L_0x0055
            r6.f4562q0 = r1
            android.content.res.ColorStateList r0 = android.content.res.ColorStateList.valueOf(r1)
            r6.T(r0)
            r0 = 1
        L_0x0055:
            android.content.res.ColorStateList r1 = r6.f4523D
            if (r1 == 0) goto L_0x0060
            int r3 = r6.f4563r0
            int r1 = r1.getColorForState(r7, r3)
            goto L_0x0061
        L_0x0060:
            r1 = 0
        L_0x0061:
            int r3 = r6.f4563r0
            if (r3 == r1) goto L_0x0068
            r6.f4563r0 = r1
            r0 = 1
        L_0x0068:
            android.content.res.ColorStateList r1 = r6.D0
            if (r1 == 0) goto L_0x007b
            boolean r1 = i0.b.c(r7)
            if (r1 == 0) goto L_0x007b
            android.content.res.ColorStateList r1 = r6.D0
            int r3 = r6.f4564s0
            int r1 = r1.getColorForState(r7, r3)
            goto L_0x007c
        L_0x007b:
            r1 = 0
        L_0x007c:
            int r3 = r6.f4564s0
            if (r3 == r1) goto L_0x0087
            r6.f4564s0 = r1
            boolean r1 = r6.f4522C0
            if (r1 == 0) goto L_0x0087
            r0 = 1
        L_0x0087:
            com.google.android.material.internal.w r1 = r6.f4559n0
            h0.d r1 = r1.e()
            if (r1 == 0) goto L_0x00ac
            com.google.android.material.internal.w r1 = r6.f4559n0
            h0.d r1 = r1.e()
            android.content.res.ColorStateList r1 = r1.i()
            if (r1 == 0) goto L_0x00ac
            com.google.android.material.internal.w r1 = r6.f4559n0
            h0.d r1 = r1.e()
            android.content.res.ColorStateList r1 = r1.i()
            int r3 = r6.f4565t0
            int r1 = r1.getColorForState(r7, r3)
            goto L_0x00ad
        L_0x00ac:
            r1 = 0
        L_0x00ad:
            int r3 = r6.f4565t0
            if (r3 == r1) goto L_0x00b4
            r6.f4565t0 = r1
            r0 = 1
        L_0x00b4:
            int[] r1 = r6.getState()
            r3 = 16842912(0x10100a0, float:2.3694006E-38)
            boolean r1 = h1(r1, r3)
            if (r1 == 0) goto L_0x00c7
            boolean r1 = r6.f4538S
            if (r1 == 0) goto L_0x00c7
            r1 = 1
            goto L_0x00c8
        L_0x00c7:
            r1 = 0
        L_0x00c8:
            boolean r3 = r6.f4566u0
            if (r3 == r1) goto L_0x00e2
            android.graphics.drawable.Drawable r3 = r6.f4540U
            if (r3 == 0) goto L_0x00e2
            float r0 = r6.g0()
            r6.f4566u0 = r1
            float r1 = r6.g0()
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x00e1
            r0 = 1
            r1 = 1
            goto L_0x00e3
        L_0x00e1:
            r0 = 1
        L_0x00e2:
            r1 = 0
        L_0x00e3:
            android.content.res.ColorStateList r3 = r6.f4572z0
            if (r3 == 0) goto L_0x00ee
            int r5 = r6.f4567v0
            int r3 = r3.getColorForState(r7, r5)
            goto L_0x00ef
        L_0x00ee:
            r3 = 0
        L_0x00ef:
            int r5 = r6.f4567v0
            if (r5 == r3) goto L_0x0100
            r6.f4567v0 = r3
            android.content.res.ColorStateList r0 = r6.f4572z0
            android.graphics.PorterDuff$Mode r3 = r6.f4518A0
            android.graphics.PorterDuffColorFilter r0 = com.google.android.material.drawable.f.j(r6, r0, r3)
            r6.f4570y0 = r0
            goto L_0x0101
        L_0x0100:
            r4 = r0
        L_0x0101:
            android.graphics.drawable.Drawable r0 = r6.f4528I
            boolean r0 = m1(r0)
            if (r0 == 0) goto L_0x0110
            android.graphics.drawable.Drawable r0 = r6.f4528I
            boolean r0 = r0.setState(r7)
            r4 = r4 | r0
        L_0x0110:
            android.graphics.drawable.Drawable r0 = r6.f4540U
            boolean r0 = m1(r0)
            if (r0 == 0) goto L_0x011f
            android.graphics.drawable.Drawable r0 = r6.f4540U
            boolean r0 = r0.setState(r7)
            r4 = r4 | r0
        L_0x011f:
            android.graphics.drawable.Drawable r0 = r6.f4533N
            boolean r0 = m1(r0)
            if (r0 == 0) goto L_0x013c
            int r0 = r7.length
            int r3 = r8.length
            int r0 = r0 + r3
            int[] r0 = new int[r0]
            int r3 = r7.length
            java.lang.System.arraycopy(r7, r2, r0, r2, r3)
            int r7 = r7.length
            int r3 = r8.length
            java.lang.System.arraycopy(r8, r2, r0, r7, r3)
            android.graphics.drawable.Drawable r7 = r6.f4533N
            boolean r7 = r7.setState(r0)
            r4 = r4 | r7
        L_0x013c:
            boolean r7 = i0.b.f5560a
            if (r7 == 0) goto L_0x014f
            android.graphics.drawable.Drawable r7 = r6.f4534O
            boolean r7 = m1(r7)
            if (r7 == 0) goto L_0x014f
            android.graphics.drawable.Drawable r7 = r6.f4534O
            boolean r7 = r7.setState(r8)
            r4 = r4 | r7
        L_0x014f:
            if (r4 == 0) goto L_0x0154
            r6.invalidateSelf()
        L_0x0154:
            if (r1 == 0) goto L_0x0159
            r6.p1()
        L_0x0159:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.a.q1(int[], int[]):boolean");
    }

    private void r0(Canvas canvas, Rect rect) {
        if (!this.I0) {
            this.f4553h0.setColor(this.f4561p0);
            this.f4553h0.setStyle(Paint.Style.FILL);
            this.f4553h0.setColorFilter(f1());
            this.f4556k0.set(rect);
            canvas.drawRoundRect(this.f4556k0, C0(), C0(), this.f4553h0);
        }
    }

    private void s0(Canvas canvas, Rect rect) {
        if (I2()) {
            f0(rect, this.f4556k0);
            RectF rectF = this.f4556k0;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f4528I.setBounds(0, 0, (int) this.f4556k0.width(), (int) this.f4556k0.height());
            this.f4528I.draw(canvas);
            canvas.translate(-f2, -f3);
        }
    }

    private void t0(Canvas canvas, Rect rect) {
        if (this.f4524E > 0.0f && !this.I0) {
            this.f4553h0.setColor(this.f4563r0);
            this.f4553h0.setStyle(Paint.Style.STROKE);
            if (!this.I0) {
                this.f4553h0.setColorFilter(f1());
            }
            RectF rectF = this.f4556k0;
            float f2 = this.f4524E;
            rectF.set(((float) rect.left) + (f2 / 2.0f), ((float) rect.top) + (f2 / 2.0f), ((float) rect.right) - (f2 / 2.0f), ((float) rect.bottom) - (f2 / 2.0f));
            float f3 = this.f4521C - (this.f4524E / 2.0f);
            canvas.drawRoundRect(this.f4556k0, f3, f3, this.f4553h0);
        }
    }

    private void u0(Canvas canvas, Rect rect) {
        if (!this.I0) {
            this.f4553h0.setColor(this.f4560o0);
            this.f4553h0.setStyle(Paint.Style.FILL);
            this.f4556k0.set(rect);
            canvas.drawRoundRect(this.f4556k0, C0(), C0(), this.f4553h0);
        }
    }

    private void v0(Canvas canvas, Rect rect) {
        Drawable drawable;
        if (J2()) {
            i0(rect, this.f4556k0);
            RectF rectF = this.f4556k0;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f4533N.setBounds(0, 0, (int) this.f4556k0.width(), (int) this.f4556k0.height());
            if (i0.b.f5560a) {
                this.f4534O.setBounds(this.f4533N.getBounds());
                this.f4534O.jumpToCurrentState();
                drawable = this.f4534O;
            } else {
                drawable = this.f4533N;
            }
            drawable.draw(canvas);
            canvas.translate(-f2, -f3);
        }
    }

    private void w0(Canvas canvas, Rect rect) {
        this.f4553h0.setColor(this.f4564s0);
        this.f4553h0.setStyle(Paint.Style.FILL);
        this.f4556k0.set(rect);
        if (!this.I0) {
            canvas.drawRoundRect(this.f4556k0, C0(), C0(), this.f4553h0);
            return;
        }
        h(new RectF(rect), this.f4558m0);
        super.p(canvas, this.f4553h0, this.f4558m0, s());
    }

    private void x0(Canvas canvas, Rect rect) {
        Paint paint = this.f4554i0;
        if (paint != null) {
            paint.setColor(androidx.core.graphics.a.k(-16777216, 127));
            canvas.drawRect(rect, this.f4554i0);
            if (I2() || H2()) {
                f0(rect, this.f4556k0);
                canvas.drawRect(this.f4556k0, this.f4554i0);
            }
            if (this.f4526G != null) {
                canvas.drawLine((float) rect.left, rect.exactCenterY(), (float) rect.right, rect.exactCenterY(), this.f4554i0);
            }
            if (J2()) {
                i0(rect, this.f4556k0);
                canvas.drawRect(this.f4556k0, this.f4554i0);
            }
            this.f4554i0.setColor(androidx.core.graphics.a.k(-65536, 127));
            h0(rect, this.f4556k0);
            canvas.drawRect(this.f4556k0, this.f4554i0);
            this.f4554i0.setColor(androidx.core.graphics.a.k(-16711936, 127));
            j0(rect, this.f4556k0);
            canvas.drawRect(this.f4556k0, this.f4554i0);
        }
    }

    private void y0(Canvas canvas, Rect rect) {
        if (this.f4526G != null) {
            Paint.Align n02 = n0(rect, this.f4557l0);
            l0(rect, this.f4556k0);
            if (this.f4559n0.e() != null) {
                this.f4559n0.f().drawableState = getState();
                this.f4559n0.l(this.f4552g0);
            }
            this.f4559n0.f().setTextAlign(n02);
            int i2 = 0;
            boolean z2 = Math.round(this.f4559n0.g(b1().toString())) > Math.round(this.f4556k0.width());
            if (z2) {
                i2 = canvas.save();
                canvas.clipRect(this.f4556k0);
            }
            CharSequence charSequence = this.f4526G;
            if (z2 && this.F0 != null) {
                charSequence = TextUtils.ellipsize(charSequence, this.f4559n0.f(), this.f4556k0.width(), this.F0);
            }
            CharSequence charSequence2 = charSequence;
            int length = charSequence2.length();
            PointF pointF = this.f4557l0;
            canvas.drawText(charSequence2, 0, length, pointF.x, pointF.y, this.f4559n0.f());
            if (z2) {
                canvas.restoreToCount(i2);
            }
        }
    }

    public ColorStateList A0() {
        return this.f4541V;
    }

    public void A1(int i2) {
        z1(C0236a.a(this.f4552g0, i2));
    }

    public void A2(float f2) {
        if (this.f4548c0 != f2) {
            this.f4548c0 = f2;
            invalidateSelf();
            p1();
        }
    }

    public ColorStateList B0() {
        return this.f4517A;
    }

    public void B1(float f2) {
        if (this.f4521C != f2) {
            this.f4521C = f2;
            setShapeAppearanceModel(A().w(f2));
        }
    }

    public void B2(int i2) {
        A2(this.f4552g0.getResources().getDimension(i2));
    }

    public float C0() {
        return this.I0 ? C() : this.f4521C;
    }

    public void C1(int i2) {
        B1(this.f4552g0.getResources().getDimension(i2));
    }

    public void C2(float f2) {
        d c1 = c1();
        if (c1 != null) {
            c1.l(f2);
            this.f4559n0.f().setTextSize(f2);
            a();
        }
    }

    public float D0() {
        return this.f4551f0;
    }

    public void D1(float f2) {
        if (this.f4551f0 != f2) {
            this.f4551f0 = f2;
            invalidateSelf();
            p1();
        }
    }

    public void D2(float f2) {
        if (this.f4547b0 != f2) {
            this.f4547b0 = f2;
            invalidateSelf();
            p1();
        }
    }

    public Drawable E0() {
        Drawable drawable = this.f4528I;
        if (drawable != null) {
            return androidx.core.graphics.drawable.a.q(drawable);
        }
        return null;
    }

    public void E1(int i2) {
        D1(this.f4552g0.getResources().getDimension(i2));
    }

    public void E2(int i2) {
        D2(this.f4552g0.getResources().getDimension(i2));
    }

    public float F0() {
        return this.f4530K;
    }

    public void F1(Drawable drawable) {
        Drawable E02 = E0();
        if (E02 != drawable) {
            float g02 = g0();
            this.f4528I = drawable != null ? androidx.core.graphics.drawable.a.r(drawable).mutate() : null;
            float g03 = g0();
            K2(E02);
            if (I2()) {
                e0(this.f4528I);
            }
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public void F2(boolean z2) {
        if (this.f4522C0 != z2) {
            this.f4522C0 = z2;
            L2();
            onStateChange(getState());
        }
    }

    public ColorStateList G0() {
        return this.f4529J;
    }

    public void G1(int i2) {
        F1(C0236a.b(this.f4552g0, i2));
    }

    /* access modifiers changed from: package-private */
    public boolean G2() {
        return this.G0;
    }

    public float H0() {
        return this.f4519B;
    }

    public void H1(float f2) {
        if (this.f4530K != f2) {
            float g02 = g0();
            this.f4530K = f2;
            float g03 = g0();
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public float I0() {
        return this.f4544Y;
    }

    public void I1(int i2) {
        H1(this.f4552g0.getResources().getDimension(i2));
    }

    public ColorStateList J0() {
        return this.f4523D;
    }

    public void J1(ColorStateList colorStateList) {
        this.f4531L = true;
        if (this.f4529J != colorStateList) {
            this.f4529J = colorStateList;
            if (I2()) {
                androidx.core.graphics.drawable.a.o(this.f4528I, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public float K0() {
        return this.f4524E;
    }

    public void K1(int i2) {
        J1(C0236a.a(this.f4552g0, i2));
    }

    public Drawable L0() {
        Drawable drawable = this.f4533N;
        if (drawable != null) {
            return androidx.core.graphics.drawable.a.q(drawable);
        }
        return null;
    }

    public void L1(int i2) {
        M1(this.f4552g0.getResources().getBoolean(i2));
    }

    public CharSequence M0() {
        return this.f4537R;
    }

    public void M1(boolean z2) {
        if (this.f4527H != z2) {
            boolean I2 = I2();
            this.f4527H = z2;
            boolean I22 = I2();
            if (I2 != I22) {
                if (I22) {
                    e0(this.f4528I);
                } else {
                    K2(this.f4528I);
                }
                invalidateSelf();
                p1();
            }
        }
    }

    public float N0() {
        return this.f4550e0;
    }

    public void N1(float f2) {
        if (this.f4519B != f2) {
            this.f4519B = f2;
            invalidateSelf();
            p1();
        }
    }

    public float O0() {
        return this.f4536Q;
    }

    public void O1(int i2) {
        N1(this.f4552g0.getResources().getDimension(i2));
    }

    public float P0() {
        return this.f4549d0;
    }

    public void P1(float f2) {
        if (this.f4544Y != f2) {
            this.f4544Y = f2;
            invalidateSelf();
            p1();
        }
    }

    public int[] Q0() {
        return this.f4520B0;
    }

    public void Q1(int i2) {
        P1(this.f4552g0.getResources().getDimension(i2));
    }

    public ColorStateList R0() {
        return this.f4535P;
    }

    public void R1(ColorStateList colorStateList) {
        if (this.f4523D != colorStateList) {
            this.f4523D = colorStateList;
            if (this.I0) {
                Z(colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void S0(RectF rectF) {
        j0(getBounds(), rectF);
    }

    public void S1(int i2) {
        R1(C0236a.a(this.f4552g0, i2));
    }

    public void T1(float f2) {
        if (this.f4524E != f2) {
            this.f4524E = f2;
            this.f4553h0.setStrokeWidth(f2);
            if (this.I0) {
                super.a0(f2);
            }
            invalidateSelf();
        }
    }

    public void U1(int i2) {
        T1(this.f4552g0.getResources().getDimension(i2));
    }

    public TextUtils.TruncateAt V0() {
        return this.F0;
    }

    public c W0() {
        return this.f4543X;
    }

    public void W1(Drawable drawable) {
        Drawable L0 = L0();
        if (L0 != drawable) {
            float k02 = k0();
            this.f4533N = drawable != null ? androidx.core.graphics.drawable.a.r(drawable).mutate() : null;
            if (i0.b.f5560a) {
                M2();
            }
            float k03 = k0();
            K2(L0);
            if (J2()) {
                e0(this.f4533N);
            }
            invalidateSelf();
            if (k02 != k03) {
                p1();
            }
        }
    }

    public float X0() {
        return this.f4546a0;
    }

    public void X1(CharSequence charSequence) {
        if (this.f4537R != charSequence) {
            this.f4537R = androidx.core.text.a.c().h(charSequence);
            invalidateSelf();
        }
    }

    public float Y0() {
        return this.f4545Z;
    }

    public void Y1(float f2) {
        if (this.f4550e0 != f2) {
            this.f4550e0 = f2;
            invalidateSelf();
            if (J2()) {
                p1();
            }
        }
    }

    public ColorStateList Z0() {
        return this.f4525F;
    }

    public void Z1(int i2) {
        Y1(this.f4552g0.getResources().getDimension(i2));
    }

    public void a() {
        p1();
        invalidateSelf();
    }

    public c a1() {
        return this.f4542W;
    }

    public void a2(int i2) {
        W1(C0236a.b(this.f4552g0, i2));
    }

    public CharSequence b1() {
        return this.f4526G;
    }

    public void b2(float f2) {
        if (this.f4536Q != f2) {
            this.f4536Q = f2;
            invalidateSelf();
            if (J2()) {
                p1();
            }
        }
    }

    public d c1() {
        return this.f4559n0.e();
    }

    public void c2(int i2) {
        b2(this.f4552g0.getResources().getDimension(i2));
    }

    public float d1() {
        return this.f4548c0;
    }

    public void d2(float f2) {
        if (this.f4549d0 != f2) {
            this.f4549d0 = f2;
            invalidateSelf();
            if (J2()) {
                p1();
            }
        }
    }

    public void draw(Canvas canvas) {
        int i2;
        Rect bounds = getBounds();
        if (!bounds.isEmpty() && getAlpha() != 0) {
            int i3 = this.f4568w0;
            if (i3 < 255) {
                i2 = W.a.a(canvas, (float) bounds.left, (float) bounds.top, (float) bounds.right, (float) bounds.bottom, i3);
            } else {
                i2 = 0;
            }
            u0(canvas, bounds);
            r0(canvas, bounds);
            if (this.I0) {
                super.draw(canvas);
            }
            t0(canvas, bounds);
            w0(canvas, bounds);
            s0(canvas, bounds);
            q0(canvas, bounds);
            if (this.G0) {
                y0(canvas, bounds);
            }
            v0(canvas, bounds);
            x0(canvas, bounds);
            if (this.f4568w0 < 255) {
                canvas.restoreToCount(i2);
            }
        }
    }

    public float e1() {
        return this.f4547b0;
    }

    public void e2(int i2) {
        d2(this.f4552g0.getResources().getDimension(i2));
    }

    public boolean f2(int[] iArr) {
        if (Arrays.equals(this.f4520B0, iArr)) {
            return false;
        }
        this.f4520B0 = iArr;
        if (J2()) {
            return q1(getState(), iArr);
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public float g0() {
        if (I2() || H2()) {
            return this.f4545Z + U0() + this.f4546a0;
        }
        return 0.0f;
    }

    public boolean g1() {
        return this.f4522C0;
    }

    public void g2(ColorStateList colorStateList) {
        if (this.f4535P != colorStateList) {
            this.f4535P = colorStateList;
            if (J2()) {
                androidx.core.graphics.drawable.a.o(this.f4533N, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public int getAlpha() {
        return this.f4568w0;
    }

    public ColorFilter getColorFilter() {
        return this.f4569x0;
    }

    public int getIntrinsicHeight() {
        return (int) this.f4519B;
    }

    public int getIntrinsicWidth() {
        return Math.min(Math.round(this.f4544Y + g0() + this.f4547b0 + this.f4559n0.g(b1().toString()) + this.f4548c0 + k0() + this.f4551f0), this.H0);
    }

    public int getOpacity() {
        return -3;
    }

    public void getOutline(Outline outline) {
        if (this.I0) {
            super.getOutline(outline);
            return;
        }
        Rect bounds = getBounds();
        if (!bounds.isEmpty()) {
            outline.setRoundRect(bounds, this.f4521C);
        } else {
            outline.setRoundRect(0, 0, getIntrinsicWidth(), getIntrinsicHeight(), this.f4521C);
        }
        outline.setAlpha(((float) getAlpha()) / 255.0f);
    }

    public void h2(int i2) {
        g2(C0236a.a(this.f4552g0, i2));
    }

    public boolean i1() {
        return this.f4538S;
    }

    public void i2(boolean z2) {
        if (this.f4532M != z2) {
            boolean J2 = J2();
            this.f4532M = z2;
            boolean J22 = J2();
            if (J2 != J22) {
                if (J22) {
                    e0(this.f4533N);
                } else {
                    K2(this.f4533N);
                }
                invalidateSelf();
                p1();
            }
        }
    }

    public void invalidateDrawable(Drawable drawable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    public boolean isStateful() {
        return l1(this.f4571z) || l1(this.f4517A) || l1(this.f4523D) || (this.f4522C0 && l1(this.D0)) || n1(this.f4559n0.e()) || o0() || m1(this.f4528I) || m1(this.f4540U) || l1(this.f4572z0);
    }

    public boolean j1() {
        return m1(this.f4533N);
    }

    public void j2(C0065a aVar) {
        this.E0 = new WeakReference(aVar);
    }

    /* access modifiers changed from: package-private */
    public float k0() {
        if (J2()) {
            return this.f4549d0 + this.f4536Q + this.f4550e0;
        }
        return 0.0f;
    }

    public boolean k1() {
        return this.f4532M;
    }

    public void k2(TextUtils.TruncateAt truncateAt) {
        this.F0 = truncateAt;
    }

    public void l2(c cVar) {
        this.f4543X = cVar;
    }

    public void m2(int i2) {
        l2(c.c(this.f4552g0, i2));
    }

    /* access modifiers changed from: package-private */
    public Paint.Align n0(Rect rect, PointF pointF) {
        pointF.set(0.0f, 0.0f);
        Paint.Align align = Paint.Align.LEFT;
        if (this.f4526G != null) {
            float g02 = this.f4544Y + g0() + this.f4547b0;
            if (androidx.core.graphics.drawable.a.f(this) == 0) {
                pointF.x = ((float) rect.left) + g02;
            } else {
                pointF.x = ((float) rect.right) - g02;
                align = Paint.Align.RIGHT;
            }
            pointF.y = ((float) rect.centerY()) - m0();
        }
        return align;
    }

    public void n2(float f2) {
        if (this.f4546a0 != f2) {
            float g02 = g0();
            this.f4546a0 = f2;
            float g03 = g0();
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public void o2(int i2) {
        n2(this.f4552g0.getResources().getDimension(i2));
    }

    public boolean onLayoutDirectionChanged(int i2) {
        boolean onLayoutDirectionChanged = super.onLayoutDirectionChanged(i2);
        if (I2()) {
            onLayoutDirectionChanged |= androidx.core.graphics.drawable.a.m(this.f4528I, i2);
        }
        if (H2()) {
            onLayoutDirectionChanged |= androidx.core.graphics.drawable.a.m(this.f4540U, i2);
        }
        if (J2()) {
            onLayoutDirectionChanged |= androidx.core.graphics.drawable.a.m(this.f4533N, i2);
        }
        if (!onLayoutDirectionChanged) {
            return true;
        }
        invalidateSelf();
        return true;
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i2) {
        boolean onLevelChange = super.onLevelChange(i2);
        if (I2()) {
            onLevelChange |= this.f4528I.setLevel(i2);
        }
        if (H2()) {
            onLevelChange |= this.f4540U.setLevel(i2);
        }
        if (J2()) {
            onLevelChange |= this.f4533N.setLevel(i2);
        }
        if (onLevelChange) {
            invalidateSelf();
        }
        return onLevelChange;
    }

    public boolean onStateChange(int[] iArr) {
        if (this.I0) {
            super.onStateChange(iArr);
        }
        return q1(iArr, Q0());
    }

    /* access modifiers changed from: protected */
    public void p1() {
        C0065a aVar = (C0065a) this.E0.get();
        if (aVar != null) {
            aVar.a();
        }
    }

    public void p2(float f2) {
        if (this.f4545Z != f2) {
            float g02 = g0();
            this.f4545Z = f2;
            float g03 = g0();
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public void q2(int i2) {
        p2(this.f4552g0.getResources().getDimension(i2));
    }

    public void r1(boolean z2) {
        if (this.f4538S != z2) {
            this.f4538S = z2;
            float g02 = g0();
            if (!z2 && this.f4566u0) {
                this.f4566u0 = false;
            }
            float g03 = g0();
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public void r2(int i2) {
        this.H0 = i2;
    }

    public void s1(int i2) {
        r1(this.f4552g0.getResources().getBoolean(i2));
    }

    public void s2(ColorStateList colorStateList) {
        if (this.f4525F != colorStateList) {
            this.f4525F = colorStateList;
            L2();
            onStateChange(getState());
        }
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, runnable, j2);
        }
    }

    public void setAlpha(int i2) {
        if (this.f4568w0 != i2) {
            this.f4568w0 = i2;
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        if (this.f4569x0 != colorFilter) {
            this.f4569x0 = colorFilter;
            invalidateSelf();
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        if (this.f4572z0 != colorStateList) {
            this.f4572z0 = colorStateList;
            onStateChange(getState());
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        if (this.f4518A0 != mode) {
            this.f4518A0 = mode;
            this.f4570y0 = f.j(this, this.f4572z0, mode);
            invalidateSelf();
        }
    }

    public boolean setVisible(boolean z2, boolean z3) {
        boolean visible = super.setVisible(z2, z3);
        if (I2()) {
            visible |= this.f4528I.setVisible(z2, z3);
        }
        if (H2()) {
            visible |= this.f4540U.setVisible(z2, z3);
        }
        if (J2()) {
            visible |= this.f4533N.setVisible(z2, z3);
        }
        if (visible) {
            invalidateSelf();
        }
        return visible;
    }

    public void t1(Drawable drawable) {
        if (this.f4540U != drawable) {
            float g02 = g0();
            this.f4540U = drawable;
            float g03 = g0();
            K2(this.f4540U);
            e0(this.f4540U);
            invalidateSelf();
            if (g02 != g03) {
                p1();
            }
        }
    }

    public void t2(int i2) {
        s2(C0236a.a(this.f4552g0, i2));
    }

    public void u1(int i2) {
        t1(C0236a.b(this.f4552g0, i2));
    }

    /* access modifiers changed from: package-private */
    public void u2(boolean z2) {
        this.G0 = z2;
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, runnable);
        }
    }

    public void v1(ColorStateList colorStateList) {
        if (this.f4541V != colorStateList) {
            this.f4541V = colorStateList;
            if (o0()) {
                androidx.core.graphics.drawable.a.o(this.f4540U, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void v2(c cVar) {
        this.f4542W = cVar;
    }

    public void w1(int i2) {
        v1(C0236a.a(this.f4552g0, i2));
    }

    public void w2(int i2) {
        v2(c.c(this.f4552g0, i2));
    }

    public void x1(int i2) {
        y1(this.f4552g0.getResources().getBoolean(i2));
    }

    public void x2(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = "";
        }
        if (!TextUtils.equals(this.f4526G, charSequence)) {
            this.f4526G = charSequence;
            this.f4559n0.k(true);
            invalidateSelf();
            p1();
        }
    }

    public void y1(boolean z2) {
        if (this.f4539T != z2) {
            boolean H2 = H2();
            this.f4539T = z2;
            boolean H22 = H2();
            if (H2 != H22) {
                if (H22) {
                    e0(this.f4540U);
                } else {
                    K2(this.f4540U);
                }
                invalidateSelf();
                p1();
            }
        }
    }

    public void y2(d dVar) {
        this.f4559n0.j(dVar, this.f4552g0);
    }

    public Drawable z0() {
        return this.f4540U;
    }

    public void z1(ColorStateList colorStateList) {
        if (this.f4517A != colorStateList) {
            this.f4517A = colorStateList;
            onStateChange(getState());
        }
    }

    public void z2(int i2) {
        y2(new d(this.f4552g0, i2));
    }
}
