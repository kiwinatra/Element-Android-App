package com.google.android.material.chip;

import T.h;
import T.i;
import T.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.appcompat.widget.C0102g;
import androidx.core.view.C0121a;
import androidx.core.view.W;
import com.google.android.material.chip.a;
import com.google.android.material.internal.B;
import com.google.android.material.internal.g;
import com.google.android.material.internal.y;
import h0.d;
import h0.f;
import java.util.List;
import k0.k;
import k0.n;
import y.I;

public class Chip extends C0102g implements a.C0065a, n, Checkable {

    /* renamed from: w  reason: collision with root package name */
    private static final int f4492w = i.Widget_MaterialComponents_Chip_Action;
    /* access modifiers changed from: private */

    /* renamed from: x  reason: collision with root package name */
    public static final Rect f4493x = new Rect();

    /* renamed from: y  reason: collision with root package name */
    private static final int[] f4494y = {16842913};

    /* renamed from: z  reason: collision with root package name */
    private static final int[] f4495z = {16842911};
    /* access modifiers changed from: private */

    /* renamed from: e  reason: collision with root package name */
    public a f4496e;

    /* renamed from: f  reason: collision with root package name */
    private InsetDrawable f4497f;

    /* renamed from: g  reason: collision with root package name */
    private RippleDrawable f4498g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public View.OnClickListener f4499h;

    /* renamed from: i  reason: collision with root package name */
    private CompoundButton.OnCheckedChangeListener f4500i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f4501j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f4502k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f4503l;
    /* access modifiers changed from: private */

    /* renamed from: m  reason: collision with root package name */
    public boolean f4504m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f4505n;

    /* renamed from: o  reason: collision with root package name */
    private int f4506o;

    /* renamed from: p  reason: collision with root package name */
    private int f4507p;

    /* renamed from: q  reason: collision with root package name */
    private CharSequence f4508q;

    /* renamed from: r  reason: collision with root package name */
    private final c f4509r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f4510s;

    /* renamed from: t  reason: collision with root package name */
    private final Rect f4511t;

    /* renamed from: u  reason: collision with root package name */
    private final RectF f4512u;

    /* renamed from: v  reason: collision with root package name */
    private final f f4513v;

    class a extends f {
        a() {
        }

        public void a(int i2) {
        }

        public void b(Typeface typeface, boolean z2) {
            Chip chip = Chip.this;
            chip.setText(chip.f4496e.G2() ? Chip.this.f4496e.b1() : Chip.this.getText());
            Chip.this.requestLayout();
            Chip.this.invalidate();
        }
    }

    class b extends ViewOutlineProvider {
        b() {
        }

        public void getOutline(View view, Outline outline) {
            if (Chip.this.f4496e != null) {
                Chip.this.f4496e.getOutline(outline);
            } else {
                outline.setAlpha(0.0f);
            }
        }
    }

    private class c extends D.a {
        c(Chip chip) {
            super(chip);
        }

        /* access modifiers changed from: protected */
        public int B(float f2, float f3) {
            return (!Chip.this.n() || !Chip.this.getCloseIconTouchBounds().contains(f2, f3)) ? 0 : 1;
        }

        /* access modifiers changed from: protected */
        public void C(List list) {
            list.add(0);
            if (Chip.this.n() && Chip.this.s() && Chip.this.f4499h != null) {
                list.add(1);
            }
        }

        /* access modifiers changed from: protected */
        public boolean J(int i2, int i3, Bundle bundle) {
            if (i3 != 16) {
                return false;
            }
            if (i2 == 0) {
                return Chip.this.performClick();
            }
            if (i2 == 1) {
                return Chip.this.u();
            }
            return false;
        }

        /* access modifiers changed from: protected */
        public void M(I i2) {
            i2.k0(Chip.this.r());
            i2.n0(Chip.this.isClickable());
            i2.m0(Chip.this.getAccessibilityClassName());
            CharSequence text = Chip.this.getText();
            if (Build.VERSION.SDK_INT >= 23) {
                i2.K0(text);
            } else {
                i2.q0(text);
            }
        }

        /* access modifiers changed from: protected */
        public void N(int i2, I i3) {
            CharSequence charSequence = "";
            if (i2 == 1) {
                CharSequence closeIconContentDescription = Chip.this.getCloseIconContentDescription();
                if (closeIconContentDescription == null) {
                    CharSequence text = Chip.this.getText();
                    Context context = Chip.this.getContext();
                    int i4 = h.mtrl_chip_close_icon_content_description;
                    if (!TextUtils.isEmpty(text)) {
                        charSequence = text;
                    }
                    closeIconContentDescription = context.getString(i4, new Object[]{charSequence}).trim();
                }
                i3.q0(closeIconContentDescription);
                i3.i0(Chip.this.getCloseIconTouchBoundsInt());
                i3.b(I.a.f6366i);
                i3.r0(Chip.this.isEnabled());
                return;
            }
            i3.q0(charSequence);
            i3.i0(Chip.f4493x);
        }

        /* access modifiers changed from: protected */
        public void O(int i2, boolean z2) {
            if (i2 == 1) {
                boolean unused = Chip.this.f4504m = z2;
                Chip.this.refreshDrawableState();
            }
        }
    }

    public Chip(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, T.a.chipStyle);
    }

    private void A() {
        this.f4498g = new RippleDrawable(i0.b.b(this.f4496e.Z0()), getBackgroundDrawable(), (Drawable) null);
        this.f4496e.F2(false);
        W.u0(this, this.f4498g);
        B();
    }

    private void B() {
        a aVar;
        if (!TextUtils.isEmpty(getText()) && (aVar = this.f4496e) != null) {
            int D0 = (int) (aVar.D0() + this.f4496e.d1() + this.f4496e.k0());
            int I0 = (int) (this.f4496e.I0() + this.f4496e.e1() + this.f4496e.g0());
            if (this.f4497f != null) {
                Rect rect = new Rect();
                this.f4497f.getPadding(rect);
                I0 += rect.left;
                D0 += rect.right;
            }
            W.D0(this, I0, getPaddingTop(), D0, getPaddingBottom());
        }
    }

    private void C() {
        TextPaint paint = getPaint();
        a aVar = this.f4496e;
        if (aVar != null) {
            paint.drawableState = aVar.getState();
        }
        d textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.n(getContext(), paint, this.f4513v);
        }
    }

    private void D(AttributeSet attributeSet) {
        if (attributeSet != null) {
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "background") != null) {
                Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
            }
            if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableLeft") != null) {
                throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableStart") != null) {
                throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableEnd") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            } else if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableRight") != null) {
                throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
            } else if (!attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "singleLine", true) || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "lines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "minLines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "maxLines", 1) != 1) {
                throw new UnsupportedOperationException("Chip does not support multi-line text");
            } else if (attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "gravity", 8388627) != 8388627) {
                Log.w("Chip", "Chip text must be vertically center and start aligned");
            }
        }
    }

    /* access modifiers changed from: private */
    public RectF getCloseIconTouchBounds() {
        this.f4512u.setEmpty();
        if (n() && this.f4499h != null) {
            this.f4496e.S0(this.f4512u);
        }
        return this.f4512u;
    }

    /* access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        this.f4511t.set((int) closeIconTouchBounds.left, (int) closeIconTouchBounds.top, (int) closeIconTouchBounds.right, (int) closeIconTouchBounds.bottom);
        return this.f4511t;
    }

    private d getTextAppearance() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.c1();
        }
        return null;
    }

    private void j(a aVar) {
        aVar.j2(this);
    }

    private int[] k() {
        int isEnabled = isEnabled();
        if (this.f4504m) {
            isEnabled++;
        }
        if (this.f4503l) {
            isEnabled++;
        }
        if (this.f4502k) {
            isEnabled++;
        }
        if (isChecked()) {
            isEnabled++;
        }
        int[] iArr = new int[isEnabled];
        int i2 = 0;
        if (isEnabled()) {
            iArr[0] = 16842910;
            i2 = 1;
        }
        if (this.f4504m) {
            iArr[i2] = 16842908;
            i2++;
        }
        if (this.f4503l) {
            iArr[i2] = 16843623;
            i2++;
        }
        if (this.f4502k) {
            iArr[i2] = 16842919;
            i2++;
        }
        if (isChecked()) {
            iArr[i2] = 16842913;
        }
        return iArr;
    }

    private void m() {
        if (getBackgroundDrawable() == this.f4497f && this.f4496e.getCallback() == null) {
            this.f4496e.setCallback(this.f4497f);
        }
    }

    /* access modifiers changed from: private */
    public boolean n() {
        a aVar = this.f4496e;
        return (aVar == null || aVar.L0() == null) ? false : true;
    }

    private void o(Context context, AttributeSet attributeSet, int i2) {
        TypedArray i3 = y.i(context, attributeSet, j.f206b0, i2, f4492w, new int[0]);
        this.f4505n = i3.getBoolean(j.I0, false);
        this.f4507p = (int) Math.ceil((double) i3.getDimension(j.f248w0, (float) Math.ceil((double) B.c(getContext(), 48))));
        i3.recycle();
    }

    private void p() {
        setOutlineProvider(new b());
    }

    private void q(int i2, int i3, int i4, int i5) {
        this.f4497f = new InsetDrawable(this.f4496e, i2, i3, i4, i5);
    }

    private void setCloseIconHovered(boolean z2) {
        if (this.f4503l != z2) {
            this.f4503l = z2;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z2) {
        if (this.f4502k != z2) {
            this.f4502k = z2;
            refreshDrawableState();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void t(CompoundButton compoundButton, boolean z2) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener = this.f4500i;
        if (onCheckedChangeListener != null) {
            onCheckedChangeListener.onCheckedChanged(compoundButton, z2);
        }
    }

    private void v() {
        if (this.f4497f != null) {
            this.f4497f = null;
            setMinWidth(0);
            setMinHeight((int) getChipMinHeight());
            z();
        }
    }

    private void x(a aVar) {
        if (aVar != null) {
            aVar.j2((a.C0065a) null);
        }
    }

    private void y() {
        boolean z2;
        if (!n() || !s() || this.f4499h == null) {
            W.q0(this, (C0121a) null);
            z2 = false;
        } else {
            W.q0(this, this.f4509r);
            z2 = true;
        }
        this.f4510s = z2;
    }

    private void z() {
        if (i0.b.f5560a) {
            A();
            return;
        }
        this.f4496e.F2(true);
        W.u0(this, getBackgroundDrawable());
        B();
        m();
    }

    public void a() {
        l(this.f4507p);
        requestLayout();
        invalidateOutline();
    }

    /* access modifiers changed from: protected */
    public boolean dispatchHoverEvent(MotionEvent motionEvent) {
        return !this.f4510s ? super.dispatchHoverEvent(motionEvent) : this.f4509r.v(motionEvent) || super.dispatchHoverEvent(motionEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!this.f4510s) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (!this.f4509r.w(keyEvent) || this.f4509r.A() == Integer.MIN_VALUE) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        a aVar = this.f4496e;
        if ((aVar == null || !aVar.j1()) ? false : this.f4496e.f2(k())) {
            invalidate();
        }
    }

    public CharSequence getAccessibilityClassName() {
        if (!TextUtils.isEmpty(this.f4508q)) {
            return this.f4508q;
        }
        if (!r()) {
            return isClickable() ? "android.widget.Button" : "android.view.View";
        }
        getParent();
        return "android.widget.Button";
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f4497f;
        return insetDrawable == null ? this.f4496e : insetDrawable;
    }

    public Drawable getCheckedIcon() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.z0();
        }
        return null;
    }

    public ColorStateList getCheckedIconTint() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.A0();
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.B0();
        }
        return null;
    }

    public float getChipCornerRadius() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return Math.max(0.0f, aVar.C0());
        }
        return 0.0f;
    }

    public Drawable getChipDrawable() {
        return this.f4496e;
    }

    public float getChipEndPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.D0();
        }
        return 0.0f;
    }

    public Drawable getChipIcon() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.E0();
        }
        return null;
    }

    public float getChipIconSize() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.F0();
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.G0();
        }
        return null;
    }

    public float getChipMinHeight() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.H0();
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.I0();
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.J0();
        }
        return null;
    }

    public float getChipStrokeWidth() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.K0();
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    public Drawable getCloseIcon() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.L0();
        }
        return null;
    }

    public CharSequence getCloseIconContentDescription() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.M0();
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.N0();
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.O0();
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.P0();
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.R0();
        }
        return null;
    }

    public TextUtils.TruncateAt getEllipsize() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.V0();
        }
        return null;
    }

    public void getFocusedRect(Rect rect) {
        if (!this.f4510s || !(this.f4509r.A() == 1 || this.f4509r.x() == 1)) {
            super.getFocusedRect(rect);
        } else {
            rect.set(getCloseIconTouchBoundsInt());
        }
    }

    public U.c getHideMotionSpec() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.W0();
        }
        return null;
    }

    public float getIconEndPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.X0();
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.Y0();
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.Z0();
        }
        return null;
    }

    public k getShapeAppearanceModel() {
        return this.f4496e.A();
    }

    public U.c getShowMotionSpec() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.a1();
        }
        return null;
    }

    public float getTextEndPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.d1();
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        a aVar = this.f4496e;
        if (aVar != null) {
            return aVar.e1();
        }
        return 0.0f;
    }

    public boolean l(int i2) {
        this.f4507p = i2;
        int i3 = 0;
        if (!w()) {
            if (this.f4497f != null) {
                v();
            } else {
                z();
            }
            return false;
        }
        int max = Math.max(0, i2 - this.f4496e.getIntrinsicHeight());
        int max2 = Math.max(0, i2 - this.f4496e.getIntrinsicWidth());
        if (max2 > 0 || max > 0) {
            int i4 = max2 > 0 ? max2 / 2 : 0;
            if (max > 0) {
                i3 = max / 2;
            }
            if (this.f4497f != null) {
                Rect rect = new Rect();
                this.f4497f.getPadding(rect);
                if (rect.top == i3 && rect.bottom == i3 && rect.left == i4 && rect.right == i4) {
                    z();
                    return true;
                }
            }
            if (getMinHeight() != i2) {
                setMinHeight(i2);
            }
            if (getMinWidth() != i2) {
                setMinWidth(i2);
            }
            q(i4, i3, i4, i3);
            z();
            return true;
        }
        if (this.f4497f != null) {
            v();
        } else {
            z();
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        k0.h.f(this, this.f4496e);
    }

    /* access modifiers changed from: protected */
    public int[] onCreateDrawableState(int i2) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i2 + 2);
        if (isChecked()) {
            View.mergeDrawableStates(onCreateDrawableState, f4494y);
        }
        if (r()) {
            View.mergeDrawableStates(onCreateDrawableState, f4495z);
        }
        return onCreateDrawableState;
    }

    /* access modifiers changed from: protected */
    public void onFocusChanged(boolean z2, int i2, Rect rect) {
        super.onFocusChanged(z2, i2, rect);
        if (this.f4510s) {
            this.f4509r.I(z2, i2, rect);
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        boolean contains;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 7) {
            if (actionMasked == 10) {
                contains = false;
            }
            return super.onHoverEvent(motionEvent);
        }
        contains = getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY());
        setCloseIconHovered(contains);
        return super.onHoverEvent(motionEvent);
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getAccessibilityClassName());
        accessibilityNodeInfo.setCheckable(r());
        accessibilityNodeInfo.setClickable(isClickable());
        getParent();
    }

    public PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i2) {
        return (!getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) || !isEnabled()) ? super.onResolvePointerIcon(motionEvent, i2) : PointerIcon.getSystemIcon(getContext(), 1002);
    }

    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        if (this.f4506o != i2) {
            this.f4506o = i2;
            B();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001e, code lost:
        if (r0 != 3) goto L_0x0040;
     */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x004a A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            int r0 = r6.getActionMasked()
            android.graphics.RectF r1 = r5.getCloseIconTouchBounds()
            float r2 = r6.getX()
            float r3 = r6.getY()
            boolean r1 = r1.contains(r2, r3)
            r2 = 1
            r3 = 0
            if (r0 == 0) goto L_0x003a
            if (r0 == r2) goto L_0x002c
            r4 = 2
            if (r0 == r4) goto L_0x0021
            r1 = 3
            if (r0 == r1) goto L_0x0035
            goto L_0x0040
        L_0x0021:
            boolean r0 = r5.f4502k
            if (r0 == 0) goto L_0x0040
            if (r1 != 0) goto L_0x002a
            r5.setCloseIconPressed(r3)
        L_0x002a:
            r0 = 1
            goto L_0x0041
        L_0x002c:
            boolean r0 = r5.f4502k
            if (r0 == 0) goto L_0x0035
            r5.u()
            r0 = 1
            goto L_0x0036
        L_0x0035:
            r0 = 0
        L_0x0036:
            r5.setCloseIconPressed(r3)
            goto L_0x0041
        L_0x003a:
            if (r1 == 0) goto L_0x0040
            r5.setCloseIconPressed(r2)
            goto L_0x002a
        L_0x0040:
            r0 = 0
        L_0x0041:
            if (r0 != 0) goto L_0x004b
            boolean r6 = super.onTouchEvent(r6)
            if (r6 == 0) goto L_0x004a
            goto L_0x004b
        L_0x004a:
            r2 = 0
        L_0x004b:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean r() {
        a aVar = this.f4496e;
        return aVar != null && aVar.i1();
    }

    public boolean s() {
        a aVar = this.f4496e;
        return aVar != null && aVar.k1();
    }

    public void setAccessibilityClassName(CharSequence charSequence) {
        this.f4508q = charSequence;
    }

    public void setBackground(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f4498g) {
            super.setBackground(drawable);
        } else {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        }
    }

    public void setBackgroundColor(int i2) {
        Log.w("Chip", "Do not set the background color; Chip manages its own background drawable.");
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f4498g) {
            super.setBackgroundDrawable(drawable);
        } else {
            Log.w("Chip", "Do not set the background drawable; Chip manages its own background drawable.");
        }
    }

    public void setBackgroundResource(int i2) {
        Log.w("Chip", "Do not set the background resource; Chip manages its own background drawable.");
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        Log.w("Chip", "Do not set the background tint list; Chip manages its own background drawable.");
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        Log.w("Chip", "Do not set the background tint mode; Chip manages its own background drawable.");
    }

    public void setCheckable(boolean z2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.r1(z2);
        }
    }

    public void setCheckableResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.s1(i2);
        }
    }

    public void setChecked(boolean z2) {
        a aVar = this.f4496e;
        if (aVar == null) {
            this.f4501j = z2;
        } else if (aVar.i1()) {
            super.setChecked(z2);
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.t1(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z2) {
        setCheckedIconVisible(z2);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i2) {
        setCheckedIconVisible(i2);
    }

    public void setCheckedIconResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.u1(i2);
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.v1(colorStateList);
        }
    }

    public void setCheckedIconTintResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.w1(i2);
        }
    }

    public void setCheckedIconVisible(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.x1(i2);
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.z1(colorStateList);
        }
    }

    public void setChipBackgroundColorResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.A1(i2);
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.B1(f2);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.C1(i2);
        }
    }

    public void setChipDrawable(a aVar) {
        a aVar2 = this.f4496e;
        if (aVar2 != aVar) {
            x(aVar2);
            this.f4496e = aVar;
            aVar.u2(false);
            j(this.f4496e);
            l(this.f4507p);
        }
    }

    public void setChipEndPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.D1(f2);
        }
    }

    public void setChipEndPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.E1(i2);
        }
    }

    public void setChipIcon(Drawable drawable) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.F1(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z2) {
        setChipIconVisible(z2);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i2) {
        setChipIconVisible(i2);
    }

    public void setChipIconResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.G1(i2);
        }
    }

    public void setChipIconSize(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.H1(f2);
        }
    }

    public void setChipIconSizeResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.I1(i2);
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.J1(colorStateList);
        }
    }

    public void setChipIconTintResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.K1(i2);
        }
    }

    public void setChipIconVisible(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.L1(i2);
        }
    }

    public void setChipMinHeight(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.N1(f2);
        }
    }

    public void setChipMinHeightResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.O1(i2);
        }
    }

    public void setChipStartPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.P1(f2);
        }
    }

    public void setChipStartPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.Q1(i2);
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.R1(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.S1(i2);
        }
    }

    public void setChipStrokeWidth(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.T1(f2);
        }
    }

    public void setChipStrokeWidthResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.U1(i2);
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i2) {
        setText(getResources().getString(i2));
    }

    public void setCloseIcon(Drawable drawable) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.W1(drawable);
        }
        y();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.X1(charSequence);
        }
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z2) {
        setCloseIconVisible(z2);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i2) {
        setCloseIconVisible(i2);
    }

    public void setCloseIconEndPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.Y1(f2);
        }
    }

    public void setCloseIconEndPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.Z1(i2);
        }
    }

    public void setCloseIconResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.a2(i2);
        }
        y();
    }

    public void setCloseIconSize(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.b2(f2);
        }
    }

    public void setCloseIconSizeResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.c2(i2);
        }
    }

    public void setCloseIconStartPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.d2(f2);
        }
    }

    public void setCloseIconStartPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.e2(i2);
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.g2(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.h2(i2);
        }
    }

    public void setCloseIconVisible(int i2) {
        setCloseIconVisible(getResources().getBoolean(i2));
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i4 == 0) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(i2, i3, i4, i5);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i4 == 0) {
            super.setCompoundDrawablesWithIntrinsicBounds(i2, i3, i4, i5);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setElevation(float f2) {
        super.setElevation(f2);
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.S(f2);
        }
    }

    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.f4496e != null) {
            if (truncateAt != TextUtils.TruncateAt.MARQUEE) {
                super.setEllipsize(truncateAt);
                a aVar = this.f4496e;
                if (aVar != null) {
                    aVar.k2(truncateAt);
                    return;
                }
                return;
            }
            throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
        }
    }

    public void setEnsureMinTouchTargetSize(boolean z2) {
        this.f4505n = z2;
        l(this.f4507p);
    }

    public void setGravity(int i2) {
        if (i2 != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        } else {
            super.setGravity(i2);
        }
    }

    public void setHideMotionSpec(U.c cVar) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.l2(cVar);
        }
    }

    public void setHideMotionSpecResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.m2(i2);
        }
    }

    public void setIconEndPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.n2(f2);
        }
    }

    public void setIconEndPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.o2(i2);
        }
    }

    public void setIconStartPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.p2(f2);
        }
    }

    public void setIconStartPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.q2(i2);
        }
    }

    public void setInternalOnCheckedChangeListener(g gVar) {
    }

    public void setLayoutDirection(int i2) {
        if (this.f4496e != null) {
            super.setLayoutDirection(i2);
        }
    }

    public void setLines(int i2) {
        if (i2 <= 1) {
            super.setLines(i2);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxLines(int i2) {
        if (i2 <= 1) {
            super.setMaxLines(i2);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxWidth(int i2) {
        super.setMaxWidth(i2);
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.r2(i2);
        }
    }

    public void setMinLines(int i2) {
        if (i2 <= 1) {
            super.setMinLines(i2);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f4500i = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.f4499h = onClickListener;
        y();
    }

    public void setRippleColor(ColorStateList colorStateList) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.s2(colorStateList);
        }
        if (!this.f4496e.g1()) {
            A();
        }
    }

    public void setRippleColorResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.t2(i2);
            if (!this.f4496e.g1()) {
                A();
            }
        }
    }

    public void setShapeAppearanceModel(k kVar) {
        this.f4496e.setShapeAppearanceModel(kVar);
    }

    public void setShowMotionSpec(U.c cVar) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.v2(cVar);
        }
    }

    public void setShowMotionSpecResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.w2(i2);
        }
    }

    public void setSingleLine(boolean z2) {
        if (z2) {
            super.setSingleLine(z2);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        a aVar = this.f4496e;
        if (aVar != null) {
            if (charSequence == null) {
                charSequence = "";
            }
            super.setText(aVar.G2() ? null : charSequence, bufferType);
            a aVar2 = this.f4496e;
            if (aVar2 != null) {
                aVar2.x2(charSequence);
            }
        }
    }

    public void setTextAppearance(int i2) {
        super.setTextAppearance(i2);
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.z2(i2);
        }
        C();
    }

    public void setTextAppearanceResource(int i2) {
        setTextAppearance(getContext(), i2);
    }

    public void setTextEndPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.A2(f2);
        }
    }

    public void setTextEndPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.B2(i2);
        }
    }

    public void setTextSize(int i2, float f2) {
        super.setTextSize(i2, f2);
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.C2(TypedValue.applyDimension(i2, f2, getResources().getDisplayMetrics()));
        }
        C();
    }

    public void setTextStartPadding(float f2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.D2(f2);
        }
    }

    public void setTextStartPaddingResource(int i2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.E2(i2);
        }
    }

    public boolean u() {
        boolean z2 = false;
        playSoundEffect(0);
        View.OnClickListener onClickListener = this.f4499h;
        if (onClickListener != null) {
            onClickListener.onClick(this);
            z2 = true;
        }
        if (this.f4510s) {
            this.f4509r.U(1, 1);
        }
        return z2;
    }

    public boolean w() {
        return this.f4505n;
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Chip(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = f4492w
            android.content.Context r8 = n0.a.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            android.graphics.Rect r8 = new android.graphics.Rect
            r8.<init>()
            r7.f4511t = r8
            android.graphics.RectF r8 = new android.graphics.RectF
            r8.<init>()
            r7.f4512u = r8
            com.google.android.material.chip.Chip$a r8 = new com.google.android.material.chip.Chip$a
            r8.<init>()
            r7.f4513v = r8
            android.content.Context r8 = r7.getContext()
            r7.D(r9)
            com.google.android.material.chip.a r6 = com.google.android.material.chip.a.p0(r8, r9, r10, r4)
            r7.o(r8, r9, r10)
            r7.setChipDrawable(r6)
            float r0 = androidx.core.view.W.w(r7)
            r6.S(r0)
            int[] r2 = T.j.f206b0
            r0 = 0
            int[] r5 = new int[r0]
            r0 = r8
            r1 = r9
            r3 = r10
            android.content.res.TypedArray r9 = com.google.android.material.internal.y.i(r0, r1, r2, r3, r4, r5)
            int r10 = android.os.Build.VERSION.SDK_INT
            r0 = 23
            if (r10 >= r0) goto L_0x0051
            int r10 = T.j.f212e0
            android.content.res.ColorStateList r8 = h0.c.a(r8, r9, r10)
            r7.setTextColor(r8)
        L_0x0051:
            int r8 = T.j.N0
            boolean r8 = r9.hasValue(r8)
            r9.recycle()
            com.google.android.material.chip.Chip$c r9 = new com.google.android.material.chip.Chip$c
            r9.<init>(r7)
            r7.f4509r = r9
            r7.y()
            if (r8 != 0) goto L_0x0069
            r7.p()
        L_0x0069:
            boolean r8 = r7.f4501j
            r7.setChecked(r8)
            java.lang.CharSequence r8 = r6.b1()
            r7.setText(r8)
            android.text.TextUtils$TruncateAt r8 = r6.V0()
            r7.setEllipsize(r8)
            r7.C()
            com.google.android.material.chip.a r8 = r7.f4496e
            boolean r8 = r8.G2()
            if (r8 != 0) goto L_0x008e
            r8 = 1
            r7.setLines(r8)
            r7.setHorizontallyScrolling(r8)
        L_0x008e:
            r8 = 8388627(0x800013, float:1.175497E-38)
            r7.setGravity(r8)
            r7.B()
            boolean r8 = r7.w()
            if (r8 == 0) goto L_0x00a2
            int r8 = r7.f4507p
            r7.setMinHeight(r8)
        L_0x00a2:
            int r8 = androidx.core.view.W.C(r7)
            r7.f4506o = r8
            Z.b r8 = new Z.b
            r8.<init>(r7)
            super.setOnCheckedChangeListener(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public void setCheckedIconVisible(boolean z2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.y1(z2);
        }
    }

    public void setChipIconVisible(boolean z2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.M1(z2);
        }
    }

    public void setCloseIconVisible(boolean z2) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.i2(z2);
        }
        y();
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
        }
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.z2(i2);
        }
        C();
    }

    public void setTextAppearance(d dVar) {
        a aVar = this.f4496e;
        if (aVar != null) {
            aVar.y2(dVar);
        }
        C();
    }
}
