package com.google.android.material.textfield;

public final /* synthetic */ class L implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TextInputLayout f4995a;

    public /* synthetic */ L(TextInputLayout textInputLayout) {
        this.f4995a = textInputLayout;
    }

    public final void run() {
        this.f4995a.U();
    }
}
