package com.google.android.material.textfield;

import android.view.View;

/* renamed from: com.google.android.material.textfield.b  reason: case insensitive filesystem */
public final /* synthetic */ class C0221b implements View.OnFocusChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0225f f5085a;

    public /* synthetic */ C0221b(C0225f fVar) {
        this.f5085a = fVar;
    }

    public final void onFocusChange(View view, boolean z2) {
        this.f5085a.H(view, z2);
    }
}
