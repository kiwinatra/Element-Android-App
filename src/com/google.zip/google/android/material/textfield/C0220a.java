package com.google.android.material.textfield;

import android.view.View;

/* renamed from: com.google.android.material.textfield.a  reason: case insensitive filesystem */
public final /* synthetic */ class C0220a implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0225f f5084a;

    public /* synthetic */ C0220a(C0225f fVar) {
        this.f5084a = fVar;
    }

    public final void onClick(View view) {
        this.f5084a.G(view);
    }
}
