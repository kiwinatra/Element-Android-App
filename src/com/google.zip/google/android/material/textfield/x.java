package com.google.android.material.textfield;

class x extends t {
    x(s sVar) {
        super(sVar);
    }
}
