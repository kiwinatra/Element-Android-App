package com.google.android.material.textfield;

import android.text.Editable;
import com.google.android.material.textfield.TextInputLayout;

public final /* synthetic */ class K implements TextInputLayout.e {
    public final int a(Editable editable) {
        return TextInputLayout.T(editable);
    }
}
