package com.google.android.material.textfield;

import android.view.View;

public final /* synthetic */ class m implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5105a;

    public /* synthetic */ m(q qVar) {
        this.f5105a = qVar;
    }

    public final void onClick(View view) {
        this.f5105a.J(view);
    }
}
