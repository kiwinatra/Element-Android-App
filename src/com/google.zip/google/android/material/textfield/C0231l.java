package com.google.android.material.textfield;

import android.widget.AutoCompleteTextView;

/* renamed from: com.google.android.material.textfield.l  reason: case insensitive filesystem */
public final /* synthetic */ class C0231l implements AutoCompleteTextView.OnDismissListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5104a;

    public /* synthetic */ C0231l(q qVar) {
        this.f5104a = qVar;
    }

    public final void onDismiss() {
        this.f5104a.N();
    }
}
