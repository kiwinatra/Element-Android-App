package com.google.android.material.textfield;

import android.view.View;

public final /* synthetic */ class y implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ z f5205a;

    public /* synthetic */ y(z zVar) {
        this.f5205a = zVar;
    }

    public final void onClick(View view) {
        this.f5205a.y(view);
    }
}
