package com.google.android.material.textfield;

import android.view.MotionEvent;
import android.view.View;

/* renamed from: com.google.android.material.textfield.k  reason: case insensitive filesystem */
public final /* synthetic */ class C0230k implements View.OnTouchListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5103a;

    public /* synthetic */ C0230k(q qVar) {
        this.f5103a = qVar;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return this.f5103a.M(view, motionEvent);
    }
}
