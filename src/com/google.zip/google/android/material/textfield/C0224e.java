package com.google.android.material.textfield;

import android.animation.ValueAnimator;

/* renamed from: com.google.android.material.textfield.e  reason: case insensitive filesystem */
public final /* synthetic */ class C0224e implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0225f f5088a;

    public /* synthetic */ C0224e(C0225f fVar) {
        this.f5088a = fVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f5088a.F(valueAnimator);
    }
}
