package com.google.android.material.textfield;

import android.view.View;

/* renamed from: com.google.android.material.textfield.g  reason: case insensitive filesystem */
class C0226g extends t {
    C0226g(s sVar) {
        super(sVar);
    }

    /* access modifiers changed from: package-private */
    public void s() {
        this.f5156b.W((View.OnLongClickListener) null);
    }
}
