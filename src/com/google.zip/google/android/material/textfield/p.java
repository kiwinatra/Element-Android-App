package com.google.android.material.textfield;

public final /* synthetic */ class p implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5108a;

    public /* synthetic */ p(q qVar) {
        this.f5108a = qVar;
    }

    public final void run() {
        this.f5108a.H();
    }
}
