package com.google.android.material.textfield;

import android.animation.ValueAnimator;

/* renamed from: com.google.android.material.textfield.j  reason: case insensitive filesystem */
public final /* synthetic */ class C0229j implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5102a;

    public /* synthetic */ C0229j(q qVar) {
        this.f5102a = qVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f5102a.I(valueAnimator);
    }
}
