package com.google.android.material.textfield;

/* renamed from: com.google.android.material.textfield.d  reason: case insensitive filesystem */
public final /* synthetic */ class C0223d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0225f f5087a;

    public /* synthetic */ C0223d(C0225f fVar) {
        this.f5087a = fVar;
    }

    public final void run() {
        this.f5087a.I();
    }
}
