package com.google.android.material.textfield;

import y.C0299c;

public final /* synthetic */ class o implements C0299c.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5107a;

    public /* synthetic */ o(q qVar) {
        this.f5107a = qVar;
    }

    public final void onTouchExplorationStateChanged(boolean z2) {
        this.f5107a.L(z2);
    }
}
