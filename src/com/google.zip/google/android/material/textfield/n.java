package com.google.android.material.textfield;

import android.view.View;

public final /* synthetic */ class n implements View.OnFocusChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f5106a;

    public /* synthetic */ n(q qVar) {
        this.f5106a = qVar;
    }

    public final void onFocusChange(View view, boolean z2) {
        this.f5106a.K(view, z2);
    }
}
