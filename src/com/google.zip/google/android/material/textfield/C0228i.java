package com.google.android.material.textfield;

/* renamed from: com.google.android.material.textfield.i  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0228i {
}
