package com.google.android.material.textfield;

import android.widget.EditText;

abstract class r {
    static boolean a(EditText editText) {
        return editText.getInputType() != 0;
    }
}
