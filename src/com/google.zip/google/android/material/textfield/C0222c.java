package com.google.android.material.textfield;

import android.animation.ValueAnimator;

/* renamed from: com.google.android.material.textfield.c  reason: case insensitive filesystem */
public final /* synthetic */ class C0222c implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0225f f5086a;

    public /* synthetic */ C0222c(C0225f fVar) {
        this.f5086a = fVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f5086a.E(valueAnimator);
    }
}
