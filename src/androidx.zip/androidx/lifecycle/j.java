package androidx.lifecycle;

import androidx.lifecycle.C0190g;

public interface j extends k {
    void d(l lVar, C0190g.a aVar);
}
