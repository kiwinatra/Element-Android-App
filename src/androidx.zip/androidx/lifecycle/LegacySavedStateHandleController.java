package androidx.lifecycle;

import O.d;
import androidx.lifecycle.C0190g;
import androidx.savedstate.a;
import w0.i;

public final class LegacySavedStateHandleController {

    /* renamed from: a  reason: collision with root package name */
    public static final LegacySavedStateHandleController f3109a = new LegacySavedStateHandleController();

    public static final class a implements a.C0058a {
        public void a(d dVar) {
            i.e(dVar, "owner");
            if (dVar instanceof E) {
                D t2 = ((E) dVar).t();
                androidx.savedstate.a e2 = dVar.e();
                for (String b2 : t2.c()) {
                    z b3 = t2.b(b2);
                    i.b(b3);
                    LegacySavedStateHandleController.a(b3, e2, dVar.v());
                }
                if (!t2.c().isEmpty()) {
                    e2.i(a.class);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner".toString());
        }
    }

    private LegacySavedStateHandleController() {
    }

    public static final void a(z zVar, androidx.savedstate.a aVar, C0190g gVar) {
        i.e(zVar, "viewModel");
        i.e(aVar, "registry");
        i.e(gVar, "lifecycle");
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) zVar.c("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController != null && !savedStateHandleController.i()) {
            savedStateHandleController.h(aVar, gVar);
            f3109a.b(aVar, gVar);
        }
    }

    private final void b(androidx.savedstate.a aVar, C0190g gVar) {
        C0190g.b b2 = gVar.b();
        if (b2 == C0190g.b.INITIALIZED || b2.b(C0190g.b.STARTED)) {
            aVar.i(a.class);
        } else {
            gVar.a(new LegacySavedStateHandleController$tryToAddRecreator$1(gVar, aVar));
        }
    }
}
