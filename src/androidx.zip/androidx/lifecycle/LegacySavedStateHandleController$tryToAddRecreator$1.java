package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import androidx.lifecycle.LegacySavedStateHandleController;
import androidx.savedstate.a;
import w0.i;

public final class LegacySavedStateHandleController$tryToAddRecreator$1 implements j {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ C0190g f3110a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ a f3111b;

    LegacySavedStateHandleController$tryToAddRecreator$1(C0190g gVar, a aVar) {
        this.f3110a = gVar;
        this.f3111b = aVar;
    }

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        if (aVar == C0190g.a.ON_START) {
            this.f3110a.c(this);
            this.f3111b.i(LegacySavedStateHandleController.a.class);
        }
    }
}
