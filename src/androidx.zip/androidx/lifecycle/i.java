package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public static final i f3152a = new i();

    /* renamed from: b  reason: collision with root package name */
    private static final AtomicBoolean f3153b = new AtomicBoolean(false);

    public static final class a extends C0187d {
        public void onActivityCreated(Activity activity, Bundle bundle) {
            w0.i.e(activity, "activity");
            u.f3182b.c(activity);
        }
    }

    private i() {
    }

    public static final void a(Context context) {
        w0.i.e(context, "context");
        if (!f3153b.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            w0.i.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new a());
        }
    }
}
