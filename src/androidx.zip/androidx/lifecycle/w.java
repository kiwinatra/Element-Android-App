package androidx.lifecycle;

import M.a;
import androidx.lifecycle.C0190g;
import v0.l;
import w0.i;
import w0.j;

public abstract class w {

    /* renamed from: a  reason: collision with root package name */
    public static final a.b f3184a = new b();

    /* renamed from: b  reason: collision with root package name */
    public static final a.b f3185b = new c();

    /* renamed from: c  reason: collision with root package name */
    public static final a.b f3186c = new a();

    public static final class a implements a.b {
        a() {
        }
    }

    public static final class b implements a.b {
        b() {
        }
    }

    public static final class c implements a.b {
        c() {
        }
    }

    static final class d extends j implements l {

        /* renamed from: b  reason: collision with root package name */
        public static final d f3187b = new d();

        d() {
            super(1);
        }

        /* renamed from: c */
        public final y b(M.a aVar) {
            i.e(aVar, "$this$initializer");
            return new y();
        }
    }

    public static final void a(O.d dVar) {
        i.e(dVar, "<this>");
        C0190g.b b2 = dVar.v().b();
        if (b2 != C0190g.b.INITIALIZED && b2 != C0190g.b.CREATED) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        } else if (dVar.e().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
            x xVar = new x(dVar.e(), (E) dVar);
            dVar.e().h("androidx.lifecycle.internal.SavedStateHandlesProvider", xVar);
            dVar.v().a(new SavedStateHandleAttacher(xVar));
        }
    }

    public static final y b(E e2) {
        i.e(e2, "<this>");
        M.c cVar = new M.c();
        Class<y> cls = y.class;
        cVar.a(w0.l.b(cls), d.f3187b);
        return (y) new A(e2, cVar.b()).b("androidx.lifecycle.internal.SavedStateHandlesVM", cls);
    }
}
