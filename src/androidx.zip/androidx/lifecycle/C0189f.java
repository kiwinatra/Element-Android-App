package androidx.lifecycle;

import M.a;

/* renamed from: androidx.lifecycle.f  reason: case insensitive filesystem */
public interface C0189f {
    a a();
}
