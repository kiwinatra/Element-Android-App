package androidx.lifecycle;

public abstract /* synthetic */ class v {
}
