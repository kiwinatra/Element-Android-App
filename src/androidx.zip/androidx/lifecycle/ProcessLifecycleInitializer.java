package androidx.lifecycle;

import P.a;
import android.content.Context;
import androidx.lifecycle.t;
import java.util.List;
import p0.k;
import w0.i;

public final class ProcessLifecycleInitializer implements a {
    public List a() {
        return k.b();
    }

    /* renamed from: c */
    public l b(Context context) {
        i.e(context, "context");
        androidx.startup.a e2 = androidx.startup.a.e(context);
        i.d(e2, "getInstance(context)");
        if (e2.g(ProcessLifecycleInitializer.class)) {
            i.a(context);
            t.b bVar = t.f3170i;
            bVar.b(context);
            return bVar.a();
        }
        throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml".toString());
    }
}
