package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import androidx.savedstate.a;
import w0.i;

public final class SavedStateHandleController implements j {

    /* renamed from: a  reason: collision with root package name */
    private boolean f3135a;

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        if (aVar == C0190g.a.ON_DESTROY) {
            this.f3135a = false;
            lVar.v().c(this);
        }
    }

    public final void h(a aVar, C0190g gVar) {
        i.e(aVar, "registry");
        i.e(gVar, "lifecycle");
        if (!(!this.f3135a)) {
            throw new IllegalStateException("Already attached to lifecycleOwner".toString());
        }
        this.f3135a = true;
        gVar.a(this);
        throw null;
    }

    public final boolean i() {
        return this.f3135a;
    }
}
