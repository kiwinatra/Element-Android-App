package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import androidx.lifecycle.LiveData.c;
import j.C0250c;
import java.util.Map;
import k.C0254b;

public abstract class LiveData {

    /* renamed from: k  reason: collision with root package name */
    static final Object f3113k = new Object();

    /* renamed from: a  reason: collision with root package name */
    final Object f3114a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private C0254b f3115b = new C0254b();

    /* renamed from: c  reason: collision with root package name */
    int f3116c = 0;

    /* renamed from: d  reason: collision with root package name */
    private boolean f3117d;

    /* renamed from: e  reason: collision with root package name */
    private volatile Object f3118e;

    /* renamed from: f  reason: collision with root package name */
    volatile Object f3119f;

    /* renamed from: g  reason: collision with root package name */
    private int f3120g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f3121h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f3122i;

    /* renamed from: j  reason: collision with root package name */
    private final Runnable f3123j;

    class LifecycleBoundObserver extends c implements j {

        /* renamed from: e  reason: collision with root package name */
        final l f3124e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ LiveData f3125f;

        /* JADX WARNING: type inference failed for: r1v0, types: [androidx.lifecycle.LiveData$LifecycleBoundObserver, androidx.lifecycle.LiveData$c] */
        public void d(l lVar, C0190g.a aVar) {
            C0190g.b b2 = this.f3124e.v().b();
            if (b2 == C0190g.b.DESTROYED) {
                this.f3125f.h(this.f3128a);
                return;
            }
            C0190g.b bVar = null;
            while (bVar != b2) {
                h(j());
                bVar = b2;
                b2 = this.f3124e.v().b();
            }
        }

        /* access modifiers changed from: package-private */
        public void i() {
            this.f3124e.v().c(this);
        }

        /* access modifiers changed from: package-private */
        public boolean j() {
            return this.f3124e.v().b().b(C0190g.b.STARTED);
        }
    }

    class a implements Runnable {
        a() {
        }

        public void run() {
            Object obj;
            synchronized (LiveData.this.f3114a) {
                obj = LiveData.this.f3119f;
                LiveData.this.f3119f = LiveData.f3113k;
            }
            LiveData.this.i(obj);
        }
    }

    private class b extends c {
        b(q qVar) {
            super(qVar);
        }

        /* access modifiers changed from: package-private */
        public boolean j() {
            return true;
        }
    }

    private abstract class c {

        /* renamed from: a  reason: collision with root package name */
        final q f3128a;

        /* renamed from: b  reason: collision with root package name */
        boolean f3129b;

        /* renamed from: c  reason: collision with root package name */
        int f3130c = -1;

        c(q qVar) {
            this.f3128a = qVar;
        }

        /* access modifiers changed from: package-private */
        public void h(boolean z2) {
            if (z2 != this.f3129b) {
                this.f3129b = z2;
                LiveData.this.b(z2 ? 1 : -1);
                if (this.f3129b) {
                    LiveData.this.d(this);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void i() {
        }

        /* access modifiers changed from: package-private */
        public abstract boolean j();
    }

    public LiveData() {
        Object obj = f3113k;
        this.f3119f = obj;
        this.f3123j = new a();
        this.f3118e = obj;
        this.f3120g = -1;
    }

    static void a(String str) {
        if (!C0250c.f().b()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
        }
    }

    private void c(c cVar) {
        if (cVar.f3129b) {
            if (!cVar.j()) {
                cVar.h(false);
                return;
            }
            int i2 = cVar.f3130c;
            int i3 = this.f3120g;
            if (i2 < i3) {
                cVar.f3130c = i3;
                cVar.f3128a.a(this.f3118e);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void b(int i2) {
        int i3 = this.f3116c;
        this.f3116c = i2 + i3;
        if (!this.f3117d) {
            this.f3117d = true;
            while (true) {
                try {
                    int i4 = this.f3116c;
                    if (i3 != i4) {
                        boolean z2 = i3 == 0 && i4 > 0;
                        boolean z3 = i3 > 0 && i4 == 0;
                        if (z2) {
                            f();
                        } else if (z3) {
                            g();
                        }
                        i3 = i4;
                    } else {
                        this.f3117d = false;
                        return;
                    }
                } catch (Throwable th) {
                    this.f3117d = false;
                    throw th;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void d(c cVar) {
        if (this.f3121h) {
            this.f3122i = true;
            return;
        }
        this.f3121h = true;
        do {
            this.f3122i = false;
            if (cVar == null) {
                C0254b.d d2 = this.f3115b.d();
                while (d2.hasNext()) {
                    c((c) ((Map.Entry) d2.next()).getValue());
                    if (this.f3122i) {
                        break;
                    }
                }
            } else {
                c(cVar);
                cVar = null;
            }
        } while (this.f3122i);
        this.f3121h = false;
    }

    public void e(q qVar) {
        a("observeForever");
        b bVar = new b(qVar);
        c cVar = (c) this.f3115b.g(qVar, bVar);
        if (cVar instanceof LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        } else if (cVar == null) {
            bVar.h(true);
        }
    }

    /* access modifiers changed from: protected */
    public void f() {
    }

    /* access modifiers changed from: protected */
    public void g() {
    }

    public void h(q qVar) {
        a("removeObserver");
        c cVar = (c) this.f3115b.h(qVar);
        if (cVar != null) {
            cVar.i();
            cVar.h(false);
        }
    }

    /* access modifiers changed from: protected */
    public void i(Object obj) {
        a("setValue");
        this.f3120g++;
        this.f3118e = obj;
        d((c) null);
    }
}
