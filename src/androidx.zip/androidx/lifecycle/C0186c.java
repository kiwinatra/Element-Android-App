package androidx.lifecycle;

/* renamed from: androidx.lifecycle.c  reason: case insensitive filesystem */
public interface C0186c extends k {
    void a(l lVar);

    void b(l lVar);

    void c(l lVar);

    void e(l lVar);

    void f(l lVar);

    void g(l lVar);
}
