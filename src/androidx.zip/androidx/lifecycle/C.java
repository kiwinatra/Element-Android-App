package androidx.lifecycle;

import M.a;
import w0.i;

public abstract class C {
    public static final a a(E e2) {
        i.e(e2, "owner");
        if (e2 instanceof C0189f) {
            return ((C0189f) e2).a();
        }
        return a.C0007a.f132b;
    }
}
