package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import w0.i;

public final class SingleGeneratedAdapterObserver implements j {
    public SingleGeneratedAdapterObserver(C0188e eVar) {
        i.e(eVar, "generatedAdapter");
    }

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        throw null;
    }
}
