package androidx.lifecycle;

/* renamed from: androidx.lifecycle.e  reason: case insensitive filesystem */
public interface C0188e {
}
