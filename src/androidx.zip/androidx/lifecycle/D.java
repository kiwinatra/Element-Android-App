package androidx.lifecycle;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import w0.i;

public class D {

    /* renamed from: a  reason: collision with root package name */
    private final Map f3105a = new LinkedHashMap();

    public final void a() {
        for (z a2 : this.f3105a.values()) {
            a2.a();
        }
        this.f3105a.clear();
    }

    public final z b(String str) {
        i.e(str, "key");
        return (z) this.f3105a.get(str);
    }

    public final Set c() {
        return new HashSet(this.f3105a.keySet());
    }

    public final void d(String str, z zVar) {
        i.e(str, "key");
        i.e(zVar, "viewModel");
        z zVar2 = (z) this.f3105a.put(str, zVar);
        if (zVar2 != null) {
            zVar2.d();
        }
    }
}
