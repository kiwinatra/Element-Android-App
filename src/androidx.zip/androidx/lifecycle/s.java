package androidx.lifecycle;

public final /* synthetic */ class s implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ t f3169a;

    public /* synthetic */ s(t tVar) {
        this.f3169a = tVar;
    }

    public final void run() {
        t.k(this.f3169a);
    }
}
