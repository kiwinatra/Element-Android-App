package androidx.lifecycle;

public interface E {
    D t();
}
