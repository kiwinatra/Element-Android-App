package androidx.lifecycle;

import M.a;
import M.d;
import w0.e;
import w0.i;

public class A {

    /* renamed from: a  reason: collision with root package name */
    private final D f3095a;

    /* renamed from: b  reason: collision with root package name */
    private final b f3096b;

    /* renamed from: c  reason: collision with root package name */
    private final M.a f3097c;

    public static class a extends c {

        /* renamed from: c  reason: collision with root package name */
        public static final C0045a f3098c = new C0045a((e) null);

        /* renamed from: d  reason: collision with root package name */
        public static final a.b f3099d = C0045a.C0046a.f3100a;

        /* renamed from: androidx.lifecycle.A$a$a  reason: collision with other inner class name */
        public static final class C0045a {

            /* renamed from: androidx.lifecycle.A$a$a$a  reason: collision with other inner class name */
            private static final class C0046a implements a.b {

                /* renamed from: a  reason: collision with root package name */
                public static final C0046a f3100a = new C0046a();

                private C0046a() {
                }
            }

            private C0045a() {
            }

            public /* synthetic */ C0045a(e eVar) {
                this();
            }
        }
    }

    public interface b {
        z a(Class cls);

        z b(Class cls, M.a aVar);
    }

    public static class c implements b {

        /* renamed from: a  reason: collision with root package name */
        public static final a f3101a = new a((e) null);

        /* renamed from: b  reason: collision with root package name */
        public static final a.b f3102b = a.C0047a.f3103a;

        public static final class a {

            /* renamed from: androidx.lifecycle.A$c$a$a  reason: collision with other inner class name */
            private static final class C0047a implements a.b {

                /* renamed from: a  reason: collision with root package name */
                public static final C0047a f3103a = new C0047a();

                private C0047a() {
                }
            }

            private a() {
            }

            public /* synthetic */ a(e eVar) {
                this();
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public A(D d2, b bVar) {
        this(d2, bVar, (M.a) null, 4, (e) null);
        i.e(d2, "store");
        i.e(bVar, "factory");
    }

    public z a(Class cls) {
        i.e(cls, "modelClass");
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return b("androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public z b(String str, Class cls) {
        z zVar;
        i.e(str, "key");
        i.e(cls, "modelClass");
        z b2 = this.f3095a.b(str);
        if (cls.isInstance(b2)) {
            i.c(b2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
            return b2;
        }
        d dVar = new d(this.f3097c);
        dVar.b(c.f3102b, str);
        try {
            zVar = this.f3096b.b(cls, dVar);
        } catch (AbstractMethodError unused) {
            zVar = this.f3096b.a(cls);
        }
        this.f3095a.d(str, zVar);
        return zVar;
    }

    public A(D d2, b bVar, M.a aVar) {
        i.e(d2, "store");
        i.e(bVar, "factory");
        i.e(aVar, "defaultCreationExtras");
        this.f3095a = d2;
        this.f3096b = bVar;
        this.f3097c = aVar;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ A(D d2, b bVar, M.a aVar, int i2, e eVar) {
        this(d2, bVar, (i2 & 4) != 0 ? a.C0007a.f132b : aVar);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public A(E e2, b bVar) {
        this(e2.t(), bVar, C.a(e2));
        i.e(e2, "owner");
        i.e(bVar, "factory");
    }
}
