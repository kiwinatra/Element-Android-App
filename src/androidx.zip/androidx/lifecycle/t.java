package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.u;
import w0.e;
import w0.i;

public final class t implements l {

    /* renamed from: i  reason: collision with root package name */
    public static final b f3170i = new b((e) null);
    /* access modifiers changed from: private */

    /* renamed from: j  reason: collision with root package name */
    public static final t f3171j = new t();

    /* renamed from: a  reason: collision with root package name */
    private int f3172a;

    /* renamed from: b  reason: collision with root package name */
    private int f3173b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f3174c = true;

    /* renamed from: d  reason: collision with root package name */
    private boolean f3175d = true;

    /* renamed from: e  reason: collision with root package name */
    private Handler f3176e;

    /* renamed from: f  reason: collision with root package name */
    private final m f3177f = new m(this);

    /* renamed from: g  reason: collision with root package name */
    private final Runnable f3178g = new s(this);
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public final u.a f3179h = new d(this);

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public static final a f3180a = new a();

        private a() {
        }

        public static final void a(Activity activity, Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
            i.e(activity, "activity");
            i.e(activityLifecycleCallbacks, "callback");
            activity.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
        }
    }

    public static final class b {
        private b() {
        }

        public final l a() {
            return t.f3171j;
        }

        public final void b(Context context) {
            i.e(context, "context");
            t.f3171j.j(context);
        }

        public /* synthetic */ b(e eVar) {
            this();
        }
    }

    public static final class c extends C0187d {
        final /* synthetic */ t this$0;

        public static final class a extends C0187d {
            final /* synthetic */ t this$0;

            a(t tVar) {
                this.this$0 = tVar;
            }

            public void onActivityPostResumed(Activity activity) {
                i.e(activity, "activity");
                this.this$0.g();
            }

            public void onActivityPostStarted(Activity activity) {
                i.e(activity, "activity");
                this.this$0.h();
            }
        }

        c(t tVar) {
            this.this$0 = tVar;
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
            if (Build.VERSION.SDK_INT < 29) {
                u.f3182b.b(activity).f(this.this$0.f3179h);
            }
        }

        public void onActivityPaused(Activity activity) {
            i.e(activity, "activity");
            this.this$0.f();
        }

        public void onActivityPreCreated(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
            a.a(activity, new a(this.this$0));
        }

        public void onActivityStopped(Activity activity) {
            i.e(activity, "activity");
            this.this$0.i();
        }
    }

    public static final class d implements u.a {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ t f3181a;

        d(t tVar) {
            this.f3181a = tVar;
        }

        public void a() {
        }

        public void b() {
            this.f3181a.g();
        }

        public void c() {
            this.f3181a.h();
        }
    }

    private t() {
    }

    /* access modifiers changed from: private */
    public static final void k(t tVar) {
        i.e(tVar, "this$0");
        tVar.l();
        tVar.m();
    }

    public final void f() {
        int i2 = this.f3173b - 1;
        this.f3173b = i2;
        if (i2 == 0) {
            Handler handler = this.f3176e;
            i.b(handler);
            handler.postDelayed(this.f3178g, 700);
        }
    }

    public final void g() {
        int i2 = this.f3173b + 1;
        this.f3173b = i2;
        if (i2 != 1) {
            return;
        }
        if (this.f3174c) {
            this.f3177f.h(C0190g.a.ON_RESUME);
            this.f3174c = false;
            return;
        }
        Handler handler = this.f3176e;
        i.b(handler);
        handler.removeCallbacks(this.f3178g);
    }

    public final void h() {
        int i2 = this.f3172a + 1;
        this.f3172a = i2;
        if (i2 == 1 && this.f3175d) {
            this.f3177f.h(C0190g.a.ON_START);
            this.f3175d = false;
        }
    }

    public final void i() {
        this.f3172a--;
        m();
    }

    public final void j(Context context) {
        i.e(context, "context");
        this.f3176e = new Handler();
        this.f3177f.h(C0190g.a.ON_CREATE);
        Context applicationContext = context.getApplicationContext();
        i.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext).registerActivityLifecycleCallbacks(new c(this));
    }

    public final void l() {
        if (this.f3173b == 0) {
            this.f3174c = true;
            this.f3177f.h(C0190g.a.ON_PAUSE);
        }
    }

    public final void m() {
        if (this.f3172a == 0 && this.f3174c) {
            this.f3177f.h(C0190g.a.ON_STOP);
            this.f3175d = true;
        }
    }

    public C0190g v() {
        return this.f3177f;
    }
}
