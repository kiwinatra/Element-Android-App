package androidx.lifecycle;

public interface l {
    C0190g v();
}
