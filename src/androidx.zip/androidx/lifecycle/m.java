package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import j.C0250c;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import k.C0253a;
import k.C0254b;
import w0.e;
import w0.i;

public class m extends C0190g {

    /* renamed from: j  reason: collision with root package name */
    public static final a f3154j = new a((e) null);

    /* renamed from: b  reason: collision with root package name */
    private final boolean f3155b;

    /* renamed from: c  reason: collision with root package name */
    private C0253a f3156c;

    /* renamed from: d  reason: collision with root package name */
    private C0190g.b f3157d;

    /* renamed from: e  reason: collision with root package name */
    private final WeakReference f3158e;

    /* renamed from: f  reason: collision with root package name */
    private int f3159f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f3160g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f3161h;

    /* renamed from: i  reason: collision with root package name */
    private ArrayList f3162i;

    public static final class a {
        private a() {
        }

        public final C0190g.b a(C0190g.b bVar, C0190g.b bVar2) {
            i.e(bVar, "state1");
            return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private C0190g.b f3163a;

        /* renamed from: b  reason: collision with root package name */
        private j f3164b;

        public b(k kVar, C0190g.b bVar) {
            i.e(bVar, "initialState");
            i.b(kVar);
            this.f3164b = n.f(kVar);
            this.f3163a = bVar;
        }

        public final void a(l lVar, C0190g.a aVar) {
            i.e(aVar, "event");
            C0190g.b b2 = aVar.b();
            this.f3163a = m.f3154j.a(this.f3163a, b2);
            j jVar = this.f3164b;
            i.b(lVar);
            jVar.d(lVar, aVar);
            this.f3163a = b2;
        }

        public final C0190g.b b() {
            return this.f3163a;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public m(l lVar) {
        this(lVar, true);
        i.e(lVar, "provider");
    }

    private final void d(l lVar) {
        Iterator a2 = this.f3156c.a();
        i.d(a2, "observerMap.descendingIterator()");
        while (a2.hasNext() && !this.f3161h) {
            Map.Entry entry = (Map.Entry) a2.next();
            i.d(entry, "next()");
            k kVar = (k) entry.getKey();
            b bVar = (b) entry.getValue();
            while (bVar.b().compareTo(this.f3157d) > 0 && !this.f3161h && this.f3156c.contains(kVar)) {
                C0190g.a a3 = C0190g.a.Companion.a(bVar.b());
                if (a3 != null) {
                    l(a3.b());
                    bVar.a(lVar, a3);
                    k();
                } else {
                    throw new IllegalStateException("no event down from " + bVar.b());
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0009, code lost:
        r4 = (androidx.lifecycle.m.b) r4.getValue();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final androidx.lifecycle.C0190g.b e(androidx.lifecycle.k r4) {
        /*
            r3 = this;
            k.a r0 = r3.f3156c
            java.util.Map$Entry r4 = r0.i(r4)
            r0 = 0
            if (r4 == 0) goto L_0x0016
            java.lang.Object r4 = r4.getValue()
            androidx.lifecycle.m$b r4 = (androidx.lifecycle.m.b) r4
            if (r4 == 0) goto L_0x0016
            androidx.lifecycle.g$b r4 = r4.b()
            goto L_0x0017
        L_0x0016:
            r4 = r0
        L_0x0017:
            java.util.ArrayList r1 = r3.f3162i
            boolean r1 = r1.isEmpty()
            r1 = r1 ^ 1
            if (r1 == 0) goto L_0x002f
            java.util.ArrayList r0 = r3.f3162i
            int r1 = r0.size()
            int r1 = r1 + -1
            java.lang.Object r0 = r0.get(r1)
            androidx.lifecycle.g$b r0 = (androidx.lifecycle.C0190g.b) r0
        L_0x002f:
            androidx.lifecycle.m$a r1 = f3154j
            androidx.lifecycle.g$b r2 = r3.f3157d
            androidx.lifecycle.g$b r4 = r1.a(r2, r4)
            androidx.lifecycle.g$b r4 = r1.a(r4, r0)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.m.e(androidx.lifecycle.k):androidx.lifecycle.g$b");
    }

    private final void f(String str) {
        if (this.f3155b && !C0250c.f().b()) {
            throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
        }
    }

    private final void g(l lVar) {
        C0254b.d d2 = this.f3156c.d();
        i.d(d2, "observerMap.iteratorWithAdditions()");
        while (d2.hasNext() && !this.f3161h) {
            Map.Entry entry = (Map.Entry) d2.next();
            k kVar = (k) entry.getKey();
            b bVar = (b) entry.getValue();
            while (bVar.b().compareTo(this.f3157d) < 0 && !this.f3161h && this.f3156c.contains(kVar)) {
                l(bVar.b());
                C0190g.a b2 = C0190g.a.Companion.b(bVar.b());
                if (b2 != null) {
                    bVar.a(lVar, b2);
                    k();
                } else {
                    throw new IllegalStateException("no event up from " + bVar.b());
                }
            }
        }
    }

    private final boolean i() {
        if (this.f3156c.size() == 0) {
            return true;
        }
        Map.Entry b2 = this.f3156c.b();
        i.b(b2);
        C0190g.b b3 = ((b) b2.getValue()).b();
        Map.Entry e2 = this.f3156c.e();
        i.b(e2);
        C0190g.b b4 = ((b) e2.getValue()).b();
        return b3 == b4 && this.f3157d == b4;
    }

    private final void j(C0190g.b bVar) {
        C0190g.b bVar2 = this.f3157d;
        if (bVar2 != bVar) {
            if (bVar2 == C0190g.b.INITIALIZED && bVar == C0190g.b.DESTROYED) {
                throw new IllegalStateException(("no event down from " + this.f3157d + " in component " + this.f3158e.get()).toString());
            }
            this.f3157d = bVar;
            if (this.f3160g || this.f3159f != 0) {
                this.f3161h = true;
                return;
            }
            this.f3160g = true;
            n();
            this.f3160g = false;
            if (this.f3157d == C0190g.b.DESTROYED) {
                this.f3156c = new C0253a();
            }
        }
    }

    private final void k() {
        ArrayList arrayList = this.f3162i;
        arrayList.remove(arrayList.size() - 1);
    }

    private final void l(C0190g.b bVar) {
        this.f3162i.add(bVar);
    }

    private final void n() {
        l lVar = (l) this.f3158e.get();
        if (lVar != null) {
            while (true) {
                boolean i2 = i();
                this.f3161h = false;
                if (!i2) {
                    C0190g.b bVar = this.f3157d;
                    Map.Entry b2 = this.f3156c.b();
                    i.b(b2);
                    if (bVar.compareTo(((b) b2.getValue()).b()) < 0) {
                        d(lVar);
                    }
                    Map.Entry e2 = this.f3156c.e();
                    if (!this.f3161h && e2 != null && this.f3157d.compareTo(((b) e2.getValue()).b()) > 0) {
                        g(lVar);
                    }
                } else {
                    return;
                }
            }
        } else {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
    }

    public void a(k kVar) {
        l lVar;
        i.e(kVar, "observer");
        f("addObserver");
        C0190g.b bVar = this.f3157d;
        C0190g.b bVar2 = C0190g.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = C0190g.b.INITIALIZED;
        }
        b bVar3 = new b(kVar, bVar2);
        if (((b) this.f3156c.g(kVar, bVar3)) == null && (lVar = (l) this.f3158e.get()) != null) {
            boolean z2 = this.f3159f != 0 || this.f3160g;
            C0190g.b e2 = e(kVar);
            this.f3159f++;
            while (bVar3.b().compareTo(e2) < 0 && this.f3156c.contains(kVar)) {
                l(bVar3.b());
                C0190g.a b2 = C0190g.a.Companion.b(bVar3.b());
                if (b2 != null) {
                    bVar3.a(lVar, b2);
                    k();
                    e2 = e(kVar);
                } else {
                    throw new IllegalStateException("no event up from " + bVar3.b());
                }
            }
            if (!z2) {
                n();
            }
            this.f3159f--;
        }
    }

    public C0190g.b b() {
        return this.f3157d;
    }

    public void c(k kVar) {
        i.e(kVar, "observer");
        f("removeObserver");
        this.f3156c.h(kVar);
    }

    public void h(C0190g.a aVar) {
        i.e(aVar, "event");
        f("handleLifecycleEvent");
        j(aVar.b());
    }

    public void m(C0190g.b bVar) {
        i.e(bVar, "state");
        f("setCurrentState");
        j(bVar);
    }

    private m(l lVar, boolean z2) {
        this.f3155b = z2;
        this.f3156c = new C0253a();
        this.f3157d = C0190g.b.INITIALIZED;
        this.f3162i = new ArrayList();
        this.f3158e = new WeakReference(lVar);
    }
}
