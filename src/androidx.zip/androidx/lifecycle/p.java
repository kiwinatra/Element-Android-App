package androidx.lifecycle;

public class p extends LiveData {
    public void i(Object obj) {
        super.i(obj);
    }
}
