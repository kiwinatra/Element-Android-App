package androidx.lifecycle;

import androidx.lifecycle.C0184a;
import androidx.lifecycle.C0190g;

@Deprecated
class ReflectiveGenericLifecycleObserver implements j {

    /* renamed from: a  reason: collision with root package name */
    private final Object f3132a;

    /* renamed from: b  reason: collision with root package name */
    private final C0184a.C0048a f3133b;

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f3132a = obj;
        this.f3133b = C0184a.f3136c.c(obj.getClass());
    }

    public void d(l lVar, C0190g.a aVar) {
        this.f3133b.a(lVar, aVar, this.f3132a);
    }
}
