package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import java.util.concurrent.CancellationException;
import q0.a;
import w0.i;

public final class LifecycleCoroutineScopeImpl extends h implements j {

    /* renamed from: a  reason: collision with root package name */
    private final C0190g f3112a;

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        if (i().b().compareTo(C0190g.b.DESTROYED) <= 0) {
            i().c(this);
            h();
            c.b((a) null, (CancellationException) null, 1, (Object) null);
        }
    }

    public a h() {
        return null;
    }

    public C0190g i() {
        return this.f3112a;
    }
}
