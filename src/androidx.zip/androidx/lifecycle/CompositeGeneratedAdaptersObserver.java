package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import w0.i;

public final class CompositeGeneratedAdaptersObserver implements j {

    /* renamed from: a  reason: collision with root package name */
    private final C0188e[] f3104a;

    public CompositeGeneratedAdaptersObserver(C0188e[] eVarArr) {
        i.e(eVarArr, "generatedAdapters");
        this.f3104a = eVarArr;
    }

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        new o();
        C0188e[] eVarArr = this.f3104a;
        if (eVarArr.length > 0) {
            C0188e eVar = eVarArr[0];
            throw null;
        } else if (eVarArr.length > 0) {
            C0188e eVar2 = eVarArr[0];
            throw null;
        }
    }
}
