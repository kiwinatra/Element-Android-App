package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface r {
    C0190g.a value();
}
