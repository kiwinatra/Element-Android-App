package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class o {

    /* renamed from: a  reason: collision with root package name */
    private final Map f3168a = new HashMap();
}
