package androidx.lifecycle;

import M.e;
import android.view.View;
import w0.i;

public abstract class G {
    public static final void a(View view, E e2) {
        i.e(view, "<this>");
        view.setTag(e.view_tree_view_model_store_owner, e2);
    }
}
