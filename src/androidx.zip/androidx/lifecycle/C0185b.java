package androidx.lifecycle;

import w0.i;

/* renamed from: androidx.lifecycle.b  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0185b {
    public static void a(C0186c cVar, l lVar) {
        i.e(lVar, "owner");
    }

    public static void b(C0186c cVar, l lVar) {
        i.e(lVar, "owner");
    }

    public static void c(C0186c cVar, l lVar) {
        i.e(lVar, "owner");
    }

    public static void d(C0186c cVar, l lVar) {
        i.e(lVar, "owner");
    }

    public static void e(C0186c cVar, l lVar) {
        i.e(lVar, "owner");
    }
}
