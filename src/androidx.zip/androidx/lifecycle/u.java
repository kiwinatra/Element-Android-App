package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import androidx.lifecycle.C0190g;
import w0.e;
import w0.i;

public class u extends Fragment {

    /* renamed from: b  reason: collision with root package name */
    public static final b f3182b = new b((e) null);

    /* renamed from: a  reason: collision with root package name */
    private a f3183a;

    public interface a {
        void a();

        void b();

        void c();
    }

    public static final class b {
        private b() {
        }

        public final void a(Activity activity, C0190g.a aVar) {
            i.e(activity, "activity");
            i.e(aVar, "event");
            if (activity instanceof l) {
                C0190g v2 = ((l) activity).v();
                if (v2 instanceof m) {
                    ((m) v2).h(aVar);
                }
            }
        }

        public final u b(Activity activity) {
            i.e(activity, "<this>");
            Fragment findFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            i.c(findFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            return (u) findFragmentByTag;
        }

        public final void c(Activity activity) {
            i.e(activity, "activity");
            if (Build.VERSION.SDK_INT >= 29) {
                c.Companion.a(activity);
            }
            FragmentManager fragmentManager = activity.getFragmentManager();
            if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
                fragmentManager.beginTransaction().add(new u(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
                fragmentManager.executePendingTransactions();
            }
        }

        public /* synthetic */ b(e eVar) {
            this();
        }
    }

    public static final class c implements Application.ActivityLifecycleCallbacks {
        public static final a Companion = new a((e) null);

        public static final class a {
            private a() {
            }

            public final void a(Activity activity) {
                i.e(activity, "activity");
                activity.registerActivityLifecycleCallbacks(new c());
            }

            public /* synthetic */ a(e eVar) {
                this();
            }
        }

        public static final void registerIn(Activity activity) {
            Companion.a(activity);
        }

        public void onActivityCreated(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
        }

        public void onActivityDestroyed(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivityPaused(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_CREATE);
        }

        public void onActivityPostResumed(Activity activity) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_RESUME);
        }

        public void onActivityPostStarted(Activity activity) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_START);
        }

        public void onActivityPreDestroyed(Activity activity) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_DESTROY);
        }

        public void onActivityPrePaused(Activity activity) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_PAUSE);
        }

        public void onActivityPreStopped(Activity activity) {
            i.e(activity, "activity");
            u.f3182b.a(activity, C0190g.a.ON_STOP);
        }

        public void onActivityResumed(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            i.e(activity, "activity");
            i.e(bundle, "bundle");
        }

        public void onActivityStarted(Activity activity) {
            i.e(activity, "activity");
        }

        public void onActivityStopped(Activity activity) {
            i.e(activity, "activity");
        }
    }

    private final void a(C0190g.a aVar) {
        if (Build.VERSION.SDK_INT < 29) {
            b bVar = f3182b;
            Activity activity = getActivity();
            i.d(activity, "activity");
            bVar.a(activity, aVar);
        }
    }

    private final void b(a aVar) {
        if (aVar != null) {
            aVar.a();
        }
    }

    private final void c(a aVar) {
        if (aVar != null) {
            aVar.b();
        }
    }

    private final void d(a aVar) {
        if (aVar != null) {
            aVar.c();
        }
    }

    public static final void e(Activity activity) {
        f3182b.c(activity);
    }

    public final void f(a aVar) {
        this.f3183a = aVar;
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        b(this.f3183a);
        a(C0190g.a.ON_CREATE);
    }

    public void onDestroy() {
        super.onDestroy();
        a(C0190g.a.ON_DESTROY);
        this.f3183a = null;
    }

    public void onPause() {
        super.onPause();
        a(C0190g.a.ON_PAUSE);
    }

    public void onResume() {
        super.onResume();
        c(this.f3183a);
        a(C0190g.a.ON_RESUME);
    }

    public void onStart() {
        super.onStart();
        d(this.f3183a);
        a(C0190g.a.ON_START);
    }

    public void onStop() {
        super.onStop();
        a(C0190g.a.ON_STOP);
    }
}
