package androidx.lifecycle;

import androidx.lifecycle.C0190g;
import w0.i;

public final class SavedStateHandleAttacher implements j {

    /* renamed from: a  reason: collision with root package name */
    private final x f3134a;

    public SavedStateHandleAttacher(x xVar) {
        i.e(xVar, "provider");
        this.f3134a = xVar;
    }

    public void d(l lVar, C0190g.a aVar) {
        i.e(lVar, "source");
        i.e(aVar, "event");
        if (aVar == C0190g.a.ON_CREATE) {
            lVar.v().c(this);
            this.f3134a.c();
            return;
        }
        throw new IllegalStateException(("Next event must be ON_CREATE, it was " + aVar).toString());
    }
}
