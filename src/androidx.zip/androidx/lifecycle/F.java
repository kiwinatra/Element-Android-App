package androidx.lifecycle;

import L.a;
import android.view.View;
import w0.i;

public abstract class F {
    public static final void a(View view, l lVar) {
        i.e(view, "<this>");
        view.setTag(a.view_tree_lifecycle_owner, lVar);
    }
}
