package androidx.lifecycle;

import M.a;
import androidx.lifecycle.A;
import w0.i;

public abstract /* synthetic */ class B {
    public static z a(A.b bVar, Class cls) {
        i.e(cls, "modelClass");
        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
    }

    public static z b(A.b bVar, Class cls, a aVar) {
        i.e(cls, "modelClass");
        i.e(aVar, "extras");
        return bVar.a(cls);
    }
}
