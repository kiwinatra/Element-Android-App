package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import androidx.core.view.C;
import androidx.core.view.C0156s;
import androidx.core.view.C0165w0;
import androidx.core.view.D;
import androidx.core.view.E;
import androidx.core.view.F;
import androidx.core.view.W;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import s.C0281a;
import s.C0282b;

public class CoordinatorLayout extends ViewGroup implements C, D {

    /* renamed from: u  reason: collision with root package name */
    static final String f2030u;

    /* renamed from: v  reason: collision with root package name */
    static final Class[] f2031v = {Context.class, AttributeSet.class};

    /* renamed from: w  reason: collision with root package name */
    static final ThreadLocal f2032w = new ThreadLocal();

    /* renamed from: x  reason: collision with root package name */
    static final Comparator f2033x = new h();

    /* renamed from: y  reason: collision with root package name */
    private static final x.e f2034y = new x.g(12);

    /* renamed from: a  reason: collision with root package name */
    private final List f2035a;

    /* renamed from: b  reason: collision with root package name */
    private final b f2036b;

    /* renamed from: c  reason: collision with root package name */
    private final List f2037c;

    /* renamed from: d  reason: collision with root package name */
    private final List f2038d;

    /* renamed from: e  reason: collision with root package name */
    private Paint f2039e;

    /* renamed from: f  reason: collision with root package name */
    private final int[] f2040f;

    /* renamed from: g  reason: collision with root package name */
    private final int[] f2041g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f2042h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f2043i;

    /* renamed from: j  reason: collision with root package name */
    private int[] f2044j;

    /* renamed from: k  reason: collision with root package name */
    private View f2045k;

    /* renamed from: l  reason: collision with root package name */
    private View f2046l;

    /* renamed from: m  reason: collision with root package name */
    private f f2047m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f2048n;

    /* renamed from: o  reason: collision with root package name */
    private C0165w0 f2049o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f2050p;

    /* renamed from: q  reason: collision with root package name */
    private Drawable f2051q;

    /* renamed from: r  reason: collision with root package name */
    ViewGroup.OnHierarchyChangeListener f2052r;

    /* renamed from: s  reason: collision with root package name */
    private F f2053s;

    /* renamed from: t  reason: collision with root package name */
    private final E f2054t;

    class a implements F {
        a() {
        }

        public C0165w0 a(View view, C0165w0 w0Var) {
            return CoordinatorLayout.this.U(w0Var);
        }
    }

    public static abstract class b {
        public b() {
        }

        public boolean A(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z2) {
            return false;
        }

        public void B(CoordinatorLayout coordinatorLayout, View view, Parcelable parcelable) {
        }

        public Parcelable C(CoordinatorLayout coordinatorLayout, View view) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        public boolean D(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2) {
            return false;
        }

        public boolean E(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
            if (i3 == 0) {
                return D(coordinatorLayout, view, view2, view3, i2);
            }
            return false;
        }

        public void F(CoordinatorLayout coordinatorLayout, View view, View view2) {
        }

        public void G(CoordinatorLayout coordinatorLayout, View view, View view2, int i2) {
            if (i2 == 0) {
                F(coordinatorLayout, view, view2);
            }
        }

        public boolean H(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return false;
        }

        public boolean e(CoordinatorLayout coordinatorLayout, View view) {
            return h(coordinatorLayout, view) > 0.0f;
        }

        public boolean f(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            return false;
        }

        public int g(CoordinatorLayout coordinatorLayout, View view) {
            return -16777216;
        }

        public float h(CoordinatorLayout coordinatorLayout, View view) {
            return 0.0f;
        }

        public boolean i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return false;
        }

        public C0165w0 j(CoordinatorLayout coordinatorLayout, View view, C0165w0 w0Var) {
            return w0Var;
        }

        public void k(e eVar) {
        }

        public boolean l(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return false;
        }

        public void m(CoordinatorLayout coordinatorLayout, View view, View view2) {
        }

        public void n() {
        }

        public boolean o(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return false;
        }

        public boolean p(CoordinatorLayout coordinatorLayout, View view, int i2) {
            return false;
        }

        public boolean q(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
            return false;
        }

        public boolean r(CoordinatorLayout coordinatorLayout, View view, View view2, float f2, float f3, boolean z2) {
            return false;
        }

        public boolean s(CoordinatorLayout coordinatorLayout, View view, View view2, float f2, float f3) {
            return false;
        }

        public void t(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int[] iArr) {
        }

        public void u(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int[] iArr, int i4) {
            if (i4 == 0) {
                t(coordinatorLayout, view, view2, i2, i3, iArr);
            }
        }

        public void v(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5) {
        }

        public void w(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5, int i6) {
            if (i6 == 0) {
                v(coordinatorLayout, view, view2, i2, i3, i4, i5);
            }
        }

        public void x(CoordinatorLayout coordinatorLayout, View view, View view2, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            iArr[0] = iArr[0] + i4;
            iArr[1] = iArr[1] + i5;
            w(coordinatorLayout, view, view2, i2, i3, i4, i5, i6);
        }

        public void y(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2) {
        }

        public void z(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i2, int i3) {
            if (i3 == 0) {
                y(coordinatorLayout, view, view2, view3, i2);
            }
        }

        public b(Context context, AttributeSet attributeSet) {
        }
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface c {
        Class value();
    }

    private class d implements ViewGroup.OnHierarchyChangeListener {
        d() {
        }

        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2052r;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.F(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2052r;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    public static class e extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        b f2057a;

        /* renamed from: b  reason: collision with root package name */
        boolean f2058b = false;

        /* renamed from: c  reason: collision with root package name */
        public int f2059c = 0;

        /* renamed from: d  reason: collision with root package name */
        public int f2060d = 0;

        /* renamed from: e  reason: collision with root package name */
        public int f2061e = -1;

        /* renamed from: f  reason: collision with root package name */
        int f2062f = -1;

        /* renamed from: g  reason: collision with root package name */
        public int f2063g = 0;

        /* renamed from: h  reason: collision with root package name */
        public int f2064h = 0;

        /* renamed from: i  reason: collision with root package name */
        int f2065i;

        /* renamed from: j  reason: collision with root package name */
        int f2066j;

        /* renamed from: k  reason: collision with root package name */
        View f2067k;

        /* renamed from: l  reason: collision with root package name */
        View f2068l;

        /* renamed from: m  reason: collision with root package name */
        private boolean f2069m;

        /* renamed from: n  reason: collision with root package name */
        private boolean f2070n;

        /* renamed from: o  reason: collision with root package name */
        private boolean f2071o;

        /* renamed from: p  reason: collision with root package name */
        private boolean f2072p;

        /* renamed from: q  reason: collision with root package name */
        final Rect f2073q = new Rect();

        /* renamed from: r  reason: collision with root package name */
        Object f2074r;

        public e(int i2, int i3) {
            super(i2, i3);
        }

        private void m(View view, CoordinatorLayout coordinatorLayout) {
            View findViewById = coordinatorLayout.findViewById(this.f2062f);
            this.f2067k = findViewById;
            if (findViewById != null) {
                if (findViewById != coordinatorLayout) {
                    ViewParent parent = findViewById.getParent();
                    while (parent != coordinatorLayout && parent != null) {
                        if (parent != view) {
                            if (parent instanceof View) {
                                findViewById = (View) parent;
                            }
                            parent = parent.getParent();
                        } else if (!coordinatorLayout.isInEditMode()) {
                            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                        }
                    }
                    this.f2068l = findViewById;
                    return;
                } else if (!coordinatorLayout.isInEditMode()) {
                    throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                }
            } else if (!coordinatorLayout.isInEditMode()) {
                throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + coordinatorLayout.getResources().getResourceName(this.f2062f) + " to anchor view " + view);
            }
            this.f2068l = null;
            this.f2067k = null;
        }

        private boolean r(View view, int i2) {
            int b2 = C0156s.b(((e) view.getLayoutParams()).f2063g, i2);
            return b2 != 0 && (C0156s.b(this.f2064h, i2) & b2) == b2;
        }

        private boolean s(View view, CoordinatorLayout coordinatorLayout) {
            if (this.f2067k.getId() != this.f2062f) {
                return false;
            }
            View view2 = this.f2067k;
            for (ViewParent parent = view2.getParent(); parent != coordinatorLayout; parent = parent.getParent()) {
                if (parent == null || parent == view) {
                    this.f2068l = null;
                    this.f2067k = null;
                    return false;
                }
                if (parent instanceof View) {
                    view2 = (View) parent;
                }
            }
            this.f2068l = view2;
            return true;
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            return this.f2067k == null && this.f2062f != -1;
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000e, code lost:
            r0 = r1.f2057a;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean b(androidx.coordinatorlayout.widget.CoordinatorLayout r2, android.view.View r3, android.view.View r4) {
            /*
                r1 = this;
                android.view.View r0 = r1.f2068l
                if (r4 == r0) goto L_0x001b
                int r0 = androidx.core.view.W.C(r2)
                boolean r0 = r1.r(r4, r0)
                if (r0 != 0) goto L_0x001b
                androidx.coordinatorlayout.widget.CoordinatorLayout$b r0 = r1.f2057a
                if (r0 == 0) goto L_0x0019
                boolean r2 = r0.i(r2, r3, r4)
                if (r2 == 0) goto L_0x0019
                goto L_0x001b
            L_0x0019:
                r2 = 0
                goto L_0x001c
            L_0x001b:
                r2 = 1
            L_0x001c:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.e.b(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View):boolean");
        }

        /* access modifiers changed from: package-private */
        public boolean c() {
            if (this.f2057a == null) {
                this.f2069m = false;
            }
            return this.f2069m;
        }

        /* access modifiers changed from: package-private */
        public View d(CoordinatorLayout coordinatorLayout, View view) {
            if (this.f2062f == -1) {
                this.f2068l = null;
                this.f2067k = null;
                return null;
            }
            if (this.f2067k == null || !s(view, coordinatorLayout)) {
                m(view, coordinatorLayout);
            }
            return this.f2067k;
        }

        public b e() {
            return this.f2057a;
        }

        /* access modifiers changed from: package-private */
        public boolean f() {
            return this.f2072p;
        }

        /* access modifiers changed from: package-private */
        public Rect g() {
            return this.f2073q;
        }

        /* access modifiers changed from: package-private */
        public boolean h(CoordinatorLayout coordinatorLayout, View view) {
            boolean z2 = this.f2069m;
            if (z2) {
                return true;
            }
            b bVar = this.f2057a;
            boolean e2 = (bVar != null ? bVar.e(coordinatorLayout, view) : false) | z2;
            this.f2069m = e2;
            return e2;
        }

        /* access modifiers changed from: package-private */
        public boolean i(int i2) {
            if (i2 == 0) {
                return this.f2070n;
            }
            if (i2 != 1) {
                return false;
            }
            return this.f2071o;
        }

        /* access modifiers changed from: package-private */
        public void j() {
            this.f2072p = false;
        }

        /* access modifiers changed from: package-private */
        public void k(int i2) {
            q(i2, false);
        }

        /* access modifiers changed from: package-private */
        public void l() {
            this.f2069m = false;
        }

        public void n(b bVar) {
            b bVar2 = this.f2057a;
            if (bVar2 != bVar) {
                if (bVar2 != null) {
                    bVar2.n();
                }
                this.f2057a = bVar;
                this.f2074r = null;
                this.f2058b = true;
                if (bVar != null) {
                    bVar.k(this);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void o(boolean z2) {
            this.f2072p = z2;
        }

        /* access modifiers changed from: package-private */
        public void p(Rect rect) {
            this.f2073q.set(rect);
        }

        /* access modifiers changed from: package-private */
        public void q(int i2, boolean z2) {
            if (i2 == 0) {
                this.f2070n = z2;
            } else if (i2 == 1) {
                this.f2071o = z2;
            }
        }

        e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s.c.f6200e);
            this.f2059c = obtainStyledAttributes.getInteger(s.c.f6201f, 0);
            this.f2062f = obtainStyledAttributes.getResourceId(s.c.f6202g, -1);
            this.f2060d = obtainStyledAttributes.getInteger(s.c.f6203h, 0);
            this.f2061e = obtainStyledAttributes.getInteger(s.c.f6207l, -1);
            this.f2063g = obtainStyledAttributes.getInt(s.c.f6206k, 0);
            this.f2064h = obtainStyledAttributes.getInt(s.c.f6205j, 0);
            int i2 = s.c.f6204i;
            boolean hasValue = obtainStyledAttributes.hasValue(i2);
            this.f2058b = hasValue;
            if (hasValue) {
                this.f2057a = CoordinatorLayout.I(context, attributeSet, obtainStyledAttributes.getString(i2));
            }
            obtainStyledAttributes.recycle();
            b bVar = this.f2057a;
            if (bVar != null) {
                bVar.k(this);
            }
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public e(e eVar) {
            super(eVar);
        }
    }

    class f implements ViewTreeObserver.OnPreDrawListener {
        f() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.F(0);
            return true;
        }
    }

    protected static class g extends C.a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        SparseArray f2076c;

        static class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            /* renamed from: c */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f2076c = new SparseArray(readInt);
            for (int i2 = 0; i2 < readInt; i2++) {
                this.f2076c.append(iArr[i2], readParcelableArray[i2]);
            }
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            SparseArray sparseArray = this.f2076c;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i3 = 0; i3 < size; i3++) {
                iArr[i3] = this.f2076c.keyAt(i3);
                parcelableArr[i3] = (Parcelable) this.f2076c.valueAt(i3);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i2);
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }
    }

    static class h implements Comparator {
        h() {
        }

        /* renamed from: a */
        public int compare(View view, View view2) {
            float O2 = W.O(view);
            float O3 = W.O(view2);
            if (O2 > O3) {
                return -1;
            }
            return O2 < O3 ? 1 : 0;
        }
    }

    static {
        Package packageR = CoordinatorLayout.class.getPackage();
        f2030u = packageR != null ? packageR.getName() : null;
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0281a.coordinatorLayoutStyle);
    }

    private void A(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        Rect a2 = a();
        a2.set(getPaddingLeft() + eVar.leftMargin, getPaddingTop() + eVar.topMargin, (getWidth() - getPaddingRight()) - eVar.rightMargin, (getHeight() - getPaddingBottom()) - eVar.bottomMargin);
        if (this.f2049o != null && W.z(this) && !W.z(view)) {
            a2.left += this.f2049o.j();
            a2.top += this.f2049o.l();
            a2.right -= this.f2049o.k();
            a2.bottom -= this.f2049o.i();
        }
        Rect a3 = a();
        C0156s.a(Q(eVar.f2059c), view.getMeasuredWidth(), view.getMeasuredHeight(), a2, a3, i2);
        view.layout(a3.left, a3.top, a3.right, a3.bottom);
        M(a2);
        M(a3);
    }

    private void B(View view, View view2, int i2) {
        Rect a2 = a();
        Rect a3 = a();
        try {
            r(view2, a2);
            s(view, i2, a2, a3);
            view.layout(a3.left, a3.top, a3.right, a3.bottom);
        } finally {
            M(a2);
            M(a3);
        }
    }

    private void C(View view, int i2, int i3) {
        e eVar = (e) view.getLayoutParams();
        int b2 = C0156s.b(R(eVar.f2059c), i3);
        int i4 = b2 & 7;
        int i5 = b2 & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        if (i3 == 1) {
            i2 = width - i2;
        }
        int u2 = u(i2) - measuredWidth;
        if (i4 == 1) {
            u2 += measuredWidth / 2;
        } else if (i4 == 5) {
            u2 += measuredWidth;
        }
        int i6 = i5 != 16 ? i5 != 80 ? 0 : measuredHeight : measuredHeight / 2;
        int max = Math.max(getPaddingLeft() + eVar.leftMargin, Math.min(u2, ((width - getPaddingRight()) - measuredWidth) - eVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + eVar.topMargin, Math.min(i6, ((height - getPaddingBottom()) - measuredHeight) - eVar.bottomMargin));
        view.layout(max, max2, measuredWidth + max, measuredHeight + max2);
    }

    private void D(View view, Rect rect, int i2) {
        boolean z2;
        boolean z3;
        int width;
        int i3;
        int i4;
        int i5;
        int height;
        int i6;
        int i7;
        int i8;
        if (W.U(view) && view.getWidth() > 0 && view.getHeight() > 0) {
            e eVar = (e) view.getLayoutParams();
            b e2 = eVar.e();
            Rect a2 = a();
            Rect a3 = a();
            a3.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            if (e2 == null || !e2.f(this, view, a2)) {
                a2.set(a3);
            } else if (!a3.contains(a2)) {
                throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + a2.toShortString() + " | Bounds:" + a3.toShortString());
            }
            M(a3);
            if (a2.isEmpty()) {
                M(a2);
                return;
            }
            int b2 = C0156s.b(eVar.f2064h, i2);
            boolean z4 = true;
            if ((b2 & 48) != 48 || (i7 = (a2.top - eVar.topMargin) - eVar.f2066j) >= (i8 = rect.top)) {
                z2 = false;
            } else {
                T(view, i8 - i7);
                z2 = true;
            }
            if ((b2 & 80) == 80 && (height = ((getHeight() - a2.bottom) - eVar.bottomMargin) + eVar.f2066j) < (i6 = rect.bottom)) {
                T(view, height - i6);
                z2 = true;
            }
            if (!z2) {
                T(view, 0);
            }
            if ((b2 & 3) != 3 || (i4 = (a2.left - eVar.leftMargin) - eVar.f2065i) >= (i5 = rect.left)) {
                z3 = false;
            } else {
                S(view, i5 - i4);
                z3 = true;
            }
            if ((b2 & 5) != 5 || (width = ((getWidth() - a2.right) - eVar.rightMargin) + eVar.f2065i) >= (i3 = rect.right)) {
                z4 = z3;
            } else {
                S(view, width - i3);
            }
            if (!z4) {
                S(view, 0);
            }
            M(a2);
        }
    }

    static b I(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0) {
            String str2 = f2030u;
            if (!TextUtils.isEmpty(str2)) {
                str = str2 + '.' + str;
            }
        }
        try {
            ThreadLocal threadLocal = f2032w;
            Map map = (Map) threadLocal.get();
            if (map == null) {
                map = new HashMap();
                threadLocal.set(map);
            }
            Constructor<?> constructor = (Constructor) map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, false, context.getClassLoader()).getConstructor(f2031v);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return (b) constructor.newInstance(new Object[]{context, attributeSet});
        } catch (Exception e2) {
            throw new RuntimeException("Could not inflate Behavior subclass " + str, e2);
        }
    }

    private boolean J(MotionEvent motionEvent, int i2) {
        MotionEvent motionEvent2 = motionEvent;
        int i3 = i2;
        int actionMasked = motionEvent.getActionMasked();
        List list = this.f2037c;
        x(list);
        int size = list.size();
        MotionEvent motionEvent3 = null;
        boolean z2 = false;
        boolean z3 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view = (View) list.get(i4);
            e eVar = (e) view.getLayoutParams();
            b e2 = eVar.e();
            if ((!z2 && !z3) || actionMasked == 0) {
                if (!z2 && e2 != null) {
                    if (i3 == 0) {
                        z2 = e2.o(this, view, motionEvent2);
                    } else if (i3 == 1) {
                        z2 = e2.H(this, view, motionEvent2);
                    }
                    if (z2) {
                        this.f2045k = view;
                    }
                }
                boolean c2 = eVar.c();
                boolean h2 = eVar.h(this, view);
                z3 = h2 && !c2;
                if (h2 && !z3) {
                    break;
                }
            } else if (e2 != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i3 == 0) {
                    e2.o(this, view, motionEvent3);
                } else if (i3 == 1) {
                    e2.H(this, view, motionEvent3);
                }
            }
        }
        list.clear();
        return z2;
    }

    private void K() {
        this.f2035a.clear();
        this.f2036b.c();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            e w2 = w(childAt);
            w2.d(this, childAt);
            this.f2036b.b(childAt);
            for (int i3 = 0; i3 < childCount; i3++) {
                if (i3 != i2) {
                    View childAt2 = getChildAt(i3);
                    if (w2.b(this, childAt, childAt2)) {
                        if (!this.f2036b.d(childAt2)) {
                            this.f2036b.b(childAt2);
                        }
                        this.f2036b.a(childAt2, childAt);
                    }
                }
            }
        }
        this.f2035a.addAll(this.f2036b.h());
        Collections.reverse(this.f2035a);
    }

    private static void M(Rect rect) {
        rect.setEmpty();
        f2034y.a(rect);
    }

    private void O(boolean z2) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            b e2 = ((e) childAt.getLayoutParams()).e();
            if (e2 != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z2) {
                    e2.o(this, childAt, obtain);
                } else {
                    e2.H(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            ((e) getChildAt(i3).getLayoutParams()).l();
        }
        this.f2045k = null;
        this.f2042h = false;
    }

    private static int P(int i2) {
        if (i2 == 0) {
            return 17;
        }
        return i2;
    }

    private static int Q(int i2) {
        if ((i2 & 7) == 0) {
            i2 |= 8388611;
        }
        return (i2 & 112) == 0 ? i2 | 48 : i2;
    }

    private static int R(int i2) {
        if (i2 == 0) {
            return 8388661;
        }
        return i2;
    }

    private void S(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        int i3 = eVar.f2065i;
        if (i3 != i2) {
            W.a0(view, i2 - i3);
            eVar.f2065i = i2;
        }
    }

    private void T(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        int i3 = eVar.f2066j;
        if (i3 != i2) {
            W.b0(view, i2 - i3);
            eVar.f2066j = i2;
        }
    }

    private void V() {
        if (W.z(this)) {
            if (this.f2053s == null) {
                this.f2053s = new a();
            }
            W.C0(this, this.f2053s);
            setSystemUiVisibility(1280);
            return;
        }
        W.C0(this, (F) null);
    }

    private static Rect a() {
        Rect rect = (Rect) f2034y.b();
        return rect == null ? new Rect() : rect;
    }

    private static int c(int i2, int i3, int i4) {
        if (i2 < i3) {
            return i3;
        }
        return i2 > i4 ? i4 : i2;
    }

    private void d(e eVar, Rect rect, int i2, int i3) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + eVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i2) - eVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + eVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i3) - eVar.bottomMargin));
        rect.set(max, max2, i2 + max, i3 + max2);
    }

    private C0165w0 e(C0165w0 w0Var) {
        b e2;
        if (w0Var.p()) {
            return w0Var;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (W.z(childAt) && (e2 = ((e) childAt.getLayoutParams()).e()) != null) {
                w0Var = e2.j(this, childAt, w0Var);
                if (w0Var.p()) {
                    break;
                }
            }
        }
        return w0Var;
    }

    private void t(View view, int i2, Rect rect, Rect rect2, e eVar, int i3, int i4) {
        int b2 = C0156s.b(P(eVar.f2059c), i2);
        int b3 = C0156s.b(Q(eVar.f2060d), i2);
        int i5 = b2 & 7;
        int i6 = b2 & 112;
        int i7 = b3 & 7;
        int i8 = b3 & 112;
        int width = i7 != 1 ? i7 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int height = i8 != 16 ? i8 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i5 == 1) {
            width -= i3 / 2;
        } else if (i5 != 5) {
            width -= i3;
        }
        if (i6 == 16) {
            height -= i4 / 2;
        } else if (i6 != 80) {
            height -= i4;
        }
        rect2.set(width, height, i3 + width, i4 + height);
    }

    private int u(int i2) {
        StringBuilder sb;
        int[] iArr = this.f2044j;
        if (iArr == null) {
            sb = new StringBuilder();
            sb.append("No keylines defined for ");
            sb.append(this);
            sb.append(" - attempted index lookup ");
            sb.append(i2);
        } else if (i2 >= 0 && i2 < iArr.length) {
            return iArr[i2];
        } else {
            sb = new StringBuilder();
            sb.append("Keyline index ");
            sb.append(i2);
            sb.append(" out of range for ");
            sb.append(this);
        }
        Log.e("CoordinatorLayout", sb.toString());
        return 0;
    }

    private void x(List list) {
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i2 = childCount - 1; i2 >= 0; i2--) {
            list.add(getChildAt(isChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i2) : i2));
        }
        Comparator comparator = f2033x;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
    }

    private boolean y(View view) {
        return this.f2036b.i(view);
    }

    /* access modifiers changed from: package-private */
    public void E(View view, int i2) {
        b e2;
        View view2 = view;
        e eVar = (e) view.getLayoutParams();
        if (eVar.f2067k != null) {
            Rect a2 = a();
            Rect a3 = a();
            Rect a4 = a();
            r(eVar.f2067k, a2);
            boolean z2 = false;
            p(view2, false, a3);
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            int i3 = measuredHeight;
            t(view, i2, a2, a4, eVar, measuredWidth, measuredHeight);
            if (!(a4.left == a3.left && a4.top == a3.top)) {
                z2 = true;
            }
            d(eVar, a4, measuredWidth, i3);
            int i4 = a4.left - a3.left;
            int i5 = a4.top - a3.top;
            if (i4 != 0) {
                W.a0(view2, i4);
            }
            if (i5 != 0) {
                W.b0(view2, i5);
            }
            if (z2 && (e2 = eVar.e()) != null) {
                e2.l(this, view2, eVar.f2067k);
            }
            M(a2);
            M(a3);
            M(a4);
        }
    }

    /* access modifiers changed from: package-private */
    public final void F(int i2) {
        boolean z2;
        int i3 = i2;
        int C2 = W.C(this);
        int size = this.f2035a.size();
        Rect a2 = a();
        Rect a3 = a();
        Rect a4 = a();
        for (int i4 = 0; i4 < size; i4++) {
            View view = (View) this.f2035a.get(i4);
            e eVar = (e) view.getLayoutParams();
            if (i3 != 0 || view.getVisibility() != 8) {
                for (int i5 = 0; i5 < i4; i5++) {
                    if (eVar.f2068l == ((View) this.f2035a.get(i5))) {
                        E(view, C2);
                    }
                }
                p(view, true, a3);
                if (eVar.f2063g != 0 && !a3.isEmpty()) {
                    int b2 = C0156s.b(eVar.f2063g, C2);
                    int i6 = b2 & 112;
                    if (i6 == 48) {
                        a2.top = Math.max(a2.top, a3.bottom);
                    } else if (i6 == 80) {
                        a2.bottom = Math.max(a2.bottom, getHeight() - a3.top);
                    }
                    int i7 = b2 & 7;
                    if (i7 == 3) {
                        a2.left = Math.max(a2.left, a3.right);
                    } else if (i7 == 5) {
                        a2.right = Math.max(a2.right, getWidth() - a3.left);
                    }
                }
                if (eVar.f2064h != 0 && view.getVisibility() == 0) {
                    D(view, a2, C2);
                }
                if (i3 != 2) {
                    v(view, a4);
                    if (!a4.equals(a3)) {
                        L(view, a3);
                    }
                }
                for (int i8 = i4 + 1; i8 < size; i8++) {
                    View view2 = (View) this.f2035a.get(i8);
                    e eVar2 = (e) view2.getLayoutParams();
                    b e2 = eVar2.e();
                    if (e2 != null && e2.i(this, view2, view)) {
                        if (i3 != 0 || !eVar2.f()) {
                            if (i3 != 2) {
                                z2 = e2.l(this, view2, view);
                            } else {
                                e2.m(this, view2, view);
                                z2 = true;
                            }
                            if (i3 == 1) {
                                eVar2.o(z2);
                            }
                        } else {
                            eVar2.j();
                        }
                    }
                }
            }
        }
        M(a2);
        M(a3);
        M(a4);
    }

    public void G(View view, int i2) {
        e eVar = (e) view.getLayoutParams();
        if (!eVar.a()) {
            View view2 = eVar.f2067k;
            if (view2 != null) {
                B(view, view2, i2);
                return;
            }
            int i3 = eVar.f2061e;
            if (i3 >= 0) {
                C(view, i3, i2);
            } else {
                A(view, i2);
            }
        } else {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
    }

    public void H(View view, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    /* access modifiers changed from: package-private */
    public void L(View view, Rect rect) {
        ((e) view.getLayoutParams()).p(rect);
    }

    /* access modifiers changed from: package-private */
    public void N() {
        if (this.f2043i && this.f2047m != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2047m);
        }
        this.f2048n = false;
    }

    /* access modifiers changed from: package-private */
    public final C0165w0 U(C0165w0 w0Var) {
        if (x.c.a(this.f2049o, w0Var)) {
            return w0Var;
        }
        this.f2049o = w0Var;
        boolean z2 = false;
        boolean z3 = w0Var != null && w0Var.l() > 0;
        this.f2050p = z3;
        if (!z3 && getBackground() == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        C0165w0 e2 = e(w0Var);
        requestLayout();
        return e2;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (this.f2043i) {
            if (this.f2047m == null) {
                this.f2047m = new f();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2047m);
        }
        this.f2048n = true;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof e) && super.checkLayoutParams(layoutParams);
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j2) {
        e eVar = (e) view.getLayoutParams();
        b bVar = eVar.f2057a;
        if (bVar != null) {
            float h2 = bVar.h(this, view);
            if (h2 > 0.0f) {
                if (this.f2039e == null) {
                    this.f2039e = new Paint();
                }
                this.f2039e.setColor(eVar.f2057a.g(this, view));
                this.f2039e.setAlpha(c(Math.round(h2 * 255.0f), 0, 255));
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f2039e);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j2);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2051q;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    /* access modifiers changed from: package-private */
    public void f() {
        int childCount = getChildCount();
        boolean z2 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            } else if (y(getChildAt(i2))) {
                z2 = true;
                break;
            } else {
                i2++;
            }
        }
        if (z2 == this.f2048n) {
            return;
        }
        if (z2) {
            b();
        } else {
            N();
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    /* access modifiers changed from: package-private */
    public final List<View> getDependencySortedChildren() {
        K();
        return Collections.unmodifiableList(this.f2035a);
    }

    public final C0165w0 getLastWindowInsets() {
        return this.f2049o;
    }

    public int getNestedScrollAxes() {
        return this.f2054t.a();
    }

    public Drawable getStatusBarBackground() {
        return this.f2051q;
    }

    /* access modifiers changed from: protected */
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
    }

    /* access modifiers changed from: protected */
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
    }

    public void h(View view, View view2, int i2, int i3) {
        b e2;
        this.f2054t.c(view, view2, i2, i3);
        this.f2046l = view2;
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.i(i3) && (e2 = eVar.e()) != null) {
                e2.z(this, childAt, view, view2, i2, i3);
            }
        }
    }

    public void i(View view, int i2) {
        this.f2054t.e(view, i2);
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.i(i2)) {
                b e2 = eVar.e();
                if (e2 != null) {
                    e2.G(this, childAt, view, i2);
                }
                eVar.k(i2);
                eVar.j();
            }
        }
        this.f2046l = null;
    }

    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        b e2;
        int childCount = getChildCount();
        boolean z2 = false;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() == 8) {
                int i8 = i4;
            } else {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.i(i4) && (e2 = eVar.e()) != null) {
                    int[] iArr2 = this.f2040f;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    e2.u(this, childAt, view, i2, i3, iArr2, i4);
                    int[] iArr3 = this.f2040f;
                    i5 = i2 > 0 ? Math.max(i5, iArr3[0]) : Math.min(i5, iArr3[0]);
                    int[] iArr4 = this.f2040f;
                    i6 = i3 > 0 ? Math.max(i6, iArr4[1]) : Math.min(i6, iArr4[1]);
                    z2 = true;
                }
            }
        }
        iArr[0] = i5;
        iArr[1] = i6;
        if (z2) {
            F(1);
        }
    }

    /* renamed from: k */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: l */
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof e) {
            return new e((e) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        b e2;
        int childCount = getChildCount();
        boolean z2 = false;
        int i7 = 0;
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.i(i6) && (e2 = eVar.e()) != null) {
                    int[] iArr2 = this.f2040f;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    e2.x(this, childAt, view, i2, i3, i4, i5, i6, iArr2);
                    int[] iArr3 = this.f2040f;
                    i7 = i4 > 0 ? Math.max(i7, iArr3[0]) : Math.min(i7, iArr3[0]);
                    i8 = i5 > 0 ? Math.max(i8, this.f2040f[1]) : Math.min(i8, this.f2040f[1]);
                    z2 = true;
                }
            }
        }
        iArr[0] = iArr[0] + i7;
        iArr[1] = iArr[1] + i8;
        if (z2) {
            F(1);
        }
    }

    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        m(view, i2, i3, i4, i5, 0, this.f2041g);
    }

    public boolean o(View view, View view2, int i2, int i3) {
        int i4 = i3;
        int childCount = getChildCount();
        int i5 = 0;
        boolean z2 = false;
        while (true) {
            if (i5 >= childCount) {
                return z2;
            }
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                b e2 = eVar.e();
                if (e2 != null) {
                    boolean E2 = e2.E(this, childAt, view, view2, i2, i3);
                    z2 |= E2;
                    eVar.q(i4, E2);
                } else {
                    eVar.q(i4, false);
                }
            }
            i5++;
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        O(false);
        if (this.f2048n) {
            if (this.f2047m == null) {
                this.f2047m = new f();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2047m);
        }
        if (this.f2049o == null && W.z(this)) {
            W.n0(this);
        }
        this.f2043i = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        O(false);
        if (this.f2048n && this.f2047m != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2047m);
        }
        View view = this.f2046l;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f2043i = false;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f2050p && this.f2051q != null) {
            C0165w0 w0Var = this.f2049o;
            int l2 = w0Var != null ? w0Var.l() : 0;
            if (l2 > 0) {
                this.f2051q.setBounds(0, 0, getWidth(), l2);
                this.f2051q.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            O(true);
        }
        boolean J2 = J(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            O(true);
        }
        return J2;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        b e2;
        int C2 = W.C(this);
        int size = this.f2035a.size();
        for (int i6 = 0; i6 < size; i6++) {
            View view = (View) this.f2035a.get(i6);
            if (view.getVisibility() != 8 && ((e2 = ((e) view.getLayoutParams()).e()) == null || !e2.p(this, view, C2))) {
                G(view, C2);
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x011c, code lost:
        if (r0.q(r30, r20, r11, r21, r23, 0) == false) goto L_0x012c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00c9  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00f3  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00fd  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x011f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r7 = r30
            r30.K()
            r30.f()
            int r8 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r9 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            int r10 = androidx.core.view.W.C(r30)
            r2 = 1
            if (r10 != r2) goto L_0x0021
            r12 = 1
            goto L_0x0022
        L_0x0021:
            r12 = 0
        L_0x0022:
            int r13 = android.view.View.MeasureSpec.getMode(r31)
            int r14 = android.view.View.MeasureSpec.getSize(r31)
            int r15 = android.view.View.MeasureSpec.getMode(r32)
            int r16 = android.view.View.MeasureSpec.getSize(r32)
            int r17 = r8 + r9
            int r18 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            androidx.core.view.w0 r3 = r7.f2049o
            if (r3 == 0) goto L_0x004b
            boolean r3 = androidx.core.view.W.z(r30)
            if (r3 == 0) goto L_0x004b
            r19 = 1
            goto L_0x004d
        L_0x004b:
            r19 = 0
        L_0x004d:
            java.util.List r2 = r7.f2035a
            int r6 = r2.size()
            r5 = r0
            r4 = r1
            r2 = 0
            r3 = 0
        L_0x0057:
            if (r3 >= r6) goto L_0x0171
            java.util.List r0 = r7.f2035a
            java.lang.Object r0 = r0.get(r3)
            r20 = r0
            android.view.View r20 = (android.view.View) r20
            int r0 = r20.getVisibility()
            r1 = 8
            if (r0 != r1) goto L_0x0073
            r22 = r3
            r29 = r6
            r28 = r8
            goto L_0x0169
        L_0x0073:
            android.view.ViewGroup$LayoutParams r0 = r20.getLayoutParams()
            r1 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r1 = (androidx.coordinatorlayout.widget.CoordinatorLayout.e) r1
            int r0 = r1.f2061e
            if (r0 < 0) goto L_0x00bc
            if (r13 == 0) goto L_0x00bc
            int r0 = r7.u(r0)
            int r11 = r1.f2059c
            int r11 = R(r11)
            int r11 = androidx.core.view.C0156s.b(r11, r10)
            r11 = r11 & 7
            r22 = r2
            r2 = 3
            if (r11 != r2) goto L_0x0097
            if (r12 == 0) goto L_0x009c
        L_0x0097:
            r2 = 5
            if (r11 != r2) goto L_0x00a8
            if (r12 == 0) goto L_0x00a8
        L_0x009c:
            int r2 = r14 - r9
            int r2 = r2 - r0
            r0 = 0
            int r2 = java.lang.Math.max(r0, r2)
            r21 = r2
            r11 = 0
            goto L_0x00c1
        L_0x00a8:
            if (r11 != r2) goto L_0x00ac
            if (r12 == 0) goto L_0x00b1
        L_0x00ac:
            r2 = 3
            if (r11 != r2) goto L_0x00ba
            if (r12 == 0) goto L_0x00ba
        L_0x00b1:
            int r0 = r0 - r8
            r11 = 0
            int r0 = java.lang.Math.max(r11, r0)
            r21 = r0
            goto L_0x00c1
        L_0x00ba:
            r11 = 0
            goto L_0x00bf
        L_0x00bc:
            r22 = r2
            goto L_0x00ba
        L_0x00bf:
            r21 = 0
        L_0x00c1:
            if (r19 == 0) goto L_0x00f3
            boolean r0 = androidx.core.view.W.z(r20)
            if (r0 != 0) goto L_0x00f3
            androidx.core.view.w0 r0 = r7.f2049o
            int r0 = r0.j()
            androidx.core.view.w0 r2 = r7.f2049o
            int r2 = r2.k()
            int r0 = r0 + r2
            androidx.core.view.w0 r2 = r7.f2049o
            int r2 = r2.l()
            androidx.core.view.w0 r11 = r7.f2049o
            int r11 = r11.i()
            int r2 = r2 + r11
            int r0 = r14 - r0
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r13)
            int r2 = r16 - r2
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r15)
            r11 = r0
            r23 = r2
            goto L_0x00f7
        L_0x00f3:
            r11 = r31
            r23 = r32
        L_0x00f7:
            androidx.coordinatorlayout.widget.CoordinatorLayout$b r0 = r1.e()
            if (r0 == 0) goto L_0x011f
            r24 = 0
            r2 = r1
            r1 = r30
            r26 = r2
            r25 = r22
            r2 = r20
            r22 = r3
            r3 = r11
            r27 = r4
            r4 = r21
            r28 = r8
            r8 = r5
            r5 = r23
            r29 = r6
            r6 = r24
            boolean r0 = r0.q(r1, r2, r3, r4, r5, r6)
            if (r0 != 0) goto L_0x0139
            goto L_0x012c
        L_0x011f:
            r26 = r1
            r27 = r4
            r29 = r6
            r28 = r8
            r25 = r22
            r22 = r3
            r8 = r5
        L_0x012c:
            r5 = 0
            r0 = r30
            r1 = r20
            r2 = r11
            r3 = r21
            r4 = r23
            r0.H(r1, r2, r3, r4, r5)
        L_0x0139:
            int r0 = r20.getMeasuredWidth()
            int r0 = r17 + r0
            r1 = r26
            int r2 = r1.leftMargin
            int r0 = r0 + r2
            int r2 = r1.rightMargin
            int r0 = r0 + r2
            int r0 = java.lang.Math.max(r8, r0)
            int r2 = r20.getMeasuredHeight()
            int r2 = r18 + r2
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r1 = r1.bottomMargin
            int r2 = r2 + r1
            r1 = r27
            int r1 = java.lang.Math.max(r1, r2)
            int r2 = r20.getMeasuredState()
            r11 = r25
            int r2 = android.view.View.combineMeasuredStates(r11, r2)
            r5 = r0
            r4 = r1
        L_0x0169:
            int r3 = r22 + 1
            r8 = r28
            r6 = r29
            goto L_0x0057
        L_0x0171:
            r11 = r2
            r1 = r4
            r8 = r5
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r11
            r2 = r31
            int r0 = android.view.View.resolveSizeAndState(r8, r2, r0)
            int r2 = r11 << 16
            r3 = r32
            int r1 = android.view.View.resolveSizeAndState(r1, r3, r2)
            r7.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        b e2;
        int childCount = getChildCount();
        boolean z3 = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.i(0) && (e2 = eVar.e()) != null) {
                    z3 |= e2.r(this, childAt, view, f2, f3, z2);
                }
            }
        }
        if (z3) {
            F(1);
        }
        return z3;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        b e2;
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.i(0) && (e2 = eVar.e()) != null) {
                    z2 |= e2.s(this, childAt, view, f2, f3);
                }
            }
        }
        return z2;
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        j(view, i2, i3, iArr, 0);
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        n(view, i2, i3, i4, i5, 0);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        h(view, view2, i2, 0);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.c());
        SparseArray sparseArray = gVar.f2076c;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            int id = childAt.getId();
            b e2 = w(childAt).e();
            if (!(id == -1 || e2 == null || (parcelable2 = (Parcelable) sparseArray.get(id)) == null)) {
                e2.B(this, childAt, parcelable2);
            }
        }
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        Parcelable C2;
        g gVar = new g(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            int id = childAt.getId();
            b e2 = ((e) childAt.getLayoutParams()).e();
            if (!(id == -1 || e2 == null || (C2 = e2.C(this, childAt)) == null)) {
                sparseArray.append(id, C2);
            }
        }
        gVar.f2076c = sparseArray;
        return gVar;
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return o(view, view2, i2, 0);
    }

    public void onStopNestedScroll(View view) {
        i(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0018;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0031  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0037  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f2045k
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0017
            boolean r3 = r0.J(r1, r4)
            if (r3 == 0) goto L_0x0015
            goto L_0x0018
        L_0x0015:
            r6 = 0
            goto L_0x002c
        L_0x0017:
            r3 = 0
        L_0x0018:
            android.view.View r6 = r0.f2045k
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$e r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout.e) r6
            androidx.coordinatorlayout.widget.CoordinatorLayout$b r6 = r6.e()
            if (r6 == 0) goto L_0x0015
            android.view.View r7 = r0.f2045k
            boolean r6 = r6.H(r0, r7, r1)
        L_0x002c:
            android.view.View r7 = r0.f2045k
            r8 = 0
            if (r7 != 0) goto L_0x0037
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x004a
        L_0x0037:
            if (r3 == 0) goto L_0x004a
            long r11 = android.os.SystemClock.uptimeMillis()
            r15 = 0
            r16 = 0
            r13 = 3
            r14 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x004a:
            if (r8 == 0) goto L_0x004f
            r8.recycle()
        L_0x004f:
            if (r2 == r4) goto L_0x0054
            r1 = 3
            if (r2 != r1) goto L_0x0057
        L_0x0054:
            r0.O(r5)
        L_0x0057:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    public void p(View view, boolean z2, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z2) {
            r(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public List q(View view) {
        List g2 = this.f2036b.g(view);
        this.f2038d.clear();
        if (g2 != null) {
            this.f2038d.addAll(g2);
        }
        return this.f2038d;
    }

    /* access modifiers changed from: package-private */
    public void r(View view, Rect rect) {
        c.a(this, view, rect);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        b e2 = ((e) view.getLayoutParams()).e();
        if (e2 == null || !e2.A(this, view, rect, z2)) {
            return super.requestChildRectangleOnScreen(view, rect, z2);
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        super.requestDisallowInterceptTouchEvent(z2);
        if (z2 && !this.f2042h) {
            O(false);
            this.f2042h = true;
        }
    }

    /* access modifiers changed from: package-private */
    public void s(View view, int i2, Rect rect, Rect rect2) {
        e eVar = (e) view.getLayoutParams();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        t(view, i2, rect, rect2, eVar, measuredWidth, measuredHeight);
        d(eVar, rect2, measuredWidth, measuredHeight);
    }

    public void setFitsSystemWindows(boolean z2) {
        super.setFitsSystemWindows(z2);
        V();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f2052r = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f2051q;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f2051q = drawable3;
            if (drawable3 != null) {
                if (drawable3.isStateful()) {
                    this.f2051q.setState(getDrawableState());
                }
                androidx.core.graphics.drawable.a.m(this.f2051q, W.C(this));
                this.f2051q.setVisible(getVisibility() == 0, false);
                this.f2051q.setCallback(this);
            }
            W.h0(this);
        }
    }

    public void setStatusBarBackgroundColor(int i2) {
        setStatusBarBackground(new ColorDrawable(i2));
    }

    public void setStatusBarBackgroundResource(int i2) {
        setStatusBarBackground(i2 != 0 ? androidx.core.content.a.c(getContext(), i2) : null);
    }

    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z2 = i2 == 0;
        Drawable drawable = this.f2051q;
        if (drawable != null && drawable.isVisible() != z2) {
            this.f2051q.setVisible(z2, false);
        }
    }

    /* access modifiers changed from: package-private */
    public void v(View view, Rect rect) {
        rect.set(((e) view.getLayoutParams()).g());
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2051q;
    }

    /* access modifiers changed from: package-private */
    public e w(View view) {
        e eVar = (e) view.getLayoutParams();
        if (!eVar.f2058b) {
            c cVar = null;
            for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                cVar = (c) cls.getAnnotation(c.class);
                if (cVar != null) {
                    break;
                }
            }
            if (cVar != null) {
                try {
                    eVar.n((b) cVar.value().getDeclaredConstructor((Class[]) null).newInstance((Object[]) null));
                } catch (Exception e2) {
                    Log.e("CoordinatorLayout", "Default behavior class " + cVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e2);
                }
            }
            eVar.f2058b = true;
        }
        return eVar;
    }

    public boolean z(View view, int i2, int i3) {
        Rect a2 = a();
        r(view, a2);
        try {
            return a2.contains(i2, i3);
        } finally {
            M(a2);
        }
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2035a = new ArrayList();
        this.f2036b = new b();
        this.f2037c = new ArrayList();
        this.f2038d = new ArrayList();
        this.f2040f = new int[2];
        this.f2041g = new int[2];
        this.f2054t = new E(this);
        int[] iArr = s.c.f6197b;
        TypedArray obtainStyledAttributes = i2 == 0 ? context.obtainStyledAttributes(attributeSet, iArr, 0, C0282b.Widget_Support_CoordinatorLayout) : context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            int[] iArr2 = s.c.f6197b;
            if (i2 == 0) {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, 0, C0282b.Widget_Support_CoordinatorLayout);
            } else {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, i2, 0);
            }
        }
        int resourceId = obtainStyledAttributes.getResourceId(s.c.f6198c, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f2044j = resources.getIntArray(resourceId);
            float f2 = resources.getDisplayMetrics().density;
            int length = this.f2044j.length;
            for (int i3 = 0; i3 < length; i3++) {
                int[] iArr3 = this.f2044j;
                iArr3[i3] = (int) (((float) iArr3[i3]) * f2);
            }
        }
        this.f2051q = obtainStyledAttributes.getDrawable(s.c.f6199d);
        obtainStyledAttributes.recycle();
        V();
        super.setOnHierarchyChangeListener(new d());
        if (W.A(this) == 0) {
            W.y0(this, 1);
        }
    }
}
