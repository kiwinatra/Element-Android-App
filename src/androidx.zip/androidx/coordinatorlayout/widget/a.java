package androidx.coordinatorlayout.widget;

public abstract /* synthetic */ class a {
}
