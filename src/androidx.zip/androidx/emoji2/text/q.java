package androidx.emoji2.text;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;

public final class q extends j {

    /* renamed from: g  reason: collision with root package name */
    private static Paint f2691g;

    /* renamed from: f  reason: collision with root package name */
    private TextPaint f2692f;

    public q(p pVar) {
        super(pVar);
    }

    private TextPaint c(CharSequence charSequence, int i2, int i3, Paint paint) {
        if (charSequence instanceof Spanned) {
            CharacterStyle[] characterStyleArr = (CharacterStyle[]) ((Spanned) charSequence).getSpans(i2, i3, CharacterStyle.class);
            if (characterStyleArr.length != 0) {
                if (!(characterStyleArr.length == 1 && characterStyleArr[0] == this)) {
                    TextPaint textPaint = this.f2692f;
                    if (textPaint == null) {
                        textPaint = new TextPaint();
                        this.f2692f = textPaint;
                    }
                    textPaint.set(paint);
                    for (CharacterStyle updateDrawState : characterStyleArr) {
                        updateDrawState.updateDrawState(textPaint);
                    }
                    return textPaint;
                }
            }
            if (paint instanceof TextPaint) {
                return (TextPaint) paint;
            }
            return null;
        } else if (paint instanceof TextPaint) {
            return (TextPaint) paint;
        } else {
            return null;
        }
    }

    private static Paint e() {
        if (f2691g == null) {
            TextPaint textPaint = new TextPaint();
            f2691g = textPaint;
            textPaint.setColor(f.c().d());
            f2691g.setStyle(Paint.Style.FILL);
        }
        return f2691g;
    }

    /* access modifiers changed from: package-private */
    public void d(Canvas canvas, TextPaint textPaint, float f2, float f3, float f4, float f5) {
        int color = textPaint.getColor();
        Paint.Style style = textPaint.getStyle();
        textPaint.setColor(textPaint.bgColor);
        textPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(f2, f4, f3, f5, textPaint);
        textPaint.setStyle(style);
        textPaint.setColor(color);
    }

    public void draw(Canvas canvas, CharSequence charSequence, int i2, int i3, float f2, int i4, int i5, int i6, Paint paint) {
        float f3 = f2;
        int i7 = i4;
        int i8 = i6;
        CharSequence charSequence2 = charSequence;
        TextPaint textPaint = paint;
        TextPaint c2 = c(charSequence, i2, i3, textPaint);
        if (!(c2 == null || c2.bgColor == 0)) {
            d(canvas, c2, f2, f3 + ((float) b()), (float) i7, (float) i8);
        }
        if (f.c().j()) {
            canvas.drawRect(f2, (float) i7, f3 + ((float) b()), (float) i8, e());
        }
        p a2 = a();
        float f4 = (float) i5;
        Canvas canvas2 = canvas;
        if (c2 != null) {
            textPaint = c2;
        }
        a2.a(canvas, f3, f4, textPaint);
    }
}
