package androidx.emoji2.text;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

abstract class m {

    private static class a implements c {

        /* renamed from: a  reason: collision with root package name */
        private final ByteBuffer f2674a;

        a(ByteBuffer byteBuffer) {
            this.f2674a = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        public long a() {
            return m.c(this.f2674a.getInt());
        }

        public void b(int i2) {
            ByteBuffer byteBuffer = this.f2674a;
            byteBuffer.position(byteBuffer.position() + i2);
        }

        public int c() {
            return m.d(this.f2674a.getShort());
        }

        public int d() {
            return this.f2674a.getInt();
        }

        public long e() {
            return (long) this.f2674a.position();
        }
    }

    private static class b {

        /* renamed from: a  reason: collision with root package name */
        private final long f2675a;

        /* renamed from: b  reason: collision with root package name */
        private final long f2676b;

        b(long j2, long j3) {
            this.f2675a = j2;
            this.f2676b = j3;
        }

        /* access modifiers changed from: package-private */
        public long a() {
            return this.f2675a;
        }
    }

    private interface c {
        long a();

        void b(int i2);

        int c();

        int d();

        long e();
    }

    private static b a(c cVar) {
        long j2;
        cVar.b(4);
        int c2 = cVar.c();
        if (c2 <= 100) {
            cVar.b(6);
            int i2 = 0;
            while (true) {
                if (i2 >= c2) {
                    j2 = -1;
                    break;
                }
                int d2 = cVar.d();
                cVar.b(4);
                j2 = cVar.a();
                cVar.b(4);
                if (1835365473 == d2) {
                    break;
                }
                i2++;
            }
            if (j2 != -1) {
                cVar.b((int) (j2 - cVar.e()));
                cVar.b(12);
                long a2 = cVar.a();
                for (int i3 = 0; ((long) i3) < a2; i3++) {
                    int d3 = cVar.d();
                    long a3 = cVar.a();
                    long a4 = cVar.a();
                    if (1164798569 == d3 || 1701669481 == d3) {
                        return new b(a3 + j2, a4);
                    }
                }
            }
            throw new IOException("Cannot read metadata.");
        }
        throw new IOException("Cannot read metadata.");
    }

    static G.b b(ByteBuffer byteBuffer) {
        ByteBuffer duplicate = byteBuffer.duplicate();
        duplicate.position((int) a(new a(duplicate)).a());
        return G.b.h(duplicate);
    }

    static long c(int i2) {
        return ((long) i2) & 4294967295L;
    }

    static int d(short s2) {
        return s2 & 65535;
    }
}
