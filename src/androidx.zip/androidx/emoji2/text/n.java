package androidx.emoji2.text;

import G.b;
import android.graphics.Typeface;
import android.util.SparseArray;
import androidx.core.os.l;
import java.nio.ByteBuffer;
import x.h;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    private final b f2677a;

    /* renamed from: b  reason: collision with root package name */
    private final char[] f2678b;

    /* renamed from: c  reason: collision with root package name */
    private final a f2679c = new a(1024);

    /* renamed from: d  reason: collision with root package name */
    private final Typeface f2680d;

    static class a {

        /* renamed from: a  reason: collision with root package name */
        private final SparseArray f2681a;

        /* renamed from: b  reason: collision with root package name */
        private p f2682b;

        private a() {
            this(1);
        }

        /* access modifiers changed from: package-private */
        public a a(int i2) {
            SparseArray sparseArray = this.f2681a;
            if (sparseArray == null) {
                return null;
            }
            return (a) sparseArray.get(i2);
        }

        /* access modifiers changed from: package-private */
        public final p b() {
            return this.f2682b;
        }

        /* access modifiers changed from: package-private */
        public void c(p pVar, int i2, int i3) {
            a a2 = a(pVar.b(i2));
            if (a2 == null) {
                a2 = new a();
                this.f2681a.put(pVar.b(i2), a2);
            }
            if (i3 > i2) {
                a2.c(pVar, i2 + 1, i3);
            } else {
                a2.f2682b = pVar;
            }
        }

        a(int i2) {
            this.f2681a = new SparseArray(i2);
        }
    }

    private n(Typeface typeface, b bVar) {
        this.f2680d = typeface;
        this.f2677a = bVar;
        this.f2678b = new char[(bVar.k() * 2)];
        a(bVar);
    }

    private void a(b bVar) {
        int k2 = bVar.k();
        for (int i2 = 0; i2 < k2; i2++) {
            p pVar = new p(this, i2);
            Character.toChars(pVar.f(), this.f2678b, i2 * 2);
            h(pVar);
        }
    }

    public static n b(Typeface typeface, ByteBuffer byteBuffer) {
        try {
            l.a("EmojiCompat.MetadataRepo.create");
            return new n(typeface, m.b(byteBuffer));
        } finally {
            l.b();
        }
    }

    public char[] c() {
        return this.f2678b;
    }

    public b d() {
        return this.f2677a;
    }

    /* access modifiers changed from: package-private */
    public int e() {
        return this.f2677a.l();
    }

    /* access modifiers changed from: package-private */
    public a f() {
        return this.f2679c;
    }

    /* access modifiers changed from: package-private */
    public Typeface g() {
        return this.f2680d;
    }

    /* access modifiers changed from: package-private */
    public void h(p pVar) {
        h.h(pVar, "emoji metadata cannot be null");
        h.b(pVar.c() > 0, "invalid metadata codepoint length");
        this.f2679c.c(pVar, 0, pVar.c() - 1);
    }
}
