package androidx.emoji2.text;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

class t implements Spannable {

    /* renamed from: a  reason: collision with root package name */
    private boolean f2693a = false;

    /* renamed from: b  reason: collision with root package name */
    private Spannable f2694b;

    private static class a {
        static IntStream a(CharSequence charSequence) {
            return charSequence.chars();
        }

        static IntStream b(CharSequence charSequence) {
            return charSequence.codePoints();
        }
    }

    static class b {
        b() {
        }

        /* access modifiers changed from: package-private */
        public boolean a(CharSequence charSequence) {
            return false;
        }
    }

    static class c extends b {
        c() {
        }

        /* access modifiers changed from: package-private */
        public boolean a(CharSequence charSequence) {
            return u.a(charSequence);
        }
    }

    t(Spannable spannable) {
        this.f2694b = spannable;
    }

    private void a() {
        Spannable spannable = this.f2694b;
        if (!this.f2693a && c().a(spannable)) {
            this.f2694b = new SpannableString(spannable);
        }
        this.f2693a = true;
    }

    static b c() {
        return Build.VERSION.SDK_INT < 28 ? new b() : new c();
    }

    /* access modifiers changed from: package-private */
    public Spannable b() {
        return this.f2694b;
    }

    public char charAt(int i2) {
        return this.f2694b.charAt(i2);
    }

    public IntStream chars() {
        return a.a(this.f2694b);
    }

    public IntStream codePoints() {
        return a.b(this.f2694b);
    }

    public int getSpanEnd(Object obj) {
        return this.f2694b.getSpanEnd(obj);
    }

    public int getSpanFlags(Object obj) {
        return this.f2694b.getSpanFlags(obj);
    }

    public int getSpanStart(Object obj) {
        return this.f2694b.getSpanStart(obj);
    }

    public Object[] getSpans(int i2, int i3, Class cls) {
        return this.f2694b.getSpans(i2, i3, cls);
    }

    public int length() {
        return this.f2694b.length();
    }

    public int nextSpanTransition(int i2, int i3, Class cls) {
        return this.f2694b.nextSpanTransition(i2, i3, cls);
    }

    public void removeSpan(Object obj) {
        a();
        this.f2694b.removeSpan(obj);
    }

    public void setSpan(Object obj, int i2, int i3, int i4) {
        a();
        this.f2694b.setSpan(obj, i2, i3, i4);
    }

    public CharSequence subSequence(int i2, int i3) {
        return this.f2694b.subSequence(i2, i3);
    }

    public String toString() {
        return this.f2694b.toString();
    }

    t(CharSequence charSequence) {
        this.f2694b = new SpannableString(charSequence);
    }
}
