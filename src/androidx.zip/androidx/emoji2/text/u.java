package androidx.emoji2.text;

import android.text.PrecomputedText;

public abstract /* synthetic */ class u {
    public static /* bridge */ /* synthetic */ boolean a(Object obj) {
        return obj instanceof PrecomputedText;
    }
}
