package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class f {

    /* renamed from: o  reason: collision with root package name */
    private static final Object f2604o = new Object();

    /* renamed from: p  reason: collision with root package name */
    private static final Object f2605p = new Object();

    /* renamed from: q  reason: collision with root package name */
    private static volatile f f2606q;

    /* renamed from: a  reason: collision with root package name */
    private final ReadWriteLock f2607a = new ReentrantReadWriteLock();

    /* renamed from: b  reason: collision with root package name */
    private final Set f2608b;

    /* renamed from: c  reason: collision with root package name */
    private volatile int f2609c = 3;

    /* renamed from: d  reason: collision with root package name */
    private final Handler f2610d;

    /* renamed from: e  reason: collision with root package name */
    private final b f2611e;

    /* renamed from: f  reason: collision with root package name */
    final h f2612f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public final j f2613g;

    /* renamed from: h  reason: collision with root package name */
    final boolean f2614h;

    /* renamed from: i  reason: collision with root package name */
    final boolean f2615i;

    /* renamed from: j  reason: collision with root package name */
    final int[] f2616j;

    /* renamed from: k  reason: collision with root package name */
    private final boolean f2617k;

    /* renamed from: l  reason: collision with root package name */
    private final int f2618l;

    /* renamed from: m  reason: collision with root package name */
    private final int f2619m;
    /* access modifiers changed from: private */

    /* renamed from: n  reason: collision with root package name */
    public final e f2620n;

    private static final class a extends b {

        /* renamed from: b  reason: collision with root package name */
        private volatile i f2621b;

        /* renamed from: c  reason: collision with root package name */
        private volatile n f2622c;

        /* renamed from: androidx.emoji2.text.f$a$a  reason: collision with other inner class name */
        class C0041a extends i {
            C0041a() {
            }

            public void a(Throwable th) {
                a.this.f2624a.n(th);
            }

            public void b(n nVar) {
                a.this.d(nVar);
            }
        }

        a(f fVar) {
            super(fVar);
        }

        /* access modifiers changed from: package-private */
        public void a() {
            try {
                this.f2624a.f2612f.a(new C0041a());
            } catch (Throwable th) {
                this.f2624a.n(th);
            }
        }

        /* access modifiers changed from: package-private */
        public CharSequence b(CharSequence charSequence, int i2, int i3, int i4, boolean z2) {
            return this.f2621b.h(charSequence, i2, i3, i4, z2);
        }

        /* access modifiers changed from: package-private */
        public void c(EditorInfo editorInfo) {
            editorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.f2622c.e());
            editorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", this.f2624a.f2614h);
        }

        /* access modifiers changed from: package-private */
        public void d(n nVar) {
            if (nVar == null) {
                this.f2624a.n(new IllegalArgumentException("metadataRepo cannot be null"));
                return;
            }
            this.f2622c = nVar;
            n nVar2 = this.f2622c;
            j a2 = this.f2624a.f2613g;
            e b2 = this.f2624a.f2620n;
            f fVar = this.f2624a;
            this.f2621b = new i(nVar2, a2, b2, fVar.f2615i, fVar.f2616j, h.a());
            this.f2624a.o();
        }
    }

    private static class b {

        /* renamed from: a  reason: collision with root package name */
        final f f2624a;

        b(f fVar) {
            this.f2624a = fVar;
        }

        /* access modifiers changed from: package-private */
        public abstract void a();

        /* access modifiers changed from: package-private */
        public abstract CharSequence b(CharSequence charSequence, int i2, int i3, int i4, boolean z2);

        /* access modifiers changed from: package-private */
        public abstract void c(EditorInfo editorInfo);
    }

    public static abstract class c {

        /* renamed from: a  reason: collision with root package name */
        final h f2625a;

        /* renamed from: b  reason: collision with root package name */
        j f2626b;

        /* renamed from: c  reason: collision with root package name */
        boolean f2627c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2628d;

        /* renamed from: e  reason: collision with root package name */
        int[] f2629e;

        /* renamed from: f  reason: collision with root package name */
        Set f2630f;

        /* renamed from: g  reason: collision with root package name */
        boolean f2631g;

        /* renamed from: h  reason: collision with root package name */
        int f2632h = -16711936;

        /* renamed from: i  reason: collision with root package name */
        int f2633i = 0;

        /* renamed from: j  reason: collision with root package name */
        e f2634j = new e();

        protected c(h hVar) {
            x.h.h(hVar, "metadataLoader cannot be null.");
            this.f2625a = hVar;
        }

        /* access modifiers changed from: protected */
        public final h a() {
            return this.f2625a;
        }

        public c b(int i2) {
            this.f2633i = i2;
            return this;
        }
    }

    public static class d implements j {
        public j a(p pVar) {
            return new q(pVar);
        }
    }

    public interface e {
        boolean a(CharSequence charSequence, int i2, int i3, int i4);
    }

    /* renamed from: androidx.emoji2.text.f$f  reason: collision with other inner class name */
    public static abstract class C0042f {
        public void a(Throwable th) {
        }

        public void b() {
        }
    }

    private static class g implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final List f2635a;

        /* renamed from: b  reason: collision with root package name */
        private final Throwable f2636b;

        /* renamed from: c  reason: collision with root package name */
        private final int f2637c;

        g(C0042f fVar, int i2) {
            this(Arrays.asList(new C0042f[]{(C0042f) x.h.h(fVar, "initCallback cannot be null")}), i2, (Throwable) null);
        }

        public void run() {
            int size = this.f2635a.size();
            int i2 = 0;
            if (this.f2637c != 1) {
                while (i2 < size) {
                    ((C0042f) this.f2635a.get(i2)).a(this.f2636b);
                    i2++;
                }
                return;
            }
            while (i2 < size) {
                ((C0042f) this.f2635a.get(i2)).b();
                i2++;
            }
        }

        g(Collection collection, int i2) {
            this(collection, i2, (Throwable) null);
        }

        g(Collection collection, int i2, Throwable th) {
            x.h.h(collection, "initCallbacks cannot be null");
            this.f2635a = new ArrayList(collection);
            this.f2637c = i2;
            this.f2636b = th;
        }
    }

    public interface h {
        void a(i iVar);
    }

    public static abstract class i {
        public abstract void a(Throwable th);

        public abstract void b(n nVar);
    }

    public interface j {
        j a(p pVar);
    }

    private f(c cVar) {
        this.f2614h = cVar.f2627c;
        this.f2615i = cVar.f2628d;
        this.f2616j = cVar.f2629e;
        this.f2617k = cVar.f2631g;
        this.f2618l = cVar.f2632h;
        this.f2612f = cVar.f2625a;
        this.f2619m = cVar.f2633i;
        this.f2620n = cVar.f2634j;
        this.f2610d = new Handler(Looper.getMainLooper());
        l.b bVar = new l.b();
        this.f2608b = bVar;
        j jVar = cVar.f2626b;
        this.f2613g = jVar == null ? new d() : jVar;
        Set set = cVar.f2630f;
        if (set != null && !set.isEmpty()) {
            bVar.addAll(cVar.f2630f);
        }
        this.f2611e = new a(this);
        m();
    }

    public static f c() {
        f fVar;
        synchronized (f2604o) {
            fVar = f2606q;
            x.h.i(fVar != null, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        }
        return fVar;
    }

    public static boolean f(InputConnection inputConnection, Editable editable, int i2, int i3, boolean z2) {
        return i.b(inputConnection, editable, i2, i3, z2);
    }

    public static boolean g(Editable editable, int i2, KeyEvent keyEvent) {
        return i.c(editable, i2, keyEvent);
    }

    public static f h(c cVar) {
        f fVar = f2606q;
        if (fVar == null) {
            synchronized (f2604o) {
                try {
                    fVar = f2606q;
                    if (fVar == null) {
                        fVar = new f(cVar);
                        f2606q = fVar;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return fVar;
    }

    public static boolean i() {
        return f2606q != null;
    }

    private boolean k() {
        return e() == 1;
    }

    /* JADX INFO: finally extract failed */
    private void m() {
        this.f2607a.writeLock().lock();
        try {
            if (this.f2619m == 0) {
                this.f2609c = 0;
            }
            this.f2607a.writeLock().unlock();
            if (e() == 0) {
                this.f2611e.a();
            }
        } catch (Throwable th) {
            this.f2607a.writeLock().unlock();
            throw th;
        }
    }

    public int d() {
        return this.f2618l;
    }

    public int e() {
        this.f2607a.readLock().lock();
        try {
            return this.f2609c;
        } finally {
            this.f2607a.readLock().unlock();
        }
    }

    public boolean j() {
        return this.f2617k;
    }

    public void l() {
        boolean z2 = true;
        if (this.f2619m != 1) {
            z2 = false;
        }
        x.h.i(z2, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        if (!k()) {
            this.f2607a.writeLock().lock();
            try {
                if (this.f2609c != 0) {
                    this.f2609c = 0;
                    this.f2607a.writeLock().unlock();
                    this.f2611e.a();
                }
            } finally {
                this.f2607a.writeLock().unlock();
            }
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void n(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f2607a.writeLock().lock();
        try {
            this.f2609c = 2;
            arrayList.addAll(this.f2608b);
            this.f2608b.clear();
            this.f2607a.writeLock().unlock();
            this.f2610d.post(new g(arrayList, this.f2609c, th));
        } catch (Throwable th2) {
            this.f2607a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void o() {
        ArrayList arrayList = new ArrayList();
        this.f2607a.writeLock().lock();
        try {
            this.f2609c = 1;
            arrayList.addAll(this.f2608b);
            this.f2608b.clear();
            this.f2607a.writeLock().unlock();
            this.f2610d.post(new g((Collection) arrayList, this.f2609c));
        } catch (Throwable th) {
            this.f2607a.writeLock().unlock();
            throw th;
        }
    }

    public CharSequence p(CharSequence charSequence) {
        return q(charSequence, 0, charSequence == null ? 0 : charSequence.length());
    }

    public CharSequence q(CharSequence charSequence, int i2, int i3) {
        return r(charSequence, i2, i3, Integer.MAX_VALUE);
    }

    public CharSequence r(CharSequence charSequence, int i2, int i3, int i4) {
        return s(charSequence, i2, i3, i4, 0);
    }

    public CharSequence s(CharSequence charSequence, int i2, int i3, int i4, int i5) {
        x.h.i(k(), "Not initialized yet");
        x.h.e(i2, "start cannot be negative");
        x.h.e(i3, "end cannot be negative");
        x.h.e(i4, "maxEmojiCount cannot be negative");
        x.h.b(i2 <= i3, "start should be <= than end");
        if (charSequence == null) {
            return null;
        }
        x.h.b(i2 <= charSequence.length(), "start should be < than charSequence length");
        x.h.b(i3 <= charSequence.length(), "end should be < than charSequence length");
        if (charSequence.length() == 0 || i2 == i3) {
            return charSequence;
        }
        return this.f2611e.b(charSequence, i2, i3, i4, i5 != 1 ? i5 != 2 ? this.f2614h : false : true);
    }

    public void t(C0042f fVar) {
        x.h.h(fVar, "initCallback cannot be null");
        this.f2607a.writeLock().lock();
        try {
            if (this.f2609c != 1) {
                if (this.f2609c != 2) {
                    this.f2608b.add(fVar);
                }
            }
            this.f2610d.post(new g(fVar, this.f2609c));
        } finally {
            this.f2607a.writeLock().unlock();
        }
    }

    public void u(C0042f fVar) {
        x.h.h(fVar, "initCallback cannot be null");
        this.f2607a.writeLock().lock();
        try {
            this.f2608b.remove(fVar);
        } finally {
            this.f2607a.writeLock().unlock();
        }
    }

    public void v(EditorInfo editorInfo) {
        if (k() && editorInfo != null) {
            if (editorInfo.extras == null) {
                editorInfo.extras = new Bundle();
            }
            this.f2611e.c(editorInfo);
        }
    }
}
