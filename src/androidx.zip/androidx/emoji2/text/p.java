package androidx.emoji2.text;

import G.a;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

public class p {

    /* renamed from: d  reason: collision with root package name */
    private static final ThreadLocal f2687d = new ThreadLocal();

    /* renamed from: a  reason: collision with root package name */
    private final int f2688a;

    /* renamed from: b  reason: collision with root package name */
    private final n f2689b;

    /* renamed from: c  reason: collision with root package name */
    private volatile int f2690c = 0;

    p(n nVar, int i2) {
        this.f2689b = nVar;
        this.f2688a = i2;
    }

    private a g() {
        ThreadLocal threadLocal = f2687d;
        a aVar = (a) threadLocal.get();
        if (aVar == null) {
            aVar = new a();
            threadLocal.set(aVar);
        }
        this.f2689b.d().j(aVar, this.f2688a);
        return aVar;
    }

    public void a(Canvas canvas, float f2, float f3, Paint paint) {
        Typeface g2 = this.f2689b.g();
        Typeface typeface = paint.getTypeface();
        paint.setTypeface(g2);
        Canvas canvas2 = canvas;
        canvas2.drawText(this.f2689b.c(), this.f2688a * 2, 2, f2, f3, paint);
        paint.setTypeface(typeface);
    }

    public int b(int i2) {
        return g().h(i2);
    }

    public int c() {
        return g().i();
    }

    public int d() {
        return this.f2690c & 3;
    }

    public int e() {
        return g().k();
    }

    public int f() {
        return g().l();
    }

    public short h() {
        return g().m();
    }

    public int i() {
        return g().n();
    }

    public boolean j() {
        return g().j();
    }

    public boolean k() {
        return (this.f2690c & 4) > 0;
    }

    public void l(boolean z2) {
        int d2 = d();
        if (z2) {
            this.f2690c = d2 | 4;
        } else {
            this.f2690c = d2;
        }
    }

    public void m(boolean z2) {
        int i2 = this.f2690c & 4;
        this.f2690c = z2 ? i2 | 2 : i2 | 1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        sb.append(Integer.toHexString(f()));
        sb.append(", codepoints:");
        int c2 = c();
        for (int i2 = 0; i2 < c2; i2++) {
            sb.append(Integer.toHexString(b(i2)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
