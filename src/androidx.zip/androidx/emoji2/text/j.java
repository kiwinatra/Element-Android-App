package androidx.emoji2.text;

import android.graphics.Paint;
import android.text.style.ReplacementSpan;
import x.h;

public abstract class j extends ReplacementSpan {

    /* renamed from: a  reason: collision with root package name */
    private final Paint.FontMetricsInt f2657a = new Paint.FontMetricsInt();

    /* renamed from: b  reason: collision with root package name */
    private final p f2658b;

    /* renamed from: c  reason: collision with root package name */
    private short f2659c = -1;

    /* renamed from: d  reason: collision with root package name */
    private short f2660d = -1;

    /* renamed from: e  reason: collision with root package name */
    private float f2661e = 1.0f;

    j(p pVar) {
        h.h(pVar, "rasterizer cannot be null");
        this.f2658b = pVar;
    }

    public final p a() {
        return this.f2658b;
    }

    /* access modifiers changed from: package-private */
    public final int b() {
        return this.f2659c;
    }

    public int getSize(Paint paint, CharSequence charSequence, int i2, int i3, Paint.FontMetricsInt fontMetricsInt) {
        paint.getFontMetricsInt(this.f2657a);
        Paint.FontMetricsInt fontMetricsInt2 = this.f2657a;
        this.f2661e = (((float) Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent)) * 1.0f) / ((float) this.f2658b.e());
        this.f2660d = (short) ((int) (((float) this.f2658b.e()) * this.f2661e));
        short i4 = (short) ((int) (((float) this.f2658b.i()) * this.f2661e));
        this.f2659c = i4;
        if (fontMetricsInt != null) {
            Paint.FontMetricsInt fontMetricsInt3 = this.f2657a;
            fontMetricsInt.ascent = fontMetricsInt3.ascent;
            fontMetricsInt.descent = fontMetricsInt3.descent;
            fontMetricsInt.top = fontMetricsInt3.top;
            fontMetricsInt.bottom = fontMetricsInt3.bottom;
        }
        return i4;
    }
}
