package androidx.emoji2.text;

import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import x.h;

public final class o extends SpannableStringBuilder {

    /* renamed from: a  reason: collision with root package name */
    private final Class f2683a;

    /* renamed from: b  reason: collision with root package name */
    private final List f2684b = new ArrayList();

    private static class a implements TextWatcher, SpanWatcher {

        /* renamed from: a  reason: collision with root package name */
        final Object f2685a;

        /* renamed from: b  reason: collision with root package name */
        private final AtomicInteger f2686b = new AtomicInteger(0);

        a(Object obj) {
            this.f2685a = obj;
        }

        private boolean b(Object obj) {
            return obj instanceof j;
        }

        /* access modifiers changed from: package-private */
        public final void a() {
            this.f2686b.incrementAndGet();
        }

        public void afterTextChanged(Editable editable) {
            ((TextWatcher) this.f2685a).afterTextChanged(editable);
        }

        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            ((TextWatcher) this.f2685a).beforeTextChanged(charSequence, i2, i3, i4);
        }

        /* access modifiers changed from: package-private */
        public final void c() {
            this.f2686b.decrementAndGet();
        }

        public void onSpanAdded(Spannable spannable, Object obj, int i2, int i3) {
            if (this.f2686b.get() <= 0 || !b(obj)) {
                ((SpanWatcher) this.f2685a).onSpanAdded(spannable, obj, i2, i3);
            }
        }

        public void onSpanChanged(Spannable spannable, Object obj, int i2, int i3, int i4, int i5) {
            int i6;
            int i7;
            if (this.f2686b.get() <= 0 || !b(obj)) {
                if (Build.VERSION.SDK_INT < 28) {
                    if (i2 > i3) {
                        i2 = 0;
                    }
                    if (i4 > i5) {
                        i7 = i2;
                        i6 = 0;
                        ((SpanWatcher) this.f2685a).onSpanChanged(spannable, obj, i7, i3, i6, i5);
                    }
                }
                i7 = i2;
                i6 = i4;
                ((SpanWatcher) this.f2685a).onSpanChanged(spannable, obj, i7, i3, i6, i5);
            }
        }

        public void onSpanRemoved(Spannable spannable, Object obj, int i2, int i3) {
            if (this.f2686b.get() <= 0 || !b(obj)) {
                ((SpanWatcher) this.f2685a).onSpanRemoved(spannable, obj, i2, i3);
            }
        }

        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            ((TextWatcher) this.f2685a).onTextChanged(charSequence, i2, i3, i4);
        }
    }

    o(Class cls, CharSequence charSequence) {
        super(charSequence);
        h.h(cls, "watcherClass cannot be null");
        this.f2683a = cls;
    }

    private void b() {
        for (int i2 = 0; i2 < this.f2684b.size(); i2++) {
            ((a) this.f2684b.get(i2)).a();
        }
    }

    public static o c(Class cls, CharSequence charSequence) {
        return new o(cls, charSequence);
    }

    private void e() {
        for (int i2 = 0; i2 < this.f2684b.size(); i2++) {
            ((a) this.f2684b.get(i2)).onTextChanged(this, 0, length(), length());
        }
    }

    private a f(Object obj) {
        for (int i2 = 0; i2 < this.f2684b.size(); i2++) {
            a aVar = (a) this.f2684b.get(i2);
            if (aVar.f2685a == obj) {
                return aVar;
            }
        }
        return null;
    }

    private boolean g(Class cls) {
        return this.f2683a == cls;
    }

    private boolean h(Object obj) {
        return obj != null && g(obj.getClass());
    }

    private void i() {
        for (int i2 = 0; i2 < this.f2684b.size(); i2++) {
            ((a) this.f2684b.get(i2)).c();
        }
    }

    public void a() {
        b();
    }

    public void d() {
        i();
        e();
    }

    public int getSpanEnd(Object obj) {
        a f2;
        if (h(obj) && (f2 = f(obj)) != null) {
            obj = f2;
        }
        return super.getSpanEnd(obj);
    }

    public int getSpanFlags(Object obj) {
        a f2;
        if (h(obj) && (f2 = f(obj)) != null) {
            obj = f2;
        }
        return super.getSpanFlags(obj);
    }

    public int getSpanStart(Object obj) {
        a f2;
        if (h(obj) && (f2 = f(obj)) != null) {
            obj = f2;
        }
        return super.getSpanStart(obj);
    }

    public Object[] getSpans(int i2, int i3, Class cls) {
        if (!g(cls)) {
            return super.getSpans(i2, i3, cls);
        }
        a[] aVarArr = (a[]) super.getSpans(i2, i3, a.class);
        Object[] objArr = (Object[]) Array.newInstance(cls, aVarArr.length);
        for (int i4 = 0; i4 < aVarArr.length; i4++) {
            objArr[i4] = aVarArr[i4].f2685a;
        }
        return objArr;
    }

    public int nextSpanTransition(int i2, int i3, Class<a> cls) {
        if (cls == null || g(cls)) {
            cls = a.class;
        }
        return super.nextSpanTransition(i2, i3, cls);
    }

    public void removeSpan(Object obj) {
        a aVar;
        if (h(obj)) {
            aVar = f(obj);
            if (aVar != null) {
                obj = aVar;
            }
        } else {
            aVar = null;
        }
        super.removeSpan(obj);
        if (aVar != null) {
            this.f2684b.remove(aVar);
        }
    }

    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (h(obj)) {
            a aVar = new a(obj);
            this.f2684b.add(aVar);
            obj = aVar;
        }
        super.setSpan(obj, i2, i3, i4);
    }

    public CharSequence subSequence(int i2, int i3) {
        return new o(this.f2683a, this, i2, i3);
    }

    o(Class cls, CharSequence charSequence, int i2, int i3) {
        super(charSequence, i2, i3);
        h.h(cls, "watcherClass cannot be null");
        this.f2683a = cls;
    }

    public SpannableStringBuilder delete(int i2, int i3) {
        super.delete(i2, i3);
        return this;
    }

    public SpannableStringBuilder insert(int i2, CharSequence charSequence) {
        super.insert(i2, charSequence);
        return this;
    }

    public SpannableStringBuilder replace(int i2, int i3, CharSequence charSequence) {
        b();
        super.replace(i2, i3, charSequence);
        i();
        return this;
    }

    public SpannableStringBuilder append(char c2) {
        super.append(c2);
        return this;
    }

    public SpannableStringBuilder insert(int i2, CharSequence charSequence, int i3, int i4) {
        super.insert(i2, charSequence, i3, i4);
        return this;
    }

    public SpannableStringBuilder replace(int i2, int i3, CharSequence charSequence, int i4, int i5) {
        b();
        super.replace(i2, i3, charSequence, i4, i5);
        i();
        return this;
    }

    public SpannableStringBuilder append(CharSequence charSequence) {
        super.append(charSequence);
        return this;
    }

    public SpannableStringBuilder append(CharSequence charSequence, int i2, int i3) {
        super.append(charSequence, i2, i3);
        return this;
    }

    public SpannableStringBuilder append(CharSequence charSequence, Object obj, int i2) {
        super.append(charSequence, obj, i2);
        return this;
    }
}
