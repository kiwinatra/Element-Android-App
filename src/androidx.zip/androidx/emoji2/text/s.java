package androidx.emoji2.text;

public abstract /* synthetic */ class s {
}
