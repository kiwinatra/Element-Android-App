package androidx.emoji2.text;

import androidx.emoji2.text.EmojiCompatInitializer;
import androidx.emoji2.text.f;
import java.util.concurrent.ThreadPoolExecutor;

public final /* synthetic */ class g implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ EmojiCompatInitializer.b f2638a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ f.i f2639b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f2640c;

    public /* synthetic */ g(EmojiCompatInitializer.b bVar, f.i iVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f2638a = bVar;
        this.f2639b = iVar;
        this.f2640c = threadPoolExecutor;
    }

    public final void run() {
        this.f2638a.d(this.f2639b, this.f2640c);
    }
}
