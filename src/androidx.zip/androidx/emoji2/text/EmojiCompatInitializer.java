package androidx.emoji2.text;

import android.content.Context;
import androidx.core.os.l;
import androidx.emoji2.text.f;
import androidx.lifecycle.C0185b;
import androidx.lifecycle.C0186c;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

public class EmojiCompatInitializer implements P.a {

    static class a extends f.c {
        protected a(Context context) {
            super(new b(context));
            b(1);
        }
    }

    static class b implements f.h {

        /* renamed from: a  reason: collision with root package name */
        private final Context f2596a;

        class a extends f.i {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ f.i f2597a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ ThreadPoolExecutor f2598b;

            a(f.i iVar, ThreadPoolExecutor threadPoolExecutor) {
                this.f2597a = iVar;
                this.f2598b = threadPoolExecutor;
            }

            public void a(Throwable th) {
                try {
                    this.f2597a.a(th);
                } finally {
                    this.f2598b.shutdown();
                }
            }

            public void b(n nVar) {
                try {
                    this.f2597a.b(nVar);
                } finally {
                    this.f2598b.shutdown();
                }
            }
        }

        b(Context context) {
            this.f2596a = context.getApplicationContext();
        }

        public void a(f.i iVar) {
            ThreadPoolExecutor b2 = c.b("EmojiCompatInitializer");
            b2.execute(new g(this, iVar, b2));
        }

        /* access modifiers changed from: package-private */
        /* renamed from: c */
        public void d(f.i iVar, ThreadPoolExecutor threadPoolExecutor) {
            try {
                k a2 = d.a(this.f2596a);
                if (a2 != null) {
                    a2.c(threadPoolExecutor);
                    a2.a().a(new a(iVar, threadPoolExecutor));
                    return;
                }
                throw new RuntimeException("EmojiCompat font provider not available on this device.");
            } catch (Throwable th) {
                iVar.a(th);
                threadPoolExecutor.shutdown();
            }
        }
    }

    static class c implements Runnable {
        c() {
        }

        public void run() {
            try {
                l.a("EmojiCompat.EmojiCompatInitializer.run");
                if (f.i()) {
                    f.c().l();
                }
            } finally {
                l.b();
            }
        }
    }

    public List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    /* renamed from: c */
    public Boolean b(Context context) {
        f.h(new a(context));
        d(context);
        return Boolean.TRUE;
    }

    /* access modifiers changed from: package-private */
    public void d(Context context) {
        final C0190g v2 = ((androidx.lifecycle.l) androidx.startup.a.e(context).f(ProcessLifecycleInitializer.class)).v();
        v2.a(new C0186c() {
            public void a(androidx.lifecycle.l lVar) {
                EmojiCompatInitializer.this.e();
                v2.c(this);
            }

            public /* synthetic */ void b(androidx.lifecycle.l lVar) {
                C0185b.b(this, lVar);
            }

            public /* synthetic */ void c(androidx.lifecycle.l lVar) {
                C0185b.a(this, lVar);
            }

            public /* synthetic */ void e(androidx.lifecycle.l lVar) {
                C0185b.c(this, lVar);
            }

            public /* synthetic */ void f(androidx.lifecycle.l lVar) {
                C0185b.e(this, lVar);
            }

            public /* synthetic */ void g(androidx.lifecycle.l lVar) {
                C0185b.d(this, lVar);
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void e() {
        c.d().postDelayed(new c(), 500);
    }
}
