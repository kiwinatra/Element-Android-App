package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import androidx.emoji2.text.f;
import androidx.emoji2.text.n;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;

final class i {

    /* renamed from: a  reason: collision with root package name */
    private final f.j f2641a;

    /* renamed from: b  reason: collision with root package name */
    private final n f2642b;

    /* renamed from: c  reason: collision with root package name */
    private f.e f2643c;

    /* renamed from: d  reason: collision with root package name */
    private final boolean f2644d;

    /* renamed from: e  reason: collision with root package name */
    private final int[] f2645e;

    private static final class a {
        static int a(CharSequence charSequence, int i2, int i3) {
            int length = charSequence.length();
            if (i2 < 0 || length < i2 || i3 < 0) {
                return -1;
            }
            while (true) {
                boolean z2 = false;
                while (i3 != 0) {
                    i2--;
                    if (i2 < 0) {
                        return z2 ? -1 : 0;
                    }
                    char charAt = charSequence.charAt(i2);
                    if (z2) {
                        if (!Character.isHighSurrogate(charAt)) {
                            return -1;
                        }
                        i3--;
                    } else if (!Character.isSurrogate(charAt)) {
                        i3--;
                    } else if (Character.isHighSurrogate(charAt)) {
                        return -1;
                    } else {
                        z2 = true;
                    }
                }
                return i2;
            }
        }

        static int b(CharSequence charSequence, int i2, int i3) {
            int length = charSequence.length();
            if (i2 < 0 || length < i2 || i3 < 0) {
                return -1;
            }
            while (true) {
                boolean z2 = false;
                while (i3 != 0) {
                    if (r7 < length) {
                        char charAt = charSequence.charAt(r7);
                        if (z2) {
                            if (!Character.isLowSurrogate(charAt)) {
                                return -1;
                            }
                            i3--;
                            i2 = r7 + 1;
                        } else if (!Character.isSurrogate(charAt)) {
                            i3--;
                            r7++;
                        } else if (Character.isLowSurrogate(charAt)) {
                            return -1;
                        } else {
                            r7++;
                            z2 = true;
                        }
                    } else if (z2) {
                        return -1;
                    } else {
                        return length;
                    }
                }
                return r7;
            }
        }
    }

    private static class b implements c {

        /* renamed from: a  reason: collision with root package name */
        public t f2646a;

        /* renamed from: b  reason: collision with root package name */
        private final f.j f2647b;

        b(t tVar, f.j jVar) {
            this.f2646a = tVar;
            this.f2647b = jVar;
        }

        public boolean b(CharSequence charSequence, int i2, int i3, p pVar) {
            if (pVar.k()) {
                return true;
            }
            if (this.f2646a == null) {
                this.f2646a = new t(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
            }
            this.f2646a.setSpan(this.f2647b.a(pVar), i2, i3, 33);
            return true;
        }

        /* renamed from: c */
        public t a() {
            return this.f2646a;
        }
    }

    private interface c {
        Object a();

        boolean b(CharSequence charSequence, int i2, int i3, p pVar);
    }

    private static class d implements c {

        /* renamed from: a  reason: collision with root package name */
        private final String f2648a;

        d(String str) {
            this.f2648a = str;
        }

        public boolean b(CharSequence charSequence, int i2, int i3, p pVar) {
            if (!TextUtils.equals(charSequence.subSequence(i2, i3), this.f2648a)) {
                return true;
            }
            pVar.l(true);
            return false;
        }

        /* renamed from: c */
        public d a() {
            return this;
        }
    }

    static final class e {

        /* renamed from: a  reason: collision with root package name */
        private int f2649a = 1;

        /* renamed from: b  reason: collision with root package name */
        private final n.a f2650b;

        /* renamed from: c  reason: collision with root package name */
        private n.a f2651c;

        /* renamed from: d  reason: collision with root package name */
        private n.a f2652d;

        /* renamed from: e  reason: collision with root package name */
        private int f2653e;

        /* renamed from: f  reason: collision with root package name */
        private int f2654f;

        /* renamed from: g  reason: collision with root package name */
        private final boolean f2655g;

        /* renamed from: h  reason: collision with root package name */
        private final int[] f2656h;

        e(n.a aVar, boolean z2, int[] iArr) {
            this.f2650b = aVar;
            this.f2651c = aVar;
            this.f2655g = z2;
            this.f2656h = iArr;
        }

        private static boolean d(int i2) {
            return i2 == 65039;
        }

        private static boolean f(int i2) {
            return i2 == 65038;
        }

        private int g() {
            this.f2649a = 1;
            this.f2651c = this.f2650b;
            this.f2654f = 0;
            return 1;
        }

        private boolean h() {
            if (this.f2651c.b().j() || d(this.f2653e)) {
                return true;
            }
            if (this.f2655g) {
                if (this.f2656h == null) {
                    return true;
                }
                if (Arrays.binarySearch(this.f2656h, this.f2651c.b().b(0)) < 0) {
                    return true;
                }
            }
            return false;
        }

        /* access modifiers changed from: package-private */
        public int a(int i2) {
            n.a a2 = this.f2651c.a(i2);
            int i3 = 2;
            if (this.f2649a == 2) {
                if (a2 != null) {
                    this.f2651c = a2;
                    this.f2654f++;
                } else if (!f(i2)) {
                    if (!d(i2)) {
                        if (this.f2651c.b() != null) {
                            i3 = 3;
                            if (this.f2654f != 1 || h()) {
                                this.f2652d = this.f2651c;
                                g();
                            }
                        }
                    }
                }
                this.f2653e = i2;
                return i3;
            } else if (a2 != null) {
                this.f2649a = 2;
                this.f2651c = a2;
                this.f2654f = 1;
                this.f2653e = i2;
                return i3;
            }
            i3 = g();
            this.f2653e = i2;
            return i3;
        }

        /* access modifiers changed from: package-private */
        public p b() {
            return this.f2651c.b();
        }

        /* access modifiers changed from: package-private */
        public p c() {
            return this.f2652d.b();
        }

        /* access modifiers changed from: package-private */
        public boolean e() {
            return this.f2649a == 2 && this.f2651c.b() != null && (this.f2654f > 1 || h());
        }
    }

    i(n nVar, f.j jVar, f.e eVar, boolean z2, int[] iArr, Set set) {
        this.f2641a = jVar;
        this.f2642b = nVar;
        this.f2643c = eVar;
        this.f2644d = z2;
        this.f2645e = iArr;
        g(set);
    }

    private static boolean a(Editable editable, KeyEvent keyEvent, boolean z2) {
        j[] jVarArr;
        if (f(keyEvent)) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (!e(selectionStart, selectionEnd) && (jVarArr = (j[]) editable.getSpans(selectionStart, selectionEnd, j.class)) != null && jVarArr.length > 0) {
            int length = jVarArr.length;
            int i2 = 0;
            while (i2 < length) {
                j jVar = jVarArr[i2];
                int spanStart = editable.getSpanStart(jVar);
                int spanEnd = editable.getSpanEnd(jVar);
                if ((!z2 || spanStart != selectionStart) && ((z2 || spanEnd != selectionStart) && (selectionStart <= spanStart || selectionStart >= spanEnd))) {
                    i2++;
                } else {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    static boolean b(InputConnection inputConnection, Editable editable, int i2, int i3, boolean z2) {
        int i4;
        int i5;
        if (editable != null && inputConnection != null && i2 >= 0 && i3 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (e(selectionStart, selectionEnd)) {
                return false;
            }
            if (z2) {
                i5 = a.a(editable, selectionStart, Math.max(i2, 0));
                i4 = a.b(editable, selectionEnd, Math.max(i3, 0));
                if (i5 == -1 || i4 == -1) {
                    return false;
                }
            } else {
                i5 = Math.max(selectionStart - i2, 0);
                i4 = Math.min(selectionEnd + i3, editable.length());
            }
            j[] jVarArr = (j[]) editable.getSpans(i5, i4, j.class);
            if (jVarArr != null && jVarArr.length > 0) {
                for (j jVar : jVarArr) {
                    int spanStart = editable.getSpanStart(jVar);
                    int spanEnd = editable.getSpanEnd(jVar);
                    i5 = Math.min(spanStart, i5);
                    i4 = Math.max(spanEnd, i4);
                }
                int max = Math.max(i5, 0);
                int min = Math.min(i4, editable.length());
                inputConnection.beginBatchEdit();
                editable.delete(max, min);
                inputConnection.endBatchEdit();
                return true;
            }
        }
        return false;
    }

    static boolean c(Editable editable, int i2, KeyEvent keyEvent) {
        if (!(i2 != 67 ? i2 != 112 ? false : a(editable, keyEvent, true) : a(editable, keyEvent, false))) {
            return false;
        }
        MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
        return true;
    }

    private boolean d(CharSequence charSequence, int i2, int i3, p pVar) {
        if (pVar.d() == 0) {
            pVar.m(this.f2643c.a(charSequence, i2, i3, pVar.h()));
        }
        return pVar.d() == 2;
    }

    private static boolean e(int i2, int i3) {
        return i2 == -1 || i3 == -1 || i2 != i3;
    }

    private static boolean f(KeyEvent keyEvent) {
        return !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState());
    }

    private void g(Set set) {
        if (!set.isEmpty()) {
            Iterator it = set.iterator();
            while (it.hasNext()) {
                int[] iArr = (int[]) it.next();
                String str = new String(iArr, 0, iArr.length);
                i(str, 0, str.length(), 1, true, new d(str));
            }
        }
    }

    private Object i(CharSequence charSequence, int i2, int i3, int i4, boolean z2, c cVar) {
        int i5;
        e eVar = new e(this.f2642b.f(), this.f2644d, this.f2645e);
        int codePointAt = Character.codePointAt(charSequence, i2);
        int i6 = 0;
        boolean z3 = true;
        loop0:
        while (true) {
            i5 = i2;
            while (i2 < i3 && i6 < i4 && z3) {
                int a2 = eVar.a(codePointAt);
                if (a2 == 1) {
                    i5 += Character.charCount(Character.codePointAt(charSequence, i5));
                    if (i5 < i3) {
                        codePointAt = Character.codePointAt(charSequence, i5);
                    }
                    i2 = i5;
                } else if (a2 == 2) {
                    i2 += Character.charCount(codePointAt);
                    if (i2 < i3) {
                        codePointAt = Character.codePointAt(charSequence, i2);
                    }
                } else if (a2 == 3) {
                    if (z2 || !d(charSequence, i5, i2, eVar.c())) {
                        z3 = cVar.b(charSequence, i5, i2, eVar.c());
                        i6++;
                    }
                }
            }
        }
        if (eVar.e() && i6 < i4 && z3 && (z2 || !d(charSequence, i5, i2, eVar.b()))) {
            cVar.b(charSequence, i5, i2, eVar.b());
        }
        return cVar.a();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0049 A[Catch:{ all -> 0x002a }] */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0066 A[Catch:{ all -> 0x002a }] */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00ab  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.CharSequence h(java.lang.CharSequence r11, int r12, int r13, int r14, boolean r15) {
        /*
            r10 = this;
            boolean r0 = r11 instanceof androidx.emoji2.text.o
            if (r0 == 0) goto L_0x000a
            r1 = r11
            androidx.emoji2.text.o r1 = (androidx.emoji2.text.o) r1
            r1.a()
        L_0x000a:
            java.lang.Class<androidx.emoji2.text.j> r1 = androidx.emoji2.text.j.class
            if (r0 != 0) goto L_0x002f
            boolean r2 = r11 instanceof android.text.Spannable     // Catch:{ all -> 0x002a }
            if (r2 == 0) goto L_0x0013
            goto L_0x002f
        L_0x0013:
            boolean r2 = r11 instanceof android.text.Spanned     // Catch:{ all -> 0x002a }
            if (r2 == 0) goto L_0x002d
            r2 = r11
            android.text.Spanned r2 = (android.text.Spanned) r2     // Catch:{ all -> 0x002a }
            int r3 = r12 + -1
            int r4 = r13 + 1
            int r2 = r2.nextSpanTransition(r3, r4, r1)     // Catch:{ all -> 0x002a }
            if (r2 > r13) goto L_0x002d
            androidx.emoji2.text.t r2 = new androidx.emoji2.text.t     // Catch:{ all -> 0x002a }
            r2.<init>((java.lang.CharSequence) r11)     // Catch:{ all -> 0x002a }
            goto L_0x0037
        L_0x002a:
            r12 = move-exception
            goto L_0x00b2
        L_0x002d:
            r2 = 0
            goto L_0x0037
        L_0x002f:
            androidx.emoji2.text.t r2 = new androidx.emoji2.text.t     // Catch:{ all -> 0x002a }
            r3 = r11
            android.text.Spannable r3 = (android.text.Spannable) r3     // Catch:{ all -> 0x002a }
            r2.<init>((android.text.Spannable) r3)     // Catch:{ all -> 0x002a }
        L_0x0037:
            r3 = 0
            if (r2 == 0) goto L_0x0063
            java.lang.Object[] r4 = r2.getSpans(r12, r13, r1)     // Catch:{ all -> 0x002a }
            androidx.emoji2.text.j[] r4 = (androidx.emoji2.text.j[]) r4     // Catch:{ all -> 0x002a }
            if (r4 == 0) goto L_0x0063
            int r5 = r4.length     // Catch:{ all -> 0x002a }
            if (r5 <= 0) goto L_0x0063
            int r5 = r4.length     // Catch:{ all -> 0x002a }
            r6 = 0
        L_0x0047:
            if (r6 >= r5) goto L_0x0063
            r7 = r4[r6]     // Catch:{ all -> 0x002a }
            int r8 = r2.getSpanStart(r7)     // Catch:{ all -> 0x002a }
            int r9 = r2.getSpanEnd(r7)     // Catch:{ all -> 0x002a }
            if (r8 == r13) goto L_0x0058
            r2.removeSpan(r7)     // Catch:{ all -> 0x002a }
        L_0x0058:
            int r12 = java.lang.Math.min(r8, r12)     // Catch:{ all -> 0x002a }
            int r13 = java.lang.Math.max(r9, r13)     // Catch:{ all -> 0x002a }
            int r6 = r6 + 1
            goto L_0x0047
        L_0x0063:
            r4 = r13
            if (r12 == r4) goto L_0x00a9
            int r13 = r11.length()     // Catch:{ all -> 0x002a }
            if (r12 < r13) goto L_0x006d
            goto L_0x00a9
        L_0x006d:
            r13 = 2147483647(0x7fffffff, float:NaN)
            if (r14 == r13) goto L_0x0080
            if (r2 == 0) goto L_0x0080
            int r13 = r2.length()     // Catch:{ all -> 0x002a }
            java.lang.Object[] r13 = r2.getSpans(r3, r13, r1)     // Catch:{ all -> 0x002a }
            androidx.emoji2.text.j[] r13 = (androidx.emoji2.text.j[]) r13     // Catch:{ all -> 0x002a }
            int r13 = r13.length     // Catch:{ all -> 0x002a }
            int r14 = r14 - r13
        L_0x0080:
            r5 = r14
            androidx.emoji2.text.i$b r7 = new androidx.emoji2.text.i$b     // Catch:{ all -> 0x002a }
            androidx.emoji2.text.f$j r13 = r10.f2641a     // Catch:{ all -> 0x002a }
            r7.<init>(r2, r13)     // Catch:{ all -> 0x002a }
            r1 = r10
            r2 = r11
            r3 = r12
            r6 = r15
            java.lang.Object r12 = r1.i(r2, r3, r4, r5, r6, r7)     // Catch:{ all -> 0x002a }
            androidx.emoji2.text.t r12 = (androidx.emoji2.text.t) r12     // Catch:{ all -> 0x002a }
            if (r12 == 0) goto L_0x00a0
            android.text.Spannable r12 = r12.b()     // Catch:{ all -> 0x002a }
            if (r0 == 0) goto L_0x009f
            androidx.emoji2.text.o r11 = (androidx.emoji2.text.o) r11
            r11.d()
        L_0x009f:
            return r12
        L_0x00a0:
            if (r0 == 0) goto L_0x00a8
            r12 = r11
            androidx.emoji2.text.o r12 = (androidx.emoji2.text.o) r12
            r12.d()
        L_0x00a8:
            return r11
        L_0x00a9:
            if (r0 == 0) goto L_0x00b1
            r12 = r11
            androidx.emoji2.text.o r12 = (androidx.emoji2.text.o) r12
            r12.d()
        L_0x00b1:
            return r11
        L_0x00b2:
            if (r0 == 0) goto L_0x00b9
            androidx.emoji2.text.o r11 = (androidx.emoji2.text.o) r11
            r11.d()
        L_0x00b9:
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.i.h(java.lang.CharSequence, int, int, int, boolean):java.lang.CharSequence");
    }
}
