package androidx.emoji2.text;

import androidx.emoji2.text.k;

public final /* synthetic */ class l implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k.b f2673a;

    public /* synthetic */ l(k.b bVar) {
        this.f2673a = bVar;
    }

    public final void run() {
        this.f2673a.c();
    }
}
