package androidx.drawerlayout.widget;

import D.c;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.view.C0121a;
import androidx.core.view.C0156s;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import java.util.ArrayList;
import java.util.List;
import y.I;
import y.L;

public class DrawerLayout extends ViewGroup {

    /* renamed from: L  reason: collision with root package name */
    private static final int[] f2534L = {16843828};

    /* renamed from: M  reason: collision with root package name */
    static final int[] f2535M = {16842931};

    /* renamed from: N  reason: collision with root package name */
    static final boolean f2536N = true;

    /* renamed from: O  reason: collision with root package name */
    private static final boolean f2537O = true;

    /* renamed from: P  reason: collision with root package name */
    private static boolean f2538P;

    /* renamed from: A  reason: collision with root package name */
    private CharSequence f2539A;

    /* renamed from: B  reason: collision with root package name */
    private Object f2540B;

    /* renamed from: C  reason: collision with root package name */
    private boolean f2541C;

    /* renamed from: D  reason: collision with root package name */
    private Drawable f2542D;

    /* renamed from: E  reason: collision with root package name */
    private Drawable f2543E;

    /* renamed from: F  reason: collision with root package name */
    private Drawable f2544F;

    /* renamed from: G  reason: collision with root package name */
    private Drawable f2545G;

    /* renamed from: H  reason: collision with root package name */
    private final ArrayList f2546H;

    /* renamed from: I  reason: collision with root package name */
    private Rect f2547I;

    /* renamed from: J  reason: collision with root package name */
    private Matrix f2548J;

    /* renamed from: K  reason: collision with root package name */
    private final L f2549K;

    /* renamed from: a  reason: collision with root package name */
    private final d f2550a;

    /* renamed from: b  reason: collision with root package name */
    private float f2551b;

    /* renamed from: c  reason: collision with root package name */
    private int f2552c;

    /* renamed from: d  reason: collision with root package name */
    private int f2553d;

    /* renamed from: e  reason: collision with root package name */
    private float f2554e;

    /* renamed from: f  reason: collision with root package name */
    private Paint f2555f;

    /* renamed from: g  reason: collision with root package name */
    private final D.c f2556g;

    /* renamed from: h  reason: collision with root package name */
    private final D.c f2557h;

    /* renamed from: i  reason: collision with root package name */
    private final i f2558i;

    /* renamed from: j  reason: collision with root package name */
    private final i f2559j;

    /* renamed from: k  reason: collision with root package name */
    private int f2560k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f2561l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f2562m;

    /* renamed from: n  reason: collision with root package name */
    private int f2563n;

    /* renamed from: o  reason: collision with root package name */
    private int f2564o;

    /* renamed from: p  reason: collision with root package name */
    private int f2565p;

    /* renamed from: q  reason: collision with root package name */
    private int f2566q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f2567r;

    /* renamed from: s  reason: collision with root package name */
    private e f2568s;

    /* renamed from: t  reason: collision with root package name */
    private List f2569t;

    /* renamed from: u  reason: collision with root package name */
    private float f2570u;

    /* renamed from: v  reason: collision with root package name */
    private float f2571v;

    /* renamed from: w  reason: collision with root package name */
    private Drawable f2572w;

    /* renamed from: x  reason: collision with root package name */
    private Drawable f2573x;

    /* renamed from: y  reason: collision with root package name */
    private Drawable f2574y;

    /* renamed from: z  reason: collision with root package name */
    private CharSequence f2575z;

    class a implements L {
        a() {
        }

        public boolean a(View view, L.a aVar) {
            if (!DrawerLayout.this.D(view) || DrawerLayout.this.r(view) == 2) {
                return false;
            }
            DrawerLayout.this.f(view);
            return true;
        }
    }

    class b implements View.OnApplyWindowInsetsListener {
        b() {
        }

        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            ((DrawerLayout) view).S(windowInsets, windowInsets.getSystemWindowInsetTop() > 0);
            return windowInsets.consumeSystemWindowInsets();
        }
    }

    class c extends C0121a {

        /* renamed from: d  reason: collision with root package name */
        private final Rect f2578d = new Rect();

        c() {
        }

        private void n(I i2, ViewGroup viewGroup) {
            int childCount = viewGroup.getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = viewGroup.getChildAt(i3);
                if (DrawerLayout.A(childAt)) {
                    i2.c(childAt);
                }
            }
        }

        private void o(I i2, I i3) {
            Rect rect = this.f2578d;
            i3.n(rect);
            i2.j0(rect);
            i2.M0(i3.Y());
            i2.z0(i3.y());
            i2.m0(i3.q());
            i2.q0(i3.t());
            i2.r0(i3.N());
            i2.u0(i3.P());
            i2.g0(i3.I());
            i2.F0(i3.V());
            i2.a(i3.k());
        }

        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            CharSequence s2;
            if (accessibilityEvent.getEventType() != 32) {
                return super.a(view, accessibilityEvent);
            }
            List<CharSequence> text = accessibilityEvent.getText();
            View p2 = DrawerLayout.this.p();
            if (p2 == null || (s2 = DrawerLayout.this.s(DrawerLayout.this.t(p2))) == null) {
                return true;
            }
            text.add(s2);
            return true;
        }

        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            accessibilityEvent.setClassName("androidx.drawerlayout.widget.DrawerLayout");
        }

        public void g(View view, I i2) {
            if (DrawerLayout.f2536N) {
                super.g(view, i2);
            } else {
                I b02 = I.b0(i2);
                super.g(view, b02);
                i2.H0(view);
                ViewParent I2 = W.I(view);
                if (I2 instanceof View) {
                    i2.B0((View) I2);
                }
                o(i2, b02);
                b02.d0();
                n(i2, (ViewGroup) view);
            }
            i2.m0("androidx.drawerlayout.widget.DrawerLayout");
            i2.t0(false);
            i2.u0(false);
            i2.e0(I.a.f6362e);
            i2.e0(I.a.f6363f);
        }

        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            if (DrawerLayout.f2536N || DrawerLayout.A(view)) {
                return super.i(viewGroup, view, accessibilityEvent);
            }
            return false;
        }
    }

    static final class d extends C0121a {
        d() {
        }

        public void g(View view, I i2) {
            super.g(view, i2);
            if (!DrawerLayout.A(view)) {
                i2.B0((View) null);
            }
        }
    }

    public interface e {
        void a(int i2);

        void b(View view);

        void c(View view, float f2);

        void d(View view);
    }

    public static class f extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        public int f2580a = 0;

        /* renamed from: b  reason: collision with root package name */
        float f2581b;

        /* renamed from: c  reason: collision with root package name */
        boolean f2582c;

        /* renamed from: d  reason: collision with root package name */
        int f2583d;

        public f(int i2, int i3) {
            super(i2, i3);
        }

        public f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.f2535M);
            this.f2580a = obtainStyledAttributes.getInt(0, 0);
            obtainStyledAttributes.recycle();
        }

        public f(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public f(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public f(f fVar) {
            super(fVar);
            this.f2580a = fVar.f2580a;
        }
    }

    protected static class g extends C.a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        int f2584c = 0;

        /* renamed from: d  reason: collision with root package name */
        int f2585d;

        /* renamed from: e  reason: collision with root package name */
        int f2586e;

        /* renamed from: f  reason: collision with root package name */
        int f2587f;

        /* renamed from: g  reason: collision with root package name */
        int f2588g;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }

            /* renamed from: c */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2584c = parcel.readInt();
            this.f2585d = parcel.readInt();
            this.f2586e = parcel.readInt();
            this.f2587f = parcel.readInt();
            this.f2588g = parcel.readInt();
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f2584c);
            parcel.writeInt(this.f2585d);
            parcel.writeInt(this.f2586e);
            parcel.writeInt(this.f2587f);
            parcel.writeInt(this.f2588g);
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public static abstract class h implements e {
        public void a(int i2) {
        }

        public void c(View view, float f2) {
        }
    }

    private class i extends c.C0004c {

        /* renamed from: a  reason: collision with root package name */
        private final int f2589a;

        /* renamed from: b  reason: collision with root package name */
        private D.c f2590b;

        /* renamed from: c  reason: collision with root package name */
        private final Runnable f2591c = new a();

        class a implements Runnable {
            a() {
            }

            public void run() {
                i.this.o();
            }
        }

        i(int i2) {
            this.f2589a = i2;
        }

        private void n() {
            int i2 = 3;
            if (this.f2589a == 3) {
                i2 = 5;
            }
            View n2 = DrawerLayout.this.n(i2);
            if (n2 != null) {
                DrawerLayout.this.f(n2);
            }
        }

        public int a(View view, int i2, int i3) {
            int width;
            int width2;
            if (DrawerLayout.this.c(view, 3)) {
                width2 = -view.getWidth();
                width = 0;
            } else {
                width = DrawerLayout.this.getWidth();
                width2 = width - view.getWidth();
            }
            return Math.max(width2, Math.min(i2, width));
        }

        public int b(View view, int i2, int i3) {
            return view.getTop();
        }

        public int d(View view) {
            if (DrawerLayout.this.E(view)) {
                return view.getWidth();
            }
            return 0;
        }

        public void f(int i2, int i3) {
            DrawerLayout drawerLayout;
            int i4;
            if ((i2 & 1) == 1) {
                drawerLayout = DrawerLayout.this;
                i4 = 3;
            } else {
                drawerLayout = DrawerLayout.this;
                i4 = 5;
            }
            View n2 = drawerLayout.n(i4);
            if (n2 != null && DrawerLayout.this.r(n2) == 0) {
                this.f2590b.b(n2, i3);
            }
        }

        public boolean g(int i2) {
            return false;
        }

        public void h(int i2, int i3) {
            DrawerLayout.this.postDelayed(this.f2591c, 160);
        }

        public void i(View view, int i2) {
            ((f) view.getLayoutParams()).f2582c = false;
            n();
        }

        public void j(int i2) {
            DrawerLayout.this.X(i2, this.f2590b.v());
        }

        public void k(View view, int i2, int i3, int i4, int i5) {
            int width = view.getWidth();
            float width2 = (DrawerLayout.this.c(view, 3) ? (float) (i2 + width) : (float) (DrawerLayout.this.getWidth() - i2)) / ((float) width);
            DrawerLayout.this.U(view, width2);
            view.setVisibility(width2 == 0.0f ? 4 : 0);
            DrawerLayout.this.invalidate();
        }

        public void l(View view, float f2, float f3) {
            int i2;
            float u2 = DrawerLayout.this.u(view);
            int width = view.getWidth();
            if (DrawerLayout.this.c(view, 3)) {
                int i3 = (f2 > 0.0f ? 1 : (f2 == 0.0f ? 0 : -1));
                i2 = (i3 > 0 || (i3 == 0 && u2 > 0.5f)) ? 0 : -width;
            } else {
                int width2 = DrawerLayout.this.getWidth();
                if (f2 < 0.0f || (f2 == 0.0f && u2 > 0.5f)) {
                    width2 -= width;
                }
                i2 = width2;
            }
            this.f2590b.O(i2, view.getTop());
            DrawerLayout.this.invalidate();
        }

        public boolean m(View view, int i2) {
            return DrawerLayout.this.E(view) && DrawerLayout.this.c(view, this.f2589a) && DrawerLayout.this.r(view) == 0;
        }

        /* access modifiers changed from: package-private */
        public void o() {
            View view;
            int i2;
            int x2 = this.f2590b.x();
            int i3 = 0;
            boolean z2 = this.f2589a == 3;
            if (z2) {
                view = DrawerLayout.this.n(3);
                if (view != null) {
                    i3 = -view.getWidth();
                }
                i2 = i3 + x2;
            } else {
                view = DrawerLayout.this.n(5);
                i2 = DrawerLayout.this.getWidth() - x2;
            }
            if (view == null) {
                return;
            }
            if (((z2 && view.getLeft() < i2) || (!z2 && view.getLeft() > i2)) && DrawerLayout.this.r(view) == 0) {
                this.f2590b.Q(view, i2, view.getTop());
                ((f) view.getLayoutParams()).f2582c = true;
                DrawerLayout.this.invalidate();
                n();
                DrawerLayout.this.b();
            }
        }

        public void p() {
            DrawerLayout.this.removeCallbacks(this.f2591c);
        }

        public void q(D.c cVar) {
            this.f2590b = cVar;
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        boolean z2 = true;
        if (i2 < 29) {
            z2 = false;
        }
        f2538P = z2;
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, E.a.drawerLayoutStyle);
    }

    static boolean A(View view) {
        return (W.A(view) == 4 || W.A(view) == 2) ? false : true;
    }

    private boolean H(float f2, float f3, View view) {
        if (this.f2547I == null) {
            this.f2547I = new Rect();
        }
        view.getHitRect(this.f2547I);
        return this.f2547I.contains((int) f2, (int) f3);
    }

    private void I(Drawable drawable, int i2) {
        if (drawable != null && androidx.core.graphics.drawable.a.h(drawable)) {
            androidx.core.graphics.drawable.a.m(drawable, i2);
        }
    }

    private Drawable P() {
        int C2 = W.C(this);
        if (C2 == 0) {
            Drawable drawable = this.f2542D;
            if (drawable != null) {
                I(drawable, C2);
                return this.f2542D;
            }
        } else {
            Drawable drawable2 = this.f2543E;
            if (drawable2 != null) {
                I(drawable2, C2);
                return this.f2543E;
            }
        }
        return this.f2544F;
    }

    private Drawable Q() {
        int C2 = W.C(this);
        if (C2 == 0) {
            Drawable drawable = this.f2543E;
            if (drawable != null) {
                I(drawable, C2);
                return this.f2543E;
            }
        } else {
            Drawable drawable2 = this.f2542D;
            if (drawable2 != null) {
                I(drawable2, C2);
                return this.f2542D;
            }
        }
        return this.f2545G;
    }

    private void R() {
        if (!f2537O) {
            this.f2573x = P();
            this.f2574y = Q();
        }
    }

    private void V(View view) {
        I.a aVar = I.a.f6382y;
        W.k0(view, aVar.b());
        if (D(view) && r(view) != 2) {
            W.m0(view, aVar, (CharSequence) null, this.f2549K);
        }
    }

    private void W(View view, boolean z2) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            W.y0(childAt, ((z2 || E(childAt)) && (!z2 || childAt != view)) ? 4 : 1);
        }
    }

    private boolean m(MotionEvent motionEvent, View view) {
        if (!view.getMatrix().isIdentity()) {
            MotionEvent v2 = v(motionEvent, view);
            boolean dispatchGenericMotionEvent = view.dispatchGenericMotionEvent(v2);
            v2.recycle();
            return dispatchGenericMotionEvent;
        }
        float scrollX = (float) (getScrollX() - view.getLeft());
        float scrollY = (float) (getScrollY() - view.getTop());
        motionEvent.offsetLocation(scrollX, scrollY);
        boolean dispatchGenericMotionEvent2 = view.dispatchGenericMotionEvent(motionEvent);
        motionEvent.offsetLocation(-scrollX, -scrollY);
        return dispatchGenericMotionEvent2;
    }

    private MotionEvent v(MotionEvent motionEvent, View view) {
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        obtain.offsetLocation((float) (getScrollX() - view.getLeft()), (float) (getScrollY() - view.getTop()));
        Matrix matrix = view.getMatrix();
        if (!matrix.isIdentity()) {
            if (this.f2548J == null) {
                this.f2548J = new Matrix();
            }
            matrix.invert(this.f2548J);
            obtain.transform(this.f2548J);
        }
        return obtain;
    }

    static String w(int i2) {
        if ((i2 & 3) == 3) {
            return "LEFT";
        }
        return (i2 & 5) == 5 ? "RIGHT" : Integer.toHexString(i2);
    }

    private static boolean x(View view) {
        Drawable background = view.getBackground();
        return background != null && background.getOpacity() == -1;
    }

    private boolean y() {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            if (((f) getChildAt(i2).getLayoutParams()).f2582c) {
                return true;
            }
        }
        return false;
    }

    private boolean z() {
        return p() != null;
    }

    /* access modifiers changed from: package-private */
    public boolean B(View view) {
        return ((f) view.getLayoutParams()).f2580a == 0;
    }

    public boolean C(int i2) {
        View n2 = n(i2);
        if (n2 != null) {
            return D(n2);
        }
        return false;
    }

    public boolean D(View view) {
        if (E(view)) {
            return (((f) view.getLayoutParams()).f2583d & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    /* access modifiers changed from: package-private */
    public boolean E(View view) {
        int b2 = C0156s.b(((f) view.getLayoutParams()).f2580a, W.C(view));
        return ((b2 & 3) == 0 && (b2 & 5) == 0) ? false : true;
    }

    public boolean F(int i2) {
        View n2 = n(i2);
        if (n2 != null) {
            return G(n2);
        }
        return false;
    }

    public boolean G(View view) {
        if (E(view)) {
            return ((f) view.getLayoutParams()).f2581b > 0.0f;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    /* access modifiers changed from: package-private */
    public void J(View view, float f2) {
        float u2 = u(view);
        float width = (float) view.getWidth();
        int i2 = ((int) (width * f2)) - ((int) (u2 * width));
        if (!c(view, 3)) {
            i2 = -i2;
        }
        view.offsetLeftAndRight(i2);
        U(view, f2);
    }

    public void K(int i2) {
        L(i2, true);
    }

    public void L(int i2, boolean z2) {
        View n2 = n(i2);
        if (n2 != null) {
            N(n2, z2);
            return;
        }
        throw new IllegalArgumentException("No drawer view found with gravity " + w(i2));
    }

    public void M(View view) {
        N(view, true);
    }

    public void N(View view, boolean z2) {
        if (E(view)) {
            f fVar = (f) view.getLayoutParams();
            if (this.f2562m) {
                fVar.f2581b = 1.0f;
                fVar.f2583d = 1;
                W(view, true);
                V(view);
            } else if (z2) {
                fVar.f2583d |= 2;
                if (c(view, 3)) {
                    this.f2556g.Q(view, 0, view.getTop());
                } else {
                    this.f2557h.Q(view, getWidth() - view.getWidth(), view.getTop());
                }
            } else {
                J(view, 1.0f);
                X(0, view);
                view.setVisibility(0);
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    public void O(e eVar) {
        List list;
        if (eVar != null && (list = this.f2569t) != null) {
            list.remove(eVar);
        }
    }

    public void S(Object obj, boolean z2) {
        this.f2540B = obj;
        this.f2541C = z2;
        setWillNotDraw(!z2 && getBackground() == null);
        requestLayout();
    }

    public void T(int i2, int i3) {
        View n2;
        int b2 = C0156s.b(i3, W.C(this));
        if (i3 == 3) {
            this.f2563n = i2;
        } else if (i3 == 5) {
            this.f2564o = i2;
        } else if (i3 == 8388611) {
            this.f2565p = i2;
        } else if (i3 == 8388613) {
            this.f2566q = i2;
        }
        if (i2 != 0) {
            (b2 == 3 ? this.f2556g : this.f2557h).a();
        }
        if (i2 == 1) {
            View n3 = n(b2);
            if (n3 != null) {
                f(n3);
            }
        } else if (i2 == 2 && (n2 = n(b2)) != null) {
            M(n2);
        }
    }

    /* access modifiers changed from: package-private */
    public void U(View view, float f2) {
        f fVar = (f) view.getLayoutParams();
        if (f2 != fVar.f2581b) {
            fVar.f2581b = f2;
            l(view, f2);
        }
    }

    /* access modifiers changed from: package-private */
    public void X(int i2, View view) {
        int i3;
        int A2 = this.f2556g.A();
        int A3 = this.f2557h.A();
        if (A2 == 1 || A3 == 1) {
            i3 = 1;
        } else {
            i3 = 2;
            if (!(A2 == 2 || A3 == 2)) {
                i3 = 0;
            }
        }
        if (view != null && i2 == 0) {
            float f2 = ((f) view.getLayoutParams()).f2581b;
            if (f2 == 0.0f) {
                j(view);
            } else if (f2 == 1.0f) {
                k(view);
            }
        }
        if (i3 != this.f2560k) {
            this.f2560k = i3;
            List list = this.f2569t;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    ((e) this.f2569t.get(size)).a(i3);
                }
            }
        }
    }

    public void a(e eVar) {
        if (eVar != null) {
            if (this.f2569t == null) {
                this.f2569t = new ArrayList();
            }
            this.f2569t.add(eVar);
        }
    }

    public void addFocusables(ArrayList arrayList, int i2, int i3) {
        if (getDescendantFocusability() != 393216) {
            int childCount = getChildCount();
            boolean z2 = false;
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                if (!E(childAt)) {
                    this.f2546H.add(childAt);
                } else if (D(childAt)) {
                    childAt.addFocusables(arrayList, i2, i3);
                    z2 = true;
                }
            }
            if (!z2) {
                int size = this.f2546H.size();
                for (int i5 = 0; i5 < size; i5++) {
                    View view = (View) this.f2546H.get(i5);
                    if (view.getVisibility() == 0) {
                        view.addFocusables(arrayList, i2, i3);
                    }
                }
            }
            this.f2546H.clear();
        }
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i2, layoutParams);
        W.y0(view, (o() != null || E(view)) ? 4 : 1);
        if (!f2536N) {
            W.q0(view, this.f2550a);
        }
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (!this.f2567r) {
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                getChildAt(i2).dispatchTouchEvent(obtain);
            }
            obtain.recycle();
            this.f2567r = true;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean c(View view, int i2) {
        return (t(view) & i2) == i2;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof f) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        int childCount = getChildCount();
        float f2 = 0.0f;
        for (int i2 = 0; i2 < childCount; i2++) {
            f2 = Math.max(f2, ((f) getChildAt(i2).getLayoutParams()).f2581b);
        }
        this.f2554e = f2;
        boolean m2 = this.f2556g.m(true);
        boolean m3 = this.f2557h.m(true);
        if (m2 || m3) {
            W.h0(this);
        }
    }

    public void d(int i2) {
        e(i2, true);
    }

    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f2554e <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x2 = motionEvent.getX();
        float y2 = motionEvent.getY();
        for (int i2 = childCount - 1; i2 >= 0; i2--) {
            View childAt = getChildAt(i2);
            if (H(x2, y2, childAt) && !B(childAt) && m(motionEvent, childAt)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j2) {
        Drawable drawable;
        Canvas canvas2 = canvas;
        View view2 = view;
        int height = getHeight();
        boolean B2 = B(view2);
        int width = getWidth();
        int save = canvas.save();
        int i2 = 0;
        if (B2) {
            int childCount = getChildCount();
            int i3 = 0;
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                if (childAt != view2 && childAt.getVisibility() == 0 && x(childAt) && E(childAt) && childAt.getHeight() >= height) {
                    if (c(childAt, 3)) {
                        int right = childAt.getRight();
                        if (right > i3) {
                            i3 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i3, 0, width, getHeight());
            i2 = i3;
        }
        boolean drawChild = super.drawChild(canvas, view, j2);
        canvas.restoreToCount(save);
        float f2 = this.f2554e;
        if (f2 <= 0.0f || !B2) {
            if (this.f2573x != null && c(view2, 3)) {
                int intrinsicWidth = this.f2573x.getIntrinsicWidth();
                int right2 = view.getRight();
                float max = Math.max(0.0f, Math.min(((float) right2) / ((float) this.f2556g.x()), 1.0f));
                this.f2573x.setBounds(right2, view.getTop(), intrinsicWidth + right2, view.getBottom());
                this.f2573x.setAlpha((int) (max * 255.0f));
                drawable = this.f2573x;
            } else if (this.f2574y != null && c(view2, 5)) {
                int intrinsicWidth2 = this.f2574y.getIntrinsicWidth();
                int left2 = view.getLeft();
                float max2 = Math.max(0.0f, Math.min(((float) (getWidth() - left2)) / ((float) this.f2557h.x()), 1.0f));
                this.f2574y.setBounds(left2 - intrinsicWidth2, view.getTop(), left2, view.getBottom());
                this.f2574y.setAlpha((int) (max2 * 255.0f));
                drawable = this.f2574y;
            }
            drawable.draw(canvas);
        } else {
            int i5 = this.f2553d;
            this.f2555f.setColor((i5 & 16777215) | (((int) (((float) ((-16777216 & i5) >>> 24)) * f2)) << 24));
            canvas.drawRect((float) i2, 0.0f, (float) width, (float) getHeight(), this.f2555f);
        }
        return drawChild;
    }

    public void e(int i2, boolean z2) {
        View n2 = n(i2);
        if (n2 != null) {
            g(n2, z2);
            return;
        }
        throw new IllegalArgumentException("No drawer view found with gravity " + w(i2));
    }

    public void f(View view) {
        g(view, true);
    }

    public void g(View view, boolean z2) {
        D.c cVar;
        int width;
        if (E(view)) {
            f fVar = (f) view.getLayoutParams();
            if (this.f2562m) {
                fVar.f2581b = 0.0f;
                fVar.f2583d = 0;
            } else if (z2) {
                fVar.f2583d |= 4;
                if (c(view, 3)) {
                    cVar = this.f2556g;
                    width = -view.getWidth();
                } else {
                    cVar = this.f2557h;
                    width = getWidth();
                }
                cVar.Q(view, width, view.getTop());
            } else {
                J(view, 0.0f);
                X(0, view);
                view.setVisibility(4);
            }
            invalidate();
            return;
        }
        throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new f(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new f(getContext(), attributeSet);
    }

    public float getDrawerElevation() {
        if (f2537O) {
            return this.f2551b;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f2572w;
    }

    public void h() {
        i(false);
    }

    /* access modifiers changed from: package-private */
    public void i(boolean z2) {
        int childCount = getChildCount();
        boolean z3 = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            f fVar = (f) childAt.getLayoutParams();
            if (E(childAt) && (!z2 || fVar.f2582c)) {
                z3 |= c(childAt, 3) ? this.f2556g.Q(childAt, -childAt.getWidth(), childAt.getTop()) : this.f2557h.Q(childAt, getWidth(), childAt.getTop());
                fVar.f2582c = false;
            }
        }
        this.f2558i.p();
        this.f2559j.p();
        if (z3) {
            invalidate();
        }
    }

    /* access modifiers changed from: package-private */
    public void j(View view) {
        View rootView;
        f fVar = (f) view.getLayoutParams();
        if ((fVar.f2583d & 1) == 1) {
            fVar.f2583d = 0;
            List list = this.f2569t;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    ((e) this.f2569t.get(size)).d(view);
                }
            }
            W(view, false);
            V(view);
            if (hasWindowFocus() && (rootView = getRootView()) != null) {
                rootView.sendAccessibilityEvent(32);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void k(View view) {
        f fVar = (f) view.getLayoutParams();
        if ((fVar.f2583d & 1) == 0) {
            fVar.f2583d = 1;
            List list = this.f2569t;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    ((e) this.f2569t.get(size)).b(view);
                }
            }
            W(view, true);
            V(view);
            if (hasWindowFocus()) {
                sendAccessibilityEvent(32);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void l(View view, float f2) {
        List list = this.f2569t;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                ((e) this.f2569t.get(size)).c(view, f2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public View n(int i2) {
        int b2 = C0156s.b(i2, W.C(this)) & 7;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            if ((t(childAt) & 7) == b2) {
                return childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public View o() {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if ((((f) childAt.getLayoutParams()).f2583d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2562m = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f2562m = true;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f2541C && this.f2572w != null) {
            Object obj = this.f2540B;
            int systemWindowInsetTop = obj != null ? ((WindowInsets) obj).getSystemWindowInsetTop() : 0;
            if (systemWindowInsetTop > 0) {
                this.f2572w.setBounds(0, 0, getWidth(), systemWindowInsetTop);
                this.f2572w.draw(canvas);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x004b, code lost:
        r7 = r6.f2556g.t((int) r0, (int) r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x001b, code lost:
        if (r0 != 3) goto L_0x0036;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r7) {
        /*
            r6 = this;
            int r0 = r7.getActionMasked()
            D.c r1 = r6.f2556g
            boolean r1 = r1.P(r7)
            D.c r2 = r6.f2557h
            boolean r2 = r2.P(r7)
            r1 = r1 | r2
            r2 = 1
            r3 = 0
            if (r0 == 0) goto L_0x0038
            if (r0 == r2) goto L_0x0031
            r7 = 2
            r4 = 3
            if (r0 == r7) goto L_0x001e
            if (r0 == r4) goto L_0x0031
            goto L_0x0036
        L_0x001e:
            D.c r7 = r6.f2556g
            boolean r7 = r7.d(r4)
            if (r7 == 0) goto L_0x0036
            androidx.drawerlayout.widget.DrawerLayout$i r7 = r6.f2558i
            r7.p()
            androidx.drawerlayout.widget.DrawerLayout$i r7 = r6.f2559j
            r7.p()
            goto L_0x0036
        L_0x0031:
            r6.i(r2)
            r6.f2567r = r3
        L_0x0036:
            r7 = 0
            goto L_0x0060
        L_0x0038:
            float r0 = r7.getX()
            float r7 = r7.getY()
            r6.f2570u = r0
            r6.f2571v = r7
            float r4 = r6.f2554e
            r5 = 0
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 <= 0) goto L_0x005d
            D.c r4 = r6.f2556g
            int r0 = (int) r0
            int r7 = (int) r7
            android.view.View r7 = r4.t(r0, r7)
            if (r7 == 0) goto L_0x005d
            boolean r7 = r6.B(r7)
            if (r7 == 0) goto L_0x005d
            r7 = 1
            goto L_0x005e
        L_0x005d:
            r7 = 0
        L_0x005e:
            r6.f2567r = r3
        L_0x0060:
            if (r1 != 0) goto L_0x0070
            if (r7 != 0) goto L_0x0070
            boolean r7 = r6.y()
            if (r7 != 0) goto L_0x0070
            boolean r7 = r6.f2567r
            if (r7 == 0) goto L_0x006f
            goto L_0x0070
        L_0x006f:
            r2 = 0
        L_0x0070:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.drawerlayout.widget.DrawerLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 != 4 || !z()) {
            return super.onKeyDown(i2, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        if (i2 != 4) {
            return super.onKeyUp(i2, keyEvent);
        }
        View p2 = p();
        if (p2 != null && r(p2) == 0) {
            h();
        }
        return p2 != null;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        WindowInsets a2;
        float f2;
        int i6;
        int measuredHeight;
        int i7;
        int i8;
        this.f2561l = true;
        int i9 = i4 - i2;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (B(childAt)) {
                    int i11 = fVar.leftMargin;
                    childAt.layout(i11, fVar.topMargin, childAt.getMeasuredWidth() + i11, fVar.topMargin + childAt.getMeasuredHeight());
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight2 = childAt.getMeasuredHeight();
                    if (c(childAt, 3)) {
                        float f3 = (float) measuredWidth;
                        i6 = (-measuredWidth) + ((int) (fVar.f2581b * f3));
                        f2 = ((float) (measuredWidth + i6)) / f3;
                    } else {
                        float f4 = (float) measuredWidth;
                        int i12 = i9 - ((int) (fVar.f2581b * f4));
                        f2 = ((float) (i9 - i12)) / f4;
                        i6 = i12;
                    }
                    boolean z3 = f2 != fVar.f2581b;
                    int i13 = fVar.f2580a & 112;
                    if (i13 != 16) {
                        if (i13 != 80) {
                            measuredHeight = fVar.topMargin;
                            i7 = measuredWidth + i6;
                            i8 = measuredHeight2 + measuredHeight;
                        } else {
                            int i14 = i5 - i3;
                            measuredHeight = (i14 - fVar.bottomMargin) - childAt.getMeasuredHeight();
                            i7 = measuredWidth + i6;
                            i8 = i14 - fVar.bottomMargin;
                        }
                        childAt.layout(i6, measuredHeight, i7, i8);
                    } else {
                        int i15 = i5 - i3;
                        int i16 = (i15 - measuredHeight2) / 2;
                        int i17 = fVar.topMargin;
                        if (i16 < i17) {
                            i16 = i17;
                        } else {
                            int i18 = i16 + measuredHeight2;
                            int i19 = fVar.bottomMargin;
                            if (i18 > i15 - i19) {
                                i16 = (i15 - i19) - measuredHeight2;
                            }
                        }
                        childAt.layout(i6, i16, measuredWidth + i6, measuredHeight2 + i16);
                    }
                    if (z3) {
                        U(childAt, f2);
                    }
                    int i20 = fVar.f2581b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i20) {
                        childAt.setVisibility(i20);
                    }
                }
            }
        }
        if (f2538P && (a2 = getRootWindowInsets()) != null) {
            androidx.core.graphics.f h2 = C0165w0.w(a2).h();
            D.c cVar = this.f2556g;
            cVar.L(Math.max(cVar.w(), h2.f2205a));
            D.c cVar2 = this.f2557h;
            cVar2.L(Math.max(cVar2.w(), h2.f2207c));
        }
        this.f2561l = false;
        this.f2562m = false;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i2);
        int size2 = View.MeasureSpec.getSize(i3);
        if (!(mode == 1073741824 && mode2 == 1073741824)) {
            if (isInEditMode()) {
                if (mode == 0) {
                    size = 300;
                }
                if (mode2 == 0) {
                    size2 = 300;
                }
            } else {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
        }
        setMeasuredDimension(size, size2);
        boolean z2 = this.f2540B != null && W.z(this);
        int C2 = W.C(this);
        int childCount = getChildCount();
        boolean z3 = false;
        boolean z4 = false;
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                f fVar = (f) childAt.getLayoutParams();
                if (z2) {
                    int b2 = C0156s.b(fVar.f2580a, C2);
                    boolean z5 = W.z(childAt);
                    WindowInsets windowInsets = (WindowInsets) this.f2540B;
                    if (z5) {
                        if (b2 == 3) {
                            windowInsets = windowInsets.replaceSystemWindowInsets(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), 0, windowInsets.getSystemWindowInsetBottom());
                        } else if (b2 == 5) {
                            windowInsets = windowInsets.replaceSystemWindowInsets(0, windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsets);
                    } else {
                        if (b2 == 3) {
                            windowInsets = windowInsets.replaceSystemWindowInsets(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), 0, windowInsets.getSystemWindowInsetBottom());
                        } else if (b2 == 5) {
                            windowInsets = windowInsets.replaceSystemWindowInsets(0, windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
                        }
                        fVar.leftMargin = windowInsets.getSystemWindowInsetLeft();
                        fVar.topMargin = windowInsets.getSystemWindowInsetTop();
                        fVar.rightMargin = windowInsets.getSystemWindowInsetRight();
                        fVar.bottomMargin = windowInsets.getSystemWindowInsetBottom();
                    }
                }
                if (B(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - fVar.leftMargin) - fVar.rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - fVar.topMargin) - fVar.bottomMargin, 1073741824));
                } else if (E(childAt)) {
                    if (f2537O) {
                        float w2 = W.w(childAt);
                        float f2 = this.f2551b;
                        if (w2 != f2) {
                            W.x0(childAt, f2);
                        }
                    }
                    int t2 = t(childAt) & 7;
                    boolean z6 = t2 == 3;
                    if ((!z6 || !z3) && (z6 || !z4)) {
                        if (z6) {
                            z3 = true;
                        } else {
                            z4 = true;
                        }
                        childAt.measure(ViewGroup.getChildMeasureSpec(i2, this.f2552c + fVar.leftMargin + fVar.rightMargin, fVar.width), ViewGroup.getChildMeasureSpec(i3, fVar.topMargin + fVar.bottomMargin, fVar.height));
                    } else {
                        throw new IllegalStateException("Child drawer has absolute gravity " + w(t2) + " but this " + "DrawerLayout" + " already has a drawer view along that edge");
                    }
                } else {
                    throw new IllegalStateException("Child " + childAt + " at index " + i4 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                }
            }
            int i5 = i2;
            int i6 = i3;
        }
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        View n2;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.c());
        int i2 = gVar.f2584c;
        if (!(i2 == 0 || (n2 = n(i2)) == null)) {
            M(n2);
        }
        int i3 = gVar.f2585d;
        if (i3 != 3) {
            T(i3, 3);
        }
        int i4 = gVar.f2586e;
        if (i4 != 3) {
            T(i4, 5);
        }
        int i5 = gVar.f2587f;
        if (i5 != 3) {
            T(i5, 8388611);
        }
        int i6 = gVar.f2588g;
        if (i6 != 3) {
            T(i6, 8388613);
        }
    }

    public void onRtlPropertiesChanged(int i2) {
        R();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        int childCount = getChildCount();
        int i2 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            f fVar = (f) getChildAt(i2).getLayoutParams();
            int i3 = fVar.f2583d;
            boolean z2 = true;
            boolean z3 = i3 == 1;
            if (i3 != 2) {
                z2 = false;
            }
            if (z3 || z2) {
                gVar.f2584c = fVar.f2580a;
            } else {
                i2++;
            }
        }
        gVar.f2585d = this.f2563n;
        gVar.f2586e = this.f2564o;
        gVar.f2587f = this.f2565p;
        gVar.f2588g = this.f2566q;
        return gVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x005b, code lost:
        if (r(r7) != 2) goto L_0x005e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r7) {
        /*
            r6 = this;
            D.c r0 = r6.f2556g
            r0.F(r7)
            D.c r0 = r6.f2557h
            r0.F(r7)
            int r0 = r7.getAction()
            r0 = r0 & 255(0xff, float:3.57E-43)
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0062
            if (r0 == r2) goto L_0x0020
            r7 = 3
            if (r0 == r7) goto L_0x001a
            goto L_0x006f
        L_0x001a:
            r6.i(r2)
        L_0x001d:
            r6.f2567r = r1
            goto L_0x006f
        L_0x0020:
            float r0 = r7.getX()
            float r7 = r7.getY()
            D.c r3 = r6.f2556g
            int r4 = (int) r0
            int r5 = (int) r7
            android.view.View r3 = r3.t(r4, r5)
            if (r3 == 0) goto L_0x005d
            boolean r3 = r6.B(r3)
            if (r3 == 0) goto L_0x005d
            float r3 = r6.f2570u
            float r0 = r0 - r3
            float r3 = r6.f2571v
            float r7 = r7 - r3
            D.c r3 = r6.f2556g
            int r3 = r3.z()
            float r0 = r0 * r0
            float r7 = r7 * r7
            float r0 = r0 + r7
            int r3 = r3 * r3
            float r7 = (float) r3
            int r7 = (r0 > r7 ? 1 : (r0 == r7 ? 0 : -1))
            if (r7 >= 0) goto L_0x005d
            android.view.View r7 = r6.o()
            if (r7 == 0) goto L_0x005d
            int r7 = r6.r(r7)
            r0 = 2
            if (r7 != r0) goto L_0x005e
        L_0x005d:
            r1 = 1
        L_0x005e:
            r6.i(r1)
            goto L_0x006f
        L_0x0062:
            float r0 = r7.getX()
            float r7 = r7.getY()
            r6.f2570u = r0
            r6.f2571v = r7
            goto L_0x001d
        L_0x006f:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.drawerlayout.widget.DrawerLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* access modifiers changed from: package-private */
    public View p() {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (E(childAt) && G(childAt)) {
                return childAt;
            }
        }
        return null;
    }

    public int q(int i2) {
        int C2 = W.C(this);
        if (i2 == 3) {
            int i3 = this.f2563n;
            if (i3 != 3) {
                return i3;
            }
            int i4 = C2 == 0 ? this.f2565p : this.f2566q;
            if (i4 != 3) {
                return i4;
            }
            return 0;
        } else if (i2 == 5) {
            int i5 = this.f2564o;
            if (i5 != 3) {
                return i5;
            }
            int i6 = C2 == 0 ? this.f2566q : this.f2565p;
            if (i6 != 3) {
                return i6;
            }
            return 0;
        } else if (i2 == 8388611) {
            int i7 = this.f2565p;
            if (i7 != 3) {
                return i7;
            }
            int i8 = C2 == 0 ? this.f2563n : this.f2564o;
            if (i8 != 3) {
                return i8;
            }
            return 0;
        } else if (i2 != 8388613) {
            return 0;
        } else {
            int i9 = this.f2566q;
            if (i9 != 3) {
                return i9;
            }
            int i10 = C2 == 0 ? this.f2564o : this.f2563n;
            if (i10 != 3) {
                return i10;
            }
            return 0;
        }
    }

    public int r(View view) {
        if (E(view)) {
            return q(((f) view.getLayoutParams()).f2580a);
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        super.requestDisallowInterceptTouchEvent(z2);
        if (z2) {
            i(true);
        }
    }

    public void requestLayout() {
        if (!this.f2561l) {
            super.requestLayout();
        }
    }

    public CharSequence s(int i2) {
        int b2 = C0156s.b(i2, W.C(this));
        if (b2 == 3) {
            return this.f2575z;
        }
        if (b2 == 5) {
            return this.f2539A;
        }
        return null;
    }

    public void setDrawerElevation(float f2) {
        this.f2551b = f2;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (E(childAt)) {
                W.x0(childAt, this.f2551b);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(e eVar) {
        e eVar2 = this.f2568s;
        if (eVar2 != null) {
            O(eVar2);
        }
        if (eVar != null) {
            a(eVar);
        }
        this.f2568s = eVar;
    }

    public void setDrawerLockMode(int i2) {
        T(i2, 3);
        T(i2, 5);
    }

    public void setScrimColor(int i2) {
        this.f2553d = i2;
        invalidate();
    }

    public void setStatusBarBackground(int i2) {
        this.f2572w = i2 != 0 ? androidx.core.content.a.c(getContext(), i2) : null;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i2) {
        this.f2572w = new ColorDrawable(i2);
        invalidate();
    }

    /* access modifiers changed from: package-private */
    public int t(View view) {
        return C0156s.b(((f) view.getLayoutParams()).f2580a, W.C(this));
    }

    /* access modifiers changed from: package-private */
    public float u(View view) {
        return ((f) view.getLayoutParams()).f2581b;
    }

    /* JADX INFO: finally extract failed */
    public DrawerLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2550a = new d();
        this.f2553d = -1728053248;
        this.f2555f = new Paint();
        this.f2562m = true;
        this.f2563n = 3;
        this.f2564o = 3;
        this.f2565p = 3;
        this.f2566q = 3;
        this.f2542D = null;
        this.f2543E = null;
        this.f2544F = null;
        this.f2545G = null;
        this.f2549K = new a();
        setDescendantFocusability(262144);
        float f2 = getResources().getDisplayMetrics().density;
        this.f2552c = (int) ((64.0f * f2) + 0.5f);
        float f3 = f2 * 400.0f;
        i iVar = new i(3);
        this.f2558i = iVar;
        i iVar2 = new i(5);
        this.f2559j = iVar2;
        D.c n2 = D.c.n(this, 1.0f, iVar);
        this.f2556g = n2;
        n2.M(1);
        n2.N(f3);
        iVar.q(n2);
        D.c n3 = D.c.n(this, 1.0f, iVar2);
        this.f2557h = n3;
        n3.M(2);
        n3.N(f3);
        iVar2.q(n3);
        setFocusableInTouchMode(true);
        W.y0(this, 1);
        W.q0(this, new c());
        setMotionEventSplittingEnabled(false);
        if (W.z(this)) {
            setOnApplyWindowInsetsListener(new b());
            setSystemUiVisibility(1280);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(f2534L);
            try {
                this.f2572w = obtainStyledAttributes.getDrawable(0);
            } finally {
                obtainStyledAttributes.recycle();
            }
        }
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, E.c.f57b, i2, 0);
        try {
            int i3 = E.c.f58c;
            this.f2551b = obtainStyledAttributes2.hasValue(i3) ? obtainStyledAttributes2.getDimension(i3, 0.0f) : getResources().getDimension(E.b.def_drawer_elevation);
            obtainStyledAttributes2.recycle();
            this.f2546H = new ArrayList();
        } catch (Throwable th) {
            obtainStyledAttributes2.recycle();
            throw th;
        }
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof f) {
            return new f((f) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new f((ViewGroup.MarginLayoutParams) layoutParams) : new f(layoutParams);
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f2572w = drawable;
        invalidate();
    }
}
