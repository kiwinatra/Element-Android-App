package androidx.activity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import v0.a;
import w0.i;

public final class m {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f435a;

    /* renamed from: b  reason: collision with root package name */
    private final a f436b;

    /* renamed from: c  reason: collision with root package name */
    private final Object f437c = new Object();

    /* renamed from: d  reason: collision with root package name */
    private int f438d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f439e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f440f;

    /* renamed from: g  reason: collision with root package name */
    private final List f441g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    private final Runnable f442h = new l(this);

    public m(Executor executor, a aVar) {
        i.e(executor, "executor");
        i.e(aVar, "reportFullyDrawn");
        this.f435a = executor;
        this.f436b = aVar;
    }

    /* access modifiers changed from: private */
    public static final void d(m mVar) {
        i.e(mVar, "this$0");
        synchronized (mVar.f437c) {
            try {
                mVar.f439e = false;
                if (mVar.f438d == 0 && !mVar.f440f) {
                    mVar.f436b.a();
                    mVar.b();
                }
                o0.i iVar = o0.i.f5937a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.f437c) {
            try {
                this.f440f = true;
                for (a a2 : this.f441g) {
                    a2.a();
                }
                this.f441g.clear();
                o0.i iVar = o0.i.f5937a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean c() {
        boolean z2;
        synchronized (this.f437c) {
            z2 = this.f440f;
        }
        return z2;
    }
}
