package androidx.activity;

public abstract /* synthetic */ class i {
}
