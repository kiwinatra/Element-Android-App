package androidx.activity;

import v0.a;

public final /* synthetic */ class e implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComponentActivity f426a;

    public /* synthetic */ e(ComponentActivity componentActivity) {
        this.f426a = componentActivity;
    }

    public final Object a() {
        return this.f426a.K();
    }
}
