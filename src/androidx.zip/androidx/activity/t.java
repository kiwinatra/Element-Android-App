package androidx.activity;

import android.view.View;
import w0.i;

public abstract class t {
    public static final void a(View view, q qVar) {
        i.e(view, "<this>");
        i.e(qVar, "onBackPressedDispatcherOwner");
        view.setTag(r.view_tree_on_back_pressed_dispatcher_owner, qVar);
    }
}
