package androidx.activity;

public abstract class r {

    /* renamed from: a */
    public static final int report_drawn = 2131231096;

    /* renamed from: b */
    public static final int view_tree_on_back_pressed_dispatcher_owner = 2131231226;
}
