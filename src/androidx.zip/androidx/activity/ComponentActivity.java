package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.core.app.i;
import androidx.core.app.j;
import androidx.core.app.k;
import androidx.core.view.C0164w;
import androidx.core.view.C0166x;
import androidx.core.view.C0170z;
import androidx.lifecycle.A;
import androidx.lifecycle.C0189f;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.u;
import androidx.lifecycle.w;
import b.C0208a;
import b.C0209b;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import x.C0290a;

public abstract class ComponentActivity extends androidx.core.app.f implements l, E, C0189f, O.d, q, androidx.activity.result.e, androidx.core.content.c, androidx.core.content.d, i, j, C0164w, n {

    /* renamed from: c  reason: collision with root package name */
    final C0208a f359c = new C0208a();

    /* renamed from: d  reason: collision with root package name */
    private final C0166x f360d = new C0166x(new d(this));

    /* renamed from: e  reason: collision with root package name */
    private final m f361e = new m(this);

    /* renamed from: f  reason: collision with root package name */
    final O.c f362f;

    /* renamed from: g  reason: collision with root package name */
    private D f363g;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public OnBackPressedDispatcher f364h;

    /* renamed from: i  reason: collision with root package name */
    final f f365i;

    /* renamed from: j  reason: collision with root package name */
    final m f366j;

    /* renamed from: k  reason: collision with root package name */
    private int f367k;

    /* renamed from: l  reason: collision with root package name */
    private final AtomicInteger f368l;

    /* renamed from: m  reason: collision with root package name */
    private final androidx.activity.result.d f369m;

    /* renamed from: n  reason: collision with root package name */
    private final CopyOnWriteArrayList f370n;

    /* renamed from: o  reason: collision with root package name */
    private final CopyOnWriteArrayList f371o;

    /* renamed from: p  reason: collision with root package name */
    private final CopyOnWriteArrayList f372p;

    /* renamed from: q  reason: collision with root package name */
    private final CopyOnWriteArrayList f373q;

    /* renamed from: r  reason: collision with root package name */
    private final CopyOnWriteArrayList f374r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f375s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f376t;

    class a extends androidx.activity.result.d {
        a() {
        }
    }

    class b implements Runnable {
        b() {
        }

        public void run() {
            try {
                ComponentActivity.super.onBackPressed();
            } catch (IllegalStateException e2) {
                if (!TextUtils.equals(e2.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e2;
                }
            } catch (NullPointerException e3) {
                if (!TextUtils.equals(e3.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                    throw e3;
                }
            }
        }
    }

    static class c {
        static void a(View view) {
            view.cancelPendingInputEvents();
        }
    }

    static class d {
        static OnBackInvokedDispatcher a(Activity activity) {
            return activity.getOnBackInvokedDispatcher();
        }
    }

    static final class e {

        /* renamed from: a  reason: collision with root package name */
        Object f383a;

        /* renamed from: b  reason: collision with root package name */
        D f384b;

        e() {
        }
    }

    private interface f extends Executor {
        void a();

        void b(View view);
    }

    class g implements f, ViewTreeObserver.OnDrawListener, Runnable {

        /* renamed from: a  reason: collision with root package name */
        final long f385a = (SystemClock.uptimeMillis() + 10000);

        /* renamed from: b  reason: collision with root package name */
        Runnable f386b;

        /* renamed from: c  reason: collision with root package name */
        boolean f387c = false;

        g() {
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void d() {
            Runnable runnable = this.f386b;
            if (runnable != null) {
                runnable.run();
                this.f386b = null;
            }
        }

        public void a() {
            ComponentActivity.this.getWindow().getDecorView().removeCallbacks(this);
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }

        public void b(View view) {
            if (!this.f387c) {
                this.f387c = true;
                view.getViewTreeObserver().addOnDrawListener(this);
            }
        }

        public void execute(Runnable runnable) {
            this.f386b = runnable;
            View decorView = ComponentActivity.this.getWindow().getDecorView();
            if (!this.f387c) {
                decorView.postOnAnimation(new h(this));
            } else if (Looper.myLooper() == Looper.getMainLooper()) {
                decorView.invalidate();
            } else {
                decorView.postInvalidate();
            }
        }

        public void onDraw() {
            Runnable runnable = this.f386b;
            if (runnable != null) {
                runnable.run();
                this.f386b = null;
                if (!ComponentActivity.this.f366j.c()) {
                    return;
                }
            } else if (SystemClock.uptimeMillis() <= this.f385a) {
                return;
            }
            this.f387c = false;
            ComponentActivity.this.getWindow().getDecorView().post(this);
        }

        public void run() {
            ComponentActivity.this.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
        }
    }

    public ComponentActivity() {
        O.c a2 = O.c.a(this);
        this.f362f = a2;
        this.f364h = null;
        f G2 = G();
        this.f365i = G2;
        this.f366j = new m(G2, new e(this));
        this.f368l = new AtomicInteger();
        this.f369m = new a();
        this.f370n = new CopyOnWriteArrayList();
        this.f371o = new CopyOnWriteArrayList();
        this.f372p = new CopyOnWriteArrayList();
        this.f373q = new CopyOnWriteArrayList();
        this.f374r = new CopyOnWriteArrayList();
        this.f375s = false;
        this.f376t = false;
        if (v() != null) {
            int i2 = Build.VERSION.SDK_INT;
            v().a(new androidx.lifecycle.j() {
                public void d(l lVar, C0190g.a aVar) {
                    if (aVar == C0190g.a.ON_STOP) {
                        Window window = ComponentActivity.this.getWindow();
                        View peekDecorView = window != null ? window.peekDecorView() : null;
                        if (peekDecorView != null) {
                            c.a(peekDecorView);
                        }
                    }
                }
            });
            v().a(new androidx.lifecycle.j() {
                public void d(l lVar, C0190g.a aVar) {
                    if (aVar == C0190g.a.ON_DESTROY) {
                        ComponentActivity.this.f359c.b();
                        if (!ComponentActivity.this.isChangingConfigurations()) {
                            ComponentActivity.this.t().a();
                        }
                        ComponentActivity.this.f365i.a();
                    }
                }
            });
            v().a(new androidx.lifecycle.j() {
                public void d(l lVar, C0190g.a aVar) {
                    ComponentActivity.this.H();
                    ComponentActivity.this.v().c(this);
                }
            });
            a2.c();
            w.a(this);
            if (i2 <= 23) {
                v().a(new ImmLeaksCleaner(this));
            }
            e().h("android:support:activity-result", new f(this));
            E(new g(this));
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    private f G() {
        return new g();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ o0.i K() {
        reportFullyDrawn();
        return null;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Bundle L() {
        Bundle bundle = new Bundle();
        this.f369m.f(bundle);
        return bundle;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void M(Context context) {
        Bundle b2 = e().b("android:support:activity-result");
        if (b2 != null) {
            this.f369m.e(b2);
        }
    }

    public final void E(C0209b bVar) {
        this.f359c.a(bVar);
    }

    public final void F(C0290a aVar) {
        this.f372p.add(aVar);
    }

    /* access modifiers changed from: package-private */
    public void H() {
        if (this.f363g == null) {
            e eVar = (e) getLastNonConfigurationInstance();
            if (eVar != null) {
                this.f363g = eVar.f384b;
            }
            if (this.f363g == null) {
                this.f363g = new D();
            }
        }
    }

    public void I() {
        F.a(getWindow().getDecorView(), this);
        G.a(getWindow().getDecorView(), this);
        O.e.a(getWindow().getDecorView(), this);
        t.a(getWindow().getDecorView(), this);
        s.a(getWindow().getDecorView(), this);
    }

    public void J() {
        invalidateOptionsMenu();
    }

    public Object N() {
        return null;
    }

    public M.a a() {
        M.d dVar = new M.d();
        if (getApplication() != null) {
            dVar.b(A.a.f3099d, getApplication());
        }
        dVar.b(w.f3184a, this);
        dVar.b(w.f3185b, this);
        if (!(getIntent() == null || getIntent().getExtras() == null)) {
            dVar.b(w.f3186c, getIntent().getExtras());
        }
        return dVar;
    }

    public final void b(C0290a aVar) {
        this.f374r.add(aVar);
    }

    public final void c(C0290a aVar) {
        this.f373q.add(aVar);
    }

    public final OnBackPressedDispatcher d() {
        if (this.f364h == null) {
            this.f364h = new OnBackPressedDispatcher(new b());
            v().a(new androidx.lifecycle.j() {
                public void d(l lVar, C0190g.a aVar) {
                    if (aVar == C0190g.a.ON_CREATE && Build.VERSION.SDK_INT >= 33) {
                        ComponentActivity.this.f364h.n(d.a((ComponentActivity) lVar));
                    }
                }
            });
        }
        return this.f364h;
    }

    public final androidx.savedstate.a e() {
        return this.f362f.b();
    }

    public void f(C0170z zVar) {
        this.f360d.f(zVar);
    }

    public final void g(C0290a aVar) {
        this.f373q.remove(aVar);
    }

    public void h(C0170z zVar) {
        this.f360d.a(zVar);
    }

    public final void i(C0290a aVar) {
        this.f374r.remove(aVar);
    }

    public final void j(C0290a aVar) {
        this.f371o.remove(aVar);
    }

    public final androidx.activity.result.d k() {
        return this.f369m;
    }

    public final void l(C0290a aVar) {
        this.f371o.add(aVar);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i2, int i3, Intent intent) {
        if (!this.f369m.b(i2, i3, intent)) {
            super.onActivityResult(i2, i3, intent);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f370n.iterator();
        while (it.hasNext()) {
            ((C0290a) it.next()).a(configuration);
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        this.f362f.d(bundle);
        this.f359c.c(this);
        super.onCreate(bundle);
        u.e(this);
        int i2 = this.f367k;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    public boolean onCreatePanelMenu(int i2, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i2, menu);
        this.f360d.b(menu, getMenuInflater());
        return true;
    }

    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            return this.f360d.d(menuItem);
        }
        return false;
    }

    public void onMultiWindowModeChanged(boolean z2) {
        if (!this.f375s) {
            Iterator it = this.f373q.iterator();
            while (it.hasNext()) {
                ((C0290a) it.next()).a(new androidx.core.app.g(z2));
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f372p.iterator();
        while (it.hasNext()) {
            ((C0290a) it.next()).a(intent);
        }
    }

    public void onPanelClosed(int i2, Menu menu) {
        this.f360d.c(menu);
        super.onPanelClosed(i2, menu);
    }

    public void onPictureInPictureModeChanged(boolean z2) {
        if (!this.f376t) {
            Iterator it = this.f374r.iterator();
            while (it.hasNext()) {
                ((C0290a) it.next()).a(new k(z2));
            }
        }
    }

    public boolean onPreparePanel(int i2, View view, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onPreparePanel(i2, view, menu);
        this.f360d.e(menu);
        return true;
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (!this.f369m.b(i2, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr)) && Build.VERSION.SDK_INT >= 23) {
            super.onRequestPermissionsResult(i2, strArr, iArr);
        }
    }

    public final Object onRetainNonConfigurationInstance() {
        e eVar;
        Object N2 = N();
        D d2 = this.f363g;
        if (d2 == null && (eVar = (e) getLastNonConfigurationInstance()) != null) {
            d2 = eVar.f384b;
        }
        if (d2 == null && N2 == null) {
            return null;
        }
        e eVar2 = new e();
        eVar2.f383a = N2;
        eVar2.f384b = d2;
        return eVar2;
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        C0190g v2 = v();
        if (v2 instanceof m) {
            ((m) v2).m(C0190g.b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f362f.e(bundle);
    }

    public void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        Iterator it = this.f371o.iterator();
        while (it.hasNext()) {
            ((C0290a) it.next()).a(Integer.valueOf(i2));
        }
    }

    public final void p(C0290a aVar) {
        this.f370n.add(aVar);
    }

    public final void r(C0290a aVar) {
        this.f370n.remove(aVar);
    }

    public void reportFullyDrawn() {
        try {
            if (Q.b.d()) {
                Q.b.a("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            this.f366j.b();
            Q.b.b();
        } catch (Throwable th) {
            Q.b.b();
            throw th;
        }
    }

    public abstract void setContentView(int i2);

    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        I();
        this.f365i.b(getWindow().getDecorView());
        super.setContentView(view);
    }

    public void startActivityForResult(Intent intent, int i2) {
        super.startActivityForResult(intent, i2);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5) {
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
    }

    public D t() {
        if (getApplication() != null) {
            H();
            return this.f363g;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public C0190g v() {
        return this.f361e;
    }

    /* JADX INFO: finally extract failed */
    public void onMultiWindowModeChanged(boolean z2, Configuration configuration) {
        this.f375s = true;
        try {
            super.onMultiWindowModeChanged(z2, configuration);
            this.f375s = false;
            Iterator it = this.f373q.iterator();
            while (it.hasNext()) {
                ((C0290a) it.next()).a(new androidx.core.app.g(z2, configuration));
            }
        } catch (Throwable th) {
            this.f375s = false;
            throw th;
        }
    }

    /* JADX INFO: finally extract failed */
    public void onPictureInPictureModeChanged(boolean z2, Configuration configuration) {
        this.f376t = true;
        try {
            super.onPictureInPictureModeChanged(z2, configuration);
            this.f376t = false;
            Iterator it = this.f374r.iterator();
            while (it.hasNext()) {
                ((C0290a) it.next()).a(new k(z2, configuration));
            }
        } catch (Throwable th) {
            this.f376t = false;
            throw th;
        }
    }

    public void startActivityForResult(Intent intent, int i2, Bundle bundle) {
        super.startActivityForResult(intent, i2, bundle);
    }

    public void startIntentSenderForResult(IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) {
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
    }
}
