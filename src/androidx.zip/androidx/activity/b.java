package androidx.activity;

import w0.e;

public final class b {

    /* renamed from: e  reason: collision with root package name */
    public static final a f420e = new a((e) null);

    /* renamed from: a  reason: collision with root package name */
    private final float f421a;

    /* renamed from: b  reason: collision with root package name */
    private final float f422b;

    /* renamed from: c  reason: collision with root package name */
    private final float f423c;

    /* renamed from: d  reason: collision with root package name */
    private final int f424d;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(e eVar) {
            this();
        }
    }

    public b(float f2, float f3, float f4, int i2) {
        this.f421a = f2;
        this.f422b = f3;
        this.f423c = f4;
        this.f424d = i2;
    }

    public final float a() {
        return this.f423c;
    }

    public final int b() {
        return this.f424d;
    }

    public String toString() {
        return "BackEventCompat{touchX=" + this.f421a + ", touchY=" + this.f422b + ", progress=" + this.f423c + ", swipeEdge=" + this.f424d + '}';
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public b(android.window.BackEvent r5) {
        /*
            r4 = this;
            java.lang.String r0 = "backEvent"
            w0.i.e(r5, r0)
            androidx.activity.a r0 = androidx.activity.a.f419a
            float r1 = r0.d(r5)
            float r2 = r0.e(r5)
            float r3 = r0.b(r5)
            int r5 = r0.c(r5)
            r4.<init>(r1, r2, r3, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.b.<init>(android.window.BackEvent):void");
    }
}
