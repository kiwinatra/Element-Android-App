package androidx.activity;

import android.os.Bundle;
import androidx.savedstate.a;

public final /* synthetic */ class f implements a.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComponentActivity f427a;

    public /* synthetic */ f(ComponentActivity componentActivity) {
        this.f427a = componentActivity;
    }

    public final Bundle a() {
        return this.f427a.L();
    }
}
