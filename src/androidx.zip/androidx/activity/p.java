package androidx.activity;

import android.window.OnBackInvokedCallback;
import androidx.activity.OnBackPressedDispatcher;
import v0.a;

public final /* synthetic */ class p implements OnBackInvokedCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f446a;

    public /* synthetic */ p(a aVar) {
        this.f446a = aVar;
    }

    public final void onBackInvoked() {
        OnBackPressedDispatcher.f.c(this.f446a);
    }
}
