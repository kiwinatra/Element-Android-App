package androidx.activity;

import O.c;
import O.d;
import O.e;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.F;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.savedstate.a;
import w0.i;

public class k extends Dialog implements l, q, d {

    /* renamed from: a  reason: collision with root package name */
    private m f431a;

    /* renamed from: b  reason: collision with root package name */
    private final c f432b = c.f156d.a(this);

    /* renamed from: c  reason: collision with root package name */
    private final OnBackPressedDispatcher f433c = new OnBackPressedDispatcher(new j(this));

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k(Context context, int i2) {
        super(context, i2);
        i.e(context, "context");
    }

    private final m b() {
        m mVar = this.f431a;
        if (mVar != null) {
            return mVar;
        }
        m mVar2 = new m(this);
        this.f431a = mVar2;
        return mVar2;
    }

    /* access modifiers changed from: private */
    public static final void f(k kVar) {
        i.e(kVar, "this$0");
        super.onBackPressed();
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        i.e(view, "view");
        c();
        super.addContentView(view, layoutParams);
    }

    public void c() {
        Window window = getWindow();
        i.b(window);
        View decorView = window.getDecorView();
        i.d(decorView, "window!!.decorView");
        F.a(decorView, this);
        Window window2 = getWindow();
        i.b(window2);
        View decorView2 = window2.getDecorView();
        i.d(decorView2, "window!!.decorView");
        t.a(decorView2, this);
        Window window3 = getWindow();
        i.b(window3);
        View decorView3 = window3.getDecorView();
        i.d(decorView3, "window!!.decorView");
        e.a(decorView3, this);
    }

    public final OnBackPressedDispatcher d() {
        return this.f433c;
    }

    public a e() {
        return this.f432b.b();
    }

    public void onBackPressed() {
        this.f433c.k();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackPressedDispatcher onBackPressedDispatcher = this.f433c;
            OnBackInvokedDispatcher a2 = getOnBackInvokedDispatcher();
            i.d(a2, "onBackInvokedDispatcher");
            onBackPressedDispatcher.n(a2);
        }
        this.f432b.d(bundle);
        b().h(C0190g.a.ON_CREATE);
    }

    public Bundle onSaveInstanceState() {
        Bundle onSaveInstanceState = super.onSaveInstanceState();
        i.d(onSaveInstanceState, "super.onSaveInstanceState()");
        this.f432b.e(onSaveInstanceState);
        return onSaveInstanceState;
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        b().h(C0190g.a.ON_RESUME);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        b().h(C0190g.a.ON_DESTROY);
        this.f431a = null;
        super.onStop();
    }

    public void setContentView(int i2) {
        c();
        super.setContentView(i2);
    }

    public C0190g v() {
        return b();
    }

    public void setContentView(View view) {
        i.e(view, "view");
        c();
        super.setContentView(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        i.e(view, "view");
        c();
        super.setContentView(view, layoutParams);
    }
}
