package androidx.activity;

import android.content.Context;
import b.C0209b;

public final /* synthetic */ class g implements C0209b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComponentActivity f428a;

    public /* synthetic */ g(ComponentActivity componentActivity) {
        this.f428a = componentActivity;
    }

    public final void a(Context context) {
        this.f428a.M(context);
    }
}
