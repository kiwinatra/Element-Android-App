package androidx.activity;

public final /* synthetic */ class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k f430a;

    public /* synthetic */ j(k kVar) {
        this.f430a = kVar;
    }

    public final void run() {
        k.f(this.f430a);
    }
}
