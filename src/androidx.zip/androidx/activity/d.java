package androidx.activity;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComponentActivity f425a;

    public /* synthetic */ d(ComponentActivity componentActivity) {
        this.f425a = componentActivity;
    }

    public final void run() {
        this.f425a.J();
    }
}
