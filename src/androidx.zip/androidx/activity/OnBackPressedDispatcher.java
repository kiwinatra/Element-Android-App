package androidx.activity;

import android.os.Build;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.l;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import p0.C0270d;
import x.C0290a;

public final class OnBackPressedDispatcher {

    /* renamed from: a  reason: collision with root package name */
    private final Runnable f394a;

    /* renamed from: b  reason: collision with root package name */
    private final C0290a f395b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final C0270d f396c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public o f397d;

    /* renamed from: e  reason: collision with root package name */
    private OnBackInvokedCallback f398e;

    /* renamed from: f  reason: collision with root package name */
    private OnBackInvokedDispatcher f399f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f400g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f401h;

    private final class LifecycleOnBackPressedCancellable implements androidx.lifecycle.j, c {

        /* renamed from: a  reason: collision with root package name */
        private final C0190g f402a;

        /* renamed from: b  reason: collision with root package name */
        private final o f403b;

        /* renamed from: c  reason: collision with root package name */
        private c f404c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f405d;

        public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher onBackPressedDispatcher, C0190g gVar, o oVar) {
            w0.i.e(gVar, "lifecycle");
            w0.i.e(oVar, "onBackPressedCallback");
            this.f405d = onBackPressedDispatcher;
            this.f402a = gVar;
            this.f403b = oVar;
            gVar.a(this);
        }

        public void cancel() {
            this.f402a.c(this);
            this.f403b.i(this);
            c cVar = this.f404c;
            if (cVar != null) {
                cVar.cancel();
            }
            this.f404c = null;
        }

        public void d(l lVar, C0190g.a aVar) {
            w0.i.e(lVar, "source");
            w0.i.e(aVar, "event");
            if (aVar == C0190g.a.ON_START) {
                this.f404c = this.f405d.i(this.f403b);
            } else if (aVar == C0190g.a.ON_STOP) {
                c cVar = this.f404c;
                if (cVar != null) {
                    cVar.cancel();
                }
            } else if (aVar == C0190g.a.ON_DESTROY) {
                cancel();
            }
        }
    }

    static final class a extends w0.j implements v0.l {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f406b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(OnBackPressedDispatcher onBackPressedDispatcher) {
            super(1);
            this.f406b = onBackPressedDispatcher;
        }

        public /* bridge */ /* synthetic */ Object b(Object obj) {
            c((b) obj);
            return o0.i.f5937a;
        }

        public final void c(b bVar) {
            w0.i.e(bVar, "backEvent");
            this.f406b.m(bVar);
        }
    }

    static final class b extends w0.j implements v0.l {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f407b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(OnBackPressedDispatcher onBackPressedDispatcher) {
            super(1);
            this.f407b = onBackPressedDispatcher;
        }

        public /* bridge */ /* synthetic */ Object b(Object obj) {
            c((b) obj);
            return o0.i.f5937a;
        }

        public final void c(b bVar) {
            w0.i.e(bVar, "backEvent");
            this.f407b.l(bVar);
        }
    }

    static final class c extends w0.j implements v0.a {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f408b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(OnBackPressedDispatcher onBackPressedDispatcher) {
            super(0);
            this.f408b = onBackPressedDispatcher;
        }

        public /* bridge */ /* synthetic */ Object a() {
            c();
            return o0.i.f5937a;
        }

        public final void c() {
            this.f408b.k();
        }
    }

    static final class d extends w0.j implements v0.a {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f409b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        d(OnBackPressedDispatcher onBackPressedDispatcher) {
            super(0);
            this.f409b = onBackPressedDispatcher;
        }

        public /* bridge */ /* synthetic */ Object a() {
            c();
            return o0.i.f5937a;
        }

        public final void c() {
            this.f409b.j();
        }
    }

    static final class e extends w0.j implements v0.a {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f410b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        e(OnBackPressedDispatcher onBackPressedDispatcher) {
            super(0);
            this.f410b = onBackPressedDispatcher;
        }

        public /* bridge */ /* synthetic */ Object a() {
            c();
            return o0.i.f5937a;
        }

        public final void c() {
            this.f410b.k();
        }
    }

    public static final class f {

        /* renamed from: a  reason: collision with root package name */
        public static final f f411a = new f();

        private f() {
        }

        /* access modifiers changed from: private */
        public static final void c(v0.a aVar) {
            w0.i.e(aVar, "$onBackInvoked");
            aVar.a();
        }

        public final OnBackInvokedCallback b(v0.a aVar) {
            w0.i.e(aVar, "onBackInvoked");
            return new p(aVar);
        }

        public final void d(Object obj, int i2, Object obj2) {
            w0.i.e(obj, "dispatcher");
            w0.i.e(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i2, (OnBackInvokedCallback) obj2);
        }

        public final void e(Object obj, Object obj2) {
            w0.i.e(obj, "dispatcher");
            w0.i.e(obj2, "callback");
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    public static final class g {

        /* renamed from: a  reason: collision with root package name */
        public static final g f412a = new g();

        public static final class a implements OnBackAnimationCallback {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ v0.l f413a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ v0.l f414b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ v0.a f415c;

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ v0.a f416d;

            a(v0.l lVar, v0.l lVar2, v0.a aVar, v0.a aVar2) {
                this.f413a = lVar;
                this.f414b = lVar2;
                this.f415c = aVar;
                this.f416d = aVar2;
            }

            public void onBackCancelled() {
                this.f416d.a();
            }

            public void onBackInvoked() {
                this.f415c.a();
            }

            public void onBackProgressed(BackEvent backEvent) {
                w0.i.e(backEvent, "backEvent");
                this.f414b.b(new b(backEvent));
            }

            public void onBackStarted(BackEvent backEvent) {
                w0.i.e(backEvent, "backEvent");
                this.f413a.b(new b(backEvent));
            }
        }

        private g() {
        }

        public final OnBackInvokedCallback a(v0.l lVar, v0.l lVar2, v0.a aVar, v0.a aVar2) {
            w0.i.e(lVar, "onBackStarted");
            w0.i.e(lVar2, "onBackProgressed");
            w0.i.e(aVar, "onBackInvoked");
            w0.i.e(aVar2, "onBackCancelled");
            return new a(lVar, lVar2, aVar, aVar2);
        }
    }

    private final class h implements c {

        /* renamed from: a  reason: collision with root package name */
        private final o f417a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f418b;

        public h(OnBackPressedDispatcher onBackPressedDispatcher, o oVar) {
            w0.i.e(oVar, "onBackPressedCallback");
            this.f418b = onBackPressedDispatcher;
            this.f417a = oVar;
        }

        public void cancel() {
            this.f418b.f396c.remove(this.f417a);
            if (w0.i.a(this.f418b.f397d, this.f417a)) {
                this.f417a.c();
                this.f418b.f397d = null;
            }
            this.f417a.i(this);
            v0.a b2 = this.f417a.b();
            if (b2 != null) {
                b2.a();
            }
            this.f417a.k((v0.a) null);
        }
    }

    /* synthetic */ class i extends w0.h implements v0.a {
        i(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        public /* bridge */ /* synthetic */ Object a() {
            h();
            return o0.i.f5937a;
        }

        public final void h() {
            ((OnBackPressedDispatcher) this.f6307b).p();
        }
    }

    /* synthetic */ class j extends w0.h implements v0.a {
        j(Object obj) {
            super(0, obj, OnBackPressedDispatcher.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0);
        }

        public /* bridge */ /* synthetic */ Object a() {
            h();
            return o0.i.f5937a;
        }

        public final void h() {
            ((OnBackPressedDispatcher) this.f6307b).p();
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this(runnable, (C0290a) null);
    }

    /* access modifiers changed from: private */
    public final void j() {
        Object obj;
        C0270d dVar = this.f396c;
        ListIterator listIterator = dVar.listIterator(dVar.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            }
            obj = listIterator.previous();
            if (((o) obj).g()) {
                break;
            }
        }
        o oVar = (o) obj;
        this.f397d = null;
        if (oVar != null) {
            oVar.c();
        }
    }

    /* access modifiers changed from: private */
    public final void l(b bVar) {
        Object obj;
        C0270d dVar = this.f396c;
        ListIterator listIterator = dVar.listIterator(dVar.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            }
            obj = listIterator.previous();
            if (((o) obj).g()) {
                break;
            }
        }
        o oVar = (o) obj;
        if (oVar != null) {
            oVar.e(bVar);
        }
    }

    /* access modifiers changed from: private */
    public final void m(b bVar) {
        Object obj;
        C0270d dVar = this.f396c;
        ListIterator listIterator = dVar.listIterator(dVar.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            }
            obj = listIterator.previous();
            if (((o) obj).g()) {
                break;
            }
        }
        o oVar = (o) obj;
        this.f397d = oVar;
        if (oVar != null) {
            oVar.f(bVar);
        }
    }

    private final void o(boolean z2) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f399f;
        OnBackInvokedCallback onBackInvokedCallback = this.f398e;
        if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
            if (z2 && !this.f400g) {
                f.f411a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
                this.f400g = true;
            } else if (!z2 && this.f400g) {
                f.f411a.e(onBackInvokedDispatcher, onBackInvokedCallback);
                this.f400g = false;
            }
        }
    }

    /* access modifiers changed from: private */
    public final void p() {
        boolean z2 = this.f401h;
        C0270d dVar = this.f396c;
        boolean z3 = false;
        if (!(dVar instanceof Collection) || !dVar.isEmpty()) {
            Iterator it = dVar.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((o) it.next()).g()) {
                        z3 = true;
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        this.f401h = z3;
        if (z3 != z2) {
            C0290a aVar = this.f395b;
            if (aVar != null) {
                aVar.a(Boolean.valueOf(z3));
            }
            if (Build.VERSION.SDK_INT >= 33) {
                o(z3);
            }
        }
    }

    public final void h(l lVar, o oVar) {
        w0.i.e(lVar, "owner");
        w0.i.e(oVar, "onBackPressedCallback");
        C0190g v2 = lVar.v();
        if (v2.b() != C0190g.b.DESTROYED) {
            oVar.a(new LifecycleOnBackPressedCancellable(this, v2, oVar));
            p();
            oVar.k(new i(this));
        }
    }

    public final c i(o oVar) {
        w0.i.e(oVar, "onBackPressedCallback");
        this.f396c.add(oVar);
        h hVar = new h(this, oVar);
        oVar.a(hVar);
        p();
        oVar.k(new j(this));
        return hVar;
    }

    public final void k() {
        Object obj;
        C0270d dVar = this.f396c;
        ListIterator listIterator = dVar.listIterator(dVar.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                obj = null;
                break;
            }
            obj = listIterator.previous();
            if (((o) obj).g()) {
                break;
            }
        }
        o oVar = (o) obj;
        this.f397d = null;
        if (oVar != null) {
            oVar.d();
            return;
        }
        Runnable runnable = this.f394a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void n(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        w0.i.e(onBackInvokedDispatcher, "invoker");
        this.f399f = onBackInvokedDispatcher;
        o(this.f401h);
    }

    public OnBackPressedDispatcher(Runnable runnable, C0290a aVar) {
        this.f394a = runnable;
        this.f395b = aVar;
        this.f396c = new C0270d();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33) {
            this.f398e = i2 >= 34 ? g.f412a.a(new a(this), new b(this), new c(this), new d(this)) : f.f411a.b(new e(this));
        }
    }
}
