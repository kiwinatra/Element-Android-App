package androidx.activity.result;

public interface b {
    void a(Object obj);
}
