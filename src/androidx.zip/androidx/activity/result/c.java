package androidx.activity.result;

public abstract class c {
    public abstract void a();
}
