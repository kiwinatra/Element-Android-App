package androidx.activity.result;

import androidx.activity.result.d;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.j;
import androidx.lifecycle.l;
import c.C0211a;

class ActivityResultRegistry$1 implements j {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ String f447a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ b f448b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ C0211a f449c;

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ d f450d;

    public void d(l lVar, C0190g.a aVar) {
        if (C0190g.a.ON_START.equals(aVar)) {
            this.f450d.f457e.put(this.f447a, new d.b(this.f448b, this.f449c));
            if (this.f450d.f458f.containsKey(this.f447a)) {
                Object obj = this.f450d.f458f.get(this.f447a);
                this.f450d.f458f.remove(this.f447a);
                this.f448b.a(obj);
            }
            a aVar2 = (a) this.f450d.f459g.getParcelable(this.f447a);
            if (aVar2 != null) {
                this.f450d.f459g.remove(this.f447a);
                this.f448b.a(this.f449c.a(aVar2.d(), aVar2.c()));
            }
        } else if (C0190g.a.ON_STOP.equals(aVar)) {
            this.f450d.f457e.remove(this.f447a);
        } else if (C0190g.a.ON_DESTROY.equals(aVar)) {
            this.f450d.i(this.f447a);
        }
    }
}
