package androidx.activity.result;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

public final class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = new C0013a();

    /* renamed from: a  reason: collision with root package name */
    private final int f451a;

    /* renamed from: b  reason: collision with root package name */
    private final Intent f452b;

    /* renamed from: androidx.activity.result.a$a  reason: collision with other inner class name */
    class C0013a implements Parcelable.Creator {
        C0013a() {
        }

        /* renamed from: a */
        public a createFromParcel(Parcel parcel) {
            return new a(parcel);
        }

        /* renamed from: b */
        public a[] newArray(int i2) {
            return new a[i2];
        }
    }

    public a(int i2, Intent intent) {
        this.f451a = i2;
        this.f452b = intent;
    }

    public static String e(int i2) {
        if (i2 != -1) {
            return i2 != 0 ? String.valueOf(i2) : "RESULT_CANCELED";
        }
        return "RESULT_OK";
    }

    public Intent c() {
        return this.f452b;
    }

    public int d() {
        return this.f451a;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return "ActivityResult{resultCode=" + e(this.f451a) + ", data=" + this.f452b + '}';
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f451a);
        parcel.writeInt(this.f452b == null ? 0 : 1);
        Intent intent = this.f452b;
        if (intent != null) {
            intent.writeToParcel(parcel, i2);
        }
    }

    a(Parcel parcel) {
        this.f451a = parcel.readInt();
        this.f452b = parcel.readInt() == 0 ? null : (Intent) Intent.CREATOR.createFromParcel(parcel);
    }
}
