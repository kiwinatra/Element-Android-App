package androidx.activity.result;

public interface e {
    d k();
}
