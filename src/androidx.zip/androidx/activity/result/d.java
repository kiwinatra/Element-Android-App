package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import c.C0211a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import x0.c;

public abstract class d {

    /* renamed from: a  reason: collision with root package name */
    private final Map f453a = new HashMap();

    /* renamed from: b  reason: collision with root package name */
    final Map f454b = new HashMap();

    /* renamed from: c  reason: collision with root package name */
    private final Map f455c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    ArrayList f456d = new ArrayList();

    /* renamed from: e  reason: collision with root package name */
    final transient Map f457e = new HashMap();

    /* renamed from: f  reason: collision with root package name */
    final Map f458f = new HashMap();

    /* renamed from: g  reason: collision with root package name */
    final Bundle f459g = new Bundle();

    class a extends c {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f460a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ C0211a f461b;

        a(String str, C0211a aVar) {
            this.f460a = str;
            this.f461b = aVar;
        }

        public void a() {
            d.this.i(this.f460a);
        }
    }

    private static class b {

        /* renamed from: a  reason: collision with root package name */
        final b f463a;

        /* renamed from: b  reason: collision with root package name */
        final C0211a f464b;

        b(b bVar, C0211a aVar) {
            this.f463a = bVar;
            this.f464b = aVar;
        }
    }

    private void a(int i2, String str) {
        this.f453a.put(Integer.valueOf(i2), str);
        this.f454b.put(str, Integer.valueOf(i2));
    }

    private void c(String str, int i2, Intent intent, b bVar) {
        if (bVar == null || bVar.f463a == null || !this.f456d.contains(str)) {
            this.f458f.remove(str);
            this.f459g.putParcelable(str, new a(i2, intent));
            return;
        }
        bVar.f463a.a(bVar.f464b.a(i2, intent));
        this.f456d.remove(str);
    }

    private int d() {
        int b2 = c.f6334a.b(2147418112);
        while (true) {
            int i2 = b2 + 65536;
            if (!this.f453a.containsKey(Integer.valueOf(i2))) {
                return i2;
            }
            b2 = c.f6334a.b(2147418112);
        }
    }

    private void h(String str) {
        if (((Integer) this.f454b.get(str)) == null) {
            a(d(), str);
        }
    }

    public final boolean b(int i2, int i3, Intent intent) {
        String str = (String) this.f453a.get(Integer.valueOf(i2));
        if (str == null) {
            return false;
        }
        c(str, i3, intent, (b) this.f457e.get(str));
        return true;
    }

    public final void e(Bundle bundle) {
        if (bundle != null) {
            ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                this.f456d = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                this.f459g.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
                for (int i2 = 0; i2 < stringArrayList.size(); i2++) {
                    String str = stringArrayList.get(i2);
                    if (this.f454b.containsKey(str)) {
                        Integer num = (Integer) this.f454b.remove(str);
                        if (!this.f459g.containsKey(str)) {
                            this.f453a.remove(num);
                        }
                    }
                    a(integerArrayList.get(i2).intValue(), stringArrayList.get(i2));
                }
            }
        }
    }

    public final void f(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.f454b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.f454b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.f456d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.f459g.clone());
    }

    public final c g(String str, C0211a aVar, b bVar) {
        h(str);
        this.f457e.put(str, new b(bVar, aVar));
        if (this.f458f.containsKey(str)) {
            Object obj = this.f458f.get(str);
            this.f458f.remove(str);
            bVar.a(obj);
        }
        a aVar2 = (a) this.f459g.getParcelable(str);
        if (aVar2 != null) {
            this.f459g.remove(str);
            bVar.a(aVar.a(aVar2.d(), aVar2.c()));
        }
        return new a(str, aVar);
    }

    /* access modifiers changed from: package-private */
    public final void i(String str) {
        Integer num;
        if (!this.f456d.contains(str) && (num = (Integer) this.f454b.remove(str)) != null) {
            this.f453a.remove(num);
        }
        this.f457e.remove(str);
        if (this.f458f.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f458f.get(str));
            this.f458f.remove(str);
        }
        if (this.f459g.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f459g.getParcelable(str));
            this.f459g.remove(str);
        }
        android.support.v4.media.session.b.a(this.f455c.get(str));
    }
}
