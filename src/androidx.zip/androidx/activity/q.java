package androidx.activity;

import androidx.lifecycle.l;

public interface q extends l {
    OnBackPressedDispatcher d();
}
