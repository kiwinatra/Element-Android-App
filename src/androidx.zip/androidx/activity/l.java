package androidx.activity;

public final /* synthetic */ class l implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m f434a;

    public /* synthetic */ l(m mVar) {
        this.f434a = mVar;
    }

    public final void run() {
        m.d(this.f434a);
    }
}
