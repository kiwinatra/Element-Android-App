package androidx.activity;

import android.view.View;
import w0.i;

public abstract class s {
    public static final void a(View view, n nVar) {
        i.e(view, "<this>");
        i.e(nVar, "fullyDrawnReporterOwner");
        view.setTag(r.report_drawn, nVar);
    }
}
