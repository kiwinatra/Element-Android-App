package androidx.activity;

import androidx.activity.ComponentActivity;

public final /* synthetic */ class h implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ComponentActivity.g f429a;

    public /* synthetic */ h(ComponentActivity.g gVar) {
        this.f429a = gVar;
    }

    public final void run() {
        this.f429a.d();
    }
}
