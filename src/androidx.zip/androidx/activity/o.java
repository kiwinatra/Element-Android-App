package androidx.activity;

import java.util.concurrent.CopyOnWriteArrayList;
import v0.a;
import w0.i;

public abstract class o {

    /* renamed from: a  reason: collision with root package name */
    private boolean f443a;

    /* renamed from: b  reason: collision with root package name */
    private final CopyOnWriteArrayList f444b = new CopyOnWriteArrayList();

    /* renamed from: c  reason: collision with root package name */
    private a f445c;

    public o(boolean z2) {
        this.f443a = z2;
    }

    public final void a(c cVar) {
        i.e(cVar, "cancellable");
        this.f444b.add(cVar);
    }

    public final a b() {
        return this.f445c;
    }

    public void c() {
    }

    public abstract void d();

    public void e(b bVar) {
        i.e(bVar, "backEvent");
    }

    public void f(b bVar) {
        i.e(bVar, "backEvent");
    }

    public final boolean g() {
        return this.f443a;
    }

    public final void h() {
        for (c cancel : this.f444b) {
            cancel.cancel();
        }
    }

    public final void i(c cVar) {
        i.e(cVar, "cancellable");
        this.f444b.remove(cVar);
    }

    public final void j(boolean z2) {
        this.f443a = z2;
        a aVar = this.f445c;
        if (aVar != null) {
            aVar.a();
        }
    }

    public final void k(a aVar) {
        this.f445c = aVar;
    }
}
