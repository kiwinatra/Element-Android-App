package androidx.concurrent.futures;

public final class c extends a {
    private c() {
    }

    public static c o() {
        return new c();
    }

    public boolean m(Object obj) {
        return super.m(obj);
    }
}
