package androidx.concurrent.futures;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a implements Future {

    /* renamed from: d  reason: collision with root package name */
    static final boolean f1632d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* renamed from: e  reason: collision with root package name */
    private static final Logger f1633e;

    /* renamed from: f  reason: collision with root package name */
    static final b f1634f;

    /* renamed from: g  reason: collision with root package name */
    private static final Object f1635g = new Object();

    /* renamed from: a  reason: collision with root package name */
    volatile Object f1636a;

    /* renamed from: b  reason: collision with root package name */
    volatile e f1637b;

    /* renamed from: c  reason: collision with root package name */
    volatile h f1638c;

    private static abstract class b {
        private b() {
        }

        /* access modifiers changed from: package-private */
        public abstract boolean a(a aVar, e eVar, e eVar2);

        /* access modifiers changed from: package-private */
        public abstract boolean b(a aVar, Object obj, Object obj2);

        /* access modifiers changed from: package-private */
        public abstract boolean c(a aVar, h hVar, h hVar2);

        /* access modifiers changed from: package-private */
        public abstract void d(h hVar, h hVar2);

        /* access modifiers changed from: package-private */
        public abstract void e(h hVar, Thread thread);
    }

    private static final class c {

        /* renamed from: c  reason: collision with root package name */
        static final c f1639c;

        /* renamed from: d  reason: collision with root package name */
        static final c f1640d;

        /* renamed from: a  reason: collision with root package name */
        final boolean f1641a;

        /* renamed from: b  reason: collision with root package name */
        final Throwable f1642b;

        static {
            if (a.f1632d) {
                f1640d = null;
                f1639c = null;
                return;
            }
            f1640d = new c(false, (Throwable) null);
            f1639c = new c(true, (Throwable) null);
        }

        c(boolean z2, Throwable th) {
            this.f1641a = z2;
            this.f1642b = th;
        }
    }

    private static final class d {

        /* renamed from: a  reason: collision with root package name */
        final Throwable f1643a;
    }

    private static final class e {

        /* renamed from: d  reason: collision with root package name */
        static final e f1644d = new e((Runnable) null, (Executor) null);

        /* renamed from: a  reason: collision with root package name */
        final Runnable f1645a;

        /* renamed from: b  reason: collision with root package name */
        final Executor f1646b;

        /* renamed from: c  reason: collision with root package name */
        e f1647c;

        e(Runnable runnable, Executor executor) {
            this.f1645a = runnable;
            this.f1646b = executor;
        }
    }

    private static final class f extends b {

        /* renamed from: a  reason: collision with root package name */
        final AtomicReferenceFieldUpdater f1648a;

        /* renamed from: b  reason: collision with root package name */
        final AtomicReferenceFieldUpdater f1649b;

        /* renamed from: c  reason: collision with root package name */
        final AtomicReferenceFieldUpdater f1650c;

        /* renamed from: d  reason: collision with root package name */
        final AtomicReferenceFieldUpdater f1651d;

        /* renamed from: e  reason: collision with root package name */
        final AtomicReferenceFieldUpdater f1652e;

        f(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
            super();
            this.f1648a = atomicReferenceFieldUpdater;
            this.f1649b = atomicReferenceFieldUpdater2;
            this.f1650c = atomicReferenceFieldUpdater3;
            this.f1651d = atomicReferenceFieldUpdater4;
            this.f1652e = atomicReferenceFieldUpdater5;
        }

        /* access modifiers changed from: package-private */
        public boolean a(a aVar, e eVar, e eVar2) {
            return b.a(this.f1651d, aVar, eVar, eVar2);
        }

        /* access modifiers changed from: package-private */
        public boolean b(a aVar, Object obj, Object obj2) {
            return b.a(this.f1652e, aVar, obj, obj2);
        }

        /* access modifiers changed from: package-private */
        public boolean c(a aVar, h hVar, h hVar2) {
            return b.a(this.f1650c, aVar, hVar, hVar2);
        }

        /* access modifiers changed from: package-private */
        public void d(h hVar, h hVar2) {
            this.f1649b.lazySet(hVar, hVar2);
        }

        /* access modifiers changed from: package-private */
        public void e(h hVar, Thread thread) {
            this.f1648a.lazySet(hVar, thread);
        }
    }

    private static final class g extends b {
        g() {
            super();
        }

        /* access modifiers changed from: package-private */
        public boolean a(a aVar, e eVar, e eVar2) {
            synchronized (aVar) {
                try {
                    if (aVar.f1637b != eVar) {
                        return false;
                    }
                    aVar.f1637b = eVar2;
                    return true;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        /* access modifiers changed from: package-private */
        public boolean b(a aVar, Object obj, Object obj2) {
            synchronized (aVar) {
                try {
                    if (aVar.f1636a != obj) {
                        return false;
                    }
                    aVar.f1636a = obj2;
                    return true;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        /* access modifiers changed from: package-private */
        public boolean c(a aVar, h hVar, h hVar2) {
            synchronized (aVar) {
                try {
                    if (aVar.f1638c != hVar) {
                        return false;
                    }
                    aVar.f1638c = hVar2;
                    return true;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d(h hVar, h hVar2) {
            hVar.f1655b = hVar2;
        }

        /* access modifiers changed from: package-private */
        public void e(h hVar, Thread thread) {
            hVar.f1654a = thread;
        }
    }

    private static final class h {

        /* renamed from: c  reason: collision with root package name */
        static final h f1653c = new h(false);

        /* renamed from: a  reason: collision with root package name */
        volatile Thread f1654a;

        /* renamed from: b  reason: collision with root package name */
        volatile h f1655b;

        h() {
            a.f1634f.e(this, Thread.currentThread());
        }

        /* access modifiers changed from: package-private */
        public void a(h hVar) {
            a.f1634f.d(this, hVar);
        }

        /* access modifiers changed from: package-private */
        public void b() {
            Thread thread = this.f1654a;
            if (thread != null) {
                this.f1654a = null;
                LockSupport.unpark(thread);
            }
        }

        h(boolean z2) {
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v3, resolved type: androidx.concurrent.futures.a$f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v4, resolved type: androidx.concurrent.futures.a$g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: androidx.concurrent.futures.a$f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v3, resolved type: androidx.concurrent.futures.a$f} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.String r0 = "b"
            java.lang.String r1 = "a"
            java.lang.Class<androidx.concurrent.futures.a$h> r2 = androidx.concurrent.futures.a.h.class
            java.lang.String r3 = "guava.concurrent.generate_cancellation_cause"
            java.lang.String r4 = "false"
            java.lang.String r3 = java.lang.System.getProperty(r3, r4)
            boolean r3 = java.lang.Boolean.parseBoolean(r3)
            f1632d = r3
            java.lang.Class<androidx.concurrent.futures.a> r3 = androidx.concurrent.futures.a.class
            java.lang.String r4 = r3.getName()
            java.util.logging.Logger r4 = java.util.logging.Logger.getLogger(r4)
            f1633e = r4
            androidx.concurrent.futures.a$f r4 = new androidx.concurrent.futures.a$f     // Catch:{ all -> 0x0044 }
            java.lang.Class<java.lang.Thread> r5 = java.lang.Thread.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r5, r1)     // Catch:{ all -> 0x0044 }
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r2, r2, r0)     // Catch:{ all -> 0x0044 }
            java.lang.String r5 = "c"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r2, r5)     // Catch:{ all -> 0x0044 }
            java.lang.Class<androidx.concurrent.futures.a$e> r2 = androidx.concurrent.futures.a.e.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r9 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r2, r0)     // Catch:{ all -> 0x0044 }
            java.lang.Class<java.lang.Object> r0 = java.lang.Object.class
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r10 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r3, r0, r1)     // Catch:{ all -> 0x0044 }
            r5 = r4
            r5.<init>(r6, r7, r8, r9, r10)     // Catch:{ all -> 0x0044 }
            r0 = 0
            goto L_0x004a
        L_0x0044:
            r0 = move-exception
            androidx.concurrent.futures.a$g r4 = new androidx.concurrent.futures.a$g
            r4.<init>()
        L_0x004a:
            f1634f = r4
            if (r0 == 0) goto L_0x0057
            java.util.logging.Logger r1 = f1633e
            java.util.logging.Level r2 = java.util.logging.Level.SEVERE
            java.lang.String r3 = "SafeAtomicHelper is broken!"
            r1.log(r2, r3, r0)
        L_0x0057:
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            f1635g = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.concurrent.futures.a.<clinit>():void");
    }

    protected a() {
    }

    private void a(StringBuilder sb) {
        String str = "]";
        try {
            Object h2 = h(this);
            sb.append("SUCCESS, result=[");
            sb.append(n(h2));
            sb.append(str);
            return;
        } catch (ExecutionException e2) {
            sb.append("FAILURE, cause=[");
            sb.append(e2.getCause());
        } catch (CancellationException unused) {
            str = "CANCELLED";
        } catch (RuntimeException e3) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e3.getClass());
            str = " thrown from get()]";
        }
        sb.append(str);
    }

    private static CancellationException c(String str, Throwable th) {
        CancellationException cancellationException = new CancellationException(str);
        cancellationException.initCause(th);
        return cancellationException;
    }

    private e d(e eVar) {
        e eVar2;
        do {
            eVar2 = this.f1637b;
        } while (!f1634f.a(this, eVar2, e.f1644d));
        e eVar3 = eVar2;
        e eVar4 = eVar;
        e eVar5 = eVar3;
        while (eVar5 != null) {
            e eVar6 = eVar5.f1647c;
            eVar5.f1647c = eVar4;
            eVar4 = eVar5;
            eVar5 = eVar6;
        }
        return eVar4;
    }

    static void e(a aVar) {
        aVar.k();
        aVar.b();
        e d2 = aVar.d((e) null);
        while (d2 != null) {
            e eVar = d2.f1647c;
            f(d2.f1645a, d2.f1646b);
            d2 = eVar;
        }
    }

    private static void f(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (RuntimeException e2) {
            Logger logger = f1633e;
            Level level = Level.SEVERE;
            logger.log(level, "RuntimeException while executing runnable " + runnable + " with executor " + executor, e2);
        }
    }

    private Object g(Object obj) {
        if (obj instanceof c) {
            throw c("Task was cancelled.", ((c) obj).f1642b);
        } else if (obj instanceof d) {
            throw new ExecutionException(((d) obj).f1643a);
        } else if (obj == f1635g) {
            return null;
        } else {
            return obj;
        }
    }

    static Object h(Future future) {
        Object obj;
        boolean z2 = false;
        while (true) {
            try {
                obj = future.get();
                break;
            } catch (InterruptedException unused) {
                z2 = true;
            } catch (Throwable th) {
                if (z2) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z2) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    private void k() {
        h hVar;
        do {
            hVar = this.f1638c;
        } while (!f1634f.c(this, hVar, h.f1653c));
        while (hVar != null) {
            hVar.b();
            hVar = hVar.f1655b;
        }
    }

    private void l(h hVar) {
        hVar.f1654a = null;
        while (true) {
            h hVar2 = this.f1638c;
            if (hVar2 != h.f1653c) {
                h hVar3 = null;
                while (hVar2 != null) {
                    h hVar4 = hVar2.f1655b;
                    if (hVar2.f1654a != null) {
                        hVar3 = hVar2;
                    } else if (hVar3 != null) {
                        hVar3.f1655b = hVar4;
                        if (hVar3.f1654a == null) {
                        }
                    } else if (!f1634f.c(this, hVar2, hVar4)) {
                    }
                    hVar2 = hVar4;
                }
                return;
            }
            return;
        }
    }

    private String n(Object obj) {
        return obj == this ? "this future" : String.valueOf(obj);
    }

    /* access modifiers changed from: protected */
    public void b() {
    }

    public final boolean cancel(boolean z2) {
        Object obj = this.f1636a;
        if (obj == null) {
            if (f1634f.b(this, obj, f1632d ? new c(z2, new CancellationException("Future.cancel() was called.")) : z2 ? c.f1639c : c.f1640d)) {
                if (z2) {
                    i();
                }
                e(this);
                return true;
            }
        }
        return false;
    }

    public final Object get() {
        Object obj;
        boolean z2;
        if (!Thread.interrupted()) {
            Object obj2 = this.f1636a;
            if (obj2 != null) {
                return g(obj2);
            }
            h hVar = this.f1638c;
            if (hVar != h.f1653c) {
                h hVar2 = new h();
                do {
                    hVar2.a(hVar);
                    if (f1634f.c(this, hVar, hVar2)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f1636a;
                                if (obj != null) {
                                    z2 = true;
                                    continue;
                                } else {
                                    z2 = false;
                                    continue;
                                }
                            } else {
                                l(hVar2);
                                throw new InterruptedException();
                            }
                        } while (!z2);
                        return g(obj);
                    }
                    hVar = this.f1638c;
                } while (hVar != h.f1653c);
            }
            return g(this.f1636a);
        }
        throw new InterruptedException();
    }

    /* access modifiers changed from: protected */
    public void i() {
    }

    public final boolean isCancelled() {
        return this.f1636a instanceof c;
    }

    public final boolean isDone() {
        return this.f1636a != null;
    }

    /* access modifiers changed from: protected */
    public String j() {
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        return "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
    }

    /* access modifiers changed from: protected */
    public boolean m(Object obj) {
        if (obj == null) {
            obj = f1635g;
        }
        if (!f1634f.b(this, (Object) null, obj)) {
            return false;
        }
        e(this);
        return true;
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (isCancelled()) {
            str2 = "CANCELLED";
        } else {
            if (!isDone()) {
                try {
                    str = j();
                } catch (RuntimeException e2) {
                    str = "Exception thrown from implementation: " + e2.getClass();
                }
                if (str != null && !str.isEmpty()) {
                    sb.append("PENDING, info=[");
                    sb.append(str);
                    sb.append("]");
                    sb.append("]");
                    return sb.toString();
                } else if (!isDone()) {
                    str2 = "PENDING";
                }
            }
            a(sb);
            sb.append("]");
            return sb.toString();
        }
        sb.append(str2);
        sb.append("]");
        return sb.toString();
    }

    public final Object get(long j2, TimeUnit timeUnit) {
        long j3 = j2;
        TimeUnit timeUnit2 = timeUnit;
        long nanos = timeUnit2.toNanos(j3);
        if (!Thread.interrupted()) {
            Object obj = this.f1636a;
            if (obj != null) {
                return g(obj);
            }
            long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0;
            if (nanos >= 1000) {
                h hVar = this.f1638c;
                if (hVar != h.f1653c) {
                    h hVar2 = new h();
                    do {
                        hVar2.a(hVar);
                        if (f1634f.c(this, hVar, hVar2)) {
                            do {
                                LockSupport.parkNanos(this, nanos);
                                if (!Thread.interrupted()) {
                                    Object obj2 = this.f1636a;
                                    if (obj2 != null) {
                                        return g(obj2);
                                    }
                                    nanos = nanoTime - System.nanoTime();
                                } else {
                                    l(hVar2);
                                    throw new InterruptedException();
                                }
                            } while (nanos >= 1000);
                            l(hVar2);
                        } else {
                            hVar = this.f1638c;
                        }
                    } while (hVar != h.f1653c);
                }
                return g(this.f1636a);
            }
            while (nanos > 0) {
                Object obj3 = this.f1636a;
                if (obj3 != null) {
                    return g(obj3);
                }
                if (!Thread.interrupted()) {
                    nanos = nanoTime - System.nanoTime();
                } else {
                    throw new InterruptedException();
                }
            }
            String aVar = toString();
            String obj4 = timeUnit.toString();
            Locale locale = Locale.ROOT;
            String lowerCase = obj4.toLowerCase(locale);
            String str = "Waited " + j3 + " " + timeUnit.toString().toLowerCase(locale);
            if (nanos + 1000 < 0) {
                String str2 = str + " (plus ";
                long j4 = -nanos;
                long convert = timeUnit2.convert(j4, TimeUnit.NANOSECONDS);
                long nanos2 = j4 - timeUnit2.toNanos(convert);
                int i2 = (convert > 0 ? 1 : (convert == 0 ? 0 : -1));
                boolean z2 = i2 == 0 || nanos2 > 1000;
                if (i2 > 0) {
                    String str3 = str2 + convert + " " + lowerCase;
                    if (z2) {
                        str3 = str3 + ",";
                    }
                    str2 = str3 + " ";
                }
                if (z2) {
                    str2 = str2 + nanos2 + " nanoseconds ";
                }
                str = str2 + "delay)";
            }
            if (isDone()) {
                throw new TimeoutException(str + " but future completed as timeout expired");
            }
            throw new TimeoutException(str + " for " + aVar);
        }
        throw new InterruptedException();
    }
}
