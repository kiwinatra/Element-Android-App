package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

class D {

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList f2716a = new ArrayList();

    /* renamed from: b  reason: collision with root package name */
    private final HashMap f2717b = new HashMap();

    /* renamed from: c  reason: collision with root package name */
    private final HashMap f2718c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    private z f2719d;

    D() {
    }

    /* access modifiers changed from: package-private */
    public void A(z zVar) {
        this.f2719d = zVar;
    }

    /* access modifiers changed from: package-private */
    public B B(String str, B b2) {
        return (B) (b2 != null ? this.f2718c.put(str, b2) : this.f2718c.remove(str));
    }

    /* access modifiers changed from: package-private */
    public void a(Fragment fragment) {
        if (!this.f2716a.contains(fragment)) {
            synchronized (this.f2716a) {
                this.f2716a.add(fragment);
            }
            fragment.f2789l = true;
            return;
        }
        throw new IllegalStateException("Fragment already added: " + fragment);
    }

    /* access modifiers changed from: package-private */
    public void b() {
        this.f2717b.values().removeAll(Collections.singleton((Object) null));
    }

    /* access modifiers changed from: package-private */
    public boolean c(String str) {
        return this.f2717b.get(str) != null;
    }

    /* access modifiers changed from: package-private */
    public void d(int i2) {
        for (C c2 : this.f2717b.values()) {
            if (c2 != null) {
                c2.t(i2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2 = str + "    ";
        if (!this.f2717b.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (C c2 : this.f2717b.values()) {
                printWriter.print(str);
                if (c2 != null) {
                    Fragment k2 = c2.k();
                    printWriter.println(k2);
                    k2.f(str2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size = this.f2716a.size();
        if (size > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size; i2++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(((Fragment) this.f2716a.get(i2)).toString());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment f(String str) {
        C c2 = (C) this.f2717b.get(str);
        if (c2 != null) {
            return c2.k();
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public Fragment g(int i2) {
        for (int size = this.f2716a.size() - 1; size >= 0; size--) {
            Fragment fragment = (Fragment) this.f2716a.get(size);
            if (fragment != null && fragment.f2801x == i2) {
                return fragment;
            }
        }
        for (C c2 : this.f2717b.values()) {
            if (c2 != null) {
                Fragment k2 = c2.k();
                if (k2.f2801x == i2) {
                    return k2;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public Fragment h(String str) {
        if (str != null) {
            for (int size = this.f2716a.size() - 1; size >= 0; size--) {
                Fragment fragment = (Fragment) this.f2716a.get(size);
                if (fragment != null && str.equals(fragment.f2803z)) {
                    return fragment;
                }
            }
        }
        if (str == null) {
            return null;
        }
        for (C c2 : this.f2717b.values()) {
            if (c2 != null) {
                Fragment k2 = c2.k();
                if (str.equals(k2.f2803z)) {
                    return k2;
                }
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public Fragment i(String str) {
        Fragment h2;
        for (C c2 : this.f2717b.values()) {
            if (c2 != null && (h2 = c2.k().h(str)) != null) {
                return h2;
            }
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public int j(Fragment fragment) {
        View view;
        View view2;
        ViewGroup viewGroup = fragment.f2758H;
        if (viewGroup == null) {
            return -1;
        }
        int indexOf = this.f2716a.indexOf(fragment);
        for (int i2 = indexOf - 1; i2 >= 0; i2--) {
            Fragment fragment2 = (Fragment) this.f2716a.get(i2);
            if (fragment2.f2758H == viewGroup && (view2 = fragment2.f2759I) != null) {
                return viewGroup.indexOfChild(view2) + 1;
            }
        }
        while (true) {
            indexOf++;
            if (indexOf >= this.f2716a.size()) {
                return -1;
            }
            Fragment fragment3 = (Fragment) this.f2716a.get(indexOf);
            if (fragment3.f2758H == viewGroup && (view = fragment3.f2759I) != null) {
                return viewGroup.indexOfChild(view);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public List k() {
        ArrayList arrayList = new ArrayList();
        for (C c2 : this.f2717b.values()) {
            if (c2 != null) {
                arrayList.add(c2);
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    public List l() {
        ArrayList arrayList = new ArrayList();
        for (C c2 : this.f2717b.values()) {
            arrayList.add(c2 != null ? c2.k() : null);
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    public ArrayList m() {
        return new ArrayList(this.f2718c.values());
    }

    /* access modifiers changed from: package-private */
    public C n(String str) {
        return (C) this.f2717b.get(str);
    }

    /* access modifiers changed from: package-private */
    public List o() {
        ArrayList arrayList;
        if (this.f2716a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f2716a) {
            arrayList = new ArrayList(this.f2716a);
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    public z p() {
        return this.f2719d;
    }

    /* access modifiers changed from: package-private */
    public B q(String str) {
        return (B) this.f2718c.get(str);
    }

    /* access modifiers changed from: package-private */
    public void r(C c2) {
        Fragment k2 = c2.k();
        if (!c(k2.f2783f)) {
            this.f2717b.put(k2.f2783f, c2);
            if (k2.f2754D) {
                if (k2.f2753C) {
                    this.f2719d.e(k2);
                } else {
                    this.f2719d.o(k2);
                }
                k2.f2754D = false;
            }
            if (w.G0(2)) {
                Log.v("FragmentManager", "Added fragment to active set " + k2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void s(C c2) {
        Fragment k2 = c2.k();
        if (k2.f2753C) {
            this.f2719d.o(k2);
        }
        if (((C) this.f2717b.put(k2.f2783f, (Object) null)) != null && w.G0(2)) {
            Log.v("FragmentManager", "Removed fragment from active set " + k2);
        }
    }

    /* access modifiers changed from: package-private */
    public void t() {
        Iterator it = this.f2716a.iterator();
        while (it.hasNext()) {
            C c2 = (C) this.f2717b.get(((Fragment) it.next()).f2783f);
            if (c2 != null) {
                c2.m();
            }
        }
        for (C c3 : this.f2717b.values()) {
            if (c3 != null) {
                c3.m();
                Fragment k2 = c3.k();
                if (k2.f2790m && !k2.Y()) {
                    if (k2.f2791n && !this.f2718c.containsKey(k2.f2783f)) {
                        c3.r();
                    }
                    s(c3);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void u(Fragment fragment) {
        synchronized (this.f2716a) {
            this.f2716a.remove(fragment);
        }
        fragment.f2789l = false;
    }

    /* access modifiers changed from: package-private */
    public void v() {
        this.f2717b.clear();
    }

    /* access modifiers changed from: package-private */
    public void w(List list) {
        this.f2716a.clear();
        if (list != null) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                Fragment f2 = f(str);
                if (f2 != null) {
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "restoreSaveState: added (" + str + "): " + f2);
                    }
                    a(f2);
                } else {
                    throw new IllegalStateException("No instantiated fragment for (" + str + ")");
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void x(ArrayList arrayList) {
        this.f2718c.clear();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            B b2 = (B) it.next();
            this.f2718c.put(b2.f2696b, b2);
        }
    }

    /* access modifiers changed from: package-private */
    public ArrayList y() {
        ArrayList arrayList = new ArrayList(this.f2717b.size());
        for (C c2 : this.f2717b.values()) {
            if (c2 != null) {
                Fragment k2 = c2.k();
                c2.r();
                arrayList.add(k2.f2783f);
                if (w.G0(2)) {
                    Log.v("FragmentManager", "Saved state of " + k2 + ": " + k2.f2779b);
                }
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    public ArrayList z() {
        synchronized (this.f2716a) {
            try {
                if (this.f2716a.isEmpty()) {
                    return null;
                }
                ArrayList arrayList = new ArrayList(this.f2716a.size());
                Iterator it = this.f2716a.iterator();
                while (it.hasNext()) {
                    Fragment fragment = (Fragment) it.next();
                    arrayList.add(fragment.f2783f);
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "saveAllState: adding fragment (" + fragment.f2783f + "): " + fragment);
                    }
                }
                return arrayList;
            } finally {
            }
        }
    }
}
