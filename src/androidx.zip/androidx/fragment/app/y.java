package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.fragment.app.w;
import java.util.ArrayList;

final class y implements Parcelable {
    public static final Parcelable.Creator<y> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    ArrayList f3079a;

    /* renamed from: b  reason: collision with root package name */
    ArrayList f3080b;

    /* renamed from: c  reason: collision with root package name */
    C0172b[] f3081c;

    /* renamed from: d  reason: collision with root package name */
    int f3082d;

    /* renamed from: e  reason: collision with root package name */
    String f3083e = null;

    /* renamed from: f  reason: collision with root package name */
    ArrayList f3084f = new ArrayList();

    /* renamed from: g  reason: collision with root package name */
    ArrayList f3085g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    ArrayList f3086h;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public y createFromParcel(Parcel parcel) {
            return new y(parcel);
        }

        /* renamed from: b */
        public y[] newArray(int i2) {
            return new y[i2];
        }
    }

    public y() {
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f3079a);
        parcel.writeStringList(this.f3080b);
        parcel.writeTypedArray(this.f3081c, i2);
        parcel.writeInt(this.f3082d);
        parcel.writeString(this.f3083e);
        parcel.writeStringList(this.f3084f);
        parcel.writeTypedList(this.f3085g);
        parcel.writeTypedList(this.f3086h);
    }

    public y(Parcel parcel) {
        this.f3079a = parcel.createStringArrayList();
        this.f3080b = parcel.createStringArrayList();
        this.f3081c = (C0172b[]) parcel.createTypedArray(C0172b.CREATOR);
        this.f3082d = parcel.readInt();
        this.f3083e = parcel.readString();
        this.f3084f = parcel.createStringArrayList();
        this.f3085g = parcel.createTypedArrayList(C0173c.CREATOR);
        this.f3086h = parcel.createTypedArrayList(w.k.CREATOR);
    }
}
