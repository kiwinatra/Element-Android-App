package androidx.fragment.app;

import android.animation.Animator;
import android.content.Context;
import android.content.res.TypedArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;
import androidx.core.view.I;

/* renamed from: androidx.fragment.app.k  reason: case insensitive filesystem */
abstract class C0181k {

    /* renamed from: androidx.fragment.app.k$a */
    static class a {

        /* renamed from: a  reason: collision with root package name */
        public final Animation f2994a;

        /* renamed from: b  reason: collision with root package name */
        public final Animator f2995b;

        a(Animator animator) {
            this.f2994a = null;
            this.f2995b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        a(Animation animation) {
            this.f2994a = animation;
            this.f2995b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    /* renamed from: androidx.fragment.app.k$b */
    static class b extends AnimationSet implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private final ViewGroup f2996a;

        /* renamed from: b  reason: collision with root package name */
        private final View f2997b;

        /* renamed from: c  reason: collision with root package name */
        private boolean f2998c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f2999d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f3000e = true;

        b(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f2996a = viewGroup;
            this.f2997b = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        public boolean getTransformation(long j2, Transformation transformation) {
            this.f3000e = true;
            if (this.f2998c) {
                return !this.f2999d;
            }
            if (!super.getTransformation(j2, transformation)) {
                this.f2998c = true;
                I.a(this.f2996a, this);
            }
            return true;
        }

        public void run() {
            if (this.f2998c || !this.f3000e) {
                this.f2996a.endViewTransition(this.f2997b);
                this.f2999d = true;
                return;
            }
            this.f3000e = false;
            this.f2996a.post(this);
        }

        public boolean getTransformation(long j2, Transformation transformation, float f2) {
            this.f3000e = true;
            if (this.f2998c) {
                return !this.f2999d;
            }
            if (!super.getTransformation(j2, transformation, f2)) {
                this.f2998c = true;
                I.a(this.f2996a, this);
            }
            return true;
        }
    }

    private static int a(Fragment fragment, boolean z2, boolean z3) {
        return z3 ? z2 ? fragment.F() : fragment.G() : z2 ? fragment.p() : fragment.s();
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:31:0x0069 */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0069 A[SYNTHETIC, Splitter:B:31:0x0069] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static androidx.fragment.app.C0181k.a b(android.content.Context r4, androidx.fragment.app.Fragment r5, boolean r6, boolean r7) {
        /*
            int r0 = r5.B()
            int r7 = a(r5, r6, r7)
            r1 = 0
            r5.p1(r1, r1, r1, r1)
            android.view.ViewGroup r1 = r5.f2758H
            r2 = 0
            if (r1 == 0) goto L_0x001e
            int r3 = I.b.visible_removing_fragment_view_tag
            java.lang.Object r1 = r1.getTag(r3)
            if (r1 == 0) goto L_0x001e
            android.view.ViewGroup r1 = r5.f2758H
            r1.setTag(r3, r2)
        L_0x001e:
            android.view.ViewGroup r1 = r5.f2758H
            if (r1 == 0) goto L_0x0029
            android.animation.LayoutTransition r1 = r1.getLayoutTransition()
            if (r1 == 0) goto L_0x0029
            return r2
        L_0x0029:
            android.view.animation.Animation r1 = r5.k0(r0, r6, r7)
            if (r1 == 0) goto L_0x0035
            androidx.fragment.app.k$a r4 = new androidx.fragment.app.k$a
            r4.<init>((android.view.animation.Animation) r1)
            return r4
        L_0x0035:
            android.animation.Animator r5 = r5.l0(r0, r6, r7)
            if (r5 == 0) goto L_0x0041
            androidx.fragment.app.k$a r4 = new androidx.fragment.app.k$a
            r4.<init>((android.animation.Animator) r5)
            return r4
        L_0x0041:
            if (r7 != 0) goto L_0x0049
            if (r0 == 0) goto L_0x0049
            int r7 = d(r4, r0, r6)
        L_0x0049:
            if (r7 == 0) goto L_0x0085
            android.content.res.Resources r5 = r4.getResources()
            java.lang.String r5 = r5.getResourceTypeName(r7)
            java.lang.String r6 = "anim"
            boolean r5 = r6.equals(r5)
            if (r5 == 0) goto L_0x0069
            android.view.animation.Animation r6 = android.view.animation.AnimationUtils.loadAnimation(r4, r7)     // Catch:{ NotFoundException -> 0x0067, RuntimeException -> 0x0069 }
            if (r6 == 0) goto L_0x0085
            androidx.fragment.app.k$a r0 = new androidx.fragment.app.k$a     // Catch:{ NotFoundException -> 0x0067, RuntimeException -> 0x0069 }
            r0.<init>((android.view.animation.Animation) r6)     // Catch:{ NotFoundException -> 0x0067, RuntimeException -> 0x0069 }
            return r0
        L_0x0067:
            r4 = move-exception
            throw r4
        L_0x0069:
            android.animation.Animator r6 = android.animation.AnimatorInflater.loadAnimator(r4, r7)     // Catch:{ RuntimeException -> 0x0075 }
            if (r6 == 0) goto L_0x0085
            androidx.fragment.app.k$a r0 = new androidx.fragment.app.k$a     // Catch:{ RuntimeException -> 0x0075 }
            r0.<init>((android.animation.Animator) r6)     // Catch:{ RuntimeException -> 0x0075 }
            return r0
        L_0x0075:
            r6 = move-exception
            if (r5 != 0) goto L_0x0084
            android.view.animation.Animation r4 = android.view.animation.AnimationUtils.loadAnimation(r4, r7)
            if (r4 == 0) goto L_0x0085
            androidx.fragment.app.k$a r5 = new androidx.fragment.app.k$a
            r5.<init>((android.view.animation.Animation) r4)
            return r5
        L_0x0084:
            throw r6
        L_0x0085:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0181k.b(android.content.Context, androidx.fragment.app.Fragment, boolean, boolean):androidx.fragment.app.k$a");
    }

    private static int c(Context context, int i2) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(16973825, new int[]{i2});
        int resourceId = obtainStyledAttributes.getResourceId(0, -1);
        obtainStyledAttributes.recycle();
        return resourceId;
    }

    private static int d(Context context, int i2, boolean z2) {
        int i3;
        if (i2 == 4097) {
            return z2 ? I.a.fragment_open_enter : I.a.fragment_open_exit;
        }
        if (i2 == 8194) {
            return z2 ? I.a.fragment_close_enter : I.a.fragment_close_exit;
        }
        if (i2 == 8197) {
            i3 = z2 ? 16842938 : 16842939;
        } else if (i2 == 4099) {
            return z2 ? I.a.fragment_fade_enter : I.a.fragment_fade_exit;
        } else {
            if (i2 != 4100) {
                return -1;
            }
            i3 = z2 ? 16842936 : 16842937;
        }
        return c(context, i3);
    }
}
