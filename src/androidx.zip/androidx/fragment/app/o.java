package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import x.h;

public abstract class o extends C0182l {

    /* renamed from: a  reason: collision with root package name */
    private final Activity f3003a;

    /* renamed from: b  reason: collision with root package name */
    private final Context f3004b;

    /* renamed from: c  reason: collision with root package name */
    private final Handler f3005c;

    /* renamed from: d  reason: collision with root package name */
    private final int f3006d;

    /* renamed from: e  reason: collision with root package name */
    final w f3007e;

    o(Activity activity, Context context, Handler handler, int i2) {
        this.f3007e = new x();
        this.f3003a = activity;
        this.f3004b = (Context) h.h(context, "context == null");
        this.f3005c = (Handler) h.h(handler, "handler == null");
        this.f3006d = i2;
    }

    /* access modifiers changed from: package-private */
    public Activity q() {
        return this.f3003a;
    }

    /* access modifiers changed from: package-private */
    public Context s() {
        return this.f3004b;
    }

    public Handler u() {
        return this.f3005c;
    }

    public abstract void w(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract Object x();

    public abstract LayoutInflater y();

    public abstract void z();

    o(C0180j jVar) {
        this(jVar, jVar, new Handler(), 0);
    }
}
