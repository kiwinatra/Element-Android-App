package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

/* renamed from: androidx.fragment.app.l  reason: case insensitive filesystem */
public abstract class C0182l {
    public Fragment m(Context context, String str, Bundle bundle) {
        return Fragment.V(context, str, bundle);
    }

    public abstract View n(int i2);

    public abstract boolean o();
}
