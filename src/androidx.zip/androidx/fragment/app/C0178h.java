package androidx.fragment.app;

import android.content.Intent;
import x.C0290a;

/* renamed from: androidx.fragment.app.h  reason: case insensitive filesystem */
public final /* synthetic */ class C0178h implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0180j f2986a;

    public /* synthetic */ C0178h(C0180j jVar) {
        this.f2986a = jVar;
    }

    public final void a(Object obj) {
        this.f2986a.X((Intent) obj);
    }
}
