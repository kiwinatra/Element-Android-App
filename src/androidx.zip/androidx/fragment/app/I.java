package androidx.fragment.app;

import M.a;
import O.c;
import O.d;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import androidx.lifecycle.A;
import androidx.lifecycle.C0189f;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.m;
import androidx.lifecycle.w;

class I implements C0189f, d, E {

    /* renamed from: a  reason: collision with root package name */
    private final Fragment f2861a;

    /* renamed from: b  reason: collision with root package name */
    private final D f2862b;

    /* renamed from: c  reason: collision with root package name */
    private m f2863c = null;

    /* renamed from: d  reason: collision with root package name */
    private c f2864d = null;

    I(Fragment fragment, D d2) {
        this.f2861a = fragment;
        this.f2862b = d2;
    }

    public a a() {
        Application application;
        Context applicationContext = this.f2861a.k1().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            } else if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            } else {
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
        }
        M.d dVar = new M.d();
        if (application != null) {
            dVar.b(A.a.f3099d, application);
        }
        dVar.b(w.f3184a, this);
        dVar.b(w.f3185b, this);
        if (this.f2861a.m() != null) {
            dVar.b(w.f3186c, this.f2861a.m());
        }
        return dVar;
    }

    /* access modifiers changed from: package-private */
    public void b(C0190g.a aVar) {
        this.f2863c.h(aVar);
    }

    /* access modifiers changed from: package-private */
    public void c() {
        if (this.f2863c == null) {
            this.f2863c = new m(this);
            c a2 = c.a(this);
            this.f2864d = a2;
            a2.c();
            w.a(this);
        }
    }

    public androidx.savedstate.a e() {
        c();
        return this.f2864d.b();
    }

    /* access modifiers changed from: package-private */
    public boolean f() {
        return this.f2863c != null;
    }

    /* access modifiers changed from: package-private */
    public void g(Bundle bundle) {
        this.f2864d.d(bundle);
    }

    /* access modifiers changed from: package-private */
    public void h(Bundle bundle) {
        this.f2864d.e(bundle);
    }

    /* access modifiers changed from: package-private */
    public void i(C0190g.b bVar) {
        this.f2863c.m(bVar);
    }

    public D t() {
        c();
        return this.f2862b;
    }

    public C0190g v() {
        c();
        return this.f2863c;
    }
}
