package androidx.fragment.app;

public interface A {
    void a(w wVar, Fragment fragment);
}
