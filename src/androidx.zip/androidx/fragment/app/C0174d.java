package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.os.a;
import androidx.core.view.C0124b0;
import androidx.core.view.W;
import androidx.fragment.app.C0181k;
import androidx.fragment.app.K;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import l.C0255a;

/* renamed from: androidx.fragment.app.d  reason: case insensitive filesystem */
class C0174d extends K {

    /* renamed from: androidx.fragment.app.d$a */
    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f2916a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                androidx.fragment.app.K$e$c[] r0 = androidx.fragment.app.K.e.c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f2916a = r0
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.GONE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f2916a     // Catch:{ NoSuchFieldError -> 0x001d }
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.INVISIBLE     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f2916a     // Catch:{ NoSuchFieldError -> 0x0028 }
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.REMOVED     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f2916a     // Catch:{ NoSuchFieldError -> 0x0033 }
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.VISIBLE     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0174d.a.<clinit>():void");
        }
    }

    /* renamed from: androidx.fragment.app.d$b */
    class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ List f2917a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ K.e f2918b;

        b(List list, K.e eVar) {
            this.f2917a = list;
            this.f2918b = eVar;
        }

        public void run() {
            if (this.f2917a.contains(this.f2918b)) {
                this.f2917a.remove(this.f2918b);
                C0174d.this.s(this.f2918b);
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$c */
    class c extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ ViewGroup f2920a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f2921b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ boolean f2922c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ K.e f2923d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ k f2924e;

        c(ViewGroup viewGroup, View view, boolean z2, K.e eVar, k kVar) {
            this.f2920a = viewGroup;
            this.f2921b = view;
            this.f2922c = z2;
            this.f2923d = eVar;
            this.f2924e = kVar;
        }

        public void onAnimationEnd(Animator animator) {
            this.f2920a.endViewTransition(this.f2921b);
            if (this.f2922c) {
                this.f2923d.e().a(this.f2921b);
            }
            this.f2924e.a();
            if (w.G0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.f2923d + " has ended.");
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$d  reason: collision with other inner class name */
    class C0043d implements a.C0028a {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Animator f2926a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ K.e f2927b;

        C0043d(Animator animator, K.e eVar) {
            this.f2926a = animator;
            this.f2927b = eVar;
        }

        public void a() {
            this.f2926a.end();
            if (w.G0(2)) {
                Log.v("FragmentManager", "Animator from operation " + this.f2927b + " has been canceled.");
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$e */
    class e implements Animation.AnimationListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ K.e f2929a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ViewGroup f2930b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f2931c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ k f2932d;

        /* renamed from: androidx.fragment.app.d$e$a */
        class a implements Runnable {
            a() {
            }

            public void run() {
                e eVar = e.this;
                eVar.f2930b.endViewTransition(eVar.f2931c);
                e.this.f2932d.a();
            }
        }

        e(K.e eVar, ViewGroup viewGroup, View view, k kVar) {
            this.f2929a = eVar;
            this.f2930b = viewGroup;
            this.f2931c = view;
            this.f2932d = kVar;
        }

        public void onAnimationEnd(Animation animation) {
            this.f2930b.post(new a());
            if (w.G0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.f2929a + " has ended.");
            }
        }

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.f2929a + " has reached onAnimationStart.");
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$f */
    class f implements a.C0028a {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f2935a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ViewGroup f2936b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ k f2937c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ K.e f2938d;

        f(View view, ViewGroup viewGroup, k kVar, K.e eVar) {
            this.f2935a = view;
            this.f2936b = viewGroup;
            this.f2937c = kVar;
            this.f2938d = eVar;
        }

        public void a() {
            this.f2935a.clearAnimation();
            this.f2936b.endViewTransition(this.f2935a);
            this.f2937c.a();
            if (w.G0(2)) {
                Log.v("FragmentManager", "Animation from operation " + this.f2938d + " has been cancelled.");
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$g */
    class g implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ K.e f2940a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ K.e f2941b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ boolean f2942c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ C0255a f2943d;

        g(K.e eVar, K.e eVar2, boolean z2, C0255a aVar) {
            this.f2940a = eVar;
            this.f2941b = eVar2;
            this.f2942c = z2;
            this.f2943d = aVar;
        }

        public void run() {
            F.a(this.f2940a.f(), this.f2941b.f(), this.f2942c, this.f2943d, false);
        }
    }

    /* renamed from: androidx.fragment.app.d$h */
    class h implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ H f2945a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f2946b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Rect f2947c;

        h(H h2, View view, Rect rect) {
            this.f2945a = h2;
            this.f2946b = view;
            this.f2947c = rect;
        }

        public void run() {
            this.f2945a.h(this.f2946b, this.f2947c);
        }
    }

    /* renamed from: androidx.fragment.app.d$i */
    class i implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ ArrayList f2949a;

        i(ArrayList arrayList) {
            this.f2949a = arrayList;
        }

        public void run() {
            F.d(this.f2949a, 4);
        }
    }

    /* renamed from: androidx.fragment.app.d$j */
    class j implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ m f2951a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ K.e f2952b;

        j(m mVar, K.e eVar) {
            this.f2951a = mVar;
            this.f2952b = eVar;
        }

        public void run() {
            this.f2951a.a();
            if (w.G0(2)) {
                Log.v("FragmentManager", "Transition for operation " + this.f2952b + "has completed");
            }
        }
    }

    /* renamed from: androidx.fragment.app.d$k */
    private static class k extends l {

        /* renamed from: c  reason: collision with root package name */
        private boolean f2954c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f2955d = false;

        /* renamed from: e  reason: collision with root package name */
        private C0181k.a f2956e;

        k(K.e eVar, androidx.core.os.a aVar, boolean z2) {
            super(eVar, aVar);
            this.f2954c = z2;
        }

        /* access modifiers changed from: package-private */
        public C0181k.a e(Context context) {
            if (this.f2955d) {
                return this.f2956e;
            }
            C0181k.a b2 = C0181k.b(context, b().f(), b().e() == K.e.c.VISIBLE, this.f2954c);
            this.f2956e = b2;
            this.f2955d = true;
            return b2;
        }
    }

    /* renamed from: androidx.fragment.app.d$l */
    private static class l {

        /* renamed from: a  reason: collision with root package name */
        private final K.e f2957a;

        /* renamed from: b  reason: collision with root package name */
        private final androidx.core.os.a f2958b;

        l(K.e eVar, androidx.core.os.a aVar) {
            this.f2957a = eVar;
            this.f2958b = aVar;
        }

        /* access modifiers changed from: package-private */
        public void a() {
            this.f2957a.d(this.f2958b);
        }

        /* access modifiers changed from: package-private */
        public K.e b() {
            return this.f2957a;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.os.a c() {
            return this.f2958b;
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0014, code lost:
            r2 = androidx.fragment.app.K.e.c.VISIBLE;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean d() {
            /*
                r3 = this;
                androidx.fragment.app.K$e r0 = r3.f2957a
                androidx.fragment.app.Fragment r0 = r0.f()
                android.view.View r0 = r0.f2759I
                androidx.fragment.app.K$e$c r0 = androidx.fragment.app.K.e.c.c(r0)
                androidx.fragment.app.K$e r1 = r3.f2957a
                androidx.fragment.app.K$e$c r1 = r1.e()
                if (r0 == r1) goto L_0x001d
                androidx.fragment.app.K$e$c r2 = androidx.fragment.app.K.e.c.VISIBLE
                if (r0 == r2) goto L_0x001b
                if (r1 == r2) goto L_0x001b
                goto L_0x001d
            L_0x001b:
                r0 = 0
                goto L_0x001e
            L_0x001d:
                r0 = 1
            L_0x001e:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0174d.l.d():boolean");
        }
    }

    /* renamed from: androidx.fragment.app.d$m */
    private static class m extends l {

        /* renamed from: c  reason: collision with root package name */
        private final Object f2959c;

        /* renamed from: d  reason: collision with root package name */
        private final boolean f2960d;

        /* renamed from: e  reason: collision with root package name */
        private final Object f2961e;

        m(K.e eVar, androidx.core.os.a aVar, boolean z2, boolean z3) {
            super(eVar, aVar);
            boolean z4;
            Object obj;
            if (eVar.e() == K.e.c.VISIBLE) {
                Fragment f2 = eVar.f();
                this.f2959c = z2 ? f2.I() : f2.q();
                Fragment f3 = eVar.f();
                z4 = z2 ? f3.k() : f3.j();
            } else {
                Fragment f4 = eVar.f();
                this.f2959c = z2 ? f4.K() : f4.u();
                z4 = true;
            }
            this.f2960d = z4;
            if (z3) {
                Fragment f5 = eVar.f();
                obj = z2 ? f5.M() : f5.L();
            } else {
                obj = null;
            }
            this.f2961e = obj;
        }

        private H f(Object obj) {
            if (obj == null) {
                return null;
            }
            H h2 = F.f2748a;
            if (h2 != null && h2.e(obj)) {
                return h2;
            }
            H h3 = F.f2749b;
            if (h3 != null && h3.e(obj)) {
                return h3;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + b().f() + " is not a valid framework Transition or AndroidX Transition");
        }

        /* access modifiers changed from: package-private */
        public H e() {
            H f2 = f(this.f2959c);
            H f3 = f(this.f2961e);
            if (f2 == null || f3 == null || f2 == f3) {
                return f2 != null ? f2 : f3;
            }
            throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + b().f() + " returned Transition " + this.f2959c + " which uses a different Transition  type than its shared element transition " + this.f2961e);
        }

        public Object g() {
            return this.f2961e;
        }

        /* access modifiers changed from: package-private */
        public Object h() {
            return this.f2959c;
        }

        public boolean i() {
            return this.f2961e != null;
        }

        /* access modifiers changed from: package-private */
        public boolean j() {
            return this.f2960d;
        }
    }

    C0174d(ViewGroup viewGroup) {
        super(viewGroup);
    }

    private void w(List list, List list2, boolean z2, Map map) {
        int i2;
        Context context;
        boolean z3;
        View view;
        StringBuilder sb;
        String str;
        C0181k.a e2;
        K.e eVar;
        ViewGroup m2 = m();
        Context context2 = m2.getContext();
        ArrayList arrayList = new ArrayList();
        Iterator it = list.iterator();
        boolean z4 = false;
        while (true) {
            i2 = 2;
            if (!it.hasNext()) {
                break;
            }
            k kVar = (k) it.next();
            if (!kVar.d() && (e2 = kVar.e(context2)) != null) {
                Animator animator = e2.f2995b;
                if (animator == null) {
                    arrayList.add(kVar);
                } else {
                    K.e b2 = kVar.b();
                    Fragment f2 = b2.f();
                    if (Boolean.TRUE.equals(map.get(b2))) {
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "Ignoring Animator set on " + f2 + " as this Fragment was involved in a Transition.");
                        }
                        kVar.a();
                    } else {
                        boolean z5 = b2.e() == K.e.c.GONE;
                        List list3 = list2;
                        if (z5) {
                            list3.remove(b2);
                        }
                        View view2 = f2.f2759I;
                        m2.startViewTransition(view2);
                        c cVar = r0;
                        View view3 = view2;
                        K.e eVar2 = b2;
                        Animator animator2 = animator;
                        c cVar2 = new c(m2, view3, z5, eVar2, kVar);
                        animator2.addListener(cVar2);
                        animator2.setTarget(view3);
                        animator2.start();
                        if (w.G0(2)) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("Animator from operation ");
                            eVar = eVar2;
                            sb2.append(eVar);
                            sb2.append(" has started.");
                            Log.v("FragmentManager", sb2.toString());
                        } else {
                            eVar = eVar2;
                        }
                        kVar.c().b(new C0043d(animator2, eVar));
                        z4 = true;
                    }
                }
            } else {
                kVar.a();
            }
            Map map2 = map;
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            k kVar2 = (k) it2.next();
            K.e b3 = kVar2.b();
            Fragment f3 = b3.f();
            if (z2) {
                if (w.G0(i2)) {
                    sb = new StringBuilder();
                    sb.append("Ignoring Animation set on ");
                    sb.append(f3);
                    str = " as Animations cannot run alongside Transitions.";
                }
                kVar2.a();
            } else if (z4) {
                if (w.G0(i2)) {
                    sb = new StringBuilder();
                    sb.append("Ignoring Animation set on ");
                    sb.append(f3);
                    str = " as Animations cannot run alongside Animators.";
                }
                kVar2.a();
            } else {
                View view4 = f3.f2759I;
                Animation animation = (Animation) x.h.g(((C0181k.a) x.h.g(kVar2.e(context2))).f2994a);
                if (b3.e() != K.e.c.REMOVED) {
                    view4.startAnimation(animation);
                    kVar2.a();
                    z3 = z4;
                    context = context2;
                    view = view4;
                } else {
                    m2.startViewTransition(view4);
                    e eVar3 = r0;
                    z3 = z4;
                    C0181k.b bVar = new C0181k.b(animation, m2, view4);
                    context = context2;
                    view = view4;
                    e eVar4 = new e(b3, m2, view4, kVar2);
                    bVar.setAnimationListener(eVar3);
                    view.startAnimation(bVar);
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "Animation from operation " + b3 + " has started.");
                    }
                }
                androidx.core.os.a c2 = kVar2.c();
                f fVar = r0;
                f fVar2 = new f(view, m2, kVar2, b3);
                c2.b(fVar);
                z4 = z3;
                context2 = context;
                i2 = 2;
            }
            sb.append(str);
            Log.v("FragmentManager", sb.toString());
            kVar2.a();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v27, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v27, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.util.Map x(java.util.List r34, java.util.List r35, boolean r36, androidx.fragment.app.K.e r37, androidx.fragment.app.K.e r38) {
        /*
            r33 = this;
            r6 = r33
            r7 = r36
            r8 = r37
            r9 = r38
            java.util.HashMap r10 = new java.util.HashMap
            r10.<init>()
            java.util.Iterator r0 = r34.iterator()
            r15 = 0
        L_0x0012:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0062
            java.lang.Object r1 = r0.next()
            androidx.fragment.app.d$m r1 = (androidx.fragment.app.C0174d.m) r1
            boolean r2 = r1.d()
            if (r2 == 0) goto L_0x0025
            goto L_0x0012
        L_0x0025:
            androidx.fragment.app.H r2 = r1.e()
            if (r15 != 0) goto L_0x002d
            r15 = r2
            goto L_0x0012
        L_0x002d:
            if (r2 == 0) goto L_0x0012
            if (r15 != r2) goto L_0x0032
            goto L_0x0012
        L_0x0032:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "Mixing framework transitions and AndroidX transitions is not allowed. Fragment "
            r2.append(r3)
            androidx.fragment.app.K$e r3 = r1.b()
            androidx.fragment.app.Fragment r3 = r3.f()
            r2.append(r3)
            java.lang.String r3 = " returned Transition "
            r2.append(r3)
            java.lang.Object r1 = r1.h()
            r2.append(r1)
            java.lang.String r1 = " which uses a different Transition  type than other Fragments."
            r2.append(r1)
            java.lang.String r1 = r2.toString()
            r0.<init>(r1)
            throw r0
        L_0x0062:
            if (r15 != 0) goto L_0x0082
            java.util.Iterator r0 = r34.iterator()
        L_0x0068:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0081
            java.lang.Object r1 = r0.next()
            androidx.fragment.app.d$m r1 = (androidx.fragment.app.C0174d.m) r1
            androidx.fragment.app.K$e r2 = r1.b()
            java.lang.Boolean r3 = java.lang.Boolean.FALSE
            r10.put(r2, r3)
            r1.a()
            goto L_0x0068
        L_0x0081:
            return r10
        L_0x0082:
            android.view.View r14 = new android.view.View
            android.view.ViewGroup r0 = r33.m()
            android.content.Context r0 = r0.getContext()
            r14.<init>(r0)
            android.graphics.Rect r13 = new android.graphics.Rect
            r13.<init>()
            java.util.ArrayList r12 = new java.util.ArrayList
            r12.<init>()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            l.a r4 = new l.a
            r4.<init>()
            java.util.Iterator r20 = r34.iterator()
            r0 = 0
            r2 = 0
            r21 = 0
        L_0x00ab:
            boolean r1 = r20.hasNext()
            r22 = 2
            java.lang.String r3 = "FragmentManager"
            if (r1 == 0) goto L_0x02e5
            java.lang.Object r1 = r20.next()
            androidx.fragment.app.d$m r1 = (androidx.fragment.app.C0174d.m) r1
            boolean r17 = r1.i()
            if (r17 == 0) goto L_0x02c2
            if (r8 == 0) goto L_0x02c2
            if (r9 == 0) goto L_0x02c2
            java.lang.Object r0 = r1.g()
            java.lang.Object r0 = r15.f(r0)
            java.lang.Object r1 = r15.u(r0)
            androidx.fragment.app.Fragment r0 = r38.f()
            java.util.ArrayList r0 = r0.N()
            androidx.fragment.app.Fragment r17 = r37.f()
            java.util.ArrayList r11 = r17.N()
            androidx.fragment.app.Fragment r17 = r37.f()
            r18 = r1
            java.util.ArrayList r1 = r17.O()
            r17 = r2
            r2 = 0
        L_0x00ee:
            int r9 = r1.size()
            if (r2 >= r9) goto L_0x010f
            java.lang.Object r9 = r1.get(r2)
            int r9 = r0.indexOf(r9)
            r19 = r1
            r1 = -1
            if (r9 == r1) goto L_0x010a
            java.lang.Object r1 = r11.get(r2)
            java.lang.String r1 = (java.lang.String) r1
            r0.set(r9, r1)
        L_0x010a:
            int r2 = r2 + 1
            r1 = r19
            goto L_0x00ee
        L_0x010f:
            androidx.fragment.app.Fragment r1 = r38.f()
            java.util.ArrayList r9 = r1.O()
            androidx.fragment.app.Fragment r1 = r37.f()
            if (r7 != 0) goto L_0x0128
            r1.w()
            androidx.fragment.app.Fragment r1 = r38.f()
            r1.r()
            goto L_0x0132
        L_0x0128:
            r1.r()
            androidx.fragment.app.Fragment r1 = r38.f()
            r1.w()
        L_0x0132:
            int r1 = r0.size()
            r2 = 0
        L_0x0137:
            if (r2 >= r1) goto L_0x0151
            java.lang.Object r11 = r0.get(r2)
            java.lang.String r11 = (java.lang.String) r11
            java.lang.Object r19 = r9.get(r2)
            r24 = r1
            r1 = r19
            java.lang.String r1 = (java.lang.String) r1
            r4.put(r11, r1)
            int r2 = r2 + 1
            r1 = r24
            goto L_0x0137
        L_0x0151:
            boolean r1 = androidx.fragment.app.w.G0(r22)
            if (r1 == 0) goto L_0x01b1
            java.lang.String r1 = ">>> entering view names <<<"
            android.util.Log.v(r3, r1)
            java.util.Iterator r1 = r9.iterator()
        L_0x0160:
            boolean r2 = r1.hasNext()
            java.lang.String r11 = "Name: "
            if (r2 == 0) goto L_0x0185
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            r19 = r1
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r11)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r3, r1)
            r1 = r19
            goto L_0x0160
        L_0x0185:
            java.lang.String r1 = ">>> exiting view names <<<"
            android.util.Log.v(r3, r1)
            java.util.Iterator r1 = r0.iterator()
        L_0x018e:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x01b1
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            r19 = r1
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r11)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.v(r3, r1)
            r1 = r19
            goto L_0x018e
        L_0x01b1:
            l.a r11 = new l.a
            r11.<init>()
            androidx.fragment.app.Fragment r1 = r37.f()
            android.view.View r1 = r1.f2759I
            r6.u(r11, r1)
            r11.o(r0)
            java.util.Set r1 = r11.keySet()
            r4.o(r1)
            l.a r3 = new l.a
            r3.<init>()
            androidx.fragment.app.Fragment r1 = r38.f()
            android.view.View r1 = r1.f2759I
            r6.u(r3, r1)
            r3.o(r9)
            java.util.Collection r1 = r4.values()
            r3.o(r1)
            androidx.fragment.app.F.c(r4, r3)
            java.util.Set r1 = r4.keySet()
            r6.v(r11, r1)
            java.util.Collection r1 = r4.values()
            r6.v(r3, r1)
            boolean r1 = r4.isEmpty()
            if (r1 == 0) goto L_0x020f
            r12.clear()
            r5.clear()
            r26 = r4
            r1 = r5
            r4 = r8
            r5 = r12
            r7 = r13
            r9 = r14
            r11 = r15
            r2 = r17
            r0 = 0
            r14 = r38
            r15 = r10
            r10 = 0
            goto L_0x02d4
        L_0x020f:
            androidx.fragment.app.Fragment r1 = r38.f()
            androidx.fragment.app.Fragment r2 = r37.f()
            r8 = 1
            androidx.fragment.app.F.a(r1, r2, r7, r11, r8)
            android.view.ViewGroup r2 = r33.m()
            androidx.fragment.app.d$g r1 = new androidx.fragment.app.d$g
            r19 = r0
            r0 = r1
            r7 = r1
            r8 = r18
            r1 = r33
            r24 = r10
            r25 = r17
            r10 = r2
            r2 = r38
            r16 = r3
            r17 = r14
            r14 = 0
            r3 = r37
            r26 = r4
            r4 = r36
            r27 = r5
            r5 = r16
            r0.<init>(r2, r3, r4, r5)
            androidx.core.view.I.a(r10, r7)
            java.util.Collection r0 = r11.values()
            r12.addAll(r0)
            boolean r0 = r19.isEmpty()
            if (r0 != 0) goto L_0x0265
            r0 = r19
            java.lang.Object r0 = r0.get(r14)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.Object r0 = r11.get(r0)
            r2 = r0
            android.view.View r2 = (android.view.View) r2
            r15.p(r8, r2)
            goto L_0x0267
        L_0x0265:
            r2 = r25
        L_0x0267:
            java.util.Collection r0 = r16.values()
            r1 = r27
            r1.addAll(r0)
            boolean r0 = r9.isEmpty()
            if (r0 != 0) goto L_0x0297
            java.lang.Object r0 = r9.get(r14)
            java.lang.String r0 = (java.lang.String) r0
            r3 = r16
            java.lang.Object r0 = r3.get(r0)
            android.view.View r0 = (android.view.View) r0
            if (r0 == 0) goto L_0x0297
            android.view.ViewGroup r3 = r33.m()
            androidx.fragment.app.d$h r4 = new androidx.fragment.app.d$h
            r4.<init>(r15, r0, r13)
            androidx.core.view.I.a(r3, r4)
            r0 = r17
            r21 = 1
            goto L_0x0299
        L_0x0297:
            r0 = r17
        L_0x0299:
            r15.s(r8, r0, r12)
            r16 = 0
            r17 = 0
            r3 = 0
            r4 = 0
            r5 = r12
            r12 = r15
            r7 = r13
            r13 = r8
            r9 = r0
            r10 = 0
            r14 = r3
            r11 = r15
            r15 = r4
            r18 = r8
            r19 = r1
            r12.n(r13, r14, r15, r16, r17, r18, r19)
            java.lang.Boolean r0 = java.lang.Boolean.TRUE
            r4 = r37
            r15 = r24
            r15.put(r4, r0)
            r14 = r38
            r15.put(r14, r0)
            r0 = r8
            goto L_0x02d4
        L_0x02c2:
            r25 = r2
            r26 = r4
            r1 = r5
            r4 = r8
            r5 = r12
            r7 = r13
            r11 = r15
            r15 = r10
            r10 = 0
            r32 = r14
            r14 = r9
            r9 = r32
            r2 = r25
        L_0x02d4:
            r8 = r4
            r12 = r5
            r13 = r7
            r10 = r15
            r4 = r26
            r7 = r36
            r5 = r1
            r15 = r11
            r32 = r14
            r14 = r9
            r9 = r32
            goto L_0x00ab
        L_0x02e5:
            r25 = r2
            r26 = r4
            r1 = r5
            r4 = r8
            r5 = r12
            r7 = r13
            r11 = r15
            r2 = 1
            r15 = r10
            r10 = 0
            r32 = r14
            r14 = r9
            r9 = r32
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            java.util.Iterator r20 = r34.iterator()
            r12 = 0
            r13 = 0
        L_0x0301:
            boolean r16 = r20.hasNext()
            if (r16 == 0) goto L_0x041c
            java.lang.Object r16 = r20.next()
            r23 = r16
            androidx.fragment.app.d$m r23 = (androidx.fragment.app.C0174d.m) r23
            boolean r16 = r23.d()
            if (r16 == 0) goto L_0x0324
            androidx.fragment.app.K$e r2 = r23.b()
            java.lang.Boolean r10 = java.lang.Boolean.FALSE
            r15.put(r2, r10)
            r23.a()
        L_0x0321:
            r2 = 1
            r10 = 0
            goto L_0x0301
        L_0x0324:
            java.lang.Object r2 = r23.h()
            java.lang.Object r2 = r11.f(r2)
            androidx.fragment.app.K$e r10 = r23.b()
            if (r0 == 0) goto L_0x0339
            if (r10 == r4) goto L_0x0336
            if (r10 != r14) goto L_0x0339
        L_0x0336:
            r16 = 1
            goto L_0x033b
        L_0x0339:
            r16 = 0
        L_0x033b:
            if (r2 != 0) goto L_0x0358
            if (r16 != 0) goto L_0x0347
            java.lang.Boolean r2 = java.lang.Boolean.FALSE
            r15.put(r10, r2)
            r23.a()
        L_0x0347:
            r31 = r1
            r28 = r3
            r30 = r5
            r29 = r9
            r2 = r12
            r1 = r15
            r3 = r25
            r10 = 0
            r12 = r35
            goto L_0x040c
        L_0x0358:
            r28 = r3
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r36 = r12
            androidx.fragment.app.Fragment r12 = r10.f()
            android.view.View r12 = r12.f2759I
            r6.t(r3, r12)
            if (r16 == 0) goto L_0x0375
            if (r10 != r4) goto L_0x0372
            r3.removeAll(r5)
            goto L_0x0375
        L_0x0372:
            r3.removeAll(r1)
        L_0x0375:
            boolean r12 = r3.isEmpty()
            if (r12 == 0) goto L_0x038b
            r11.a(r2, r9)
            r12 = r35
            r31 = r1
            r30 = r5
            r29 = r9
            r5 = r13
            r1 = r15
            r9 = r36
            goto L_0x03db
        L_0x038b:
            r11.b(r2, r3)
            r18 = 0
            r19 = 0
            r16 = 0
            r17 = 0
            r29 = r9
            r9 = r36
            r12 = r11
            r30 = r5
            r5 = r13
            r13 = r2
            r31 = r1
            r1 = r14
            r14 = r2
            r1 = r15
            r15 = r3
            r12.n(r13, r14, r15, r16, r17, r18, r19)
            androidx.fragment.app.K$e$c r12 = r10.e()
            androidx.fragment.app.K$e$c r13 = androidx.fragment.app.K.e.c.GONE
            if (r12 != r13) goto L_0x03d9
            r12 = r35
            r12.remove(r10)
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>(r3)
            androidx.fragment.app.Fragment r14 = r10.f()
            android.view.View r14 = r14.f2759I
            r13.remove(r14)
            androidx.fragment.app.Fragment r14 = r10.f()
            android.view.View r14 = r14.f2759I
            r11.m(r2, r14, r13)
            android.view.ViewGroup r13 = r33.m()
            androidx.fragment.app.d$i r14 = new androidx.fragment.app.d$i
            r14.<init>(r3)
            androidx.core.view.I.a(r13, r14)
            goto L_0x03db
        L_0x03d9:
            r12 = r35
        L_0x03db:
            androidx.fragment.app.K$e$c r13 = r10.e()
            androidx.fragment.app.K$e$c r14 = androidx.fragment.app.K.e.c.VISIBLE
            if (r13 != r14) goto L_0x03ee
            r8.addAll(r3)
            if (r21 == 0) goto L_0x03eb
            r11.o(r2, r7)
        L_0x03eb:
            r3 = r25
            goto L_0x03f3
        L_0x03ee:
            r3 = r25
            r11.p(r2, r3)
        L_0x03f3:
            java.lang.Boolean r13 = java.lang.Boolean.TRUE
            r1.put(r10, r13)
            boolean r10 = r23.j()
            if (r10 == 0) goto L_0x0406
            r10 = 0
            java.lang.Object r2 = r11.k(r5, r2, r10)
            r13 = r2
            r2 = r9
            goto L_0x040c
        L_0x0406:
            r10 = 0
            java.lang.Object r2 = r11.k(r9, r2, r10)
            r13 = r5
        L_0x040c:
            r14 = r38
            r15 = r1
            r12 = r2
            r25 = r3
            r3 = r28
            r9 = r29
            r5 = r30
            r1 = r31
            goto L_0x0321
        L_0x041c:
            r31 = r1
            r28 = r3
            r30 = r5
            r9 = r12
            r5 = r13
            r1 = r15
            java.lang.Object r2 = r11.j(r5, r9, r0)
            if (r2 != 0) goto L_0x042c
            return r1
        L_0x042c:
            java.util.Iterator r3 = r34.iterator()
        L_0x0430:
            boolean r5 = r3.hasNext()
            if (r5 == 0) goto L_0x04b3
            java.lang.Object r5 = r3.next()
            androidx.fragment.app.d$m r5 = (androidx.fragment.app.C0174d.m) r5
            boolean r7 = r5.d()
            if (r7 == 0) goto L_0x0443
            goto L_0x0430
        L_0x0443:
            java.lang.Object r7 = r5.h()
            androidx.fragment.app.K$e r9 = r5.b()
            r10 = r1
            r1 = r38
            if (r0 == 0) goto L_0x0456
            if (r9 == r4) goto L_0x0454
            if (r9 != r1) goto L_0x0456
        L_0x0454:
            r12 = 1
            goto L_0x0457
        L_0x0456:
            r12 = 0
        L_0x0457:
            if (r7 != 0) goto L_0x045f
            if (r12 == 0) goto L_0x045c
            goto L_0x045f
        L_0x045c:
            r12 = r28
            goto L_0x04ae
        L_0x045f:
            android.view.ViewGroup r7 = r33.m()
            boolean r7 = androidx.core.view.W.U(r7)
            if (r7 != 0) goto L_0x0498
            boolean r7 = androidx.fragment.app.w.G0(r22)
            if (r7 == 0) goto L_0x0492
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r12 = "SpecialEffectsController: Container "
            r7.append(r12)
            android.view.ViewGroup r12 = r33.m()
            r7.append(r12)
            java.lang.String r12 = " has not been laid out. Completing operation "
            r7.append(r12)
            r7.append(r9)
            java.lang.String r7 = r7.toString()
            r12 = r28
            android.util.Log.v(r12, r7)
            goto L_0x0494
        L_0x0492:
            r12 = r28
        L_0x0494:
            r5.a()
            goto L_0x04ae
        L_0x0498:
            r12 = r28
            androidx.fragment.app.K$e r7 = r5.b()
            androidx.fragment.app.Fragment r7 = r7.f()
            androidx.core.os.a r13 = r5.c()
            androidx.fragment.app.d$j r14 = new androidx.fragment.app.d$j
            r14.<init>(r5, r9)
            r11.q(r7, r2, r13, r14)
        L_0x04ae:
            r1 = r10
            r28 = r12
            goto L_0x0430
        L_0x04b3:
            r10 = r1
            r12 = r28
            android.view.ViewGroup r1 = r33.m()
            boolean r1 = androidx.core.view.W.U(r1)
            if (r1 != 0) goto L_0x04c1
            return r10
        L_0x04c1:
            r1 = 4
            androidx.fragment.app.F.d(r8, r1)
            r1 = r31
            java.util.ArrayList r16 = r11.l(r1)
            boolean r3 = androidx.fragment.app.w.G0(r22)
            if (r3 == 0) goto L_0x053e
            java.lang.String r3 = ">>>>> Beginning transition <<<<<"
            android.util.Log.v(r12, r3)
            java.lang.String r3 = ">>>>> SharedElementFirstOutViews <<<<<"
            android.util.Log.v(r12, r3)
            java.util.Iterator r3 = r30.iterator()
        L_0x04df:
            boolean r4 = r3.hasNext()
            java.lang.String r5 = " Name: "
            java.lang.String r7 = "View: "
            if (r4 == 0) goto L_0x050c
            java.lang.Object r4 = r3.next()
            android.view.View r4 = (android.view.View) r4
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r7)
            r9.append(r4)
            r9.append(r5)
            java.lang.String r4 = androidx.core.view.W.L(r4)
            r9.append(r4)
            java.lang.String r4 = r9.toString()
            android.util.Log.v(r12, r4)
            goto L_0x04df
        L_0x050c:
            java.lang.String r3 = ">>>>> SharedElementLastInViews <<<<<"
            android.util.Log.v(r12, r3)
            java.util.Iterator r3 = r1.iterator()
        L_0x0515:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L_0x053e
            java.lang.Object r4 = r3.next()
            android.view.View r4 = (android.view.View) r4
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r7)
            r9.append(r4)
            r9.append(r5)
            java.lang.String r4 = androidx.core.view.W.L(r4)
            r9.append(r4)
            java.lang.String r4 = r9.toString()
            android.util.Log.v(r12, r4)
            goto L_0x0515
        L_0x053e:
            android.view.ViewGroup r3 = r33.m()
            r11.c(r3, r2)
            android.view.ViewGroup r13 = r33.m()
            r12 = r11
            r14 = r30
            r15 = r1
            r17 = r26
            r12.r(r13, r14, r15, r16, r17)
            r2 = 0
            androidx.fragment.app.F.d(r8, r2)
            r2 = r30
            r11.t(r0, r2, r1)
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0174d.x(java.util.List, java.util.List, boolean, androidx.fragment.app.K$e, androidx.fragment.app.K$e):java.util.Map");
    }

    private void y(List list) {
        Fragment f2 = ((K.e) list.get(list.size() - 1)).f();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            K.e eVar = (K.e) it.next();
            eVar.f().f2762L.f2813c = f2.f2762L.f2813c;
            eVar.f().f2762L.f2814d = f2.f2762L.f2814d;
            eVar.f().f2762L.f2815e = f2.f2762L.f2815e;
            eVar.f().f2762L.f2816f = f2.f2762L.f2816f;
        }
    }

    /* access modifiers changed from: package-private */
    public void f(List list, boolean z2) {
        Iterator it = list.iterator();
        K.e eVar = null;
        K.e eVar2 = null;
        while (it.hasNext()) {
            K.e eVar3 = (K.e) it.next();
            K.e.c c2 = K.e.c.c(eVar3.f().f2759I);
            int i2 = a.f2916a[eVar3.e().ordinal()];
            if (i2 == 1 || i2 == 2 || i2 == 3) {
                if (c2 == K.e.c.VISIBLE && eVar == null) {
                    eVar = eVar3;
                }
            } else if (i2 == 4 && c2 != K.e.c.VISIBLE) {
                eVar2 = eVar3;
            }
        }
        if (w.G0(2)) {
            Log.v("FragmentManager", "Executing operations from " + eVar + " to " + eVar2);
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList<K.e> arrayList3 = new ArrayList<>(list);
        y(list);
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            K.e eVar4 = (K.e) it2.next();
            androidx.core.os.a aVar = new androidx.core.os.a();
            eVar4.j(aVar);
            arrayList.add(new k(eVar4, aVar, z2));
            androidx.core.os.a aVar2 = new androidx.core.os.a();
            eVar4.j(aVar2);
            boolean z3 = false;
            if (z2) {
                if (eVar4 != eVar) {
                    arrayList2.add(new m(eVar4, aVar2, z2, z3));
                    eVar4.a(new b(arrayList3, eVar4));
                }
            } else if (eVar4 != eVar2) {
                arrayList2.add(new m(eVar4, aVar2, z2, z3));
                eVar4.a(new b(arrayList3, eVar4));
            }
            z3 = true;
            arrayList2.add(new m(eVar4, aVar2, z2, z3));
            eVar4.a(new b(arrayList3, eVar4));
        }
        Map x2 = x(arrayList2, arrayList3, z2, eVar, eVar2);
        w(arrayList, arrayList3, x2.containsValue(Boolean.TRUE), x2);
        for (K.e s2 : arrayList3) {
            s(s2);
        }
        arrayList3.clear();
        if (w.G0(2)) {
            Log.v("FragmentManager", "Completed executing operations from " + eVar + " to " + eVar2);
        }
    }

    /* access modifiers changed from: package-private */
    public void s(K.e eVar) {
        eVar.e().a(eVar.f().f2759I);
    }

    /* access modifiers changed from: package-private */
    public void t(ArrayList arrayList, View view) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            if (!C0124b0.a(viewGroup)) {
                int childCount = viewGroup.getChildCount();
                for (int i2 = 0; i2 < childCount; i2++) {
                    View childAt = viewGroup.getChildAt(i2);
                    if (childAt.getVisibility() == 0) {
                        t(arrayList, childAt);
                    }
                }
            } else if (!arrayList.contains(view)) {
                arrayList.add(viewGroup);
            }
        } else if (!arrayList.contains(view)) {
            arrayList.add(view);
        }
    }

    /* access modifiers changed from: package-private */
    public void u(Map map, View view) {
        String L2 = W.L(view);
        if (L2 != null) {
            map.put(L2, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt.getVisibility() == 0) {
                    u(map, childAt);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void v(C0255a aVar, Collection collection) {
        Iterator it = aVar.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(W.L((View) ((Map.Entry) it.next()).getValue()))) {
                it.remove();
            }
        }
    }
}
