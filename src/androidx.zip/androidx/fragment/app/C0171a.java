package androidx.fragment.app;

import android.util.Log;
import androidx.fragment.app.E;
import androidx.fragment.app.w;
import java.io.PrintWriter;
import java.util.ArrayList;

/* renamed from: androidx.fragment.app.a  reason: case insensitive filesystem */
final class C0171a extends E implements w.l {

    /* renamed from: t  reason: collision with root package name */
    final w f2896t;

    /* renamed from: u  reason: collision with root package name */
    boolean f2897u;

    /* renamed from: v  reason: collision with root package name */
    int f2898v;

    /* renamed from: w  reason: collision with root package name */
    boolean f2899w;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    C0171a(w wVar) {
        super(wVar.r0(), wVar.t0() != null ? wVar.t0().s().getClassLoader() : null);
        this.f2898v = -1;
        this.f2899w = false;
        this.f2896t = wVar;
    }

    public boolean a(ArrayList arrayList, ArrayList arrayList2) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f2728i) {
            return true;
        }
        this.f2896t.i(this);
        return true;
    }

    public int e() {
        return p(false);
    }

    public int f() {
        return p(true);
    }

    public void g() {
        i();
        this.f2896t.b0(this, false);
    }

    public void h() {
        i();
        this.f2896t.b0(this, true);
    }

    /* access modifiers changed from: package-private */
    public void j(int i2, Fragment fragment, String str, int i3) {
        super.j(i2, fragment, str, i3);
        fragment.f2797t = this.f2896t;
    }

    public E k(Fragment fragment) {
        w wVar = fragment.f2797t;
        if (wVar == null || wVar == this.f2896t) {
            return super.k(fragment);
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    /* access modifiers changed from: package-private */
    public void o(int i2) {
        if (this.f2728i) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            int size = this.f2722c.size();
            for (int i3 = 0; i3 < size; i3++) {
                E.a aVar = (E.a) this.f2722c.get(i3);
                Fragment fragment = aVar.f2740b;
                if (fragment != null) {
                    fragment.f2796s += i2;
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "Bump nesting of " + aVar.f2740b + " to " + aVar.f2740b.f2796s);
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int p(boolean z2) {
        if (!this.f2897u) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Commit: " + this);
                PrintWriter printWriter = new PrintWriter(new J("FragmentManager"));
                q("  ", printWriter);
                printWriter.close();
            }
            this.f2897u = true;
            this.f2898v = this.f2728i ? this.f2896t.l() : -1;
            this.f2896t.Y(this, z2);
            return this.f2898v;
        }
        throw new IllegalStateException("commit already called");
    }

    public void q(String str, PrintWriter printWriter) {
        r(str, printWriter, true);
    }

    public void r(String str, PrintWriter printWriter, boolean z2) {
        String str2;
        if (z2) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f2730k);
            printWriter.print(" mIndex=");
            printWriter.print(this.f2898v);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f2897u);
            if (this.f2727h != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f2727h));
            }
            if (!(this.f2723d == 0 && this.f2724e == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f2723d));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f2724e));
            }
            if (!(this.f2725f == 0 && this.f2726g == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f2725f));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f2726g));
            }
            if (!(this.f2731l == 0 && this.f2732m == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f2731l));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f2732m);
            }
            if (!(this.f2733n == 0 && this.f2734o == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f2733n));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f2734o);
            }
        }
        if (!this.f2722c.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.f2722c.size();
            for (int i2 = 0; i2 < size; i2++) {
                E.a aVar = (E.a) this.f2722c.get(i2);
                switch (aVar.f2739a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        str2 = "cmd=" + aVar.f2739a;
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f2740b);
                if (z2) {
                    if (!(aVar.f2742d == 0 && aVar.f2743e == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f2742d));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f2743e));
                    }
                    if (aVar.f2744f != 0 || aVar.f2745g != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f2744f));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f2745g));
                    }
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void s() {
        w wVar;
        int size = this.f2722c.size();
        for (int i2 = 0; i2 < size; i2++) {
            E.a aVar = (E.a) this.f2722c.get(i2);
            Fragment fragment = aVar.f2740b;
            if (fragment != null) {
                fragment.f2791n = this.f2899w;
                fragment.t1(false);
                fragment.s1(this.f2727h);
                fragment.v1(this.f2735p, this.f2736q);
            }
            switch (aVar.f2739a) {
                case 1:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, false);
                    this.f2896t.j(fragment);
                    continue;
                case 3:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.c1(fragment);
                    continue;
                case 4:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.D0(fragment);
                    continue;
                case 5:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, false);
                    this.f2896t.n1(fragment);
                    continue;
                case 6:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.w(fragment);
                    continue;
                case 7:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, false);
                    this.f2896t.n(fragment);
                    continue;
                case 8:
                    wVar = this.f2896t;
                    break;
                case 9:
                    wVar = this.f2896t;
                    fragment = null;
                    break;
                case 10:
                    this.f2896t.k1(fragment, aVar.f2747i);
                    continue;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f2739a);
            }
            wVar.l1(fragment);
        }
    }

    /* access modifiers changed from: package-private */
    public void t() {
        w wVar;
        for (int size = this.f2722c.size() - 1; size >= 0; size--) {
            E.a aVar = (E.a) this.f2722c.get(size);
            Fragment fragment = aVar.f2740b;
            if (fragment != null) {
                fragment.f2791n = this.f2899w;
                fragment.t1(true);
                fragment.s1(w.g1(this.f2727h));
                fragment.v1(this.f2736q, this.f2735p);
            }
            switch (aVar.f2739a) {
                case 1:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, true);
                    this.f2896t.c1(fragment);
                    continue;
                case 3:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j(fragment);
                    continue;
                case 4:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.n1(fragment);
                    continue;
                case 5:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, true);
                    this.f2896t.D0(fragment);
                    continue;
                case 6:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.n(fragment);
                    continue;
                case 7:
                    fragment.p1(aVar.f2742d, aVar.f2743e, aVar.f2744f, aVar.f2745g);
                    this.f2896t.j1(fragment, true);
                    this.f2896t.w(fragment);
                    continue;
                case 8:
                    wVar = this.f2896t;
                    fragment = null;
                    break;
                case 9:
                    wVar = this.f2896t;
                    break;
                case 10:
                    this.f2896t.k1(fragment, aVar.f2746h);
                    continue;
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f2739a);
            }
            wVar.l1(fragment);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f2898v >= 0) {
            sb.append(" #");
            sb.append(this.f2898v);
        }
        if (this.f2730k != null) {
            sb.append(" ");
            sb.append(this.f2730k);
        }
        sb.append("}");
        return sb.toString();
    }

    /* access modifiers changed from: package-private */
    public Fragment u(ArrayList arrayList, Fragment fragment) {
        ArrayList arrayList2 = arrayList;
        Fragment fragment2 = fragment;
        int i2 = 0;
        while (i2 < this.f2722c.size()) {
            E.a aVar = (E.a) this.f2722c.get(i2);
            int i3 = aVar.f2739a;
            if (i3 != 1) {
                if (i3 == 2) {
                    Fragment fragment3 = aVar.f2740b;
                    int i4 = fragment3.f2802y;
                    boolean z2 = false;
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        Fragment fragment4 = (Fragment) arrayList2.get(size);
                        if (fragment4.f2802y == i4) {
                            if (fragment4 == fragment3) {
                                z2 = true;
                            } else {
                                if (fragment4 == fragment2) {
                                    this.f2722c.add(i2, new E.a(9, fragment4, true));
                                    i2++;
                                    fragment2 = null;
                                }
                                E.a aVar2 = new E.a(3, fragment4, true);
                                aVar2.f2742d = aVar.f2742d;
                                aVar2.f2744f = aVar.f2744f;
                                aVar2.f2743e = aVar.f2743e;
                                aVar2.f2745g = aVar.f2745g;
                                this.f2722c.add(i2, aVar2);
                                arrayList2.remove(fragment4);
                                i2++;
                            }
                        }
                    }
                    if (z2) {
                        this.f2722c.remove(i2);
                        i2--;
                    } else {
                        aVar.f2739a = 1;
                        aVar.f2741c = true;
                        arrayList2.add(fragment3);
                    }
                } else if (i3 == 3 || i3 == 6) {
                    arrayList2.remove(aVar.f2740b);
                    Fragment fragment5 = aVar.f2740b;
                    if (fragment5 == fragment2) {
                        this.f2722c.add(i2, new E.a(9, fragment5));
                        i2++;
                        fragment2 = null;
                    }
                } else if (i3 != 7) {
                    if (i3 == 8) {
                        this.f2722c.add(i2, new E.a(9, fragment2, true));
                        aVar.f2741c = true;
                        i2++;
                        fragment2 = aVar.f2740b;
                    }
                }
                i2++;
            }
            arrayList2.add(aVar.f2740b);
            i2++;
        }
        return fragment2;
    }

    public String v() {
        return this.f2730k;
    }

    public void w() {
        if (this.f2738s != null) {
            for (int i2 = 0; i2 < this.f2738s.size(); i2++) {
                ((Runnable) this.f2738s.get(i2)).run();
            }
            this.f2738s = null;
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment x(ArrayList arrayList, Fragment fragment) {
        for (int size = this.f2722c.size() - 1; size >= 0; size--) {
            E.a aVar = (E.a) this.f2722c.get(size);
            int i2 = aVar.f2739a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case 6:
                            break;
                        case 7:
                            break;
                        case 8:
                            fragment = null;
                            break;
                        case 9:
                            fragment = aVar.f2740b;
                            break;
                        case 10:
                            aVar.f2747i = aVar.f2746h;
                            break;
                    }
                }
                arrayList.add(aVar.f2740b);
            }
            arrayList.remove(aVar.f2740b);
        }
        return fragment;
    }
}
