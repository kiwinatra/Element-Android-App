package androidx.fragment.app;

import android.content.res.Configuration;
import x.C0290a;

public final /* synthetic */ class r implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w f3013a;

    public /* synthetic */ r(w wVar) {
        this.f3013a = wVar;
    }

    public final void a(Object obj) {
        this.f3013a.P0((Configuration) obj);
    }
}
