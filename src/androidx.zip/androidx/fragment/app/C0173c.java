package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

/* renamed from: androidx.fragment.app.c  reason: case insensitive filesystem */
class C0173c implements Parcelable {
    public static final Parcelable.Creator<C0173c> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    final List f2914a;

    /* renamed from: b  reason: collision with root package name */
    final List f2915b;

    /* renamed from: androidx.fragment.app.c$a */
    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public C0173c createFromParcel(Parcel parcel) {
            return new C0173c(parcel);
        }

        /* renamed from: b */
        public C0173c[] newArray(int i2) {
            return new C0173c[i2];
        }
    }

    C0173c(Parcel parcel) {
        this.f2914a = parcel.createStringArrayList();
        this.f2915b = parcel.createTypedArrayList(C0172b.CREATOR);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f2914a);
        parcel.writeTypedList(this.f2915b);
    }
}
