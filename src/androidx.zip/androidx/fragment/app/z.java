package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.A;
import androidx.lifecycle.B;
import androidx.lifecycle.D;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

final class z extends androidx.lifecycle.z {

    /* renamed from: k  reason: collision with root package name */
    private static final A.b f3087k = new a();

    /* renamed from: d  reason: collision with root package name */
    private final HashMap f3088d = new HashMap();

    /* renamed from: e  reason: collision with root package name */
    private final HashMap f3089e = new HashMap();

    /* renamed from: f  reason: collision with root package name */
    private final HashMap f3090f = new HashMap();

    /* renamed from: g  reason: collision with root package name */
    private final boolean f3091g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f3092h = false;

    /* renamed from: i  reason: collision with root package name */
    private boolean f3093i = false;

    /* renamed from: j  reason: collision with root package name */
    private boolean f3094j = false;

    class a implements A.b {
        a() {
        }

        public androidx.lifecycle.z a(Class cls) {
            return new z(true);
        }

        public /* synthetic */ androidx.lifecycle.z b(Class cls, M.a aVar) {
            return B.b(this, cls, aVar);
        }
    }

    z(boolean z2) {
        this.f3091g = z2;
    }

    private void h(String str) {
        z zVar = (z) this.f3089e.get(str);
        if (zVar != null) {
            zVar.d();
            this.f3089e.remove(str);
        }
        D d2 = (D) this.f3090f.get(str);
        if (d2 != null) {
            d2.a();
            this.f3090f.remove(str);
        }
    }

    static z k(D d2) {
        return (z) new A(d2, f3087k).a(z.class);
    }

    /* access modifiers changed from: protected */
    public void d() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f3092h = true;
    }

    /* access modifiers changed from: package-private */
    public void e(Fragment fragment) {
        if (this.f3094j) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else if (!this.f3088d.containsKey(fragment.f2783f)) {
            this.f3088d.put(fragment.f2783f, fragment);
            if (w.G0(2)) {
                Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
            }
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || z.class != obj.getClass()) {
            return false;
        }
        z zVar = (z) obj;
        return this.f3088d.equals(zVar.f3088d) && this.f3089e.equals(zVar.f3089e) && this.f3090f.equals(zVar.f3090f);
    }

    /* access modifiers changed from: package-private */
    public void f(Fragment fragment) {
        if (w.G0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        h(fragment.f2783f);
    }

    /* access modifiers changed from: package-private */
    public void g(String str) {
        if (w.G0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
        }
        h(str);
    }

    public int hashCode() {
        return (((this.f3088d.hashCode() * 31) + this.f3089e.hashCode()) * 31) + this.f3090f.hashCode();
    }

    /* access modifiers changed from: package-private */
    public Fragment i(String str) {
        return (Fragment) this.f3088d.get(str);
    }

    /* access modifiers changed from: package-private */
    public z j(Fragment fragment) {
        z zVar = (z) this.f3089e.get(fragment.f2783f);
        if (zVar != null) {
            return zVar;
        }
        z zVar2 = new z(this.f3091g);
        this.f3089e.put(fragment.f2783f, zVar2);
        return zVar2;
    }

    /* access modifiers changed from: package-private */
    public Collection l() {
        return new ArrayList(this.f3088d.values());
    }

    /* access modifiers changed from: package-private */
    public D m(Fragment fragment) {
        D d2 = (D) this.f3090f.get(fragment.f2783f);
        if (d2 != null) {
            return d2;
        }
        D d3 = new D();
        this.f3090f.put(fragment.f2783f, d3);
        return d3;
    }

    /* access modifiers changed from: package-private */
    public boolean n() {
        return this.f3092h;
    }

    /* access modifiers changed from: package-private */
    public void o(Fragment fragment) {
        if (this.f3094j) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else if (this.f3088d.remove(fragment.f2783f) != null && w.G0(2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    /* access modifiers changed from: package-private */
    public void p(boolean z2) {
        this.f3094j = z2;
    }

    /* access modifiers changed from: package-private */
    public boolean q(Fragment fragment) {
        if (!this.f3088d.containsKey(fragment.f2783f)) {
            return true;
        }
        return this.f3091g ? this.f3092h : !this.f3093i;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f3088d.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f3089e.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.f3090f.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
