package androidx.fragment.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import x.h;

/* renamed from: androidx.fragment.app.m  reason: case insensitive filesystem */
public class C0183m {

    /* renamed from: a  reason: collision with root package name */
    private final o f3001a;

    private C0183m(o oVar) {
        this.f3001a = oVar;
    }

    public static C0183m b(o oVar) {
        return new C0183m((o) h.h(oVar, "callbacks == null"));
    }

    public void a(Fragment fragment) {
        o oVar = this.f3001a;
        oVar.f3007e.m(oVar, oVar, fragment);
    }

    public void c() {
        this.f3001a.f3007e.x();
    }

    public boolean d(MenuItem menuItem) {
        return this.f3001a.f3007e.A(menuItem);
    }

    public void e() {
        this.f3001a.f3007e.B();
    }

    public void f() {
        this.f3001a.f3007e.D();
    }

    public void g() {
        this.f3001a.f3007e.M();
    }

    public void h() {
        this.f3001a.f3007e.Q();
    }

    public void i() {
        this.f3001a.f3007e.R();
    }

    public void j() {
        this.f3001a.f3007e.T();
    }

    public boolean k() {
        return this.f3001a.f3007e.a0(true);
    }

    public w l() {
        return this.f3001a.f3007e;
    }

    public void m() {
        this.f3001a.f3007e.U0();
    }

    public View n(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f3001a.f3007e.u0().onCreateView(view, str, context, attributeSet);
    }
}
