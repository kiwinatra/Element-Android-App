package androidx.fragment.app;

import O.e;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.k;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import androidx.lifecycle.l;
import androidx.lifecycle.q;

/* renamed from: androidx.fragment.app.e  reason: case insensitive filesystem */
public class C0175e extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    /* renamed from: c0  reason: collision with root package name */
    private Handler f2962c0;

    /* renamed from: d0  reason: collision with root package name */
    private Runnable f2963d0 = new a();

    /* renamed from: e0  reason: collision with root package name */
    private DialogInterface.OnCancelListener f2964e0 = new b();
    /* access modifiers changed from: private */

    /* renamed from: f0  reason: collision with root package name */
    public DialogInterface.OnDismissListener f2965f0 = new c();

    /* renamed from: g0  reason: collision with root package name */
    private int f2966g0 = 0;

    /* renamed from: h0  reason: collision with root package name */
    private int f2967h0 = 0;

    /* renamed from: i0  reason: collision with root package name */
    private boolean f2968i0 = true;
    /* access modifiers changed from: private */

    /* renamed from: j0  reason: collision with root package name */
    public boolean f2969j0 = true;

    /* renamed from: k0  reason: collision with root package name */
    private int f2970k0 = -1;

    /* renamed from: l0  reason: collision with root package name */
    private boolean f2971l0;

    /* renamed from: m0  reason: collision with root package name */
    private q f2972m0 = new d();
    /* access modifiers changed from: private */

    /* renamed from: n0  reason: collision with root package name */
    public Dialog f2973n0;

    /* renamed from: o0  reason: collision with root package name */
    private boolean f2974o0;

    /* renamed from: p0  reason: collision with root package name */
    private boolean f2975p0;

    /* renamed from: q0  reason: collision with root package name */
    private boolean f2976q0;

    /* renamed from: r0  reason: collision with root package name */
    private boolean f2977r0 = false;

    /* renamed from: androidx.fragment.app.e$a */
    class a implements Runnable {
        a() {
        }

        public void run() {
            C0175e.this.f2965f0.onDismiss(C0175e.this.f2973n0);
        }
    }

    /* renamed from: androidx.fragment.app.e$b */
    class b implements DialogInterface.OnCancelListener {
        b() {
        }

        public void onCancel(DialogInterface dialogInterface) {
            if (C0175e.this.f2973n0 != null) {
                C0175e eVar = C0175e.this;
                eVar.onCancel(eVar.f2973n0);
            }
        }
    }

    /* renamed from: androidx.fragment.app.e$c */
    class c implements DialogInterface.OnDismissListener {
        c() {
        }

        public void onDismiss(DialogInterface dialogInterface) {
            if (C0175e.this.f2973n0 != null) {
                C0175e eVar = C0175e.this;
                eVar.onDismiss(eVar.f2973n0);
            }
        }
    }

    /* renamed from: androidx.fragment.app.e$d */
    class d implements q {
        d() {
        }

        /* renamed from: b */
        public void a(l lVar) {
            if (lVar != null && C0175e.this.f2969j0) {
                View l1 = C0175e.this.l1();
                if (l1.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                } else if (C0175e.this.f2973n0 != null) {
                    if (w.G0(3)) {
                        Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + C0175e.this.f2973n0);
                    }
                    C0175e.this.f2973n0.setContentView(l1);
                }
            }
        }
    }

    /* renamed from: androidx.fragment.app.e$e  reason: collision with other inner class name */
    class C0044e extends C0182l {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ C0182l f2982a;

        C0044e(C0182l lVar) {
            this.f2982a = lVar;
        }

        public View n(int i2) {
            return this.f2982a.o() ? this.f2982a.n(i2) : C0175e.this.E1(i2);
        }

        public boolean o() {
            return this.f2982a.o() || C0175e.this.F1();
        }
    }

    private void A1(boolean z2, boolean z3, boolean z4) {
        if (!this.f2975p0) {
            this.f2975p0 = true;
            this.f2976q0 = false;
            Dialog dialog = this.f2973n0;
            if (dialog != null) {
                dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
                this.f2973n0.dismiss();
                if (!z3) {
                    if (Looper.myLooper() == this.f2962c0.getLooper()) {
                        onDismiss(this.f2973n0);
                    } else {
                        this.f2962c0.post(this.f2963d0);
                    }
                }
            }
            this.f2974o0 = true;
            if (this.f2970k0 >= 0) {
                if (z4) {
                    D().Z0(this.f2970k0, 1);
                } else {
                    D().X0(this.f2970k0, 1, z2);
                }
                this.f2970k0 = -1;
                return;
            }
            E o2 = D().o();
            o2.n(true);
            o2.k(this);
            if (z4) {
                o2.g();
            } else if (z2) {
                o2.f();
            } else {
                o2.e();
            }
        }
    }

    private void G1(Bundle bundle) {
        if (this.f2969j0 && !this.f2977r0) {
            try {
                this.f2971l0 = true;
                Dialog D1 = D1(bundle);
                this.f2973n0 = D1;
                if (this.f2969j0) {
                    I1(D1, this.f2966g0);
                    Context o2 = o();
                    if (o2 instanceof Activity) {
                        this.f2973n0.setOwnerActivity((Activity) o2);
                    }
                    this.f2973n0.setCancelable(this.f2968i0);
                    this.f2973n0.setOnCancelListener(this.f2964e0);
                    this.f2973n0.setOnDismissListener(this.f2965f0);
                    this.f2977r0 = true;
                } else {
                    this.f2973n0 = null;
                }
            } finally {
                this.f2971l0 = false;
            }
        }
    }

    public Dialog B1() {
        return this.f2973n0;
    }

    public int C1() {
        return this.f2967h0;
    }

    public Dialog D1(Bundle bundle) {
        if (w.G0(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new k(k1(), C1());
    }

    /* access modifiers changed from: package-private */
    public View E1(int i2) {
        Dialog dialog = this.f2973n0;
        if (dialog != null) {
            return dialog.findViewById(i2);
        }
        return null;
    }

    public void F0(Bundle bundle) {
        super.F0(bundle);
        Dialog dialog = this.f2973n0;
        if (dialog != null) {
            Bundle onSaveInstanceState = dialog.onSaveInstanceState();
            onSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", onSaveInstanceState);
        }
        int i2 = this.f2966g0;
        if (i2 != 0) {
            bundle.putInt("android:style", i2);
        }
        int i3 = this.f2967h0;
        if (i3 != 0) {
            bundle.putInt("android:theme", i3);
        }
        boolean z2 = this.f2968i0;
        if (!z2) {
            bundle.putBoolean("android:cancelable", z2);
        }
        boolean z3 = this.f2969j0;
        if (!z3) {
            bundle.putBoolean("android:showsDialog", z3);
        }
        int i4 = this.f2970k0;
        if (i4 != -1) {
            bundle.putInt("android:backStackId", i4);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean F1() {
        return this.f2977r0;
    }

    public void G0() {
        super.G0();
        Dialog dialog = this.f2973n0;
        if (dialog != null) {
            this.f2974o0 = false;
            dialog.show();
            View decorView = this.f2973n0.getWindow().getDecorView();
            F.a(decorView, this);
            G.a(decorView, this);
            e.a(decorView, this);
        }
    }

    public void H0() {
        super.H0();
        Dialog dialog = this.f2973n0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    public final Dialog H1() {
        Dialog B1 = B1();
        if (B1 != null) {
            return B1;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    public void I1(Dialog dialog, int i2) {
        if (!(i2 == 1 || i2 == 2)) {
            if (i2 == 3) {
                Window window = dialog.getWindow();
                if (window != null) {
                    window.addFlags(24);
                }
            } else {
                return;
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void J0(Bundle bundle) {
        Bundle bundle2;
        super.J0(bundle);
        if (this.f2973n0 != null && bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
            this.f2973n0.onRestoreInstanceState(bundle2);
        }
    }

    /* access modifiers changed from: package-private */
    public void Q0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.Q0(layoutInflater, viewGroup, bundle);
        if (this.f2759I == null && this.f2973n0 != null && bundle != null && (bundle2 = bundle.getBundle("android:savedDialogState")) != null) {
            this.f2973n0.onRestoreInstanceState(bundle2);
        }
    }

    /* access modifiers changed from: package-private */
    public C0182l c() {
        return new C0044e(super.c());
    }

    public void d0(Bundle bundle) {
        super.d0(bundle);
    }

    public void g0(Context context) {
        super.g0(context);
        S().e(this.f2972m0);
        if (!this.f2976q0) {
            this.f2975p0 = false;
        }
    }

    public void j0(Bundle bundle) {
        super.j0(bundle);
        this.f2962c0 = new Handler();
        this.f2969j0 = this.f2802y == 0;
        if (bundle != null) {
            this.f2966g0 = bundle.getInt("android:style", 0);
            this.f2967h0 = bundle.getInt("android:theme", 0);
            this.f2968i0 = bundle.getBoolean("android:cancelable", true);
            this.f2969j0 = bundle.getBoolean("android:showsDialog", this.f2969j0);
            this.f2970k0 = bundle.getInt("android:backStackId", -1);
        }
    }

    public void onCancel(DialogInterface dialogInterface) {
    }

    public void onDismiss(DialogInterface dialogInterface) {
        if (!this.f2974o0) {
            if (w.G0(3)) {
                Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
            }
            A1(true, true, false);
        }
    }

    public void q0() {
        super.q0();
        Dialog dialog = this.f2973n0;
        if (dialog != null) {
            this.f2974o0 = true;
            dialog.setOnDismissListener((DialogInterface.OnDismissListener) null);
            this.f2973n0.dismiss();
            if (!this.f2975p0) {
                onDismiss(this.f2973n0);
            }
            this.f2973n0 = null;
            this.f2977r0 = false;
        }
    }

    public void r0() {
        super.r0();
        if (!this.f2976q0 && !this.f2975p0) {
            this.f2975p0 = true;
        }
        S().h(this.f2972m0);
    }

    public LayoutInflater s0(Bundle bundle) {
        StringBuilder sb;
        String str;
        LayoutInflater s02 = super.s0(bundle);
        if (!this.f2969j0 || this.f2971l0) {
            if (w.G0(2)) {
                String str2 = "getting layout inflater for DialogFragment " + this;
                if (!this.f2969j0) {
                    sb = new StringBuilder();
                    str = "mShowsDialog = false: ";
                } else {
                    sb = new StringBuilder();
                    str = "mCreatingDialog = true: ";
                }
                sb.append(str);
                sb.append(str2);
                Log.d("FragmentManager", sb.toString());
            }
            return s02;
        }
        G1(bundle);
        if (w.G0(2)) {
            Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
        }
        Dialog dialog = this.f2973n0;
        return dialog != null ? s02.cloneInContext(dialog.getContext()) : s02;
    }
}
