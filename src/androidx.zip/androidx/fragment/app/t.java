package androidx.fragment.app;

import androidx.core.app.g;
import x.C0290a;

public final /* synthetic */ class t implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w f3015a;

    public /* synthetic */ t(w wVar) {
        this.f3015a = wVar;
    }

    public final void a(Object obj) {
        this.f3015a.R0((g) obj);
    }
}
