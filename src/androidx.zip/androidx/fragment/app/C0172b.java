package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.fragment.app.E;
import androidx.lifecycle.C0190g;
import java.util.ArrayList;

/* renamed from: androidx.fragment.app.b  reason: case insensitive filesystem */
final class C0172b implements Parcelable {
    public static final Parcelable.Creator<C0172b> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    final int[] f2900a;

    /* renamed from: b  reason: collision with root package name */
    final ArrayList f2901b;

    /* renamed from: c  reason: collision with root package name */
    final int[] f2902c;

    /* renamed from: d  reason: collision with root package name */
    final int[] f2903d;

    /* renamed from: e  reason: collision with root package name */
    final int f2904e;

    /* renamed from: f  reason: collision with root package name */
    final String f2905f;

    /* renamed from: g  reason: collision with root package name */
    final int f2906g;

    /* renamed from: h  reason: collision with root package name */
    final int f2907h;

    /* renamed from: i  reason: collision with root package name */
    final CharSequence f2908i;

    /* renamed from: j  reason: collision with root package name */
    final int f2909j;

    /* renamed from: k  reason: collision with root package name */
    final CharSequence f2910k;

    /* renamed from: l  reason: collision with root package name */
    final ArrayList f2911l;

    /* renamed from: m  reason: collision with root package name */
    final ArrayList f2912m;

    /* renamed from: n  reason: collision with root package name */
    final boolean f2913n;

    /* renamed from: androidx.fragment.app.b$a */
    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public C0172b createFromParcel(Parcel parcel) {
            return new C0172b(parcel);
        }

        /* renamed from: b */
        public C0172b[] newArray(int i2) {
            return new C0172b[i2];
        }
    }

    C0172b(Parcel parcel) {
        this.f2900a = parcel.createIntArray();
        this.f2901b = parcel.createStringArrayList();
        this.f2902c = parcel.createIntArray();
        this.f2903d = parcel.createIntArray();
        this.f2904e = parcel.readInt();
        this.f2905f = parcel.readString();
        this.f2906g = parcel.readInt();
        this.f2907h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f2908i = (CharSequence) creator.createFromParcel(parcel);
        this.f2909j = parcel.readInt();
        this.f2910k = (CharSequence) creator.createFromParcel(parcel);
        this.f2911l = parcel.createStringArrayList();
        this.f2912m = parcel.createStringArrayList();
        this.f2913n = parcel.readInt() != 0;
    }

    private void c(C0171a aVar) {
        int i2 = 0;
        int i3 = 0;
        while (true) {
            boolean z2 = true;
            if (i2 < this.f2900a.length) {
                E.a aVar2 = new E.a();
                int i4 = i2 + 1;
                aVar2.f2739a = this.f2900a[i2];
                if (w.G0(2)) {
                    Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i3 + " base fragment #" + this.f2900a[i4]);
                }
                aVar2.f2746h = C0190g.b.values()[this.f2902c[i3]];
                aVar2.f2747i = C0190g.b.values()[this.f2903d[i3]];
                int[] iArr = this.f2900a;
                int i5 = i2 + 2;
                if (iArr[i4] == 0) {
                    z2 = false;
                }
                aVar2.f2741c = z2;
                int i6 = iArr[i5];
                aVar2.f2742d = i6;
                int i7 = iArr[i2 + 3];
                aVar2.f2743e = i7;
                int i8 = i2 + 5;
                int i9 = iArr[i2 + 4];
                aVar2.f2744f = i9;
                i2 += 6;
                int i10 = iArr[i8];
                aVar2.f2745g = i10;
                aVar.f2723d = i6;
                aVar.f2724e = i7;
                aVar.f2725f = i9;
                aVar.f2726g = i10;
                aVar.d(aVar2);
                i3++;
            } else {
                aVar.f2727h = this.f2904e;
                aVar.f2730k = this.f2905f;
                aVar.f2728i = true;
                aVar.f2731l = this.f2907h;
                aVar.f2732m = this.f2908i;
                aVar.f2733n = this.f2909j;
                aVar.f2734o = this.f2910k;
                aVar.f2735p = this.f2911l;
                aVar.f2736q = this.f2912m;
                aVar.f2737r = this.f2913n;
                return;
            }
        }
    }

    public C0171a d(w wVar) {
        C0171a aVar = new C0171a(wVar);
        c(aVar);
        aVar.f2898v = this.f2906g;
        for (int i2 = 0; i2 < this.f2901b.size(); i2++) {
            String str = (String) this.f2901b.get(i2);
            if (str != null) {
                ((E.a) aVar.f2722c.get(i2)).f2740b = wVar.e0(str);
            }
        }
        aVar.o(1);
        return aVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f2900a);
        parcel.writeStringList(this.f2901b);
        parcel.writeIntArray(this.f2902c);
        parcel.writeIntArray(this.f2903d);
        parcel.writeInt(this.f2904e);
        parcel.writeString(this.f2905f);
        parcel.writeInt(this.f2906g);
        parcel.writeInt(this.f2907h);
        TextUtils.writeToParcel(this.f2908i, parcel, 0);
        parcel.writeInt(this.f2909j);
        TextUtils.writeToParcel(this.f2910k, parcel, 0);
        parcel.writeStringList(this.f2911l);
        parcel.writeStringList(this.f2912m);
        parcel.writeInt(this.f2913n ? 1 : 0);
    }

    C0172b(C0171a aVar) {
        int size = aVar.f2722c.size();
        this.f2900a = new int[(size * 6)];
        if (aVar.f2728i) {
            this.f2901b = new ArrayList(size);
            this.f2902c = new int[size];
            this.f2903d = new int[size];
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                E.a aVar2 = (E.a) aVar.f2722c.get(i3);
                int i4 = i2 + 1;
                this.f2900a[i2] = aVar2.f2739a;
                ArrayList arrayList = this.f2901b;
                Fragment fragment = aVar2.f2740b;
                arrayList.add(fragment != null ? fragment.f2783f : null);
                int[] iArr = this.f2900a;
                iArr[i4] = aVar2.f2741c;
                iArr[i2 + 2] = aVar2.f2742d;
                iArr[i2 + 3] = aVar2.f2743e;
                int i5 = i2 + 5;
                iArr[i2 + 4] = aVar2.f2744f;
                i2 += 6;
                iArr[i5] = aVar2.f2745g;
                this.f2902c[i3] = aVar2.f2746h.ordinal();
                this.f2903d[i3] = aVar2.f2747i.ordinal();
            }
            this.f2904e = aVar.f2727h;
            this.f2905f = aVar.f2730k;
            this.f2906g = aVar.f2898v;
            this.f2907h = aVar.f2731l;
            this.f2908i = aVar.f2732m;
            this.f2909j = aVar.f2733n;
            this.f2910k = aVar.f2734o;
            this.f2911l = aVar.f2735p;
            this.f2912m = aVar.f2736q;
            this.f2913n = aVar.f2737r;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }
}
