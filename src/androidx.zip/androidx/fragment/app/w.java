package androidx.fragment.app;

import J.c;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.o;
import androidx.core.view.C0164w;
import androidx.core.view.C0170z;
import androidx.fragment.app.E;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.D;
import c.C0211a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import x.C0290a;

public abstract class w {

    /* renamed from: S  reason: collision with root package name */
    private static boolean f3018S = false;

    /* renamed from: A  reason: collision with root package name */
    private n f3019A = new d();

    /* renamed from: B  reason: collision with root package name */
    private L f3020B = null;

    /* renamed from: C  reason: collision with root package name */
    private L f3021C = new e();

    /* renamed from: D  reason: collision with root package name */
    private androidx.activity.result.c f3022D;

    /* renamed from: E  reason: collision with root package name */
    private androidx.activity.result.c f3023E;

    /* renamed from: F  reason: collision with root package name */
    private androidx.activity.result.c f3024F;

    /* renamed from: G  reason: collision with root package name */
    ArrayDeque f3025G = new ArrayDeque();

    /* renamed from: H  reason: collision with root package name */
    private boolean f3026H;

    /* renamed from: I  reason: collision with root package name */
    private boolean f3027I;

    /* renamed from: J  reason: collision with root package name */
    private boolean f3028J;

    /* renamed from: K  reason: collision with root package name */
    private boolean f3029K;

    /* renamed from: L  reason: collision with root package name */
    private boolean f3030L;

    /* renamed from: M  reason: collision with root package name */
    private ArrayList f3031M;

    /* renamed from: N  reason: collision with root package name */
    private ArrayList f3032N;

    /* renamed from: O  reason: collision with root package name */
    private ArrayList f3033O;

    /* renamed from: P  reason: collision with root package name */
    private z f3034P;

    /* renamed from: Q  reason: collision with root package name */
    private c.C0006c f3035Q;

    /* renamed from: R  reason: collision with root package name */
    private Runnable f3036R = new f();

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList f3037a = new ArrayList();

    /* renamed from: b  reason: collision with root package name */
    private boolean f3038b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final D f3039c = new D();

    /* renamed from: d  reason: collision with root package name */
    ArrayList f3040d;

    /* renamed from: e  reason: collision with root package name */
    private ArrayList f3041e;

    /* renamed from: f  reason: collision with root package name */
    private final p f3042f = new p(this);

    /* renamed from: g  reason: collision with root package name */
    private OnBackPressedDispatcher f3043g;

    /* renamed from: h  reason: collision with root package name */
    private final o f3044h = new b(false);

    /* renamed from: i  reason: collision with root package name */
    private final AtomicInteger f3045i = new AtomicInteger();

    /* renamed from: j  reason: collision with root package name */
    private final Map f3046j = Collections.synchronizedMap(new HashMap());
    /* access modifiers changed from: private */

    /* renamed from: k  reason: collision with root package name */
    public final Map f3047k = Collections.synchronizedMap(new HashMap());
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public final Map f3048l = Collections.synchronizedMap(new HashMap());

    /* renamed from: m  reason: collision with root package name */
    private ArrayList f3049m;

    /* renamed from: n  reason: collision with root package name */
    private final q f3050n = new q(this);

    /* renamed from: o  reason: collision with root package name */
    private final CopyOnWriteArrayList f3051o = new CopyOnWriteArrayList();

    /* renamed from: p  reason: collision with root package name */
    private final C0290a f3052p = new r(this);

    /* renamed from: q  reason: collision with root package name */
    private final C0290a f3053q = new s(this);

    /* renamed from: r  reason: collision with root package name */
    private final C0290a f3054r = new t(this);

    /* renamed from: s  reason: collision with root package name */
    private final C0290a f3055s = new u(this);

    /* renamed from: t  reason: collision with root package name */
    private final C0170z f3056t = new c();

    /* renamed from: u  reason: collision with root package name */
    int f3057u = -1;

    /* renamed from: v  reason: collision with root package name */
    private o f3058v;

    /* renamed from: w  reason: collision with root package name */
    private C0182l f3059w;

    /* renamed from: x  reason: collision with root package name */
    private Fragment f3060x;

    /* renamed from: y  reason: collision with root package name */
    Fragment f3061y;

    /* renamed from: z  reason: collision with root package name */
    private n f3062z = null;

    class a implements androidx.activity.result.b {
        a() {
        }

        /* renamed from: b */
        public void a(Map map) {
            StringBuilder sb;
            String[] strArr = (String[]) map.keySet().toArray(new String[0]);
            ArrayList arrayList = new ArrayList(map.values());
            int[] iArr = new int[arrayList.size()];
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                iArr[i2] = ((Boolean) arrayList.get(i2)).booleanValue() ? 0 : -1;
            }
            k kVar = (k) w.this.f3025G.pollFirst();
            if (kVar == null) {
                sb = new StringBuilder();
                sb.append("No permissions were requested for ");
                sb.append(this);
            } else {
                String str = kVar.f3073a;
                int i3 = kVar.f3074b;
                Fragment i4 = w.this.f3039c.i(str);
                if (i4 == null) {
                    sb = new StringBuilder();
                    sb.append("Permission request result delivered for unknown Fragment ");
                    sb.append(str);
                } else {
                    i4.D0(i3, strArr, iArr);
                    return;
                }
            }
            Log.w("FragmentManager", sb.toString());
        }
    }

    class b extends o {
        b(boolean z2) {
            super(z2);
        }

        public void d() {
            w.this.C0();
        }
    }

    class c implements C0170z {
        c() {
        }

        public void a(Menu menu, MenuInflater menuInflater) {
            w.this.C(menu, menuInflater);
        }

        public void b(Menu menu) {
            w.this.O(menu);
        }

        public boolean c(MenuItem menuItem) {
            return w.this.J(menuItem);
        }

        public void d(Menu menu) {
            w.this.K(menu);
        }
    }

    class d extends n {
        d() {
        }

        public Fragment a(ClassLoader classLoader, String str) {
            return w.this.t0().m(w.this.t0().s(), str, (Bundle) null);
        }
    }

    class e implements L {
        e() {
        }

        public K a(ViewGroup viewGroup) {
            return new C0174d(viewGroup);
        }
    }

    class f implements Runnable {
        f() {
        }

        public void run() {
            w.this.a0(true);
        }
    }

    class g implements A {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Fragment f3069a;

        g(Fragment fragment) {
            this.f3069a = fragment;
        }

        public void a(w wVar, Fragment fragment) {
            this.f3069a.h0(fragment);
        }
    }

    class h implements androidx.activity.result.b {
        h() {
        }

        /* renamed from: b */
        public void a(androidx.activity.result.a aVar) {
            k kVar = (k) w.this.f3025G.pollFirst();
            if (kVar == null) {
                Log.w("FragmentManager", "No Activities were started for result for " + this);
                return;
            }
            String str = kVar.f3073a;
            int i2 = kVar.f3074b;
            Fragment i3 = w.this.f3039c.i(str);
            if (i3 == null) {
                Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str);
                return;
            }
            i3.e0(i2, aVar.d(), aVar.c());
        }
    }

    class i implements androidx.activity.result.b {
        i() {
        }

        /* renamed from: b */
        public void a(androidx.activity.result.a aVar) {
            k kVar = (k) w.this.f3025G.pollFirst();
            if (kVar == null) {
                Log.w("FragmentManager", "No IntentSenders were started for " + this);
                return;
            }
            String str = kVar.f3073a;
            int i2 = kVar.f3074b;
            Fragment i3 = w.this.f3039c.i(str);
            if (i3 == null) {
                Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str);
                return;
            }
            i3.e0(i2, aVar.d(), aVar.c());
        }
    }

    static class j extends C0211a {
        j() {
        }

        /* renamed from: b */
        public androidx.activity.result.a a(int i2, Intent intent) {
            return new androidx.activity.result.a(i2, intent);
        }
    }

    static class k implements Parcelable {
        public static final Parcelable.Creator<k> CREATOR = new a();

        /* renamed from: a  reason: collision with root package name */
        String f3073a;

        /* renamed from: b  reason: collision with root package name */
        int f3074b;

        class a implements Parcelable.Creator {
            a() {
            }

            /* renamed from: a */
            public k createFromParcel(Parcel parcel) {
                return new k(parcel);
            }

            /* renamed from: b */
            public k[] newArray(int i2) {
                return new k[i2];
            }
        }

        k(Parcel parcel) {
            this.f3073a = parcel.readString();
            this.f3074b = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeString(this.f3073a);
            parcel.writeInt(this.f3074b);
        }
    }

    interface l {
        boolean a(ArrayList arrayList, ArrayList arrayList2);
    }

    private class m implements l {

        /* renamed from: a  reason: collision with root package name */
        final String f3075a;

        /* renamed from: b  reason: collision with root package name */
        final int f3076b;

        /* renamed from: c  reason: collision with root package name */
        final int f3077c;

        m(String str, int i2, int i3) {
            this.f3075a = str;
            this.f3076b = i2;
            this.f3077c = i3;
        }

        public boolean a(ArrayList arrayList, ArrayList arrayList2) {
            Fragment fragment = w.this.f3061y;
            if (fragment != null && this.f3076b < 0 && this.f3075a == null && fragment.n().Y0()) {
                return false;
            }
            return w.this.b1(arrayList, arrayList2, this.f3075a, this.f3076b, this.f3077c);
        }
    }

    static Fragment A0(View view) {
        Object tag = view.getTag(I.b.fragment_container_view_tag);
        if (tag instanceof Fragment) {
            return (Fragment) tag;
        }
        return null;
    }

    public static boolean G0(int i2) {
        return f3018S || Log.isLoggable("FragmentManager", i2);
    }

    private boolean H0(Fragment fragment) {
        return (fragment.f2755E && fragment.f2756F) || fragment.f2799v.p();
    }

    private boolean I0() {
        Fragment fragment = this.f3060x;
        if (fragment == null) {
            return true;
        }
        return fragment.W() && this.f3060x.D().I0();
    }

    private void L(Fragment fragment) {
        if (fragment != null && fragment.equals(e0(fragment.f2783f))) {
            fragment.c1();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void P0(Configuration configuration) {
        if (I0()) {
            z(configuration, false);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void Q0(Integer num) {
        if (I0() && num.intValue() == 80) {
            F(false);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void R0(androidx.core.app.g gVar) {
        if (I0()) {
            G(gVar.a(), false);
        }
    }

    /* JADX INFO: finally extract failed */
    private void S(int i2) {
        try {
            this.f3038b = true;
            this.f3039c.d(i2);
            T0(i2, false);
            for (K j2 : t()) {
                j2.j();
            }
            this.f3038b = false;
            a0(true);
        } catch (Throwable th) {
            this.f3038b = false;
            throw th;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void S0(androidx.core.app.k kVar) {
        if (I0()) {
            N(kVar.a(), false);
        }
    }

    private void V() {
        if (this.f3030L) {
            this.f3030L = false;
            o1();
        }
    }

    private void X() {
        for (K j2 : t()) {
            j2.j();
        }
    }

    private void Z(boolean z2) {
        if (this.f3038b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        } else if (this.f3058v == null) {
            if (this.f3029K) {
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            throw new IllegalStateException("FragmentManager has not been attached to a host.");
        } else if (Looper.myLooper() == this.f3058v.u().getLooper()) {
            if (!z2) {
                q();
            }
            if (this.f3031M == null) {
                this.f3031M = new ArrayList();
                this.f3032N = new ArrayList();
            }
        } else {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
    }

    private boolean a1(String str, int i2, int i3) {
        a0(false);
        Z(true);
        Fragment fragment = this.f3061y;
        if (fragment != null && i2 < 0 && str == null && fragment.n().Y0()) {
            return true;
        }
        boolean b1 = b1(this.f3031M, this.f3032N, str, i2, i3);
        if (b1) {
            this.f3038b = true;
            try {
                d1(this.f3031M, this.f3032N);
            } finally {
                r();
            }
        }
        q1();
        V();
        this.f3039c.b();
        return b1;
    }

    private static void c0(ArrayList arrayList, ArrayList arrayList2, int i2, int i3) {
        while (i2 < i3) {
            C0171a aVar = (C0171a) arrayList.get(i2);
            if (((Boolean) arrayList2.get(i2)).booleanValue()) {
                aVar.o(-1);
                aVar.t();
            } else {
                aVar.o(1);
                aVar.s();
            }
            i2++;
        }
    }

    private void d0(ArrayList arrayList, ArrayList arrayList2, int i2, int i3) {
        boolean z2 = ((C0171a) arrayList.get(i2)).f2737r;
        ArrayList arrayList3 = this.f3033O;
        if (arrayList3 == null) {
            this.f3033O = new ArrayList();
        } else {
            arrayList3.clear();
        }
        this.f3033O.addAll(this.f3039c.o());
        Fragment x02 = x0();
        boolean z3 = false;
        for (int i4 = i2; i4 < i3; i4++) {
            C0171a aVar = (C0171a) arrayList.get(i4);
            x02 = !((Boolean) arrayList2.get(i4)).booleanValue() ? aVar.u(this.f3033O, x02) : aVar.x(this.f3033O, x02);
            z3 = z3 || aVar.f2728i;
        }
        this.f3033O.clear();
        if (!z2 && this.f3057u >= 1) {
            for (int i5 = i2; i5 < i3; i5++) {
                Iterator it = ((C0171a) arrayList.get(i5)).f2722c.iterator();
                while (it.hasNext()) {
                    Fragment fragment = ((E.a) it.next()).f2740b;
                    if (!(fragment == null || fragment.f2797t == null)) {
                        this.f3039c.r(v(fragment));
                    }
                }
            }
        }
        c0(arrayList, arrayList2, i2, i3);
        boolean booleanValue = ((Boolean) arrayList2.get(i3 - 1)).booleanValue();
        for (int i6 = i2; i6 < i3; i6++) {
            C0171a aVar2 = (C0171a) arrayList.get(i6);
            if (booleanValue) {
                for (int size = aVar2.f2722c.size() - 1; size >= 0; size--) {
                    Fragment fragment2 = ((E.a) aVar2.f2722c.get(size)).f2740b;
                    if (fragment2 != null) {
                        v(fragment2).m();
                    }
                }
            } else {
                Iterator it2 = aVar2.f2722c.iterator();
                while (it2.hasNext()) {
                    Fragment fragment3 = ((E.a) it2.next()).f2740b;
                    if (fragment3 != null) {
                        v(fragment3).m();
                    }
                }
            }
        }
        T0(this.f3057u, true);
        for (K k2 : u(arrayList, i2, i3)) {
            k2.r(booleanValue);
            k2.p();
            k2.g();
        }
        while (i2 < i3) {
            C0171a aVar3 = (C0171a) arrayList.get(i2);
            if (((Boolean) arrayList2.get(i2)).booleanValue() && aVar3.f2898v >= 0) {
                aVar3.f2898v = -1;
            }
            aVar3.w();
            i2++;
        }
        if (z3) {
            e1();
        }
    }

    private void d1(ArrayList arrayList, ArrayList arrayList2) {
        if (!arrayList.isEmpty()) {
            if (arrayList.size() == arrayList2.size()) {
                int size = arrayList.size();
                int i2 = 0;
                int i3 = 0;
                while (i2 < size) {
                    if (!((C0171a) arrayList.get(i2)).f2737r) {
                        if (i3 != i2) {
                            d0(arrayList, arrayList2, i3, i2);
                        }
                        i3 = i2 + 1;
                        if (((Boolean) arrayList2.get(i2)).booleanValue()) {
                            while (i3 < size && ((Boolean) arrayList2.get(i3)).booleanValue() && !((C0171a) arrayList.get(i3)).f2737r) {
                                i3++;
                            }
                        }
                        d0(arrayList, arrayList2, i2, i3);
                        i2 = i3 - 1;
                    }
                    i2++;
                }
                if (i3 != size) {
                    d0(arrayList, arrayList2, i3, size);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Internal error with the back stack records");
        }
    }

    private void e1() {
        ArrayList arrayList = this.f3049m;
        if (arrayList != null && arrayList.size() > 0) {
            android.support.v4.media.session.b.a(this.f3049m.get(0));
            throw null;
        }
    }

    private int f0(String str, int i2, boolean z2) {
        ArrayList arrayList = this.f3040d;
        if (arrayList == null || arrayList.isEmpty()) {
            return -1;
        }
        if (str != null || i2 >= 0) {
            int size = this.f3040d.size() - 1;
            while (size >= 0) {
                C0171a aVar = (C0171a) this.f3040d.get(size);
                if ((str != null && str.equals(aVar.v())) || (i2 >= 0 && i2 == aVar.f2898v)) {
                    break;
                }
                size--;
            }
            if (size < 0) {
                return size;
            }
            if (z2) {
                while (size > 0) {
                    C0171a aVar2 = (C0171a) this.f3040d.get(size - 1);
                    if ((str == null || !str.equals(aVar2.v())) && (i2 < 0 || i2 != aVar2.f2898v)) {
                        return size;
                    }
                    size--;
                }
                return size;
            } else if (size == this.f3040d.size() - 1) {
                return -1;
            } else {
                return size + 1;
            }
        } else if (z2) {
            return 0;
        } else {
            return this.f3040d.size() - 1;
        }
    }

    static int g1(int i2) {
        if (i2 == 4097) {
            return 8194;
        }
        if (i2 == 8194) {
            return 4097;
        }
        if (i2 == 8197) {
            return 4100;
        }
        if (i2 != 4099) {
            return i2 != 4100 ? 0 : 8197;
        }
        return 4099;
    }

    static w j0(View view) {
        C0180j jVar;
        Fragment k02 = k0(view);
        if (k02 == null) {
            Context context = view.getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    jVar = null;
                    break;
                } else if (context instanceof C0180j) {
                    jVar = (C0180j) context;
                    break;
                } else {
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
            if (jVar != null) {
                return jVar.T();
            }
            throw new IllegalStateException("View " + view + " is not within a subclass of FragmentActivity.");
        } else if (k02.W()) {
            return k02.n();
        } else {
            throw new IllegalStateException("The Fragment " + k02 + " that owns View " + view + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
        }
    }

    private static Fragment k0(View view) {
        while (view != null) {
            Fragment A02 = A0(view);
            if (A02 != null) {
                return A02;
            }
            ViewParent parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        return null;
    }

    private void l0() {
        for (K k2 : t()) {
            k2.k();
        }
    }

    private boolean m0(ArrayList arrayList, ArrayList arrayList2) {
        synchronized (this.f3037a) {
            if (this.f3037a.isEmpty()) {
                return false;
            }
            try {
                int size = this.f3037a.size();
                boolean z2 = false;
                for (int i2 = 0; i2 < size; i2++) {
                    z2 |= ((l) this.f3037a.get(i2)).a(arrayList, arrayList2);
                }
                return z2;
            } finally {
                this.f3037a.clear();
                this.f3058v.u().removeCallbacks(this.f3036R);
            }
        }
    }

    private void m1(Fragment fragment) {
        ViewGroup q02 = q0(fragment);
        if (q02 != null && fragment.p() + fragment.s() + fragment.F() + fragment.G() > 0) {
            int i2 = I.b.visible_removing_fragment_view_tag;
            if (q02.getTag(i2) == null) {
                q02.setTag(i2, fragment);
            }
            ((Fragment) q02.getTag(i2)).t1(fragment.E());
        }
    }

    private z o0(Fragment fragment) {
        return this.f3034P.j(fragment);
    }

    private void o1() {
        for (C W0 : this.f3039c.k()) {
            W0(W0);
        }
    }

    private void p1(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new J("FragmentManager"));
        o oVar = this.f3058v;
        if (oVar != null) {
            try {
                oVar.w("  ", (FileDescriptor) null, printWriter, new String[0]);
            } catch (Exception e2) {
                Log.e("FragmentManager", "Failed dumping state", e2);
            }
        } else {
            W("  ", (FileDescriptor) null, printWriter, new String[0]);
        }
        throw runtimeException;
    }

    private void q() {
        if (N0()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    private ViewGroup q0(Fragment fragment) {
        ViewGroup viewGroup = fragment.f2758H;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (fragment.f2802y > 0 && this.f3059w.o()) {
            View n2 = this.f3059w.n(fragment.f2802y);
            if (n2 instanceof ViewGroup) {
                return (ViewGroup) n2;
            }
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0016, code lost:
        r0 = r3.f3044h;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001c, code lost:
        if (n0() <= 0) goto L_0x0027;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0024, code lost:
        if (L0(r3.f3060x) == false) goto L_0x0027;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0027, code lost:
        r2 = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0028, code lost:
        r0.j(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002b, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void q1() {
        /*
            r3 = this;
            java.util.ArrayList r0 = r3.f3037a
            monitor-enter(r0)
            java.util.ArrayList r1 = r3.f3037a     // Catch:{ all -> 0x0013 }
            boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x0013 }
            r2 = 1
            if (r1 != 0) goto L_0x0015
            androidx.activity.o r1 = r3.f3044h     // Catch:{ all -> 0x0013 }
            r1.j(r2)     // Catch:{ all -> 0x0013 }
            monitor-exit(r0)     // Catch:{ all -> 0x0013 }
            return
        L_0x0013:
            r1 = move-exception
            goto L_0x002c
        L_0x0015:
            monitor-exit(r0)     // Catch:{ all -> 0x0013 }
            androidx.activity.o r0 = r3.f3044h
            int r1 = r3.n0()
            if (r1 <= 0) goto L_0x0027
            androidx.fragment.app.Fragment r1 = r3.f3060x
            boolean r1 = r3.L0(r1)
            if (r1 == 0) goto L_0x0027
            goto L_0x0028
        L_0x0027:
            r2 = 0
        L_0x0028:
            r0.j(r2)
            return
        L_0x002c:
            monitor-exit(r0)     // Catch:{ all -> 0x0013 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.w.q1():void");
    }

    private void r() {
        this.f3038b = false;
        this.f3032N.clear();
        this.f3031M.clear();
    }

    private void s() {
        o oVar = this.f3058v;
        if (oVar instanceof androidx.lifecycle.E ? this.f3039c.p().n() : oVar.s() instanceof Activity ? !((Activity) this.f3058v.s()).isChangingConfigurations() : true) {
            for (C0173c cVar : this.f3046j.values()) {
                for (String g2 : cVar.f2914a) {
                    this.f3039c.p().g(g2);
                }
            }
        }
    }

    private Set t() {
        HashSet hashSet = new HashSet();
        for (C k2 : this.f3039c.k()) {
            ViewGroup viewGroup = k2.k().f2758H;
            if (viewGroup != null) {
                hashSet.add(K.o(viewGroup, y0()));
            }
        }
        return hashSet;
    }

    private Set u(ArrayList arrayList, int i2, int i3) {
        ViewGroup viewGroup;
        HashSet hashSet = new HashSet();
        while (i2 < i3) {
            Iterator it = ((C0171a) arrayList.get(i2)).f2722c.iterator();
            while (it.hasNext()) {
                Fragment fragment = ((E.a) it.next()).f2740b;
                if (!(fragment == null || (viewGroup = fragment.f2758H) == null)) {
                    hashSet.add(K.n(viewGroup, this));
                }
            }
            i2++;
        }
        return hashSet;
    }

    /* access modifiers changed from: package-private */
    public boolean A(MenuItem menuItem) {
        if (this.f3057u < 1) {
            return false;
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null && fragment.N0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void B() {
        this.f3027I = false;
        this.f3028J = false;
        this.f3034P.p(false);
        S(1);
    }

    /* access modifiers changed from: package-private */
    public D B0(Fragment fragment) {
        return this.f3034P.m(fragment);
    }

    /* access modifiers changed from: package-private */
    public boolean C(Menu menu, MenuInflater menuInflater) {
        if (this.f3057u < 1) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z2 = false;
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null && K0(fragment) && fragment.P0(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(fragment);
                z2 = true;
            }
        }
        if (this.f3041e != null) {
            for (int i2 = 0; i2 < this.f3041e.size(); i2++) {
                Fragment fragment2 = (Fragment) this.f3041e.get(i2);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    fragment2.p0();
                }
            }
        }
        this.f3041e = arrayList;
        return z2;
    }

    /* access modifiers changed from: package-private */
    public void C0() {
        a0(true);
        if (this.f3044h.g()) {
            Y0();
        } else {
            this.f3043g.k();
        }
    }

    /* access modifiers changed from: package-private */
    public void D() {
        this.f3029K = true;
        a0(true);
        X();
        s();
        S(-1);
        o oVar = this.f3058v;
        if (oVar instanceof androidx.core.content.d) {
            ((androidx.core.content.d) oVar).j(this.f3053q);
        }
        o oVar2 = this.f3058v;
        if (oVar2 instanceof androidx.core.content.c) {
            ((androidx.core.content.c) oVar2).r(this.f3052p);
        }
        o oVar3 = this.f3058v;
        if (oVar3 instanceof androidx.core.app.i) {
            ((androidx.core.app.i) oVar3).g(this.f3054r);
        }
        o oVar4 = this.f3058v;
        if (oVar4 instanceof androidx.core.app.j) {
            ((androidx.core.app.j) oVar4).i(this.f3055s);
        }
        o oVar5 = this.f3058v;
        if (oVar5 instanceof C0164w) {
            ((C0164w) oVar5).f(this.f3056t);
        }
        this.f3058v = null;
        this.f3059w = null;
        this.f3060x = null;
        if (this.f3043g != null) {
            this.f3044h.h();
            this.f3043g = null;
        }
        androidx.activity.result.c cVar = this.f3022D;
        if (cVar != null) {
            cVar.a();
            this.f3023E.a();
            this.f3024F.a();
        }
    }

    /* access modifiers changed from: package-private */
    public void D0(Fragment fragment) {
        if (G0(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (!fragment.f2751A) {
            fragment.f2751A = true;
            fragment.f2764N = true ^ fragment.f2764N;
            m1(fragment);
        }
    }

    /* access modifiers changed from: package-private */
    public void E() {
        S(1);
    }

    /* access modifiers changed from: package-private */
    public void E0(Fragment fragment) {
        if (fragment.f2789l && H0(fragment)) {
            this.f3026H = true;
        }
    }

    /* access modifiers changed from: package-private */
    public void F(boolean z2) {
        if (z2 && (this.f3058v instanceof androidx.core.content.d)) {
            p1(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments."));
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null) {
                fragment.V0();
                if (z2) {
                    fragment.f2799v.F(true);
                }
            }
        }
    }

    public boolean F0() {
        return this.f3029K;
    }

    /* access modifiers changed from: package-private */
    public void G(boolean z2, boolean z3) {
        if (z3 && (this.f3058v instanceof androidx.core.app.i)) {
            p1(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments."));
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null) {
                fragment.W0(z2);
                if (z3) {
                    fragment.f2799v.G(z2, true);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void H(Fragment fragment) {
        Iterator it = this.f3051o.iterator();
        while (it.hasNext()) {
            ((A) it.next()).a(this, fragment);
        }
    }

    /* access modifiers changed from: package-private */
    public void I() {
        for (Fragment fragment : this.f3039c.l()) {
            if (fragment != null) {
                fragment.t0(fragment.X());
                fragment.f2799v.I();
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean J(MenuItem menuItem) {
        if (this.f3057u < 1) {
            return false;
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null && fragment.X0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public boolean J0(Fragment fragment) {
        if (fragment == null) {
            return false;
        }
        return fragment.X();
    }

    /* access modifiers changed from: package-private */
    public void K(Menu menu) {
        if (this.f3057u >= 1) {
            for (Fragment fragment : this.f3039c.o()) {
                if (fragment != null) {
                    fragment.Y0(menu);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public boolean K0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        return fragment.Z();
    }

    /* access modifiers changed from: package-private */
    public boolean L0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        w wVar = fragment.f2797t;
        return fragment.equals(wVar.x0()) && L0(wVar.f3060x);
    }

    /* access modifiers changed from: package-private */
    public void M() {
        S(5);
    }

    /* access modifiers changed from: package-private */
    public boolean M0(int i2) {
        return this.f3057u >= i2;
    }

    /* access modifiers changed from: package-private */
    public void N(boolean z2, boolean z3) {
        if (z3 && (this.f3058v instanceof androidx.core.app.j)) {
            p1(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments."));
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null) {
                fragment.a1(z2);
                if (z3) {
                    fragment.f2799v.N(z2, true);
                }
            }
        }
    }

    public boolean N0() {
        return this.f3027I || this.f3028J;
    }

    /* access modifiers changed from: package-private */
    public boolean O(Menu menu) {
        boolean z2 = false;
        if (this.f3057u < 1) {
            return false;
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null && K0(fragment) && fragment.b1(menu)) {
                z2 = true;
            }
        }
        return z2;
    }

    /* access modifiers changed from: package-private */
    public void P() {
        q1();
        L(this.f3061y);
    }

    /* access modifiers changed from: package-private */
    public void Q() {
        this.f3027I = false;
        this.f3028J = false;
        this.f3034P.p(false);
        S(7);
    }

    /* access modifiers changed from: package-private */
    public void R() {
        this.f3027I = false;
        this.f3028J = false;
        this.f3034P.p(false);
        S(5);
    }

    /* access modifiers changed from: package-private */
    public void T() {
        this.f3028J = true;
        this.f3034P.p(true);
        S(4);
    }

    /* access modifiers changed from: package-private */
    public void T0(int i2, boolean z2) {
        o oVar;
        if (this.f3058v == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        } else if (z2 || i2 != this.f3057u) {
            this.f3057u = i2;
            this.f3039c.t();
            o1();
            if (this.f3026H && (oVar = this.f3058v) != null && this.f3057u == 7) {
                oVar.z();
                this.f3026H = false;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void U() {
        S(2);
    }

    /* access modifiers changed from: package-private */
    public void U0() {
        if (this.f3058v != null) {
            this.f3027I = false;
            this.f3028J = false;
            this.f3034P.p(false);
            for (Fragment fragment : this.f3039c.o()) {
                if (fragment != null) {
                    fragment.c0();
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void V0(FragmentContainerView fragmentContainerView) {
        View view;
        for (C c2 : this.f3039c.k()) {
            Fragment k2 = c2.k();
            if (k2.f2802y == fragmentContainerView.getId() && (view = k2.f2759I) != null && view.getParent() == null) {
                k2.f2758H = fragmentContainerView;
                c2.b();
            }
        }
    }

    public void W(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String str2 = str + "    ";
        this.f3039c.e(str, fileDescriptor, printWriter, strArr);
        ArrayList arrayList = this.f3041e;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i2 = 0; i2 < size2; i2++) {
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(((Fragment) this.f3041e.get(i2)).toString());
            }
        }
        ArrayList arrayList2 = this.f3040d;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i3 = 0; i3 < size; i3++) {
                C0171a aVar = (C0171a) this.f3040d.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.q(str2, printWriter);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f3045i.get());
        synchronized (this.f3037a) {
            try {
                int size3 = this.f3037a.size();
                if (size3 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i4 = 0; i4 < size3; i4++) {
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i4);
                        printWriter.print(": ");
                        printWriter.println((l) this.f3037a.get(i4));
                    }
                }
            } catch (Throwable th) {
                while (true) {
                    throw th;
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f3058v);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f3059w);
        if (this.f3060x != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f3060x);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f3057u);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f3027I);
        printWriter.print(" mStopped=");
        printWriter.print(this.f3028J);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f3029K);
        if (this.f3026H) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f3026H);
        }
    }

    /* access modifiers changed from: package-private */
    public void W0(C c2) {
        Fragment k2 = c2.k();
        if (!k2.f2760J) {
            return;
        }
        if (this.f3038b) {
            this.f3030L = true;
            return;
        }
        k2.f2760J = false;
        c2.m();
    }

    /* access modifiers changed from: package-private */
    public void X0(int i2, int i3, boolean z2) {
        if (i2 >= 0) {
            Y(new m((String) null, i2, i3), z2);
            return;
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    /* access modifiers changed from: package-private */
    public void Y(l lVar, boolean z2) {
        if (!z2) {
            if (this.f3058v != null) {
                q();
            } else if (this.f3029K) {
                throw new IllegalStateException("FragmentManager has been destroyed");
            } else {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
        }
        synchronized (this.f3037a) {
            try {
                if (this.f3058v != null) {
                    this.f3037a.add(lVar);
                    i1();
                } else if (!z2) {
                    throw new IllegalStateException("Activity has been destroyed");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public boolean Y0() {
        return a1((String) null, -1, 0);
    }

    public boolean Z0(int i2, int i3) {
        if (i2 >= 0) {
            return a1((String) null, i2, i3);
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    /* access modifiers changed from: package-private */
    public boolean a0(boolean z2) {
        Z(z2);
        boolean z3 = false;
        while (m0(this.f3031M, this.f3032N)) {
            z3 = true;
            this.f3038b = true;
            try {
                d1(this.f3031M, this.f3032N);
            } finally {
                r();
            }
        }
        q1();
        V();
        this.f3039c.b();
        return z3;
    }

    /* access modifiers changed from: package-private */
    public void b0(l lVar, boolean z2) {
        if (!z2 || (this.f3058v != null && !this.f3029K)) {
            Z(z2);
            if (lVar.a(this.f3031M, this.f3032N)) {
                this.f3038b = true;
                try {
                    d1(this.f3031M, this.f3032N);
                } finally {
                    r();
                }
            }
            q1();
            V();
            this.f3039c.b();
        }
    }

    /* access modifiers changed from: package-private */
    public boolean b1(ArrayList arrayList, ArrayList arrayList2, String str, int i2, int i3) {
        int f02 = f0(str, i2, (i3 & 1) != 0);
        if (f02 < 0) {
            return false;
        }
        for (int size = this.f3040d.size() - 1; size >= f02; size--) {
            arrayList.add((C0171a) this.f3040d.remove(size));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public void c1(Fragment fragment) {
        if (G0(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.f2796s);
        }
        boolean z2 = !fragment.Y();
        if (!fragment.f2752B || z2) {
            this.f3039c.u(fragment);
            if (H0(fragment)) {
                this.f3026H = true;
            }
            fragment.f2790m = true;
            m1(fragment);
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment e0(String str) {
        return this.f3039c.f(str);
    }

    /* access modifiers changed from: package-private */
    public void f1(Parcelable parcelable) {
        C c2;
        Bundle bundle;
        Bundle bundle2;
        if (parcelable != null) {
            Bundle bundle3 = (Bundle) parcelable;
            for (String next : bundle3.keySet()) {
                if (next.startsWith("result_") && (bundle2 = bundle3.getBundle(next)) != null) {
                    bundle2.setClassLoader(this.f3058v.s().getClassLoader());
                    this.f3047k.put(next.substring(7), bundle2);
                }
            }
            ArrayList arrayList = new ArrayList();
            for (String next2 : bundle3.keySet()) {
                if (next2.startsWith("fragment_") && (bundle = bundle3.getBundle(next2)) != null) {
                    bundle.setClassLoader(this.f3058v.s().getClassLoader());
                    arrayList.add((B) bundle.getParcelable("state"));
                }
            }
            this.f3039c.x(arrayList);
            y yVar = (y) bundle3.getParcelable("state");
            if (yVar != null) {
                this.f3039c.v();
                Iterator it = yVar.f3079a.iterator();
                while (it.hasNext()) {
                    B B2 = this.f3039c.B((String) it.next(), (B) null);
                    if (B2 != null) {
                        Fragment i2 = this.f3034P.i(B2.f2696b);
                        if (i2 != null) {
                            if (G0(2)) {
                                Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + i2);
                            }
                            c2 = new C(this.f3050n, this.f3039c, i2, B2);
                        } else {
                            c2 = new C(this.f3050n, this.f3039c, this.f3058v.s().getClassLoader(), r0(), B2);
                        }
                        Fragment k2 = c2.k();
                        k2.f2797t = this;
                        if (G0(2)) {
                            Log.v("FragmentManager", "restoreSaveState: active (" + k2.f2783f + "): " + k2);
                        }
                        c2.o(this.f3058v.s().getClassLoader());
                        this.f3039c.r(c2);
                        c2.t(this.f3057u);
                    }
                }
                for (Fragment fragment : this.f3034P.l()) {
                    if (!this.f3039c.c(fragment.f2783f)) {
                        if (G0(2)) {
                            Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + yVar.f3079a);
                        }
                        this.f3034P.o(fragment);
                        fragment.f2797t = this;
                        C c3 = new C(this.f3050n, this.f3039c, fragment);
                        c3.t(1);
                        c3.m();
                        fragment.f2790m = true;
                        c3.m();
                    }
                }
                this.f3039c.w(yVar.f3080b);
                if (yVar.f3081c != null) {
                    this.f3040d = new ArrayList(yVar.f3081c.length);
                    int i3 = 0;
                    while (true) {
                        C0172b[] bVarArr = yVar.f3081c;
                        if (i3 >= bVarArr.length) {
                            break;
                        }
                        C0171a d2 = bVarArr[i3].d(this);
                        if (G0(2)) {
                            Log.v("FragmentManager", "restoreAllState: back stack #" + i3 + " (index " + d2.f2898v + "): " + d2);
                            PrintWriter printWriter = new PrintWriter(new J("FragmentManager"));
                            d2.r("  ", printWriter, false);
                            printWriter.close();
                        }
                        this.f3040d.add(d2);
                        i3++;
                    }
                } else {
                    this.f3040d = null;
                }
                this.f3045i.set(yVar.f3082d);
                String str = yVar.f3083e;
                if (str != null) {
                    Fragment e02 = e0(str);
                    this.f3061y = e02;
                    L(e02);
                }
                ArrayList arrayList2 = yVar.f3084f;
                if (arrayList2 != null) {
                    for (int i4 = 0; i4 < arrayList2.size(); i4++) {
                        this.f3046j.put((String) arrayList2.get(i4), (C0173c) yVar.f3085g.get(i4));
                    }
                }
                this.f3025G = new ArrayDeque(yVar.f3086h);
            }
        }
    }

    public Fragment g0(int i2) {
        return this.f3039c.g(i2);
    }

    public Fragment h0(String str) {
        return this.f3039c.h(str);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: h1 */
    public Bundle O0() {
        C0172b[] bVarArr;
        int size;
        Bundle bundle = new Bundle();
        l0();
        X();
        a0(true);
        this.f3027I = true;
        this.f3034P.p(true);
        ArrayList y2 = this.f3039c.y();
        ArrayList m2 = this.f3039c.m();
        if (!m2.isEmpty()) {
            ArrayList z2 = this.f3039c.z();
            ArrayList arrayList = this.f3040d;
            if (arrayList == null || (size = arrayList.size()) <= 0) {
                bVarArr = null;
            } else {
                bVarArr = new C0172b[size];
                for (int i2 = 0; i2 < size; i2++) {
                    bVarArr[i2] = new C0172b((C0171a) this.f3040d.get(i2));
                    if (G0(2)) {
                        Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.f3040d.get(i2));
                    }
                }
            }
            y yVar = new y();
            yVar.f3079a = y2;
            yVar.f3080b = z2;
            yVar.f3081c = bVarArr;
            yVar.f3082d = this.f3045i.get();
            Fragment fragment = this.f3061y;
            if (fragment != null) {
                yVar.f3083e = fragment.f2783f;
            }
            yVar.f3084f.addAll(this.f3046j.keySet());
            yVar.f3085g.addAll(this.f3046j.values());
            yVar.f3086h = new ArrayList(this.f3025G);
            bundle.putParcelable("state", yVar);
            for (String str : this.f3047k.keySet()) {
                bundle.putBundle("result_" + str, (Bundle) this.f3047k.get(str));
            }
            Iterator it = m2.iterator();
            while (it.hasNext()) {
                B b2 = (B) it.next();
                Bundle bundle2 = new Bundle();
                bundle2.putParcelable("state", b2);
                bundle.putBundle("fragment_" + b2.f2696b, bundle2);
            }
        } else if (G0(2)) {
            Log.v("FragmentManager", "saveAllState: no fragments!");
        }
        return bundle;
    }

    /* access modifiers changed from: package-private */
    public void i(C0171a aVar) {
        if (this.f3040d == null) {
            this.f3040d = new ArrayList();
        }
        this.f3040d.add(aVar);
    }

    /* access modifiers changed from: package-private */
    public Fragment i0(String str) {
        return this.f3039c.i(str);
    }

    /* access modifiers changed from: package-private */
    public void i1() {
        synchronized (this.f3037a) {
            try {
                if (this.f3037a.size() == 1) {
                    this.f3058v.u().removeCallbacks(this.f3036R);
                    this.f3058v.u().post(this.f3036R);
                    q1();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public C j(Fragment fragment) {
        String str = fragment.f2767Q;
        if (str != null) {
            J.c.f(fragment, str);
        }
        if (G0(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        C v2 = v(fragment);
        fragment.f2797t = this;
        this.f3039c.r(v2);
        if (!fragment.f2752B) {
            this.f3039c.a(fragment);
            fragment.f2790m = false;
            if (fragment.f2759I == null) {
                fragment.f2764N = false;
            }
            if (H0(fragment)) {
                this.f3026H = true;
            }
        }
        return v2;
    }

    /* access modifiers changed from: package-private */
    public void j1(Fragment fragment, boolean z2) {
        ViewGroup q02 = q0(fragment);
        if (q02 != null && (q02 instanceof FragmentContainerView)) {
            ((FragmentContainerView) q02).setDrawDisappearingViewsLast(!z2);
        }
    }

    public void k(A a2) {
        this.f3051o.add(a2);
    }

    /* access modifiers changed from: package-private */
    public void k1(Fragment fragment, C0190g.b bVar) {
        if (!fragment.equals(e0(fragment.f2783f)) || !(fragment.f2798u == null || fragment.f2797t == this)) {
            throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
        }
        fragment.f2768R = bVar;
    }

    /* access modifiers changed from: package-private */
    public int l() {
        return this.f3045i.getAndIncrement();
    }

    /* access modifiers changed from: package-private */
    public void l1(Fragment fragment) {
        if (fragment == null || (fragment.equals(e0(fragment.f2783f)) && (fragment.f2798u == null || fragment.f2797t == this))) {
            Fragment fragment2 = this.f3061y;
            this.f3061y = fragment;
            L(fragment2);
            L(this.f3061y);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v29, resolved type: androidx.activity.q} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v30, resolved type: androidx.fragment.app.Fragment} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v31, resolved type: androidx.fragment.app.Fragment} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v37, resolved type: androidx.fragment.app.Fragment} */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0021  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0028  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x003b  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0044  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0091  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0129  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0136  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0143  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0150  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m(androidx.fragment.app.o r4, androidx.fragment.app.C0182l r5, androidx.fragment.app.Fragment r6) {
        /*
            r3 = this;
            androidx.fragment.app.o r0 = r3.f3058v
            if (r0 != 0) goto L_0x0167
            r3.f3058v = r4
            r3.f3059w = r5
            r3.f3060x = r6
            if (r6 == 0) goto L_0x0015
            androidx.fragment.app.w$g r5 = new androidx.fragment.app.w$g
            r5.<init>(r6)
        L_0x0011:
            r3.k(r5)
            goto L_0x001d
        L_0x0015:
            boolean r5 = r4 instanceof androidx.fragment.app.A
            if (r5 == 0) goto L_0x001d
            r5 = r4
            androidx.fragment.app.A r5 = (androidx.fragment.app.A) r5
            goto L_0x0011
        L_0x001d:
            androidx.fragment.app.Fragment r5 = r3.f3060x
            if (r5 == 0) goto L_0x0024
            r3.q1()
        L_0x0024:
            boolean r5 = r4 instanceof androidx.activity.q
            if (r5 == 0) goto L_0x0039
            r5 = r4
            androidx.activity.q r5 = (androidx.activity.q) r5
            androidx.activity.OnBackPressedDispatcher r0 = r5.d()
            r3.f3043g = r0
            if (r6 == 0) goto L_0x0034
            r5 = r6
        L_0x0034:
            androidx.activity.o r1 = r3.f3044h
            r0.h(r5, r1)
        L_0x0039:
            if (r6 == 0) goto L_0x0044
            androidx.fragment.app.w r4 = r6.f2797t
            androidx.fragment.app.z r4 = r4.o0(r6)
        L_0x0041:
            r3.f3034P = r4
            goto L_0x005a
        L_0x0044:
            boolean r5 = r4 instanceof androidx.lifecycle.E
            if (r5 == 0) goto L_0x0053
            androidx.lifecycle.E r4 = (androidx.lifecycle.E) r4
            androidx.lifecycle.D r4 = r4.t()
            androidx.fragment.app.z r4 = androidx.fragment.app.z.k(r4)
            goto L_0x0041
        L_0x0053:
            androidx.fragment.app.z r4 = new androidx.fragment.app.z
            r5 = 0
            r4.<init>(r5)
            goto L_0x0041
        L_0x005a:
            androidx.fragment.app.z r4 = r3.f3034P
            boolean r5 = r3.N0()
            r4.p(r5)
            androidx.fragment.app.D r4 = r3.f3039c
            androidx.fragment.app.z r5 = r3.f3034P
            r4.A(r5)
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof O.d
            if (r5 == 0) goto L_0x008b
            if (r6 != 0) goto L_0x008b
            O.d r4 = (O.d) r4
            androidx.savedstate.a r4 = r4.e()
            androidx.fragment.app.v r5 = new androidx.fragment.app.v
            r5.<init>(r3)
            java.lang.String r0 = "android:support:fragments"
            r4.h(r0, r5)
            android.os.Bundle r4 = r4.b(r0)
            if (r4 == 0) goto L_0x008b
            r3.f1(r4)
        L_0x008b:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.activity.result.e
            if (r5 == 0) goto L_0x0123
            androidx.activity.result.e r4 = (androidx.activity.result.e) r4
            androidx.activity.result.d r4 = r4.k()
            if (r6 == 0) goto L_0x00ad
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r0 = r6.f2783f
            r5.append(r0)
            java.lang.String r0 = ":"
            r5.append(r0)
            java.lang.String r5 = r5.toString()
            goto L_0x00af
        L_0x00ad:
            java.lang.String r5 = ""
        L_0x00af:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "FragmentManager:"
            r0.append(r1)
            r0.append(r5)
            java.lang.String r5 = r0.toString()
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r5)
            java.lang.String r1 = "StartActivityForResult"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            c.c r1 = new c.c
            r1.<init>()
            androidx.fragment.app.w$h r2 = new androidx.fragment.app.w$h
            r2.<init>()
            androidx.activity.result.c r0 = r4.g(r0, r1, r2)
            r3.f3022D = r0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r5)
            java.lang.String r1 = "StartIntentSenderForResult"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            androidx.fragment.app.w$j r1 = new androidx.fragment.app.w$j
            r1.<init>()
            androidx.fragment.app.w$i r2 = new androidx.fragment.app.w$i
            r2.<init>()
            androidx.activity.result.c r0 = r4.g(r0, r1, r2)
            r3.f3023E = r0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r5)
            java.lang.String r5 = "RequestPermissions"
            r0.append(r5)
            java.lang.String r5 = r0.toString()
            c.b r0 = new c.b
            r0.<init>()
            androidx.fragment.app.w$a r1 = new androidx.fragment.app.w$a
            r1.<init>()
            androidx.activity.result.c r4 = r4.g(r5, r0, r1)
            r3.f3024F = r4
        L_0x0123:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.core.content.c
            if (r5 == 0) goto L_0x0130
            androidx.core.content.c r4 = (androidx.core.content.c) r4
            x.a r5 = r3.f3052p
            r4.p(r5)
        L_0x0130:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.core.content.d
            if (r5 == 0) goto L_0x013d
            androidx.core.content.d r4 = (androidx.core.content.d) r4
            x.a r5 = r3.f3053q
            r4.l(r5)
        L_0x013d:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.core.app.i
            if (r5 == 0) goto L_0x014a
            androidx.core.app.i r4 = (androidx.core.app.i) r4
            x.a r5 = r3.f3054r
            r4.c(r5)
        L_0x014a:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.core.app.j
            if (r5 == 0) goto L_0x0157
            androidx.core.app.j r4 = (androidx.core.app.j) r4
            x.a r5 = r3.f3055s
            r4.b(r5)
        L_0x0157:
            androidx.fragment.app.o r4 = r3.f3058v
            boolean r5 = r4 instanceof androidx.core.view.C0164w
            if (r5 == 0) goto L_0x0166
            if (r6 != 0) goto L_0x0166
            androidx.core.view.w r4 = (androidx.core.view.C0164w) r4
            androidx.core.view.z r5 = r3.f3056t
            r4.h(r5)
        L_0x0166:
            return
        L_0x0167:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "Already attached"
            r4.<init>(r5)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.w.m(androidx.fragment.app.o, androidx.fragment.app.l, androidx.fragment.app.Fragment):void");
    }

    /* access modifiers changed from: package-private */
    public void n(Fragment fragment) {
        if (G0(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.f2752B) {
            fragment.f2752B = false;
            if (!fragment.f2789l) {
                this.f3039c.a(fragment);
                if (G0(2)) {
                    Log.v("FragmentManager", "add from attach: " + fragment);
                }
                if (H0(fragment)) {
                    this.f3026H = true;
                }
            }
        }
    }

    public int n0() {
        ArrayList arrayList = this.f3040d;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    /* access modifiers changed from: package-private */
    public void n1(Fragment fragment) {
        if (G0(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.f2751A) {
            fragment.f2751A = false;
            fragment.f2764N = !fragment.f2764N;
        }
    }

    public E o() {
        return new C0171a(this);
    }

    /* access modifiers changed from: package-private */
    public boolean p() {
        boolean z2 = false;
        for (Fragment fragment : this.f3039c.l()) {
            if (fragment != null) {
                z2 = H0(fragment);
                continue;
            }
            if (z2) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public C0182l p0() {
        return this.f3059w;
    }

    public n r0() {
        n nVar = this.f3062z;
        if (nVar != null) {
            return nVar;
        }
        Fragment fragment = this.f3060x;
        return fragment != null ? fragment.f2797t.r0() : this.f3019A;
    }

    public List s0() {
        return this.f3039c.o();
    }

    public o t0() {
        return this.f3058v;
    }

    public String toString() {
        Object obj;
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.f3060x;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            obj = this.f3060x;
        } else {
            o oVar = this.f3058v;
            if (oVar != null) {
                sb.append(oVar.getClass().getSimpleName());
                sb.append("{");
                obj = this.f3058v;
            } else {
                sb.append("null");
                sb.append("}}");
                return sb.toString();
            }
        }
        sb.append(Integer.toHexString(System.identityHashCode(obj)));
        sb.append("}");
        sb.append("}}");
        return sb.toString();
    }

    /* access modifiers changed from: package-private */
    public LayoutInflater.Factory2 u0() {
        return this.f3042f;
    }

    /* access modifiers changed from: package-private */
    public C v(Fragment fragment) {
        C n2 = this.f3039c.n(fragment.f2783f);
        if (n2 != null) {
            return n2;
        }
        C c2 = new C(this.f3050n, this.f3039c, fragment);
        c2.o(this.f3058v.s().getClassLoader());
        c2.t(this.f3057u);
        return c2;
    }

    /* access modifiers changed from: package-private */
    public q v0() {
        return this.f3050n;
    }

    /* access modifiers changed from: package-private */
    public void w(Fragment fragment) {
        if (G0(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (!fragment.f2752B) {
            fragment.f2752B = true;
            if (fragment.f2789l) {
                if (G0(2)) {
                    Log.v("FragmentManager", "remove from detach: " + fragment);
                }
                this.f3039c.u(fragment);
                if (H0(fragment)) {
                    this.f3026H = true;
                }
                m1(fragment);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment w0() {
        return this.f3060x;
    }

    /* access modifiers changed from: package-private */
    public void x() {
        this.f3027I = false;
        this.f3028J = false;
        this.f3034P.p(false);
        S(4);
    }

    public Fragment x0() {
        return this.f3061y;
    }

    /* access modifiers changed from: package-private */
    public void y() {
        this.f3027I = false;
        this.f3028J = false;
        this.f3034P.p(false);
        S(0);
    }

    /* access modifiers changed from: package-private */
    public L y0() {
        L l2 = this.f3020B;
        if (l2 != null) {
            return l2;
        }
        Fragment fragment = this.f3060x;
        return fragment != null ? fragment.f2797t.y0() : this.f3021C;
    }

    /* access modifiers changed from: package-private */
    public void z(Configuration configuration, boolean z2) {
        if (z2 && (this.f3058v instanceof androidx.core.content.c)) {
            p1(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments."));
        }
        for (Fragment fragment : this.f3039c.o()) {
            if (fragment != null) {
                fragment.M0(configuration);
                if (z2) {
                    fragment.f2799v.z(configuration, true);
                }
            }
        }
    }

    public c.C0006c z0() {
        return this.f3035Q;
    }
}
