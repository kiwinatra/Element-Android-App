package androidx.fragment.app;

import android.view.View;
import androidx.transition.C0198e;
import java.util.ArrayList;
import l.C0255a;

abstract class F {

    /* renamed from: a  reason: collision with root package name */
    static final H f2748a = new G();

    /* renamed from: b  reason: collision with root package name */
    static final H f2749b = b();

    static void a(Fragment fragment, Fragment fragment2, boolean z2, C0255a aVar, boolean z3) {
        if (z2) {
            fragment2.r();
        } else {
            fragment.r();
        }
    }

    private static H b() {
        try {
            return C0198e.class.getDeclaredConstructor((Class[]) null).newInstance((Object[]) null);
        } catch (Exception unused) {
            return null;
        }
    }

    static void c(C0255a aVar, C0255a aVar2) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            if (!aVar2.containsKey((String) aVar.m(size))) {
                aVar.k(size);
            }
        }
    }

    static void d(ArrayList arrayList, int i2) {
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((View) arrayList.get(size)).setVisibility(i2);
            }
        }
    }
}
