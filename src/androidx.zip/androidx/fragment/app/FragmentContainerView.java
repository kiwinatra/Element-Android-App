package androidx.fragment.app;

import I.c;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.core.view.C0165w0;
import androidx.core.view.W;
import java.util.ArrayList;
import java.util.List;
import w0.e;
import w0.i;

public final class FragmentContainerView extends FrameLayout {

    /* renamed from: a  reason: collision with root package name */
    private final List f2831a;

    /* renamed from: b  reason: collision with root package name */
    private final List f2832b;

    /* renamed from: c  reason: collision with root package name */
    private View.OnApplyWindowInsetsListener f2833c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f2834d;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public static final a f2835a = new a();

        private a() {
        }

        public final WindowInsets a(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener, View view, WindowInsets windowInsets) {
            i.e(onApplyWindowInsetsListener, "onApplyWindowInsetsListener");
            i.e(view, "v");
            i.e(windowInsets, "insets");
            WindowInsets onApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(view, windowInsets);
            i.d(onApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            return onApplyWindowInsets;
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, (e) null);
        i.e(context, "context");
    }

    private final void a(View view) {
        if (this.f2832b.contains(view)) {
            this.f2831a.add(view);
        }
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        i.e(view, "child");
        if (w.A0(view) != null) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    public WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        C0165w0 w0Var;
        i.e(windowInsets, "insets");
        C0165w0 w2 = C0165w0.w(windowInsets);
        i.d(w2, "toWindowInsetsCompat(insets)");
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f2833c;
        if (onApplyWindowInsetsListener != null) {
            a aVar = a.f2835a;
            i.b(onApplyWindowInsetsListener);
            w0Var = C0165w0.w(aVar.a(onApplyWindowInsetsListener, this, windowInsets));
        } else {
            w0Var = W.c0(this, w2);
        }
        i.d(w0Var, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
        if (!w0Var.p()) {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                W.i(getChildAt(i2), w0Var);
            }
        }
        return windowInsets;
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        i.e(canvas, "canvas");
        if (this.f2834d) {
            for (View drawChild : this.f2831a) {
                super.drawChild(canvas, drawChild, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j2) {
        i.e(canvas, "canvas");
        i.e(view, "child");
        if (!this.f2834d || !(!this.f2831a.isEmpty()) || !this.f2831a.contains(view)) {
            return super.drawChild(canvas, view, j2);
        }
        return false;
    }

    public void endViewTransition(View view) {
        i.e(view, "view");
        this.f2832b.remove(view);
        if (this.f2831a.remove(view)) {
            this.f2834d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends Fragment> F getFragment() {
        return w.j0(this).g0(getId());
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        i.e(windowInsets, "insets");
        return windowInsets;
    }

    public void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 < childCount) {
                View childAt = getChildAt(childCount);
                i.d(childAt, "view");
                a(childAt);
            } else {
                super.removeAllViewsInLayout();
                return;
            }
        }
    }

    public void removeView(View view) {
        i.e(view, "view");
        a(view);
        super.removeView(view);
    }

    public void removeViewAt(int i2) {
        View childAt = getChildAt(i2);
        i.d(childAt, "view");
        a(childAt);
        super.removeViewAt(i2);
    }

    public void removeViewInLayout(View view) {
        i.e(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    public void removeViews(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            i.d(childAt, "view");
            a(childAt);
        }
        super.removeViews(i2, i3);
    }

    public void removeViewsInLayout(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            i.d(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i2, i3);
    }

    public final void setDrawDisappearingViewsLast(boolean z2) {
        this.f2834d = z2;
    }

    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        i.e(onApplyWindowInsetsListener, "listener");
        this.f2833c = onApplyWindowInsetsListener;
    }

    public void startViewTransition(View view) {
        i.e(view, "view");
        if (view.getParent() == this) {
            this.f2832b.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        String str;
        i.e(context, "context");
        this.f2831a = new ArrayList();
        this.f2832b = new ArrayList();
        this.f2834d = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            int[] iArr = c.f102e;
            i.d(iArr, "FragmentContainerView");
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
            if (classAttribute == null) {
                classAttribute = obtainStyledAttributes.getString(c.f103f);
                str = "android:name";
            } else {
                str = "class";
            }
            obtainStyledAttributes.recycle();
            if (classAttribute != null && !isInEditMode()) {
                throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
            }
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ FragmentContainerView(Context context, AttributeSet attributeSet, int i2, int i3, e eVar) {
        this(context, attributeSet, (i3 & 4) != 0 ? 0 : i2);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, w wVar) {
        super(context, attributeSet);
        String str;
        i.e(context, "context");
        i.e(attributeSet, "attrs");
        i.e(wVar, "fm");
        this.f2831a = new ArrayList();
        this.f2832b = new ArrayList();
        this.f2834d = true;
        String classAttribute = attributeSet.getClassAttribute();
        int[] iArr = c.f102e;
        i.d(iArr, "FragmentContainerView");
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        classAttribute = classAttribute == null ? obtainStyledAttributes.getString(c.f103f) : classAttribute;
        String string = obtainStyledAttributes.getString(c.f104g);
        obtainStyledAttributes.recycle();
        int id = getId();
        Fragment g02 = wVar.g0(id);
        if (classAttribute != null && g02 == null) {
            if (id == -1) {
                if (string != null) {
                    str = " with tag " + string;
                } else {
                    str = "";
                }
                throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + str);
            }
            Fragment a2 = wVar.r0().a(context.getClassLoader(), classAttribute);
            i.d(a2, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            a2.v0(context, attributeSet, (Bundle) null);
            wVar.o().n(true).c(this, a2, string).h();
        }
        wVar.V0(this);
    }
}
