package androidx.fragment.app;

import android.os.Bundle;
import androidx.savedstate.a;

/* renamed from: androidx.fragment.app.f  reason: case insensitive filesystem */
public final /* synthetic */ class C0176f implements a.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0180j f2984a;

    public /* synthetic */ C0176f(C0180j jVar) {
        this.f2984a = jVar;
    }

    public final Bundle a() {
        return this.f2984a.V();
    }
}
