package androidx.fragment.app;

import android.view.ViewGroup;

interface L {
    K a(ViewGroup viewGroup);
}
