package androidx.fragment.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.core.view.W;
import androidx.fragment.app.K;
import androidx.lifecycle.E;

class C {

    /* renamed from: a  reason: collision with root package name */
    private final q f2708a;

    /* renamed from: b  reason: collision with root package name */
    private final D f2709b;

    /* renamed from: c  reason: collision with root package name */
    private final Fragment f2710c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f2711d = false;

    /* renamed from: e  reason: collision with root package name */
    private int f2712e = -1;

    class a implements View.OnAttachStateChangeListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f2713a;

        a(View view) {
            this.f2713a = view;
        }

        public void onViewAttachedToWindow(View view) {
            this.f2713a.removeOnAttachStateChangeListener(this);
            W.n0(this.f2713a);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    static /* synthetic */ class b {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f2715a;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                androidx.lifecycle.g$b[] r0 = androidx.lifecycle.C0190g.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f2715a = r0
                androidx.lifecycle.g$b r1 = androidx.lifecycle.C0190g.b.RESUMED     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f2715a     // Catch:{ NoSuchFieldError -> 0x001d }
                androidx.lifecycle.g$b r1 = androidx.lifecycle.C0190g.b.STARTED     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f2715a     // Catch:{ NoSuchFieldError -> 0x0028 }
                androidx.lifecycle.g$b r1 = androidx.lifecycle.C0190g.b.CREATED     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = f2715a     // Catch:{ NoSuchFieldError -> 0x0033 }
                androidx.lifecycle.g$b r1 = androidx.lifecycle.C0190g.b.INITIALIZED     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C.b.<clinit>():void");
        }
    }

    C(q qVar, D d2, Fragment fragment) {
        this.f2708a = qVar;
        this.f2709b = d2;
        this.f2710c = fragment;
    }

    private boolean l(View view) {
        if (view == this.f2710c.f2759I) {
            return true;
        }
        for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            if (parent == this.f2710c.f2759I) {
                return true;
            }
        }
        return false;
    }

    private Bundle q() {
        Bundle bundle = new Bundle();
        this.f2710c.e1(bundle);
        this.f2708a.j(this.f2710c, bundle, false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (this.f2710c.f2759I != null) {
            s();
        }
        if (this.f2710c.f2780c != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", this.f2710c.f2780c);
        }
        if (this.f2710c.f2781d != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", this.f2710c.f2781d);
        }
        if (!this.f2710c.f2761K) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", this.f2710c.f2761K);
        }
        return bundle;
    }

    /* access modifiers changed from: package-private */
    public void a() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + this.f2710c);
        }
        Fragment fragment = this.f2710c;
        fragment.K0(fragment.f2779b);
        q qVar = this.f2708a;
        Fragment fragment2 = this.f2710c;
        qVar.a(fragment2, fragment2.f2779b, false);
    }

    /* access modifiers changed from: package-private */
    public void b() {
        int j2 = this.f2709b.j(this.f2710c);
        Fragment fragment = this.f2710c;
        fragment.f2758H.addView(fragment.f2759I, j2);
    }

    /* access modifiers changed from: package-private */
    public void c() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto ATTACHED: " + this.f2710c);
        }
        Fragment fragment = this.f2710c;
        Fragment fragment2 = fragment.f2785h;
        C c2 = null;
        if (fragment2 != null) {
            C n2 = this.f2709b.n(fragment2.f2783f);
            if (n2 != null) {
                Fragment fragment3 = this.f2710c;
                fragment3.f2786i = fragment3.f2785h.f2783f;
                fragment3.f2785h = null;
                c2 = n2;
            } else {
                throw new IllegalStateException("Fragment " + this.f2710c + " declared target fragment " + this.f2710c.f2785h + " that does not belong to this FragmentManager!");
            }
        } else {
            String str = fragment.f2786i;
            if (str != null && (c2 = this.f2709b.n(str)) == null) {
                throw new IllegalStateException("Fragment " + this.f2710c + " declared target fragment " + this.f2710c.f2786i + " that does not belong to this FragmentManager!");
            }
        }
        if (c2 != null) {
            c2.m();
        }
        Fragment fragment4 = this.f2710c;
        fragment4.f2798u = fragment4.f2797t.t0();
        Fragment fragment5 = this.f2710c;
        fragment5.f2800w = fragment5.f2797t.w0();
        this.f2708a.g(this.f2710c, false);
        this.f2710c.L0();
        this.f2708a.b(this.f2710c, false);
    }

    /* access modifiers changed from: package-private */
    public int d() {
        Fragment fragment = this.f2710c;
        if (fragment.f2797t == null) {
            return fragment.f2777a;
        }
        int i2 = this.f2712e;
        int i3 = b.f2715a[fragment.f2768R.ordinal()];
        if (i3 != 1) {
            i2 = i3 != 2 ? i3 != 3 ? i3 != 4 ? Math.min(i2, -1) : Math.min(i2, 0) : Math.min(i2, 1) : Math.min(i2, 5);
        }
        Fragment fragment2 = this.f2710c;
        if (fragment2.f2792o) {
            if (fragment2.f2793p) {
                i2 = Math.max(this.f2712e, 2);
                View view = this.f2710c.f2759I;
                if (view != null && view.getParent() == null) {
                    i2 = Math.min(i2, 2);
                }
            } else {
                i2 = this.f2712e < 4 ? Math.min(i2, fragment2.f2777a) : Math.min(i2, 1);
            }
        }
        if (!this.f2710c.f2789l) {
            i2 = Math.min(i2, 1);
        }
        Fragment fragment3 = this.f2710c;
        ViewGroup viewGroup = fragment3.f2758H;
        K.e.b l2 = viewGroup != null ? K.n(viewGroup, fragment3.D()).l(this) : null;
        if (l2 == K.e.b.ADDING) {
            i2 = Math.min(i2, 6);
        } else if (l2 == K.e.b.REMOVING) {
            i2 = Math.max(i2, 3);
        } else {
            Fragment fragment4 = this.f2710c;
            if (fragment4.f2790m) {
                i2 = fragment4.Y() ? Math.min(i2, 1) : Math.min(i2, -1);
            }
        }
        Fragment fragment5 = this.f2710c;
        if (fragment5.f2760J && fragment5.f2777a < 5) {
            i2 = Math.min(i2, 4);
        }
        if (w.G0(2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + i2 + " for " + this.f2710c);
        }
        return i2;
    }

    /* access modifiers changed from: package-private */
    public void e() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto CREATED: " + this.f2710c);
        }
        Fragment fragment = this.f2710c;
        if (!fragment.f2766P) {
            this.f2708a.h(fragment, fragment.f2779b, false);
            Fragment fragment2 = this.f2710c;
            fragment2.O0(fragment2.f2779b);
            q qVar = this.f2708a;
            Fragment fragment3 = this.f2710c;
            qVar.c(fragment3, fragment3.f2779b, false);
            return;
        }
        fragment.m1(fragment.f2779b);
        this.f2710c.f2777a = 1;
    }

    /* JADX WARNING: type inference failed for: r2v9, types: [android.view.View] */
    /* access modifiers changed from: package-private */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void f() {
        /*
            r7 = this;
            androidx.fragment.app.Fragment r0 = r7.f2710c
            boolean r0 = r0.f2792o
            if (r0 == 0) goto L_0x0007
            return
        L_0x0007:
            r0 = 3
            boolean r0 = androidx.fragment.app.w.G0(r0)
            java.lang.String r1 = "FragmentManager"
            if (r0 == 0) goto L_0x0026
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r2 = "moveto CREATE_VIEW: "
            r0.append(r2)
            androidx.fragment.app.Fragment r2 = r7.f2710c
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            android.util.Log.d(r1, r0)
        L_0x0026:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.os.Bundle r2 = r0.f2779b
            android.view.LayoutInflater r0 = r0.U0(r2)
            androidx.fragment.app.Fragment r2 = r7.f2710c
            android.view.ViewGroup r3 = r2.f2758H
            if (r3 == 0) goto L_0x0036
            goto L_0x00c0
        L_0x0036:
            int r3 = r2.f2802y
            if (r3 == 0) goto L_0x00bf
            r4 = -1
            if (r3 == r4) goto L_0x00a1
            androidx.fragment.app.w r2 = r2.f2797t
            androidx.fragment.app.l r2 = r2.p0()
            androidx.fragment.app.Fragment r3 = r7.f2710c
            int r3 = r3.f2802y
            android.view.View r2 = r2.n(r3)
            r3 = r2
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            if (r3 != 0) goto L_0x0097
            androidx.fragment.app.Fragment r2 = r7.f2710c
            boolean r4 = r2.f2794q
            if (r4 == 0) goto L_0x0057
            goto L_0x00c0
        L_0x0057:
            android.content.res.Resources r0 = r2.J()     // Catch:{ NotFoundException -> 0x0064 }
            androidx.fragment.app.Fragment r1 = r7.f2710c     // Catch:{ NotFoundException -> 0x0064 }
            int r1 = r1.f2802y     // Catch:{ NotFoundException -> 0x0064 }
            java.lang.String r0 = r0.getResourceName(r1)     // Catch:{ NotFoundException -> 0x0064 }
            goto L_0x0066
        L_0x0064:
            java.lang.String r0 = "unknown"
        L_0x0066:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "No view found for id 0x"
            r2.append(r3)
            androidx.fragment.app.Fragment r3 = r7.f2710c
            int r3 = r3.f2802y
            java.lang.String r3 = java.lang.Integer.toHexString(r3)
            r2.append(r3)
            java.lang.String r3 = " ("
            r2.append(r3)
            r2.append(r0)
            java.lang.String r0 = ") for fragment "
            r2.append(r0)
            androidx.fragment.app.Fragment r0 = r7.f2710c
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L_0x0097:
            boolean r2 = r3 instanceof androidx.fragment.app.FragmentContainerView
            if (r2 != 0) goto L_0x00c0
            androidx.fragment.app.Fragment r2 = r7.f2710c
            J.c.i(r2, r3)
            goto L_0x00c0
        L_0x00a1:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Cannot create fragment "
            r1.append(r2)
            androidx.fragment.app.Fragment r2 = r7.f2710c
            r1.append(r2)
            java.lang.String r2 = " for a container view with no id"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x00bf:
            r3 = 0
        L_0x00c0:
            androidx.fragment.app.Fragment r2 = r7.f2710c
            r2.f2758H = r3
            android.os.Bundle r4 = r2.f2779b
            r2.Q0(r0, r3, r4)
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            r2 = 2
            if (r0 == 0) goto L_0x0173
            r4 = 0
            r0.setSaveFromParentEnabled(r4)
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r5 = r0.f2759I
            int r6 = I.b.fragment_container_view_tag
            r5.setTag(r6, r0)
            if (r3 == 0) goto L_0x00e2
            r7.b()
        L_0x00e2:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            boolean r3 = r0.f2751A
            if (r3 == 0) goto L_0x00ef
            android.view.View r0 = r0.f2759I
            r3 = 8
            r0.setVisibility(r3)
        L_0x00ef:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            boolean r0 = androidx.core.view.W.T(r0)
            if (r0 == 0) goto L_0x0101
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            androidx.core.view.W.n0(r0)
            goto L_0x010d
        L_0x0101:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            androidx.fragment.app.C$a r3 = new androidx.fragment.app.C$a
            r3.<init>(r0)
            r0.addOnAttachStateChangeListener(r3)
        L_0x010d:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            r0.h1()
            androidx.fragment.app.q r0 = r7.f2708a
            androidx.fragment.app.Fragment r3 = r7.f2710c
            android.view.View r5 = r3.f2759I
            android.os.Bundle r6 = r3.f2779b
            r0.m(r3, r5, r6, r4)
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            int r0 = r0.getVisibility()
            androidx.fragment.app.Fragment r3 = r7.f2710c
            android.view.View r3 = r3.f2759I
            float r3 = r3.getAlpha()
            androidx.fragment.app.Fragment r4 = r7.f2710c
            r4.u1(r3)
            androidx.fragment.app.Fragment r3 = r7.f2710c
            android.view.ViewGroup r4 = r3.f2758H
            if (r4 == 0) goto L_0x0173
            if (r0 != 0) goto L_0x0173
            android.view.View r0 = r3.f2759I
            android.view.View r0 = r0.findFocus()
            if (r0 == 0) goto L_0x016b
            androidx.fragment.app.Fragment r3 = r7.f2710c
            r3.r1(r0)
            boolean r3 = androidx.fragment.app.w.G0(r2)
            if (r3 == 0) goto L_0x016b
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "requestFocus: Saved focused view "
            r3.append(r4)
            r3.append(r0)
            java.lang.String r0 = " for Fragment "
            r3.append(r0)
            androidx.fragment.app.Fragment r0 = r7.f2710c
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            android.util.Log.v(r1, r0)
        L_0x016b:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            android.view.View r0 = r0.f2759I
            r1 = 0
            r0.setAlpha(r1)
        L_0x0173:
            androidx.fragment.app.Fragment r0 = r7.f2710c
            r0.f2777a = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C.f():void");
    }

    /* access modifiers changed from: package-private */
    public void g() {
        Fragment f2;
        if (w.G0(3)) {
            Log.d("FragmentManager", "movefrom CREATED: " + this.f2710c);
        }
        Fragment fragment = this.f2710c;
        boolean z2 = true;
        boolean z3 = fragment.f2790m && !fragment.Y();
        if (z3) {
            Fragment fragment2 = this.f2710c;
            if (!fragment2.f2791n) {
                this.f2709b.B(fragment2.f2783f, (B) null);
            }
        }
        if (z3 || this.f2709b.p().q(this.f2710c)) {
            o oVar = this.f2710c.f2798u;
            if (oVar instanceof E) {
                z2 = this.f2709b.p().n();
            } else if (oVar.s() instanceof Activity) {
                z2 = true ^ ((Activity) oVar.s()).isChangingConfigurations();
            }
            if ((z3 && !this.f2710c.f2791n) || z2) {
                this.f2709b.p().f(this.f2710c);
            }
            this.f2710c.R0();
            this.f2708a.d(this.f2710c, false);
            for (C c2 : this.f2709b.k()) {
                if (c2 != null) {
                    Fragment k2 = c2.k();
                    if (this.f2710c.f2783f.equals(k2.f2786i)) {
                        k2.f2785h = this.f2710c;
                        k2.f2786i = null;
                    }
                }
            }
            Fragment fragment3 = this.f2710c;
            String str = fragment3.f2786i;
            if (str != null) {
                fragment3.f2785h = this.f2709b.f(str);
            }
            this.f2709b.s(this);
            return;
        }
        String str2 = this.f2710c.f2786i;
        if (!(str2 == null || (f2 = this.f2709b.f(str2)) == null || !f2.f2753C)) {
            this.f2710c.f2785h = f2;
        }
        this.f2710c.f2777a = 0;
    }

    /* access modifiers changed from: package-private */
    public void h() {
        View view;
        if (w.G0(3)) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + this.f2710c);
        }
        Fragment fragment = this.f2710c;
        ViewGroup viewGroup = fragment.f2758H;
        if (!(viewGroup == null || (view = fragment.f2759I) == null)) {
            viewGroup.removeView(view);
        }
        this.f2710c.S0();
        this.f2708a.n(this.f2710c, false);
        Fragment fragment2 = this.f2710c;
        fragment2.f2758H = null;
        fragment2.f2759I = null;
        fragment2.f2770T = null;
        fragment2.f2771U.i((Object) null);
        this.f2710c.f2793p = false;
    }

    /* access modifiers changed from: package-private */
    public void i() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + this.f2710c);
        }
        this.f2710c.T0();
        this.f2708a.e(this.f2710c, false);
        Fragment fragment = this.f2710c;
        fragment.f2777a = -1;
        fragment.f2798u = null;
        fragment.f2800w = null;
        fragment.f2797t = null;
        if ((fragment.f2790m && !fragment.Y()) || this.f2709b.p().q(this.f2710c)) {
            if (w.G0(3)) {
                Log.d("FragmentManager", "initState called for fragment: " + this.f2710c);
            }
            this.f2710c.U();
        }
    }

    /* access modifiers changed from: package-private */
    public void j() {
        Fragment fragment = this.f2710c;
        if (fragment.f2792o && fragment.f2793p && !fragment.f2795r) {
            if (w.G0(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.f2710c);
            }
            Fragment fragment2 = this.f2710c;
            fragment2.Q0(fragment2.U0(fragment2.f2779b), (ViewGroup) null, this.f2710c.f2779b);
            View view = this.f2710c.f2759I;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.f2710c;
                fragment3.f2759I.setTag(I.b.fragment_container_view_tag, fragment3);
                Fragment fragment4 = this.f2710c;
                if (fragment4.f2751A) {
                    fragment4.f2759I.setVisibility(8);
                }
                this.f2710c.h1();
                q qVar = this.f2708a;
                Fragment fragment5 = this.f2710c;
                qVar.m(fragment5, fragment5.f2759I, fragment5.f2779b, false);
                this.f2710c.f2777a = 2;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment k() {
        return this.f2710c;
    }

    /* access modifiers changed from: package-private */
    public void m() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        if (!this.f2711d) {
            try {
                this.f2711d = true;
                boolean z2 = false;
                while (true) {
                    int d2 = d();
                    Fragment fragment = this.f2710c;
                    int i2 = fragment.f2777a;
                    if (d2 != i2) {
                        if (d2 <= i2) {
                            switch (i2 - 1) {
                                case -1:
                                    i();
                                    break;
                                case 0:
                                    if (fragment.f2791n && this.f2709b.q(fragment.f2783f) == null) {
                                        r();
                                    }
                                    g();
                                    break;
                                case 1:
                                    h();
                                    this.f2710c.f2777a = 1;
                                    break;
                                case 2:
                                    fragment.f2793p = false;
                                    fragment.f2777a = 2;
                                    break;
                                case 3:
                                    if (w.G0(3)) {
                                        Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + this.f2710c);
                                    }
                                    Fragment fragment2 = this.f2710c;
                                    if (fragment2.f2791n) {
                                        r();
                                    } else if (fragment2.f2759I != null && fragment2.f2780c == null) {
                                        s();
                                    }
                                    Fragment fragment3 = this.f2710c;
                                    if (!(fragment3.f2759I == null || (viewGroup2 = fragment3.f2758H) == null)) {
                                        K.n(viewGroup2, fragment3.D()).d(this);
                                    }
                                    this.f2710c.f2777a = 3;
                                    break;
                                case 4:
                                    v();
                                    break;
                                case 5:
                                    fragment.f2777a = 5;
                                    break;
                                case 6:
                                    n();
                                    break;
                            }
                        } else {
                            switch (i2 + 1) {
                                case 0:
                                    c();
                                    break;
                                case 1:
                                    e();
                                    break;
                                case 2:
                                    j();
                                    f();
                                    break;
                                case 3:
                                    a();
                                    break;
                                case 4:
                                    if (!(fragment.f2759I == null || (viewGroup3 = fragment.f2758H) == null)) {
                                        K.n(viewGroup3, fragment.D()).b(K.e.c.b(this.f2710c.f2759I.getVisibility()), this);
                                    }
                                    this.f2710c.f2777a = 4;
                                    break;
                                case 5:
                                    u();
                                    break;
                                case 6:
                                    fragment.f2777a = 6;
                                    break;
                                case 7:
                                    p();
                                    break;
                            }
                        }
                        z2 = true;
                    } else {
                        if (!z2 && i2 == -1 && fragment.f2790m && !fragment.Y() && !this.f2710c.f2791n) {
                            if (w.G0(3)) {
                                Log.d("FragmentManager", "Cleaning up state of never attached fragment: " + this.f2710c);
                            }
                            this.f2709b.p().f(this.f2710c);
                            this.f2709b.s(this);
                            if (w.G0(3)) {
                                Log.d("FragmentManager", "initState called for fragment: " + this.f2710c);
                            }
                            this.f2710c.U();
                        }
                        Fragment fragment4 = this.f2710c;
                        if (fragment4.f2764N) {
                            if (!(fragment4.f2759I == null || (viewGroup = fragment4.f2758H) == null)) {
                                K n2 = K.n(viewGroup, fragment4.D());
                                if (this.f2710c.f2751A) {
                                    n2.c(this);
                                } else {
                                    n2.e(this);
                                }
                            }
                            Fragment fragment5 = this.f2710c;
                            w wVar = fragment5.f2797t;
                            if (wVar != null) {
                                wVar.E0(fragment5);
                            }
                            Fragment fragment6 = this.f2710c;
                            fragment6.f2764N = false;
                            fragment6.t0(fragment6.f2751A);
                            this.f2710c.f2799v.I();
                        }
                        this.f2711d = false;
                        return;
                    }
                }
            } catch (Throwable th) {
                this.f2711d = false;
                throw th;
            }
        } else if (w.G0(2)) {
            Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + k());
        }
    }

    /* access modifiers changed from: package-private */
    public void n() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "movefrom RESUMED: " + this.f2710c);
        }
        this.f2710c.Z0();
        this.f2708a.f(this.f2710c, false);
    }

    /* access modifiers changed from: package-private */
    public void o(ClassLoader classLoader) {
        Bundle bundle = this.f2710c.f2779b;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
            Fragment fragment = this.f2710c;
            fragment.f2780c = fragment.f2779b.getSparseParcelableArray("android:view_state");
            Fragment fragment2 = this.f2710c;
            fragment2.f2781d = fragment2.f2779b.getBundle("android:view_registry_state");
            Fragment fragment3 = this.f2710c;
            fragment3.f2786i = fragment3.f2779b.getString("android:target_state");
            Fragment fragment4 = this.f2710c;
            if (fragment4.f2786i != null) {
                fragment4.f2787j = fragment4.f2779b.getInt("android:target_req_state", 0);
            }
            Fragment fragment5 = this.f2710c;
            Boolean bool = fragment5.f2782e;
            if (bool != null) {
                fragment5.f2761K = bool.booleanValue();
                this.f2710c.f2782e = null;
            } else {
                fragment5.f2761K = fragment5.f2779b.getBoolean("android:user_visible_hint", true);
            }
            Fragment fragment6 = this.f2710c;
            if (!fragment6.f2761K) {
                fragment6.f2760J = true;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void p() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto RESUMED: " + this.f2710c);
        }
        View x2 = this.f2710c.x();
        if (x2 != null && l(x2)) {
            boolean requestFocus = x2.requestFocus();
            if (w.G0(2)) {
                StringBuilder sb = new StringBuilder();
                sb.append("requestFocus: Restoring focused view ");
                sb.append(x2);
                sb.append(" ");
                sb.append(requestFocus ? "succeeded" : "failed");
                sb.append(" on Fragment ");
                sb.append(this.f2710c);
                sb.append(" resulting in focused view ");
                sb.append(this.f2710c.f2759I.findFocus());
                Log.v("FragmentManager", sb.toString());
            }
        }
        this.f2710c.r1((View) null);
        this.f2710c.d1();
        this.f2708a.i(this.f2710c, false);
        Fragment fragment = this.f2710c;
        fragment.f2779b = null;
        fragment.f2780c = null;
        fragment.f2781d = null;
    }

    /* access modifiers changed from: package-private */
    public void r() {
        B b2 = new B(this.f2710c);
        Fragment fragment = this.f2710c;
        if (fragment.f2777a <= -1 || b2.f2707m != null) {
            b2.f2707m = fragment.f2779b;
        } else {
            Bundle q2 = q();
            b2.f2707m = q2;
            if (this.f2710c.f2786i != null) {
                if (q2 == null) {
                    b2.f2707m = new Bundle();
                }
                b2.f2707m.putString("android:target_state", this.f2710c.f2786i);
                int i2 = this.f2710c.f2787j;
                if (i2 != 0) {
                    b2.f2707m.putInt("android:target_req_state", i2);
                }
            }
        }
        this.f2709b.B(this.f2710c.f2783f, b2);
    }

    /* access modifiers changed from: package-private */
    public void s() {
        if (this.f2710c.f2759I != null) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "Saving view state for fragment " + this.f2710c + " with view " + this.f2710c.f2759I);
            }
            SparseArray sparseArray = new SparseArray();
            this.f2710c.f2759I.saveHierarchyState(sparseArray);
            if (sparseArray.size() > 0) {
                this.f2710c.f2780c = sparseArray;
            }
            Bundle bundle = new Bundle();
            this.f2710c.f2770T.h(bundle);
            if (!bundle.isEmpty()) {
                this.f2710c.f2781d = bundle;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void t(int i2) {
        this.f2712e = i2;
    }

    /* access modifiers changed from: package-private */
    public void u() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto STARTED: " + this.f2710c);
        }
        this.f2710c.f1();
        this.f2708a.k(this.f2710c, false);
    }

    /* access modifiers changed from: package-private */
    public void v() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "movefrom STARTED: " + this.f2710c);
        }
        this.f2710c.g1();
        this.f2708a.l(this.f2710c, false);
    }

    C(q qVar, D d2, Fragment fragment, B b2) {
        this.f2708a = qVar;
        this.f2709b = d2;
        this.f2710c = fragment;
        fragment.f2780c = null;
        fragment.f2781d = null;
        fragment.f2796s = 0;
        fragment.f2793p = false;
        fragment.f2789l = false;
        Fragment fragment2 = fragment.f2785h;
        fragment.f2786i = fragment2 != null ? fragment2.f2783f : null;
        fragment.f2785h = null;
        Bundle bundle = b2.f2707m;
        fragment.f2779b = bundle == null ? new Bundle() : bundle;
    }

    C(q qVar, D d2, ClassLoader classLoader, n nVar, B b2) {
        this.f2708a = qVar;
        this.f2709b = d2;
        Fragment c2 = b2.c(nVar, classLoader);
        this.f2710c = c2;
        if (w.G0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + c2);
        }
    }
}
