package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.lifecycle.C0190g;

final class B implements Parcelable {
    public static final Parcelable.Creator<B> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    final String f2695a;

    /* renamed from: b  reason: collision with root package name */
    final String f2696b;

    /* renamed from: c  reason: collision with root package name */
    final boolean f2697c;

    /* renamed from: d  reason: collision with root package name */
    final int f2698d;

    /* renamed from: e  reason: collision with root package name */
    final int f2699e;

    /* renamed from: f  reason: collision with root package name */
    final String f2700f;

    /* renamed from: g  reason: collision with root package name */
    final boolean f2701g;

    /* renamed from: h  reason: collision with root package name */
    final boolean f2702h;

    /* renamed from: i  reason: collision with root package name */
    final boolean f2703i;

    /* renamed from: j  reason: collision with root package name */
    final Bundle f2704j;

    /* renamed from: k  reason: collision with root package name */
    final boolean f2705k;

    /* renamed from: l  reason: collision with root package name */
    final int f2706l;

    /* renamed from: m  reason: collision with root package name */
    Bundle f2707m;

    class a implements Parcelable.Creator {
        a() {
        }

        /* renamed from: a */
        public B createFromParcel(Parcel parcel) {
            return new B(parcel);
        }

        /* renamed from: b */
        public B[] newArray(int i2) {
            return new B[i2];
        }
    }

    B(Parcel parcel) {
        this.f2695a = parcel.readString();
        this.f2696b = parcel.readString();
        boolean z2 = false;
        this.f2697c = parcel.readInt() != 0;
        this.f2698d = parcel.readInt();
        this.f2699e = parcel.readInt();
        this.f2700f = parcel.readString();
        this.f2701g = parcel.readInt() != 0;
        this.f2702h = parcel.readInt() != 0;
        this.f2703i = parcel.readInt() != 0;
        this.f2704j = parcel.readBundle();
        this.f2705k = parcel.readInt() != 0 ? true : z2;
        this.f2707m = parcel.readBundle();
        this.f2706l = parcel.readInt();
    }

    /* access modifiers changed from: package-private */
    public Fragment c(n nVar, ClassLoader classLoader) {
        Fragment a2 = nVar.a(classLoader, this.f2695a);
        Bundle bundle = this.f2704j;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        a2.q1(this.f2704j);
        a2.f2783f = this.f2696b;
        a2.f2792o = this.f2697c;
        a2.f2794q = true;
        a2.f2801x = this.f2698d;
        a2.f2802y = this.f2699e;
        a2.f2803z = this.f2700f;
        a2.f2753C = this.f2701g;
        a2.f2790m = this.f2702h;
        a2.f2752B = this.f2703i;
        a2.f2751A = this.f2705k;
        a2.f2768R = C0190g.b.values()[this.f2706l];
        Bundle bundle2 = this.f2707m;
        if (bundle2 == null) {
            bundle2 = new Bundle();
        }
        a2.f2779b = bundle2;
        return a2;
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f2695a);
        sb.append(" (");
        sb.append(this.f2696b);
        sb.append(")}:");
        if (this.f2697c) {
            sb.append(" fromLayout");
        }
        if (this.f2699e != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f2699e));
        }
        String str = this.f2700f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.f2700f);
        }
        if (this.f2701g) {
            sb.append(" retainInstance");
        }
        if (this.f2702h) {
            sb.append(" removing");
        }
        if (this.f2703i) {
            sb.append(" detached");
        }
        if (this.f2705k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f2695a);
        parcel.writeString(this.f2696b);
        parcel.writeInt(this.f2697c ? 1 : 0);
        parcel.writeInt(this.f2698d);
        parcel.writeInt(this.f2699e);
        parcel.writeString(this.f2700f);
        parcel.writeInt(this.f2701g ? 1 : 0);
        parcel.writeInt(this.f2702h ? 1 : 0);
        parcel.writeInt(this.f2703i ? 1 : 0);
        parcel.writeBundle(this.f2704j);
        parcel.writeInt(this.f2705k ? 1 : 0);
        parcel.writeBundle(this.f2707m);
        parcel.writeInt(this.f2706l);
    }

    B(Fragment fragment) {
        this.f2695a = fragment.getClass().getName();
        this.f2696b = fragment.f2783f;
        this.f2697c = fragment.f2792o;
        this.f2698d = fragment.f2801x;
        this.f2699e = fragment.f2802y;
        this.f2700f = fragment.f2803z;
        this.f2701g = fragment.f2753C;
        this.f2702h = fragment.f2790m;
        this.f2703i = fragment.f2752B;
        this.f2704j = fragment.f2784g;
        this.f2705k = fragment.f2751A;
        this.f2706l = fragment.f2768R.ordinal();
    }
}
