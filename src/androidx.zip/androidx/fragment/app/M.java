package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class M extends AndroidRuntimeException {
    public M(String str) {
        super(str);
    }
}
