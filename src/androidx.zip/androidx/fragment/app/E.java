package androidx.fragment.app;

import J.c;
import android.view.ViewGroup;
import androidx.lifecycle.C0190g;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class E {

    /* renamed from: a  reason: collision with root package name */
    private final n f2720a;

    /* renamed from: b  reason: collision with root package name */
    private final ClassLoader f2721b;

    /* renamed from: c  reason: collision with root package name */
    ArrayList f2722c = new ArrayList();

    /* renamed from: d  reason: collision with root package name */
    int f2723d;

    /* renamed from: e  reason: collision with root package name */
    int f2724e;

    /* renamed from: f  reason: collision with root package name */
    int f2725f;

    /* renamed from: g  reason: collision with root package name */
    int f2726g;

    /* renamed from: h  reason: collision with root package name */
    int f2727h;

    /* renamed from: i  reason: collision with root package name */
    boolean f2728i;

    /* renamed from: j  reason: collision with root package name */
    boolean f2729j = true;

    /* renamed from: k  reason: collision with root package name */
    String f2730k;

    /* renamed from: l  reason: collision with root package name */
    int f2731l;

    /* renamed from: m  reason: collision with root package name */
    CharSequence f2732m;

    /* renamed from: n  reason: collision with root package name */
    int f2733n;

    /* renamed from: o  reason: collision with root package name */
    CharSequence f2734o;

    /* renamed from: p  reason: collision with root package name */
    ArrayList f2735p;

    /* renamed from: q  reason: collision with root package name */
    ArrayList f2736q;

    /* renamed from: r  reason: collision with root package name */
    boolean f2737r = false;

    /* renamed from: s  reason: collision with root package name */
    ArrayList f2738s;

    static final class a {

        /* renamed from: a  reason: collision with root package name */
        int f2739a;

        /* renamed from: b  reason: collision with root package name */
        Fragment f2740b;

        /* renamed from: c  reason: collision with root package name */
        boolean f2741c;

        /* renamed from: d  reason: collision with root package name */
        int f2742d;

        /* renamed from: e  reason: collision with root package name */
        int f2743e;

        /* renamed from: f  reason: collision with root package name */
        int f2744f;

        /* renamed from: g  reason: collision with root package name */
        int f2745g;

        /* renamed from: h  reason: collision with root package name */
        C0190g.b f2746h;

        /* renamed from: i  reason: collision with root package name */
        C0190g.b f2747i;

        a() {
        }

        a(int i2, Fragment fragment) {
            this.f2739a = i2;
            this.f2740b = fragment;
            this.f2741c = false;
            C0190g.b bVar = C0190g.b.RESUMED;
            this.f2746h = bVar;
            this.f2747i = bVar;
        }

        a(int i2, Fragment fragment, boolean z2) {
            this.f2739a = i2;
            this.f2740b = fragment;
            this.f2741c = z2;
            C0190g.b bVar = C0190g.b.RESUMED;
            this.f2746h = bVar;
            this.f2747i = bVar;
        }
    }

    E(n nVar, ClassLoader classLoader) {
        this.f2720a = nVar;
        this.f2721b = classLoader;
    }

    public E b(int i2, Fragment fragment, String str) {
        j(i2, fragment, str, 1);
        return this;
    }

    /* access modifiers changed from: package-private */
    public E c(ViewGroup viewGroup, Fragment fragment, String str) {
        fragment.f2758H = viewGroup;
        return b(viewGroup.getId(), fragment, str);
    }

    /* access modifiers changed from: package-private */
    public void d(a aVar) {
        this.f2722c.add(aVar);
        aVar.f2742d = this.f2723d;
        aVar.f2743e = this.f2724e;
        aVar.f2744f = this.f2725f;
        aVar.f2745g = this.f2726g;
    }

    public abstract int e();

    public abstract int f();

    public abstract void g();

    public abstract void h();

    public E i() {
        if (!this.f2728i) {
            this.f2729j = false;
            return this;
        }
        throw new IllegalStateException("This transaction is already being added to the back stack");
    }

    /* access modifiers changed from: package-private */
    public void j(int i2, Fragment fragment, String str, int i3) {
        String str2 = fragment.f2767Q;
        if (str2 != null) {
            c.f(fragment, str2);
        }
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str3 = fragment.f2803z;
            if (str3 == null || str.equals(str3)) {
                fragment.f2803z = str;
            } else {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.f2803z + " now " + str);
            }
        }
        if (i2 != 0) {
            if (i2 != -1) {
                int i4 = fragment.f2801x;
                if (i4 == 0 || i4 == i2) {
                    fragment.f2801x = i2;
                    fragment.f2802y = i2;
                } else {
                    throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.f2801x + " now " + i2);
                }
            } else {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
        }
        d(new a(i3, fragment));
    }

    public E k(Fragment fragment) {
        d(new a(3, fragment));
        return this;
    }

    public E l(int i2, Fragment fragment) {
        return m(i2, fragment, (String) null);
    }

    public E m(int i2, Fragment fragment, String str) {
        if (i2 != 0) {
            j(i2, fragment, str, 2);
            return this;
        }
        throw new IllegalArgumentException("Must use non-zero containerViewId");
    }

    public E n(boolean z2) {
        this.f2737r = z2;
        return this;
    }
}
