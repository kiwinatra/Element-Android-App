package androidx.fragment.app;

import android.content.res.Configuration;
import x.C0290a;

/* renamed from: androidx.fragment.app.g  reason: case insensitive filesystem */
public final /* synthetic */ class C0177g implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0180j f2985a;

    public /* synthetic */ C0177g(C0180j jVar) {
        this.f2985a = jVar;
    }

    public final void a(Object obj) {
        this.f2985a.W((Configuration) obj);
    }
}
