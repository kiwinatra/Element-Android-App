package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.j;
import androidx.lifecycle.l;

class FragmentManager$6 implements j {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ String f2836a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ C0190g f2837b;

    /* renamed from: c  reason: collision with root package name */
    final /* synthetic */ w f2838c;

    public void d(l lVar, C0190g.a aVar) {
        if (aVar == C0190g.a.ON_START && ((Bundle) this.f2838c.f3047k.get(this.f2836a)) != null) {
            throw null;
        } else if (aVar == C0190g.a.ON_DESTROY) {
            this.f2837b.c(this);
            this.f2838c.f3048l.remove(this.f2836a);
        }
    }
}
