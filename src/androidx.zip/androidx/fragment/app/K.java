package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.os.a;
import androidx.core.view.W;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

abstract class K {

    /* renamed from: a  reason: collision with root package name */
    private final ViewGroup f2867a;

    /* renamed from: b  reason: collision with root package name */
    final ArrayList f2868b = new ArrayList();

    /* renamed from: c  reason: collision with root package name */
    final ArrayList f2869c = new ArrayList();

    /* renamed from: d  reason: collision with root package name */
    boolean f2870d = false;

    /* renamed from: e  reason: collision with root package name */
    boolean f2871e = false;

    class a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ d f2872a;

        a(d dVar) {
            this.f2872a = dVar;
        }

        public void run() {
            if (K.this.f2868b.contains(this.f2872a)) {
                this.f2872a.e().a(this.f2872a.f().f2759I);
            }
        }
    }

    class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ d f2874a;

        b(d dVar) {
            this.f2874a = dVar;
        }

        public void run() {
            K.this.f2868b.remove(this.f2874a);
            K.this.f2869c.remove(this.f2874a);
        }
    }

    static /* synthetic */ class c {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f2876a;

        /* renamed from: b  reason: collision with root package name */
        static final /* synthetic */ int[] f2877b;

        /* JADX WARNING: Can't wrap try/catch for region: R(17:0|(2:1|2)|3|(2:5|6)|7|9|10|11|13|14|15|16|17|18|19|20|22) */
        /* JADX WARNING: Can't wrap try/catch for region: R(19:0|1|2|3|5|6|7|9|10|11|13|14|15|16|17|18|19|20|22) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0039 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0043 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x004d */
        static {
            /*
                androidx.fragment.app.K$e$b[] r0 = androidx.fragment.app.K.e.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f2877b = r0
                r1 = 1
                androidx.fragment.app.K$e$b r2 = androidx.fragment.app.K.e.b.ADDING     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = f2877b     // Catch:{ NoSuchFieldError -> 0x001d }
                androidx.fragment.app.K$e$b r3 = androidx.fragment.app.K.e.b.REMOVING     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = f2877b     // Catch:{ NoSuchFieldError -> 0x0028 }
                androidx.fragment.app.K$e$b r4 = androidx.fragment.app.K.e.b.NONE     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                androidx.fragment.app.K$e$c[] r3 = androidx.fragment.app.K.e.c.values()
                int r3 = r3.length
                int[] r3 = new int[r3]
                f2876a = r3
                androidx.fragment.app.K$e$c r4 = androidx.fragment.app.K.e.c.REMOVED     // Catch:{ NoSuchFieldError -> 0x0039 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0039 }
                r3[r4] = r1     // Catch:{ NoSuchFieldError -> 0x0039 }
            L_0x0039:
                int[] r1 = f2876a     // Catch:{ NoSuchFieldError -> 0x0043 }
                androidx.fragment.app.K$e$c r3 = androidx.fragment.app.K.e.c.VISIBLE     // Catch:{ NoSuchFieldError -> 0x0043 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0043 }
                r1[r3] = r0     // Catch:{ NoSuchFieldError -> 0x0043 }
            L_0x0043:
                int[] r0 = f2876a     // Catch:{ NoSuchFieldError -> 0x004d }
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.GONE     // Catch:{ NoSuchFieldError -> 0x004d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x004d }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x004d }
            L_0x004d:
                int[] r0 = f2876a     // Catch:{ NoSuchFieldError -> 0x0058 }
                androidx.fragment.app.K$e$c r1 = androidx.fragment.app.K.e.c.INVISIBLE     // Catch:{ NoSuchFieldError -> 0x0058 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0058 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0058 }
            L_0x0058:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.K.c.<clinit>():void");
        }
    }

    private static class d extends e {

        /* renamed from: h  reason: collision with root package name */
        private final C f2878h;

        d(e.c cVar, e.b bVar, C c2, androidx.core.os.a aVar) {
            super(cVar, bVar, c2.k(), aVar);
            this.f2878h = c2;
        }

        public void c() {
            super.c();
            this.f2878h.m();
        }

        /* access modifiers changed from: package-private */
        public void l() {
            if (g() == e.b.ADDING) {
                Fragment k2 = this.f2878h.k();
                View findFocus = k2.f2759I.findFocus();
                if (findFocus != null) {
                    k2.r1(findFocus);
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + findFocus + " for Fragment " + k2);
                    }
                }
                View l1 = f().l1();
                if (l1.getParent() == null) {
                    this.f2878h.b();
                    l1.setAlpha(0.0f);
                }
                if (l1.getAlpha() == 0.0f && l1.getVisibility() == 0) {
                    l1.setVisibility(4);
                }
                l1.setAlpha(k2.H());
            } else if (g() == e.b.REMOVING) {
                Fragment k3 = this.f2878h.k();
                View l12 = k3.l1();
                if (w.G0(2)) {
                    Log.v("FragmentManager", "Clearing focus " + l12.findFocus() + " on view " + l12 + " for Fragment " + k3);
                }
                l12.clearFocus();
            }
        }
    }

    static class e {

        /* renamed from: a  reason: collision with root package name */
        private c f2879a;

        /* renamed from: b  reason: collision with root package name */
        private b f2880b;

        /* renamed from: c  reason: collision with root package name */
        private final Fragment f2881c;

        /* renamed from: d  reason: collision with root package name */
        private final List f2882d = new ArrayList();

        /* renamed from: e  reason: collision with root package name */
        private final HashSet f2883e = new HashSet();

        /* renamed from: f  reason: collision with root package name */
        private boolean f2884f = false;

        /* renamed from: g  reason: collision with root package name */
        private boolean f2885g = false;

        class a implements a.C0028a {
            a() {
            }

            public void a() {
                e.this.b();
            }
        }

        enum b {
            NONE,
            ADDING,
            REMOVING
        }

        enum c {
            REMOVED,
            VISIBLE,
            GONE,
            INVISIBLE;

            static c b(int i2) {
                if (i2 == 0) {
                    return VISIBLE;
                }
                if (i2 == 4) {
                    return INVISIBLE;
                }
                if (i2 == 8) {
                    return GONE;
                }
                throw new IllegalArgumentException("Unknown visibility " + i2);
            }

            static c c(View view) {
                return (view.getAlpha() == 0.0f && view.getVisibility() == 0) ? INVISIBLE : b(view.getVisibility());
            }

            /* access modifiers changed from: package-private */
            public void a(View view) {
                int i2;
                int i3 = c.f2876a[ordinal()];
                if (i3 != 1) {
                    if (i3 == 2) {
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to VISIBLE");
                        }
                        i2 = 0;
                    } else if (i3 == 3) {
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to GONE");
                        }
                        i2 = 8;
                    } else if (i3 == 4) {
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to INVISIBLE");
                        }
                        view.setVisibility(4);
                        return;
                    } else {
                        return;
                    }
                    view.setVisibility(i2);
                    return;
                }
                ViewGroup viewGroup = (ViewGroup) view.getParent();
                if (viewGroup != null) {
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Removing view " + view + " from container " + viewGroup);
                    }
                    viewGroup.removeView(view);
                }
            }
        }

        e(c cVar, b bVar, Fragment fragment, androidx.core.os.a aVar) {
            this.f2879a = cVar;
            this.f2880b = bVar;
            this.f2881c = fragment;
            aVar.b(new a());
        }

        /* access modifiers changed from: package-private */
        public final void a(Runnable runnable) {
            this.f2882d.add(runnable);
        }

        /* access modifiers changed from: package-private */
        public final void b() {
            if (!h()) {
                this.f2884f = true;
                if (this.f2883e.isEmpty()) {
                    c();
                    return;
                }
                Iterator it = new ArrayList(this.f2883e).iterator();
                while (it.hasNext()) {
                    ((androidx.core.os.a) it.next()).a();
                }
            }
        }

        public void c() {
            if (!this.f2885g) {
                if (w.G0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
                }
                this.f2885g = true;
                for (Runnable run : this.f2882d) {
                    run.run();
                }
            }
        }

        public final void d(androidx.core.os.a aVar) {
            if (this.f2883e.remove(aVar) && this.f2883e.isEmpty()) {
                c();
            }
        }

        public c e() {
            return this.f2879a;
        }

        public final Fragment f() {
            return this.f2881c;
        }

        /* access modifiers changed from: package-private */
        public b g() {
            return this.f2880b;
        }

        /* access modifiers changed from: package-private */
        public final boolean h() {
            return this.f2884f;
        }

        /* access modifiers changed from: package-private */
        public final boolean i() {
            return this.f2885g;
        }

        public final void j(androidx.core.os.a aVar) {
            l();
            this.f2883e.add(aVar);
        }

        /* access modifiers changed from: package-private */
        public final void k(c cVar, b bVar) {
            b bVar2;
            int i2 = c.f2877b[bVar.ordinal()];
            if (i2 != 1) {
                if (i2 == 2) {
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f2881c + " mFinalState = " + this.f2879a + " -> REMOVED. mLifecycleImpact  = " + this.f2880b + " to REMOVING.");
                    }
                    this.f2879a = c.REMOVED;
                    bVar2 = b.REMOVING;
                } else if (i2 == 3 && this.f2879a != c.REMOVED) {
                    if (w.G0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f2881c + " mFinalState = " + this.f2879a + " -> " + cVar + ". ");
                    }
                    this.f2879a = cVar;
                    return;
                } else {
                    return;
                }
            } else if (this.f2879a == c.REMOVED) {
                if (w.G0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f2881c + " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = " + this.f2880b + " to ADDING.");
                }
                this.f2879a = c.VISIBLE;
                bVar2 = b.ADDING;
            } else {
                return;
            }
            this.f2880b = bVar2;
        }

        /* access modifiers changed from: package-private */
        public abstract void l();

        public String toString() {
            return "Operation " + "{" + Integer.toHexString(System.identityHashCode(this)) + "} " + "{" + "mFinalState = " + this.f2879a + "} " + "{" + "mLifecycleImpact = " + this.f2880b + "} " + "{" + "mFragment = " + this.f2881c + "}";
        }
    }

    K(ViewGroup viewGroup) {
        this.f2867a = viewGroup;
    }

    private void a(e.c cVar, e.b bVar, C c2) {
        synchronized (this.f2868b) {
            try {
                androidx.core.os.a aVar = new androidx.core.os.a();
                e h2 = h(c2.k());
                if (h2 != null) {
                    h2.k(cVar, bVar);
                    return;
                }
                d dVar = new d(cVar, bVar, c2, aVar);
                this.f2868b.add(dVar);
                dVar.a(new a(dVar));
                dVar.a(new b(dVar));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private e h(Fragment fragment) {
        Iterator it = this.f2868b.iterator();
        while (it.hasNext()) {
            e eVar = (e) it.next();
            if (eVar.f().equals(fragment) && !eVar.h()) {
                return eVar;
            }
        }
        return null;
    }

    private e i(Fragment fragment) {
        Iterator it = this.f2869c.iterator();
        while (it.hasNext()) {
            e eVar = (e) it.next();
            if (eVar.f().equals(fragment) && !eVar.h()) {
                return eVar;
            }
        }
        return null;
    }

    static K n(ViewGroup viewGroup, w wVar) {
        return o(viewGroup, wVar.y0());
    }

    static K o(ViewGroup viewGroup, L l2) {
        int i2 = I.b.special_effects_controller_view_tag;
        Object tag = viewGroup.getTag(i2);
        if (tag instanceof K) {
            return (K) tag;
        }
        K a2 = l2.a(viewGroup);
        viewGroup.setTag(i2, a2);
        return a2;
    }

    private void q() {
        Iterator it = this.f2868b.iterator();
        while (it.hasNext()) {
            e eVar = (e) it.next();
            if (eVar.g() == e.b.ADDING) {
                eVar.k(e.c.b(eVar.f().l1().getVisibility()), e.b.NONE);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void b(e.c cVar, C c2) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing add operation for fragment " + c2.k());
        }
        a(cVar, e.b.ADDING, c2);
    }

    /* access modifiers changed from: package-private */
    public void c(C c2) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing hide operation for fragment " + c2.k());
        }
        a(e.c.GONE, e.b.NONE, c2);
    }

    /* access modifiers changed from: package-private */
    public void d(C c2) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing remove operation for fragment " + c2.k());
        }
        a(e.c.REMOVED, e.b.REMOVING, c2);
    }

    /* access modifiers changed from: package-private */
    public void e(C c2) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing show operation for fragment " + c2.k());
        }
        a(e.c.VISIBLE, e.b.NONE, c2);
    }

    /* access modifiers changed from: package-private */
    public abstract void f(List list, boolean z2);

    /* access modifiers changed from: package-private */
    public void g() {
        if (!this.f2871e) {
            if (!W.T(this.f2867a)) {
                j();
                this.f2870d = false;
                return;
            }
            synchronized (this.f2868b) {
                try {
                    if (!this.f2868b.isEmpty()) {
                        ArrayList arrayList = new ArrayList(this.f2869c);
                        this.f2869c.clear();
                        Iterator it = arrayList.iterator();
                        while (it.hasNext()) {
                            e eVar = (e) it.next();
                            if (w.G0(2)) {
                                Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + eVar);
                            }
                            eVar.b();
                            if (!eVar.i()) {
                                this.f2869c.add(eVar);
                            }
                        }
                        q();
                        ArrayList arrayList2 = new ArrayList(this.f2868b);
                        this.f2868b.clear();
                        this.f2869c.addAll(arrayList2);
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations");
                        }
                        Iterator it2 = arrayList2.iterator();
                        while (it2.hasNext()) {
                            ((e) it2.next()).l();
                        }
                        f(arrayList2, this.f2870d);
                        this.f2870d = false;
                        if (w.G0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations");
                        }
                    }
                } finally {
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void j() {
        String str;
        String str2;
        if (w.G0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete");
        }
        boolean T2 = W.T(this.f2867a);
        synchronized (this.f2868b) {
            try {
                q();
                Iterator it = this.f2868b.iterator();
                while (it.hasNext()) {
                    ((e) it.next()).l();
                }
                Iterator it2 = new ArrayList(this.f2869c).iterator();
                while (it2.hasNext()) {
                    e eVar = (e) it2.next();
                    if (w.G0(2)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("SpecialEffectsController: ");
                        if (T2) {
                            str2 = "";
                        } else {
                            str2 = "Container " + this.f2867a + " is not attached to window. ";
                        }
                        sb.append(str2);
                        sb.append("Cancelling running operation ");
                        sb.append(eVar);
                        Log.v("FragmentManager", sb.toString());
                    }
                    eVar.b();
                }
                Iterator it3 = new ArrayList(this.f2868b).iterator();
                while (it3.hasNext()) {
                    e eVar2 = (e) it3.next();
                    if (w.G0(2)) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("SpecialEffectsController: ");
                        if (T2) {
                            str = "";
                        } else {
                            str = "Container " + this.f2867a + " is not attached to window. ";
                        }
                        sb2.append(str);
                        sb2.append("Cancelling pending operation ");
                        sb2.append(eVar2);
                        Log.v("FragmentManager", sb2.toString());
                    }
                    eVar2.b();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void k() {
        if (this.f2871e) {
            if (w.G0(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: Forcing postponed operations");
            }
            this.f2871e = false;
            g();
        }
    }

    /* access modifiers changed from: package-private */
    public e.b l(C c2) {
        e h2 = h(c2.k());
        e.b g2 = h2 != null ? h2.g() : null;
        e i2 = i(c2.k());
        return (i2 == null || !(g2 == null || g2 == e.b.NONE)) ? g2 : i2.g();
    }

    public ViewGroup m() {
        return this.f2867a;
    }

    /* access modifiers changed from: package-private */
    public void p() {
        synchronized (this.f2868b) {
            try {
                q();
                this.f2871e = false;
                int size = this.f2868b.size() - 1;
                while (true) {
                    if (size < 0) {
                        break;
                    }
                    e eVar = (e) this.f2868b.get(size);
                    e.c c2 = e.c.c(eVar.f().f2759I);
                    e.c e2 = eVar.e();
                    e.c cVar = e.c.VISIBLE;
                    if (e2 == cVar && c2 != cVar) {
                        this.f2871e = eVar.f().a0();
                        break;
                    }
                    size--;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void r(boolean z2) {
        this.f2870d = z2;
    }
}
