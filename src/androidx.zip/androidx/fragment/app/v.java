package androidx.fragment.app;

import android.os.Bundle;
import androidx.savedstate.a;

public final /* synthetic */ class v implements a.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w f3017a;

    public /* synthetic */ v(w wVar) {
        this.f3017a = wVar;
    }

    public final Bundle a() {
        return this.f3017a.O0();
    }
}
