package androidx.fragment.app;

import androidx.core.app.k;
import x.C0290a;

public final /* synthetic */ class u implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w f3016a;

    public /* synthetic */ u(w wVar) {
        this.f3016a = wVar;
    }

    public final void a(Object obj) {
        this.f3016a.S0((k) obj);
    }
}
