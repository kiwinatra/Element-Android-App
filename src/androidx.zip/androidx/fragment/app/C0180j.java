package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.q;
import androidx.activity.result.e;
import androidx.core.app.i;
import androidx.core.app.j;
import androidx.core.content.c;
import androidx.core.content.d;
import androidx.core.view.C0164w;
import androidx.core.view.C0170z;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.m;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import x.C0290a;

/* renamed from: androidx.fragment.app.j  reason: case insensitive filesystem */
public abstract class C0180j extends ComponentActivity {

    /* renamed from: u  reason: collision with root package name */
    final C0183m f2988u = C0183m.b(new a());

    /* renamed from: v  reason: collision with root package name */
    final m f2989v = new m(this);

    /* renamed from: w  reason: collision with root package name */
    boolean f2990w;

    /* renamed from: x  reason: collision with root package name */
    boolean f2991x;

    /* renamed from: y  reason: collision with root package name */
    boolean f2992y = true;

    /* renamed from: androidx.fragment.app.j$a */
    class a extends o implements c, d, i, j, E, q, e, O.d, A, C0164w {
        public a() {
            super(C0180j.this);
        }

        public void A() {
            C0180j.this.invalidateOptionsMenu();
        }

        /* renamed from: B */
        public C0180j x() {
            return C0180j.this;
        }

        public void a(w wVar, Fragment fragment) {
            C0180j.this.b0(fragment);
        }

        public void b(C0290a aVar) {
            C0180j.this.b(aVar);
        }

        public void c(C0290a aVar) {
            C0180j.this.c(aVar);
        }

        public OnBackPressedDispatcher d() {
            return C0180j.this.d();
        }

        public androidx.savedstate.a e() {
            return C0180j.this.e();
        }

        public void f(C0170z zVar) {
            C0180j.this.f(zVar);
        }

        public void g(C0290a aVar) {
            C0180j.this.g(aVar);
        }

        public void h(C0170z zVar) {
            C0180j.this.h(zVar);
        }

        public void i(C0290a aVar) {
            C0180j.this.i(aVar);
        }

        public void j(C0290a aVar) {
            C0180j.this.j(aVar);
        }

        public androidx.activity.result.d k() {
            return C0180j.this.k();
        }

        public void l(C0290a aVar) {
            C0180j.this.l(aVar);
        }

        public View n(int i2) {
            return C0180j.this.findViewById(i2);
        }

        public boolean o() {
            Window window = C0180j.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        public void p(C0290a aVar) {
            C0180j.this.p(aVar);
        }

        public void r(C0290a aVar) {
            C0180j.this.r(aVar);
        }

        public D t() {
            return C0180j.this.t();
        }

        public C0190g v() {
            return C0180j.this.f2989v;
        }

        public void w(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            C0180j.this.dump(str, fileDescriptor, printWriter, strArr);
        }

        public LayoutInflater y() {
            return C0180j.this.getLayoutInflater().cloneInContext(C0180j.this);
        }

        public void z() {
            A();
        }
    }

    public C0180j() {
        U();
    }

    private void U() {
        e().h("android:support:lifecycle", new C0176f(this));
        p(new C0177g(this));
        F(new C0178h(this));
        E(new C0179i(this));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ Bundle V() {
        Z();
        this.f2989v.h(C0190g.a.ON_STOP);
        return new Bundle();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void W(Configuration configuration) {
        this.f2988u.m();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void X(Intent intent) {
        this.f2988u.m();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void Y(Context context) {
        this.f2988u.a((Fragment) null);
    }

    private static boolean a0(w wVar, C0190g.b bVar) {
        boolean z2 = false;
        for (Fragment fragment : wVar.s0()) {
            if (fragment != null) {
                if (fragment.y() != null) {
                    z2 |= a0(fragment.n(), bVar);
                }
                I i2 = fragment.f2770T;
                if (i2 != null && i2.v().b().b(C0190g.b.STARTED)) {
                    fragment.f2770T.i(bVar);
                    z2 = true;
                }
                if (fragment.f2769S.b().b(C0190g.b.STARTED)) {
                    fragment.f2769S.m(bVar);
                    z2 = true;
                }
            }
        }
        return z2;
    }

    /* access modifiers changed from: package-private */
    public final View S(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f2988u.n(view, str, context, attributeSet);
    }

    public w T() {
        return this.f2988u.l();
    }

    /* access modifiers changed from: package-private */
    public void Z() {
        do {
        } while (a0(T(), C0190g.b.CREATED));
    }

    public void b0(Fragment fragment) {
    }

    /* access modifiers changed from: protected */
    public void c0() {
        this.f2989v.h(C0190g.a.ON_RESUME);
        this.f2988u.h();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (x(strArr)) {
            printWriter.print(str);
            printWriter.print("Local FragmentActivity ");
            printWriter.print(Integer.toHexString(System.identityHashCode(this)));
            printWriter.println(" State:");
            String str2 = str + "  ";
            printWriter.print(str2);
            printWriter.print("mCreated=");
            printWriter.print(this.f2990w);
            printWriter.print(" mResumed=");
            printWriter.print(this.f2991x);
            printWriter.print(" mStopped=");
            printWriter.print(this.f2992y);
            if (getApplication() != null) {
                androidx.loader.app.a.b(this).a(str2, fileDescriptor, printWriter, strArr);
            }
            this.f2988u.l().W(str, fileDescriptor, printWriter, strArr);
        }
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i2, int i3, Intent intent) {
        this.f2988u.m();
        super.onActivityResult(i2, i3, intent);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f2989v.h(C0190g.a.ON_CREATE);
        this.f2988u.e();
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View S2 = S(view, str, context, attributeSet);
        return S2 == null ? super.onCreateView(view, str, context, attributeSet) : S2;
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        this.f2988u.f();
        this.f2989v.h(C0190g.a.ON_DESTROY);
    }

    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 6) {
            return this.f2988u.d(menuItem);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        this.f2991x = false;
        this.f2988u.g();
        this.f2989v.h(C0190g.a.ON_PAUSE);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        c0();
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.f2988u.m();
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        this.f2988u.m();
        super.onResume();
        this.f2991x = true;
        this.f2988u.k();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        this.f2988u.m();
        super.onStart();
        this.f2992y = false;
        if (!this.f2990w) {
            this.f2990w = true;
            this.f2988u.c();
        }
        this.f2988u.k();
        this.f2989v.h(C0190g.a.ON_START);
        this.f2988u.i();
    }

    public void onStateNotSaved() {
        this.f2988u.m();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f2992y = true;
        Z();
        this.f2988u.j();
        this.f2989v.h(C0190g.a.ON_STOP);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View S2 = S((View) null, str, context, attributeSet);
        return S2 == null ? super.onCreateView(str, context, attributeSet) : S2;
    }
}
