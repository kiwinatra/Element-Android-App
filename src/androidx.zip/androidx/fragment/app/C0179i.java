package androidx.fragment.app;

import android.content.Context;
import b.C0209b;

/* renamed from: androidx.fragment.app.i  reason: case insensitive filesystem */
public final /* synthetic */ class C0179i implements C0209b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0180j f2987a;

    public /* synthetic */ C0179i(C0180j jVar) {
        this.f2987a = jVar;
    }

    public final void a(Context context) {
        this.f2987a.Y(context);
    }
}
