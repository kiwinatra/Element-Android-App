package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

final class J extends Writer {

    /* renamed from: a  reason: collision with root package name */
    private final String f2865a;

    /* renamed from: b  reason: collision with root package name */
    private StringBuilder f2866b = new StringBuilder(128);

    J(String str) {
        this.f2865a = str;
    }

    private void a() {
        if (this.f2866b.length() > 0) {
            Log.d(this.f2865a, this.f2866b.toString());
            StringBuilder sb = this.f2866b;
            sb.delete(0, sb.length());
        }
    }

    public void close() {
        a();
    }

    public void flush() {
        a();
    }

    public void write(char[] cArr, int i2, int i3) {
        for (int i4 = 0; i4 < i3; i4++) {
            char c2 = cArr[i2 + i4];
            if (c2 == 10) {
                a();
            } else {
                this.f2866b.append(c2);
            }
        }
    }
}
