package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.view.C0160u;
import androidx.lifecycle.A;
import androidx.lifecycle.C0189f;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.j;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.p;
import androidx.lifecycle.w;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, l, E, C0189f, O.d {

    /* renamed from: b0  reason: collision with root package name */
    static final Object f2750b0 = new Object();

    /* renamed from: A  reason: collision with root package name */
    boolean f2751A;

    /* renamed from: B  reason: collision with root package name */
    boolean f2752B;

    /* renamed from: C  reason: collision with root package name */
    boolean f2753C;

    /* renamed from: D  reason: collision with root package name */
    boolean f2754D;

    /* renamed from: E  reason: collision with root package name */
    boolean f2755E;

    /* renamed from: F  reason: collision with root package name */
    boolean f2756F = true;

    /* renamed from: G  reason: collision with root package name */
    private boolean f2757G;

    /* renamed from: H  reason: collision with root package name */
    ViewGroup f2758H;

    /* renamed from: I  reason: collision with root package name */
    View f2759I;

    /* renamed from: J  reason: collision with root package name */
    boolean f2760J;

    /* renamed from: K  reason: collision with root package name */
    boolean f2761K = true;

    /* renamed from: L  reason: collision with root package name */
    f f2762L;

    /* renamed from: M  reason: collision with root package name */
    Runnable f2763M = new a();

    /* renamed from: N  reason: collision with root package name */
    boolean f2764N;

    /* renamed from: O  reason: collision with root package name */
    LayoutInflater f2765O;

    /* renamed from: P  reason: collision with root package name */
    boolean f2766P;

    /* renamed from: Q  reason: collision with root package name */
    public String f2767Q;

    /* renamed from: R  reason: collision with root package name */
    C0190g.b f2768R = C0190g.b.RESUMED;

    /* renamed from: S  reason: collision with root package name */
    m f2769S;

    /* renamed from: T  reason: collision with root package name */
    I f2770T;

    /* renamed from: U  reason: collision with root package name */
    p f2771U = new p();

    /* renamed from: V  reason: collision with root package name */
    A.b f2772V;

    /* renamed from: W  reason: collision with root package name */
    O.c f2773W;

    /* renamed from: X  reason: collision with root package name */
    private int f2774X;

    /* renamed from: Y  reason: collision with root package name */
    private final AtomicInteger f2775Y = new AtomicInteger();

    /* renamed from: Z  reason: collision with root package name */
    private final ArrayList f2776Z = new ArrayList();

    /* renamed from: a  reason: collision with root package name */
    int f2777a = -1;

    /* renamed from: a0  reason: collision with root package name */
    private final i f2778a0 = new b();

    /* renamed from: b  reason: collision with root package name */
    Bundle f2779b;

    /* renamed from: c  reason: collision with root package name */
    SparseArray f2780c;

    /* renamed from: d  reason: collision with root package name */
    Bundle f2781d;

    /* renamed from: e  reason: collision with root package name */
    Boolean f2782e;

    /* renamed from: f  reason: collision with root package name */
    String f2783f = UUID.randomUUID().toString();

    /* renamed from: g  reason: collision with root package name */
    Bundle f2784g;

    /* renamed from: h  reason: collision with root package name */
    Fragment f2785h;

    /* renamed from: i  reason: collision with root package name */
    String f2786i = null;

    /* renamed from: j  reason: collision with root package name */
    int f2787j;

    /* renamed from: k  reason: collision with root package name */
    private Boolean f2788k = null;

    /* renamed from: l  reason: collision with root package name */
    boolean f2789l;

    /* renamed from: m  reason: collision with root package name */
    boolean f2790m;

    /* renamed from: n  reason: collision with root package name */
    boolean f2791n;

    /* renamed from: o  reason: collision with root package name */
    boolean f2792o;

    /* renamed from: p  reason: collision with root package name */
    boolean f2793p;

    /* renamed from: q  reason: collision with root package name */
    boolean f2794q;

    /* renamed from: r  reason: collision with root package name */
    boolean f2795r;

    /* renamed from: s  reason: collision with root package name */
    int f2796s;

    /* renamed from: t  reason: collision with root package name */
    w f2797t;

    /* renamed from: u  reason: collision with root package name */
    o f2798u;

    /* renamed from: v  reason: collision with root package name */
    w f2799v = new x();

    /* renamed from: w  reason: collision with root package name */
    Fragment f2800w;

    /* renamed from: x  reason: collision with root package name */
    int f2801x;

    /* renamed from: y  reason: collision with root package name */
    int f2802y;

    /* renamed from: z  reason: collision with root package name */
    String f2803z;

    class a implements Runnable {
        a() {
        }

        public void run() {
            Fragment.this.w1();
        }
    }

    class b extends i {
        b() {
            super((a) null);
        }

        /* access modifiers changed from: package-private */
        public void a() {
            Fragment.this.f2773W.c();
            w.a(Fragment.this);
        }
    }

    class c implements Runnable {
        c() {
        }

        public void run() {
            Fragment.this.b(false);
        }
    }

    class d implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ K f2808a;

        d(K k2) {
            this.f2808a = k2;
        }

        public void run() {
            this.f2808a.g();
        }
    }

    class e extends C0182l {
        e() {
        }

        public View n(int i2) {
            View view = Fragment.this.f2759I;
            if (view != null) {
                return view.findViewById(i2);
            }
            throw new IllegalStateException("Fragment " + Fragment.this + " does not have a view");
        }

        public boolean o() {
            return Fragment.this.f2759I != null;
        }
    }

    static class f {

        /* renamed from: a  reason: collision with root package name */
        View f2811a;

        /* renamed from: b  reason: collision with root package name */
        boolean f2812b;

        /* renamed from: c  reason: collision with root package name */
        int f2813c;

        /* renamed from: d  reason: collision with root package name */
        int f2814d;

        /* renamed from: e  reason: collision with root package name */
        int f2815e;

        /* renamed from: f  reason: collision with root package name */
        int f2816f;

        /* renamed from: g  reason: collision with root package name */
        int f2817g;

        /* renamed from: h  reason: collision with root package name */
        ArrayList f2818h;

        /* renamed from: i  reason: collision with root package name */
        ArrayList f2819i;

        /* renamed from: j  reason: collision with root package name */
        Object f2820j = null;

        /* renamed from: k  reason: collision with root package name */
        Object f2821k;

        /* renamed from: l  reason: collision with root package name */
        Object f2822l;

        /* renamed from: m  reason: collision with root package name */
        Object f2823m;

        /* renamed from: n  reason: collision with root package name */
        Object f2824n;

        /* renamed from: o  reason: collision with root package name */
        Object f2825o;

        /* renamed from: p  reason: collision with root package name */
        Boolean f2826p;

        /* renamed from: q  reason: collision with root package name */
        Boolean f2827q;

        /* renamed from: r  reason: collision with root package name */
        float f2828r;

        /* renamed from: s  reason: collision with root package name */
        View f2829s;

        /* renamed from: t  reason: collision with root package name */
        boolean f2830t;

        f() {
            Object obj = Fragment.f2750b0;
            this.f2821k = obj;
            this.f2822l = null;
            this.f2823m = obj;
            this.f2824n = null;
            this.f2825o = obj;
            this.f2828r = 1.0f;
            this.f2829s = null;
        }
    }

    static class g {
        static void a(View view) {
            view.cancelPendingInputEvents();
        }
    }

    public static class h extends RuntimeException {
        public h(String str, Exception exc) {
            super(str, exc);
        }
    }

    private static abstract class i {
        private i() {
        }

        /* access modifiers changed from: package-private */
        public abstract void a();

        /* synthetic */ i(a aVar) {
            this();
        }
    }

    public Fragment() {
        T();
    }

    private int A() {
        C0190g.b bVar = this.f2768R;
        return (bVar == C0190g.b.INITIALIZED || this.f2800w == null) ? bVar.ordinal() : Math.min(bVar.ordinal(), this.f2800w.A());
    }

    private Fragment Q(boolean z2) {
        String str;
        if (z2) {
            J.c.h(this);
        }
        Fragment fragment = this.f2785h;
        if (fragment != null) {
            return fragment;
        }
        w wVar = this.f2797t;
        if (wVar == null || (str = this.f2786i) == null) {
            return null;
        }
        return wVar.e0(str);
    }

    private void T() {
        this.f2769S = new m(this);
        this.f2773W = O.c.a(this);
        this.f2772V = null;
        if (!this.f2776Z.contains(this.f2778a0)) {
            i1(this.f2778a0);
        }
    }

    public static Fragment V(Context context, String str, Bundle bundle) {
        try {
            Fragment fragment = (Fragment) n.d(context.getClassLoader(), str).getConstructor((Class[]) null).newInstance((Object[]) null);
            if (bundle != null) {
                bundle.setClassLoader(fragment.getClass().getClassLoader());
                fragment.q1(bundle);
            }
            return fragment;
        } catch (InstantiationException e2) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (IllegalAccessException e3) {
            throw new h("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new h("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new h("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    private f g() {
        if (this.f2762L == null) {
            this.f2762L = new f();
        }
        return this.f2762L;
    }

    private void i1(i iVar) {
        if (this.f2777a >= 0) {
            iVar.a();
        } else {
            this.f2776Z.add(iVar);
        }
    }

    private void n1() {
        if (w.G0(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this);
        }
        if (this.f2759I != null) {
            o1(this.f2779b);
        }
        this.f2779b = null;
    }

    public void A0(boolean z2) {
    }

    /* access modifiers changed from: package-private */
    public int B() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 0;
        }
        return fVar.f2817g;
    }

    public void B0(Menu menu) {
    }

    public final Fragment C() {
        return this.f2800w;
    }

    public void C0(boolean z2) {
    }

    public final w D() {
        w wVar = this.f2797t;
        if (wVar != null) {
            return wVar;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public void D0(int i2, String[] strArr, int[] iArr) {
    }

    /* access modifiers changed from: package-private */
    public boolean E() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return false;
        }
        return fVar.f2812b;
    }

    public void E0() {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public int F() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 0;
        }
        return fVar.f2815e;
    }

    public void F0(Bundle bundle) {
    }

    /* access modifiers changed from: package-private */
    public int G() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 0;
        }
        return fVar.f2816f;
    }

    public void G0() {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public float H() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 1.0f;
        }
        return fVar.f2828r;
    }

    public void H0() {
        this.f2757G = true;
    }

    public Object I() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.f2823m;
        return obj == f2750b0 ? u() : obj;
    }

    public void I0(View view, Bundle bundle) {
    }

    public final Resources J() {
        return k1().getResources();
    }

    public void J0(Bundle bundle) {
        this.f2757G = true;
    }

    public Object K() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.f2821k;
        return obj == f2750b0 ? q() : obj;
    }

    /* access modifiers changed from: package-private */
    public void K0(Bundle bundle) {
        this.f2799v.U0();
        this.f2777a = 3;
        this.f2757G = false;
        d0(bundle);
        if (this.f2757G) {
            n1();
            this.f2799v.x();
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onActivityCreated()");
    }

    public Object L() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        return fVar.f2824n;
    }

    /* access modifiers changed from: package-private */
    public void L0() {
        Iterator it = this.f2776Z.iterator();
        while (it.hasNext()) {
            ((i) it.next()).a();
        }
        this.f2776Z.clear();
        this.f2799v.m(this.f2798u, c(), this);
        this.f2777a = 0;
        this.f2757G = false;
        g0(this.f2798u.s());
        if (this.f2757G) {
            this.f2797t.H(this);
            this.f2799v.y();
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onAttach()");
    }

    public Object M() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        Object obj = fVar.f2825o;
        return obj == f2750b0 ? L() : obj;
    }

    /* access modifiers changed from: package-private */
    public void M0(Configuration configuration) {
        onConfigurationChanged(configuration);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r0.f2818h;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.ArrayList N() {
        /*
            r1 = this;
            androidx.fragment.app.Fragment$f r0 = r1.f2762L
            if (r0 == 0) goto L_0x000a
            java.util.ArrayList r0 = r0.f2818h
            if (r0 != 0) goto L_0x0009
            goto L_0x000a
        L_0x0009:
            return r0
        L_0x000a:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.N():java.util.ArrayList");
    }

    /* access modifiers changed from: package-private */
    public boolean N0(MenuItem menuItem) {
        if (this.f2751A) {
            return false;
        }
        if (i0(menuItem)) {
            return true;
        }
        return this.f2799v.A(menuItem);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r0.f2819i;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.ArrayList O() {
        /*
            r1 = this;
            androidx.fragment.app.Fragment$f r0 = r1.f2762L
            if (r0 == 0) goto L_0x000a
            java.util.ArrayList r0 = r0.f2819i
            if (r0 != 0) goto L_0x0009
            goto L_0x000a
        L_0x0009:
            return r0
        L_0x000a:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.O():java.util.ArrayList");
    }

    /* access modifiers changed from: package-private */
    public void O0(Bundle bundle) {
        this.f2799v.U0();
        this.f2777a = 1;
        this.f2757G = false;
        this.f2769S.a(new j() {
            public void d(l lVar, C0190g.a aVar) {
                View view;
                if (aVar == C0190g.a.ON_STOP && (view = Fragment.this.f2759I) != null) {
                    g.a(view);
                }
            }
        });
        this.f2773W.d(bundle);
        j0(bundle);
        this.f2766P = true;
        if (this.f2757G) {
            this.f2769S.h(C0190g.a.ON_CREATE);
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onCreate()");
    }

    public final String P(int i2) {
        return J().getString(i2);
    }

    /* access modifiers changed from: package-private */
    public boolean P0(Menu menu, MenuInflater menuInflater) {
        boolean z2 = false;
        if (this.f2751A) {
            return false;
        }
        if (this.f2755E && this.f2756F) {
            m0(menu, menuInflater);
            z2 = true;
        }
        return z2 | this.f2799v.C(menu, menuInflater);
    }

    /* access modifiers changed from: package-private */
    public void Q0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f2799v.U0();
        this.f2795r = true;
        this.f2770T = new I(this, t());
        View n02 = n0(layoutInflater, viewGroup, bundle);
        this.f2759I = n02;
        if (n02 != null) {
            this.f2770T.c();
            F.a(this.f2759I, this.f2770T);
            G.a(this.f2759I, this.f2770T);
            O.e.a(this.f2759I, this.f2770T);
            this.f2771U.i(this.f2770T);
        } else if (!this.f2770T.f()) {
            this.f2770T = null;
        } else {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        }
    }

    public View R() {
        return this.f2759I;
    }

    /* access modifiers changed from: package-private */
    public void R0() {
        this.f2799v.D();
        this.f2769S.h(C0190g.a.ON_DESTROY);
        this.f2777a = 0;
        this.f2757G = false;
        this.f2766P = false;
        o0();
        if (!this.f2757G) {
            throw new M("Fragment " + this + " did not call through to super.onDestroy()");
        }
    }

    public LiveData S() {
        return this.f2771U;
    }

    /* access modifiers changed from: package-private */
    public void S0() {
        this.f2799v.E();
        if (this.f2759I != null && this.f2770T.v().b().b(C0190g.b.CREATED)) {
            this.f2770T.b(C0190g.a.ON_DESTROY);
        }
        this.f2777a = 1;
        this.f2757G = false;
        q0();
        if (this.f2757G) {
            androidx.loader.app.a.b(this).c();
            this.f2795r = false;
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onDestroyView()");
    }

    /* access modifiers changed from: package-private */
    public void T0() {
        this.f2777a = -1;
        this.f2757G = false;
        r0();
        this.f2765O = null;
        if (!this.f2757G) {
            throw new M("Fragment " + this + " did not call through to super.onDetach()");
        } else if (!this.f2799v.F0()) {
            this.f2799v.D();
            this.f2799v = new x();
        }
    }

    /* access modifiers changed from: package-private */
    public void U() {
        T();
        this.f2767Q = this.f2783f;
        this.f2783f = UUID.randomUUID().toString();
        this.f2789l = false;
        this.f2790m = false;
        this.f2792o = false;
        this.f2793p = false;
        this.f2794q = false;
        this.f2796s = 0;
        this.f2797t = null;
        this.f2799v = new x();
        this.f2798u = null;
        this.f2801x = 0;
        this.f2802y = 0;
        this.f2803z = null;
        this.f2751A = false;
        this.f2752B = false;
    }

    /* access modifiers changed from: package-private */
    public LayoutInflater U0(Bundle bundle) {
        LayoutInflater s02 = s0(bundle);
        this.f2765O = s02;
        return s02;
    }

    /* access modifiers changed from: package-private */
    public void V0() {
        onLowMemory();
    }

    public final boolean W() {
        return this.f2798u != null && this.f2789l;
    }

    /* access modifiers changed from: package-private */
    public void W0(boolean z2) {
        w0(z2);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r2.f2797t;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean X() {
        /*
            r2 = this;
            boolean r0 = r2.f2751A
            if (r0 != 0) goto L_0x0013
            androidx.fragment.app.w r0 = r2.f2797t
            if (r0 == 0) goto L_0x0011
            androidx.fragment.app.Fragment r1 = r2.f2800w
            boolean r0 = r0.J0(r1)
            if (r0 == 0) goto L_0x0011
            goto L_0x0013
        L_0x0011:
            r0 = 0
            goto L_0x0014
        L_0x0013:
            r0 = 1
        L_0x0014:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.X():boolean");
    }

    /* access modifiers changed from: package-private */
    public boolean X0(MenuItem menuItem) {
        if (this.f2751A) {
            return false;
        }
        if (!this.f2755E || !this.f2756F || !x0(menuItem)) {
            return this.f2799v.J(menuItem);
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public final boolean Y() {
        return this.f2796s > 0;
    }

    /* access modifiers changed from: package-private */
    public void Y0(Menu menu) {
        if (!this.f2751A) {
            if (this.f2755E && this.f2756F) {
                y0(menu);
            }
            this.f2799v.K(menu);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r2.f2797t;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean Z() {
        /*
            r2 = this;
            boolean r0 = r2.f2756F
            if (r0 == 0) goto L_0x0012
            androidx.fragment.app.w r0 = r2.f2797t
            if (r0 == 0) goto L_0x0010
            androidx.fragment.app.Fragment r1 = r2.f2800w
            boolean r0 = r0.K0(r1)
            if (r0 == 0) goto L_0x0012
        L_0x0010:
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.Z():boolean");
    }

    /* access modifiers changed from: package-private */
    public void Z0() {
        this.f2799v.M();
        if (this.f2759I != null) {
            this.f2770T.b(C0190g.a.ON_PAUSE);
        }
        this.f2769S.h(C0190g.a.ON_PAUSE);
        this.f2777a = 6;
        this.f2757G = false;
        z0();
        if (!this.f2757G) {
            throw new M("Fragment " + this + " did not call through to super.onPause()");
        }
    }

    public M.a a() {
        Application application;
        Context applicationContext = k1().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            } else if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            } else {
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
        }
        if (application == null && w.G0(3)) {
            Log.d("FragmentManager", "Could not find Application instance from Context " + k1().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
        }
        M.d dVar = new M.d();
        if (application != null) {
            dVar.b(A.a.f3099d, application);
        }
        dVar.b(w.f3184a, this);
        dVar.b(w.f3185b, this);
        if (m() != null) {
            dVar.b(w.f3186c, m());
        }
        return dVar;
    }

    /* access modifiers changed from: package-private */
    public boolean a0() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return false;
        }
        return fVar.f2830t;
    }

    /* access modifiers changed from: package-private */
    public void a1(boolean z2) {
        A0(z2);
    }

    /* access modifiers changed from: package-private */
    public void b(boolean z2) {
        ViewGroup viewGroup;
        w wVar;
        f fVar = this.f2762L;
        if (fVar != null) {
            fVar.f2830t = false;
        }
        if (this.f2759I != null && (viewGroup = this.f2758H) != null && (wVar = this.f2797t) != null) {
            K n2 = K.n(viewGroup, wVar);
            n2.p();
            if (z2) {
                this.f2798u.u().post(new d(n2));
            } else {
                n2.g();
            }
        }
    }

    public final boolean b0() {
        w wVar = this.f2797t;
        if (wVar == null) {
            return false;
        }
        return wVar.N0();
    }

    /* access modifiers changed from: package-private */
    public boolean b1(Menu menu) {
        boolean z2 = false;
        if (this.f2751A) {
            return false;
        }
        if (this.f2755E && this.f2756F) {
            B0(menu);
            z2 = true;
        }
        return z2 | this.f2799v.O(menu);
    }

    /* access modifiers changed from: package-private */
    public C0182l c() {
        return new e();
    }

    /* access modifiers changed from: package-private */
    public void c0() {
        this.f2799v.U0();
    }

    /* access modifiers changed from: package-private */
    public void c1() {
        boolean L0 = this.f2797t.L0(this);
        Boolean bool = this.f2788k;
        if (bool == null || bool.booleanValue() != L0) {
            this.f2788k = Boolean.valueOf(L0);
            C0(L0);
            this.f2799v.P();
        }
    }

    public void d0(Bundle bundle) {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public void d1() {
        this.f2799v.U0();
        this.f2799v.a0(true);
        this.f2777a = 7;
        this.f2757G = false;
        E0();
        if (this.f2757G) {
            m mVar = this.f2769S;
            C0190g.a aVar = C0190g.a.ON_RESUME;
            mVar.h(aVar);
            if (this.f2759I != null) {
                this.f2770T.b(aVar);
            }
            this.f2799v.Q();
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onResume()");
    }

    public final androidx.savedstate.a e() {
        return this.f2773W.b();
    }

    public void e0(int i2, int i3, Intent intent) {
        if (w.G0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i2 + " resultCode: " + i3 + " data: " + intent);
        }
    }

    /* access modifiers changed from: package-private */
    public void e1(Bundle bundle) {
        F0(bundle);
        this.f2773W.e(bundle);
        Bundle h1 = this.f2799v.O0();
        if (h1 != null) {
            bundle.putParcelable("android:support:fragments", h1);
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public void f(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.f2801x));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.f2802y));
        printWriter.print(" mTag=");
        printWriter.println(this.f2803z);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f2777a);
        printWriter.print(" mWho=");
        printWriter.print(this.f2783f);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.f2796s);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.f2789l);
        printWriter.print(" mRemoving=");
        printWriter.print(this.f2790m);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.f2792o);
        printWriter.print(" mInLayout=");
        printWriter.println(this.f2793p);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.f2751A);
        printWriter.print(" mDetached=");
        printWriter.print(this.f2752B);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.f2756F);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.f2755E);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.f2753C);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.f2761K);
        if (this.f2797t != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.f2797t);
        }
        if (this.f2798u != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.f2798u);
        }
        if (this.f2800w != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.f2800w);
        }
        if (this.f2784g != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f2784g);
        }
        if (this.f2779b != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f2779b);
        }
        if (this.f2780c != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f2780c);
        }
        if (this.f2781d != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.f2781d);
        }
        Fragment Q2 = Q(false);
        if (Q2 != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(Q2);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.f2787j);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(E());
        if (p() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(p());
        }
        if (s() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(s());
        }
        if (F() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(F());
        }
        if (G() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(G());
        }
        if (this.f2758H != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.f2758H);
        }
        if (this.f2759I != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.f2759I);
        }
        if (l() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(l());
        }
        if (o() != null) {
            androidx.loader.app.a.b(this).a(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.f2799v + ":");
        w wVar = this.f2799v;
        wVar.W(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public void f0(Activity activity) {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public void f1() {
        this.f2799v.U0();
        this.f2799v.a0(true);
        this.f2777a = 5;
        this.f2757G = false;
        G0();
        if (this.f2757G) {
            m mVar = this.f2769S;
            C0190g.a aVar = C0190g.a.ON_START;
            mVar.h(aVar);
            if (this.f2759I != null) {
                this.f2770T.b(aVar);
            }
            this.f2799v.R();
            return;
        }
        throw new M("Fragment " + this + " did not call through to super.onStart()");
    }

    public void g0(Context context) {
        this.f2757G = true;
        o oVar = this.f2798u;
        Activity q2 = oVar == null ? null : oVar.q();
        if (q2 != null) {
            this.f2757G = false;
            f0(q2);
        }
    }

    /* access modifiers changed from: package-private */
    public void g1() {
        this.f2799v.T();
        if (this.f2759I != null) {
            this.f2770T.b(C0190g.a.ON_STOP);
        }
        this.f2769S.h(C0190g.a.ON_STOP);
        this.f2777a = 4;
        this.f2757G = false;
        H0();
        if (!this.f2757G) {
            throw new M("Fragment " + this + " did not call through to super.onStop()");
        }
    }

    /* access modifiers changed from: package-private */
    public Fragment h(String str) {
        return str.equals(this.f2783f) ? this : this.f2799v.i0(str);
    }

    public void h0(Fragment fragment) {
    }

    /* access modifiers changed from: package-private */
    public void h1() {
        I0(this.f2759I, this.f2779b);
        this.f2799v.U();
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final C0180j i() {
        o oVar = this.f2798u;
        if (oVar == null) {
            return null;
        }
        return (C0180j) oVar.q();
    }

    public boolean i0(MenuItem menuItem) {
        return false;
    }

    public boolean j() {
        Boolean bool;
        f fVar = this.f2762L;
        if (fVar == null || (bool = fVar.f2827q) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public void j0(Bundle bundle) {
        this.f2757G = true;
        m1(bundle);
        if (!this.f2799v.M0(1)) {
            this.f2799v.B();
        }
    }

    public final C0180j j1() {
        C0180j i2 = i();
        if (i2 != null) {
            return i2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public boolean k() {
        Boolean bool;
        f fVar = this.f2762L;
        if (fVar == null || (bool = fVar.f2826p) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public Animation k0(int i2, boolean z2, int i3) {
        return null;
    }

    public final Context k1() {
        Context o2 = o();
        if (o2 != null) {
            return o2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    /* access modifiers changed from: package-private */
    public View l() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        return fVar.f2811a;
    }

    public Animator l0(int i2, boolean z2, int i3) {
        return null;
    }

    public final View l1() {
        View R2 = R();
        if (R2 != null) {
            return R2;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    public final Bundle m() {
        return this.f2784g;
    }

    public void m0(Menu menu, MenuInflater menuInflater) {
    }

    /* access modifiers changed from: package-private */
    public void m1(Bundle bundle) {
        Parcelable parcelable;
        if (bundle != null && (parcelable = bundle.getParcelable("android:support:fragments")) != null) {
            this.f2799v.f1(parcelable);
            this.f2799v.B();
        }
    }

    public final w n() {
        if (this.f2798u != null) {
            return this.f2799v;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    public View n0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.f2774X;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    public Context o() {
        o oVar = this.f2798u;
        if (oVar == null) {
            return null;
        }
        return oVar.s();
    }

    public void o0() {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public final void o1(Bundle bundle) {
        SparseArray sparseArray = this.f2780c;
        if (sparseArray != null) {
            this.f2759I.restoreHierarchyState(sparseArray);
            this.f2780c = null;
        }
        if (this.f2759I != null) {
            this.f2770T.g(this.f2781d);
            this.f2781d = null;
        }
        this.f2757G = false;
        J0(bundle);
        if (!this.f2757G) {
            throw new M("Fragment " + this + " did not call through to super.onViewStateRestored()");
        } else if (this.f2759I != null) {
            this.f2770T.b(C0190g.a.ON_CREATE);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f2757G = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        j1().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onLowMemory() {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public int p() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 0;
        }
        return fVar.f2813c;
    }

    public void p0() {
    }

    /* access modifiers changed from: package-private */
    public void p1(int i2, int i3, int i4, int i5) {
        if (this.f2762L != null || i2 != 0 || i3 != 0 || i4 != 0 || i5 != 0) {
            g().f2813c = i2;
            g().f2814d = i3;
            g().f2815e = i4;
            g().f2816f = i5;
        }
    }

    public Object q() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        return fVar.f2820j;
    }

    public void q0() {
        this.f2757G = true;
    }

    public void q1(Bundle bundle) {
        if (this.f2797t == null || !b0()) {
            this.f2784g = bundle;
            return;
        }
        throw new IllegalStateException("Fragment already added and state has been saved");
    }

    /* access modifiers changed from: package-private */
    public androidx.core.app.l r() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public void r0() {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public void r1(View view) {
        g().f2829s = view;
    }

    /* access modifiers changed from: package-private */
    public int s() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return 0;
        }
        return fVar.f2814d;
    }

    public LayoutInflater s0(Bundle bundle) {
        return z(bundle);
    }

    /* access modifiers changed from: package-private */
    public void s1(int i2) {
        if (this.f2762L != null || i2 != 0) {
            g();
            this.f2762L.f2817g = i2;
        }
    }

    public D t() {
        if (this.f2797t == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        } else if (A() != C0190g.b.INITIALIZED.ordinal()) {
            return this.f2797t.B0(this);
        } else {
            throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
    }

    public void t0(boolean z2) {
    }

    /* access modifiers changed from: package-private */
    public void t1(boolean z2) {
        if (this.f2762L != null) {
            g().f2812b = z2;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.f2783f);
        if (this.f2801x != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f2801x));
        }
        if (this.f2803z != null) {
            sb.append(" tag=");
            sb.append(this.f2803z);
        }
        sb.append(")");
        return sb.toString();
    }

    public Object u() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        return fVar.f2822l;
    }

    public void u0(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.f2757G = true;
    }

    /* access modifiers changed from: package-private */
    public void u1(float f2) {
        g().f2828r = f2;
    }

    public C0190g v() {
        return this.f2769S;
    }

    public void v0(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.f2757G = true;
        o oVar = this.f2798u;
        Activity q2 = oVar == null ? null : oVar.q();
        if (q2 != null) {
            this.f2757G = false;
            u0(q2, attributeSet, bundle);
        }
    }

    /* access modifiers changed from: package-private */
    public void v1(ArrayList arrayList, ArrayList arrayList2) {
        g();
        f fVar = this.f2762L;
        fVar.f2818h = arrayList;
        fVar.f2819i = arrayList2;
    }

    /* access modifiers changed from: package-private */
    public androidx.core.app.l w() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        fVar.getClass();
        return null;
    }

    public void w0(boolean z2) {
    }

    public void w1() {
        if (this.f2762L != null && g().f2830t) {
            if (this.f2798u == null) {
                g().f2830t = false;
            } else if (Looper.myLooper() != this.f2798u.u().getLooper()) {
                this.f2798u.u().postAtFrontOfQueue(new c());
            } else {
                b(true);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public View x() {
        f fVar = this.f2762L;
        if (fVar == null) {
            return null;
        }
        return fVar.f2829s;
    }

    public boolean x0(MenuItem menuItem) {
        return false;
    }

    public final Object y() {
        o oVar = this.f2798u;
        if (oVar == null) {
            return null;
        }
        return oVar.x();
    }

    public void y0(Menu menu) {
    }

    public LayoutInflater z(Bundle bundle) {
        o oVar = this.f2798u;
        if (oVar != null) {
            LayoutInflater y2 = oVar.y();
            C0160u.a(y2, this.f2799v.u0());
            return y2;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public void z0() {
        this.f2757G = true;
    }
}
