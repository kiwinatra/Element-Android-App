package androidx.fragment.app;

import x.C0290a;

public final /* synthetic */ class s implements C0290a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w f3014a;

    public /* synthetic */ s(w wVar) {
        this.f3014a = wVar;
    }

    public final void a(Object obj) {
        this.f3014a.Q0((Integer) obj);
    }
}
