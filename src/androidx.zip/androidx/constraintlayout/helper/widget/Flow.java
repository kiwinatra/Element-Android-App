package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.i;
import androidx.constraintlayout.widget.k;
import p.e;
import p.g;
import p.l;

public class Flow extends k {

    /* renamed from: l  reason: collision with root package name */
    private g f1656l;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        this.f1656l = new g();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.n1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.o1) {
                    this.f1656l.D2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.p1) {
                    this.f1656l.I1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.z1) {
                    this.f1656l.N1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.A1) {
                    this.f1656l.K1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.q1) {
                    this.f1656l.L1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.r1) {
                    this.f1656l.O1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.s1) {
                    this.f1656l.M1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.t1) {
                    this.f1656l.J1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.Z1) {
                    this.f1656l.I2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.P1) {
                    this.f1656l.x2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.Y1) {
                    this.f1656l.H2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.J1) {
                    this.f1656l.r2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.R1) {
                    this.f1656l.z2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.L1) {
                    this.f1656l.t2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.T1) {
                    this.f1656l.B2(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.N1) {
                    this.f1656l.v2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.I1) {
                    this.f1656l.q2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.Q1) {
                    this.f1656l.y2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.K1) {
                    this.f1656l.s2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.S1) {
                    this.f1656l.A2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.W1) {
                    this.f1656l.F2(obtainStyledAttributes.getFloat(index, 0.5f));
                } else if (index == i.M1) {
                    this.f1656l.u2(obtainStyledAttributes.getInt(index, 2));
                } else if (index == i.V1) {
                    this.f1656l.E2(obtainStyledAttributes.getInt(index, 2));
                } else if (index == i.O1) {
                    this.f1656l.w2(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.X1) {
                    this.f1656l.G2(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                } else if (index == i.U1) {
                    this.f1656l.C2(obtainStyledAttributes.getInt(index, -1));
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1790d = this.f1656l;
        o();
    }

    public void j(e eVar, boolean z2) {
        this.f1656l.t1(z2);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        p(this.f1656l, i2, i3);
    }

    public void p(l lVar, int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (lVar != null) {
            lVar.C1(mode, size, mode2, size2);
            setMeasuredDimension(lVar.x1(), lVar.w1());
            return;
        }
        setMeasuredDimension(0, 0);
    }

    public void setFirstHorizontalBias(float f2) {
        this.f1656l.q2(f2);
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i2) {
        this.f1656l.r2(i2);
        requestLayout();
    }

    public void setFirstVerticalBias(float f2) {
        this.f1656l.s2(f2);
        requestLayout();
    }

    public void setFirstVerticalStyle(int i2) {
        this.f1656l.t2(i2);
        requestLayout();
    }

    public void setHorizontalAlign(int i2) {
        this.f1656l.u2(i2);
        requestLayout();
    }

    public void setHorizontalBias(float f2) {
        this.f1656l.v2(f2);
        requestLayout();
    }

    public void setHorizontalGap(int i2) {
        this.f1656l.w2(i2);
        requestLayout();
    }

    public void setHorizontalStyle(int i2) {
        this.f1656l.x2(i2);
        requestLayout();
    }

    public void setLastHorizontalBias(float f2) {
        this.f1656l.y2(f2);
        requestLayout();
    }

    public void setLastHorizontalStyle(int i2) {
        this.f1656l.z2(i2);
        requestLayout();
    }

    public void setLastVerticalBias(float f2) {
        this.f1656l.A2(f2);
        requestLayout();
    }

    public void setLastVerticalStyle(int i2) {
        this.f1656l.B2(i2);
        requestLayout();
    }

    public void setMaxElementsWrap(int i2) {
        this.f1656l.C2(i2);
        requestLayout();
    }

    public void setOrientation(int i2) {
        this.f1656l.D2(i2);
        requestLayout();
    }

    public void setPadding(int i2) {
        this.f1656l.I1(i2);
        requestLayout();
    }

    public void setPaddingBottom(int i2) {
        this.f1656l.J1(i2);
        requestLayout();
    }

    public void setPaddingLeft(int i2) {
        this.f1656l.L1(i2);
        requestLayout();
    }

    public void setPaddingRight(int i2) {
        this.f1656l.M1(i2);
        requestLayout();
    }

    public void setPaddingTop(int i2) {
        this.f1656l.O1(i2);
        requestLayout();
    }

    public void setVerticalAlign(int i2) {
        this.f1656l.E2(i2);
        requestLayout();
    }

    public void setVerticalBias(float f2) {
        this.f1656l.F2(f2);
        requestLayout();
    }

    public void setVerticalGap(int i2) {
        this.f1656l.G2(i2);
        requestLayout();
    }

    public void setVerticalStyle(int i2) {
        this.f1656l.H2(i2);
        requestLayout();
    }

    public void setWrapMode(int i2) {
        this.f1656l.I2(i2);
        requestLayout();
    }
}
