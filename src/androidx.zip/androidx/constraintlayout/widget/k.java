package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import p.l;

public abstract class k extends c {

    /* renamed from: j  reason: collision with root package name */
    private boolean f2028j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f2029k;

    public k(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public void f(ConstraintLayout constraintLayout) {
        e(constraintLayout);
    }

    /* access modifiers changed from: protected */
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.n1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.u1) {
                    this.f2028j = true;
                } else if (index == i.B1) {
                    this.f2029k = true;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f2028j || this.f2029k) {
            ViewParent parent = getParent();
            if (parent instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) parent;
                int visibility = getVisibility();
                float elevation = getElevation();
                for (int i2 = 0; i2 < this.f1788b; i2++) {
                    View l2 = constraintLayout.l(this.f1787a[i2]);
                    if (l2 != null) {
                        if (this.f2028j) {
                            l2.setVisibility(visibility);
                        }
                        if (this.f2029k && elevation > 0.0f) {
                            l2.setTranslationZ(l2.getTranslationZ() + elevation);
                        }
                    }
                }
            }
        }
    }

    public abstract void p(l lVar, int i2, int i3);

    public void setElevation(float f2) {
        super.setElevation(f2);
        d();
    }

    public void setVisibility(int i2) {
        super.setVisibility(i2);
        d();
    }
}
