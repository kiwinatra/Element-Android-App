package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;

public class g extends View {

    /* renamed from: a  reason: collision with root package name */
    private boolean f1944a = true;

    public g(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public void draw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        setMeasuredDimension(0, 0);
    }

    public void setFilterRedundantCalls(boolean z2) {
        this.f1944a = z2;
    }

    public void setGuidelineBegin(int i2) {
        ConstraintLayout.b bVar = (ConstraintLayout.b) getLayoutParams();
        if (!this.f1944a || bVar.f1708a != i2) {
            bVar.f1708a = i2;
            setLayoutParams(bVar);
        }
    }

    public void setGuidelineEnd(int i2) {
        ConstraintLayout.b bVar = (ConstraintLayout.b) getLayoutParams();
        if (!this.f1944a || bVar.f1710b != i2) {
            bVar.f1710b = i2;
            setLayoutParams(bVar);
        }
    }

    public void setGuidelinePercent(float f2) {
        ConstraintLayout.b bVar = (ConstraintLayout.b) getLayoutParams();
        if (!this.f1944a || bVar.f1712c != f2) {
            bVar.f1712c = f2;
            setLayoutParams(bVar);
        }
    }

    public void setVisibility(int i2) {
    }
}
