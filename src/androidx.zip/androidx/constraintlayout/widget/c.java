package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Arrays;
import java.util.HashMap;
import p.e;
import p.i;

public abstract class c extends View {

    /* renamed from: a  reason: collision with root package name */
    protected int[] f1787a = new int[32];

    /* renamed from: b  reason: collision with root package name */
    protected int f1788b;

    /* renamed from: c  reason: collision with root package name */
    protected Context f1789c;

    /* renamed from: d  reason: collision with root package name */
    protected i f1790d;

    /* renamed from: e  reason: collision with root package name */
    protected boolean f1791e = false;

    /* renamed from: f  reason: collision with root package name */
    protected String f1792f;

    /* renamed from: g  reason: collision with root package name */
    protected String f1793g;

    /* renamed from: h  reason: collision with root package name */
    private View[] f1794h = null;

    /* renamed from: i  reason: collision with root package name */
    protected HashMap f1795i = new HashMap();

    public c(Context context) {
        super(context);
        this.f1789c = context;
        i((AttributeSet) null);
    }

    private void a(String str) {
        if (str != null && str.length() != 0 && this.f1789c != null) {
            String trim = str.trim();
            if (getParent() instanceof ConstraintLayout) {
                ConstraintLayout constraintLayout = (ConstraintLayout) getParent();
            }
            int h2 = h(trim);
            if (h2 != 0) {
                this.f1795i.put(Integer.valueOf(h2), trim);
                b(h2);
                return;
            }
            Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
        }
    }

    private void b(int i2) {
        if (i2 != getId()) {
            int i3 = this.f1788b + 1;
            int[] iArr = this.f1787a;
            if (i3 > iArr.length) {
                this.f1787a = Arrays.copyOf(iArr, iArr.length * 2);
            }
            int[] iArr2 = this.f1787a;
            int i4 = this.f1788b;
            iArr2[i4] = i2;
            this.f1788b = i4 + 1;
        }
    }

    private void c(String str) {
        if (str != null && str.length() != 0 && this.f1789c != null) {
            String trim = str.trim();
            ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
            if (constraintLayout == null) {
                Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
                return;
            }
            int childCount = constraintLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = constraintLayout.getChildAt(i2);
                ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
                if ((layoutParams instanceof ConstraintLayout.b) && trim.equals(((ConstraintLayout.b) layoutParams).f1713c0)) {
                    if (childAt.getId() == -1) {
                        Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                    } else {
                        b(childAt.getId());
                    }
                }
            }
        }
    }

    private int g(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String str2;
        if (str == null || constraintLayout == null || (resources = this.f1789c.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            if (childAt.getId() != -1) {
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    str2 = null;
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    private int h(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int i2 = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object g2 = constraintLayout.g(0, str);
            if (g2 instanceof Integer) {
                i2 = ((Integer) g2).intValue();
            }
        }
        if (i2 == 0 && constraintLayout != null) {
            i2 = g(constraintLayout, str);
        }
        if (i2 == 0) {
            try {
                i2 = h.class.getField(str).getInt((Object) null);
            } catch (Exception unused) {
            }
        }
        return i2 == 0 ? this.f1789c.getResources().getIdentifier(str, "id", this.f1789c.getPackageName()) : i2;
    }

    /* access modifiers changed from: protected */
    public void d() {
        ViewParent parent = getParent();
        if (parent != null && (parent instanceof ConstraintLayout)) {
            e((ConstraintLayout) parent);
        }
    }

    /* access modifiers changed from: protected */
    public void e(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i2 = 0; i2 < this.f1788b; i2++) {
            View l2 = constraintLayout.l(this.f1787a[i2]);
            if (l2 != null) {
                l2.setVisibility(visibility);
                if (elevation > 0.0f) {
                    l2.setTranslationZ(l2.getTranslationZ() + elevation);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void f(ConstraintLayout constraintLayout) {
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1787a, this.f1788b);
    }

    /* access modifiers changed from: protected */
    public void i(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.n1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.G1) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1792f = string;
                    setIds(string);
                } else if (index == i.H1) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1793g = string2;
                    setReferenceTags(string2);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public abstract void j(e eVar, boolean z2);

    public void k(ConstraintLayout constraintLayout) {
    }

    public void l(ConstraintLayout constraintLayout) {
    }

    public void m(ConstraintLayout constraintLayout) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0022, code lost:
        r1 = (java.lang.String) r5.f1795i.get(java.lang.Integer.valueOf(r1));
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void n(androidx.constraintlayout.widget.ConstraintLayout r6) {
        /*
            r5 = this;
            boolean r0 = r5.isInEditMode()
            if (r0 == 0) goto L_0x000b
            java.lang.String r0 = r5.f1792f
            r5.setIds(r0)
        L_0x000b:
            p.i r0 = r5.f1790d
            if (r0 != 0) goto L_0x0010
            return
        L_0x0010:
            r0.a()
            r0 = 0
        L_0x0014:
            int r1 = r5.f1788b
            if (r0 >= r1) goto L_0x0053
            int[] r1 = r5.f1787a
            r1 = r1[r0]
            android.view.View r2 = r6.l(r1)
            if (r2 != 0) goto L_0x0045
            java.util.HashMap r3 = r5.f1795i
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            java.lang.Object r1 = r3.get(r1)
            java.lang.String r1 = (java.lang.String) r1
            int r3 = r5.g(r6, r1)
            if (r3 == 0) goto L_0x0045
            int[] r2 = r5.f1787a
            r2[r0] = r3
            java.util.HashMap r2 = r5.f1795i
            java.lang.Integer r4 = java.lang.Integer.valueOf(r3)
            r2.put(r4, r1)
            android.view.View r2 = r6.l(r3)
        L_0x0045:
            if (r2 == 0) goto L_0x0050
            p.i r1 = r5.f1790d
            p.e r2 = r6.p(r2)
            r1.c(r2)
        L_0x0050:
            int r0 = r0 + 1
            goto L_0x0014
        L_0x0053:
            p.i r0 = r5.f1790d
            p.f r6 = r6.f1660c
            r0.b(r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.c.n(androidx.constraintlayout.widget.ConstraintLayout):void");
    }

    public void o() {
        if (this.f1790d != null) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams instanceof ConstraintLayout.b) {
                ((ConstraintLayout.b) layoutParams).f1751v0 = (e) this.f1790d;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1792f;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f1793g;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    public void onDraw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        if (this.f1791e) {
            super.onMeasure(i2, i3);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    /* access modifiers changed from: protected */
    public void setIds(String str) {
        this.f1792f = str;
        if (str != null) {
            int i2 = 0;
            this.f1788b = 0;
            while (true) {
                int indexOf = str.indexOf(44, i2);
                if (indexOf == -1) {
                    a(str.substring(i2));
                    return;
                } else {
                    a(str.substring(i2, indexOf));
                    i2 = indexOf + 1;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setReferenceTags(String str) {
        this.f1793g = str;
        if (str != null) {
            int i2 = 0;
            this.f1788b = 0;
            while (true) {
                int indexOf = str.indexOf(44, i2);
                if (indexOf == -1) {
                    c(str.substring(i2));
                    return;
                } else {
                    c(str.substring(i2, indexOf));
                    i2 = indexOf + 1;
                }
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1792f = null;
        this.f1788b = 0;
        for (int b2 : iArr) {
            b(b2);
        }
    }

    public void setTag(int i2, Object obj) {
        super.setTag(i2, obj);
        if (obj == null && this.f1792f == null) {
            b(i2);
        }
    }

    public c(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1789c = context;
        i(attributeSet);
    }
}
