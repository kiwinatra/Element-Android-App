package androidx.constraintlayout.widget;

import com.app.mywebapp.R;
import e.j;

public abstract class i {

    /* renamed from: A  reason: collision with root package name */
    public static final int f1945A = 6;

    /* renamed from: A0  reason: collision with root package name */
    public static final int f1946A0 = 82;
    public static final int A1 = 19;
    public static final int A2 = 81;
    public static final int A3 = 19;
    public static final int A4 = 97;
    public static final int A5 = 15;
    public static final int[] A6 = {16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int A7 = 10;

    /* renamed from: B  reason: collision with root package name */
    public static final int f1947B = 7;

    /* renamed from: B0  reason: collision with root package name */
    public static final int f1948B0 = 83;
    public static final int B1 = 22;
    public static final int B2 = 82;
    public static final int B3 = 20;
    public static final int B4 = 98;
    public static final int B5 = 16;
    public static final int[] B6 = {R.attr.mock_diagonalsColor, R.attr.mock_label, R.attr.mock_labelBackgroundColor, R.attr.mock_labelColor, R.attr.mock_showDiagonals, R.attr.mock_showLabel};
    public static final int B7 = 11;

    /* renamed from: C  reason: collision with root package name */
    public static final int f1949C = 8;

    /* renamed from: C0  reason: collision with root package name */
    public static final int f1950C0 = 84;
    public static final int C1 = 25;
    public static final int C2 = 83;
    public static final int C3 = 21;
    public static final int C4 = 100;
    public static final int C5 = 17;
    public static final int[] C6 = {R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.drawPath, R.attr.motionPathRotate, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.quantizeMotionInterpolator, R.attr.quantizeMotionPhase, R.attr.quantizeMotionSteps, R.attr.transitionEasing};
    public static final int[] C7 = {16842960, R.attr.autoTransition, R.attr.constraintSetEnd, R.attr.constraintSetStart, R.attr.duration, R.attr.layoutDuringTransition, R.attr.motionInterpolator, R.attr.pathMotionArc, R.attr.staggered, R.attr.transitionDisable, R.attr.transitionFlags};

    /* renamed from: D  reason: collision with root package name */
    public static final int f1951D = 13;
    public static final int D0 = 85;
    public static final int D1 = 26;
    public static final int D2 = 84;
    public static final int D3 = 22;
    public static final int D4 = 101;
    public static final int D5 = 18;
    public static final int D6 = 0;
    public static final int[] D7 = {R.attr.constraints, R.attr.region_heightLessThan, R.attr.region_heightMoreThan, R.attr.region_widthLessThan, R.attr.region_widthMoreThan};

    /* renamed from: E  reason: collision with root package name */
    public static final int f1952E = 14;
    public static final int E0 = 86;
    public static final int E1 = 27;
    public static final int E2 = 85;
    public static final int E3 = 23;
    public static final int E4 = 102;
    public static final int E5 = 19;
    public static final int E6 = 1;
    public static final int E7 = 0;

    /* renamed from: F  reason: collision with root package name */
    public static final int f1953F = 15;
    public static final int F0 = 87;
    public static final int F1 = 34;
    public static final int F2 = 86;
    public static final int F3 = 24;
    public static final int F4 = 103;
    public static final int F5 = 22;
    public static final int F6 = 2;
    public static final int F7 = 1;

    /* renamed from: G  reason: collision with root package name */
    public static final int f1954G = 16;
    public static final int G0 = 88;
    public static final int G1 = 35;
    public static final int G2 = 87;
    public static final int G3 = 25;
    public static final int G4 = 104;
    public static final int G5 = 23;
    public static final int G6 = 3;
    public static final int G7 = 2;

    /* renamed from: H  reason: collision with root package name */
    public static final int f1955H = 17;
    public static final int H0 = 89;
    public static final int H1 = 36;
    public static final int H2 = 88;
    public static final int H3 = 26;
    public static final int H4 = 105;
    public static final int H5 = 24;
    public static final int H6 = 4;
    public static final int H7 = 3;

    /* renamed from: I  reason: collision with root package name */
    public static final int f1956I = 18;
    public static final int I0 = 90;
    public static final int I1 = 37;
    public static final int I2 = 89;
    public static final int I3 = 28;
    public static final int I4 = 106;
    public static final int I5 = 25;
    public static final int I6 = 5;
    public static final int I7 = 4;

    /* renamed from: J  reason: collision with root package name */
    public static final int f1957J = 19;
    public static final int J0 = 91;
    public static final int J1 = 38;
    public static final int J2 = 90;
    public static final int J3 = 29;
    public static final int J4 = 107;
    public static final int J5 = 26;
    public static final int J6 = 6;
    public static final int[] J7 = {16842752, 16842970, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};

    /* renamed from: K  reason: collision with root package name */
    public static final int f1958K = 20;
    public static final int K0 = 92;
    public static final int K1 = 39;
    public static final int K2 = 91;
    public static final int K3 = 30;
    public static final int[] K4 = {16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraintRotate, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.deriveConstraintsFrom, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.polarRelativeTo, R.attr.quantizeMotionSteps, R.attr.transitionEasing, R.attr.transitionPathRotate};
    public static final int K5 = 27;
    public static final int K6 = 7;
    public static final int[] K7 = {16842964, R.attr.backgroundTint, R.attr.backgroundTintMode};

    /* renamed from: L  reason: collision with root package name */
    public static final int f1959L = 21;
    public static final int L0 = 93;
    public static final int L1 = 40;
    public static final int L2 = 92;
    public static final int L3 = 31;
    public static final int[] L4 = {R.attr.attributeName, R.attr.customBoolean, R.attr.customColorDrawableValue, R.attr.customColorValue, R.attr.customDimension, R.attr.customFloatValue, R.attr.customIntegerValue, R.attr.customPixelDimension, R.attr.customReference, R.attr.customStringValue, R.attr.methodName};
    public static final int L5 = 28;
    public static final int L6 = 8;
    public static final int[] L7 = {16842960, 16842994, 16842995};

    /* renamed from: M  reason: collision with root package name */
    public static final int f1960M = 22;
    public static final int M0 = 94;
    public static final int M1 = 41;
    public static final int M2 = 93;
    public static final int M3 = 32;
    public static final int M4 = 0;
    public static final int M5 = 29;
    public static final int M6 = 9;
    public static final int[] M7 = {16842960, R.attr.SharedValue, R.attr.SharedValueId, R.attr.clearsTag, R.attr.duration, R.attr.ifTagNotSet, R.attr.ifTagSet, R.attr.motionInterpolator, R.attr.motionTarget, R.attr.onStateTransition, R.attr.pathMotionArc, R.attr.setsTag, R.attr.transitionDisable, R.attr.upDuration, R.attr.viewTransitionMode};

    /* renamed from: N  reason: collision with root package name */
    public static final int f1961N = 23;
    public static final int N0 = 95;
    public static final int N1 = 42;
    public static final int N2 = 94;
    public static final int N3 = 33;
    public static final int N4 = 1;
    public static final int N5 = 30;
    public static final int[] N6 = {R.attr.motionEffect_alpha, R.attr.motionEffect_end, R.attr.motionEffect_move, R.attr.motionEffect_start, R.attr.motionEffect_strict, R.attr.motionEffect_translationX, R.attr.motionEffect_translationY, R.attr.motionEffect_viewTransition};
    public static final int[] N7 = {R.attr.constraintSet};

    /* renamed from: O  reason: collision with root package name */
    public static final int f1962O = 24;
    public static final int O0 = 96;
    public static final int O1 = 43;
    public static final int O2 = 95;
    public static final int O3 = 34;
    public static final int O4 = 2;
    public static final int O5 = 31;
    public static final int[] O6 = {R.attr.onHide, R.attr.onShow};

    /* renamed from: P  reason: collision with root package name */
    public static final int f1963P = 25;
    public static final int P0 = 97;
    public static final int P1 = 44;
    public static final int P2 = 96;
    public static final int P3 = 54;
    public static final int P4 = 3;
    public static final int P5 = 32;
    public static final int[] P6 = {16842901, 16842902, 16842903, 16842904, 16842927, 16843087, 16843108, 16843692, 16844085, R.attr.borderRound, R.attr.borderRoundPercent, R.attr.scaleFromTextSize, R.attr.textBackground, R.attr.textBackgroundPanX, R.attr.textBackgroundPanY, R.attr.textBackgroundRotate, R.attr.textBackgroundZoom, R.attr.textOutlineColor, R.attr.textOutlineThickness, R.attr.textPanX, R.attr.textPanY, R.attr.textureBlurFactor, R.attr.textureEffect, R.attr.textureHeight, R.attr.textureWidth};

    /* renamed from: Q  reason: collision with root package name */
    public static final int f1964Q = 26;
    public static final int Q0 = 98;
    public static final int Q1 = 45;
    public static final int Q2 = 97;
    public static final int Q3 = 55;
    public static final int Q4 = 4;
    public static final int Q5 = 33;
    public static final int[] Q6 = {R.attr.applyMotionScene, R.attr.currentState, R.attr.layoutDescription, R.attr.motionDebug, R.attr.motionProgress, R.attr.showPaths};

    /* renamed from: R  reason: collision with root package name */
    public static final int f1965R = 28;
    public static final int R0 = 99;
    public static final int R1 = 46;
    public static final int R2 = 98;
    public static final int R3 = 56;
    public static final int R4 = 5;
    public static final int R5 = 34;
    public static final int[] R6 = {R.attr.defaultDuration, R.attr.layoutDuringTransition};

    /* renamed from: S  reason: collision with root package name */
    public static final int f1966S = 29;
    public static final int S0 = 100;
    public static final int S1 = 47;
    public static final int S2 = 99;
    public static final int S3 = 57;
    public static final int S4 = 6;
    public static final int S5 = 38;
    public static final int[] S6 = {R.attr.telltales_tailColor, R.attr.telltales_tailScale, R.attr.telltales_velocityMode};

    /* renamed from: T  reason: collision with root package name */
    public static final int f1967T = 30;
    public static final int T0 = 101;
    public static final int T1 = 48;
    public static final int T2 = 100;
    public static final int T3 = 58;
    public static final int T4 = 7;
    public static final int T5 = 39;
    public static final int[] T6 = {R.attr.clickAction, R.attr.targetId};

    /* renamed from: U  reason: collision with root package name */
    public static final int f1968U = 31;
    public static final int U0 = 102;
    public static final int U1 = 49;
    public static final int U2 = 101;
    public static final int U3 = 59;
    public static final int U4 = 8;
    public static final int U5 = 40;
    public static final int[] U6 = {R.attr.autoCompleteMode, R.attr.dragDirection, R.attr.dragScale, R.attr.dragThreshold, R.attr.limitBoundsTo, R.attr.maxAcceleration, R.attr.maxVelocity, R.attr.moveWhenScrollAtTop, R.attr.nestedScrollFlags, R.attr.onTouchUp, R.attr.rotationCenterId, R.attr.springBoundary, R.attr.springDamping, R.attr.springMass, R.attr.springStiffness, R.attr.springStopThreshold, R.attr.touchAnchorId, R.attr.touchAnchorSide, R.attr.touchRegionId};

    /* renamed from: V  reason: collision with root package name */
    public static final int f1969V = 32;
    public static final int V0 = 104;
    public static final int V1 = 50;
    public static final int V2 = 102;
    public static final int V3 = 60;
    public static final int V4 = 9;
    public static final int V5 = 41;
    public static final int[] V6 = {16843126, 16843465, R.attr.overlapAnchor};

    /* renamed from: W  reason: collision with root package name */
    public static final int f1970W = 33;
    public static final int W0 = 105;
    public static final int W1 = 51;
    public static final int W2 = 103;
    public static final int W3 = 64;
    public static final int W4 = 10;
    public static final int W5 = 42;
    public static final int[] W6 = {R.attr.state_above_anchor};

    /* renamed from: X  reason: collision with root package name */
    public static final int f1971X = 35;
    public static final int X0 = 106;
    public static final int X1 = 52;
    public static final int X2 = 104;
    public static final int X3 = 65;
    public static final int[] X4 = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};
    public static final int X5 = 43;
    public static final int[] X6 = {16842972, 16843551, R.attr.layout_constraintTag, R.attr.motionProgress, R.attr.visibilityMode};

    /* renamed from: Y  reason: collision with root package name */
    public static final int f1972Y = 54;
    public static final int Y0 = 107;
    public static final int Y1 = 53;
    public static final int Y2 = 105;
    public static final int Y3 = 66;
    public static final int[] Y4 = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};
    public static final int Y5 = 44;
    public static final int Y6 = 0;

    /* renamed from: Z  reason: collision with root package name */
    public static final int f1973Z = 55;
    public static final int Z0 = 108;
    public static final int Z1 = 54;
    public static final int Z2 = 106;
    public static final int Z3 = 67;
    public static final int[] Z4 = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
    public static final int Z5 = 45;
    public static final int Z6 = 1;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1974a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};

    /* renamed from: a0  reason: collision with root package name */
    public static final int f1975a0 = 56;
    public static final int a1 = 109;
    public static final int a2 = 55;
    public static final int a3 = 107;
    public static final int a4 = 68;
    public static final int[] a5 = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
    public static final int a6 = 46;
    public static final int a7 = 3;

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f1976b = {16842931};

    /* renamed from: b0  reason: collision with root package name */
    public static final int f1977b0 = 57;
    public static final int b1 = 111;
    public static final int b2 = 56;
    public static final int b3 = 108;
    public static final int b4 = 69;
    public static final int[] b5 = {16843173, 16844052};
    public static final int b6 = 47;
    public static final int b7 = 4;

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f1978c = {16843071};

    /* renamed from: c0  reason: collision with root package name */
    public static final int f1979c0 = 58;
    public static final int c1 = 112;
    public static final int c2 = 57;
    public static final int c3 = 109;
    public static final int c4 = 70;
    public static final int[] c5 = {R.attr.altSrc, R.attr.blendSrc, R.attr.brightness, R.attr.contrast, R.attr.crossfade, R.attr.imagePanX, R.attr.imagePanY, R.attr.imageRotate, R.attr.imageZoom, R.attr.overlay, R.attr.round, R.attr.roundPercent, R.attr.saturation, R.attr.warmth};
    public static final int c6 = 48;
    public static final int[] c7 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1980d = new int[0];

    /* renamed from: d0  reason: collision with root package name */
    public static final int f1981d0 = 59;
    public static final int d1 = 113;
    public static final int d2 = 58;
    public static final int d3 = 110;
    public static final int d4 = 71;
    public static final int[] d5 = {16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transformPivotTarget, R.attr.transitionEasing, R.attr.transitionPathRotate};
    public static final int d6 = 49;
    public static final int[] d7 = {16842804, 16842970, 16843039, 16843087, 16843088, 16843296, 16843364, R.attr.animateMenuItems, R.attr.animateNavigationIcon, R.attr.autoShowKeyboard, R.attr.backHandlingEnabled, R.attr.backgroundTint, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.headerLayout, R.attr.hideNavigationIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.searchPrefixText, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.useDrawerArrowDrawable, R.attr.voiceIcon};

    /* renamed from: e  reason: collision with root package name */
    public static final int[] f1982e = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};

    /* renamed from: e0  reason: collision with root package name */
    public static final int f1983e0 = 60;
    public static final int e1 = 114;
    public static final int e2 = 59;
    public static final int e3 = 111;
    public static final int e4 = 72;
    public static final int[] e5 = {16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveOffset, R.attr.wavePeriod, R.attr.wavePhase, R.attr.waveShape, R.attr.waveVariesBy};
    public static final int e6 = 50;
    public static final int[] e7 = {16842930, 16843126, 16843131, 16843362, R.attr.popupTheme};

    /* renamed from: f  reason: collision with root package name */
    public static final int[] f1984f = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};

    /* renamed from: f0  reason: collision with root package name */
    public static final int f1985f0 = 61;
    public static final int f1 = 116;
    public static final int f2 = 60;
    public static final int f3 = 112;
    public static final int f4 = 73;
    public static final int[] f5 = new int[0];
    public static final int f6 = 51;
    public static final int[] f7 = {16842960, R.attr.constraints};

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f1986g = {16842994, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};

    /* renamed from: g0  reason: collision with root package name */
    public static final int f1987g0 = 62;
    public static final int g1 = 117;
    public static final int g2 = 61;
    public static final int g3 = 113;
    public static final int g4 = 74;
    public static final int[] g5 = new int[0];
    public static final int g6 = 52;
    public static final int g7 = 0;

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f1988h = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};

    /* renamed from: h0  reason: collision with root package name */
    public static final int f1989h0 = 63;
    public static final int h1 = 118;
    public static final int h2 = 62;
    public static final int h3 = 114;
    public static final int h4 = 75;
    public static final int[] h5 = new int[0];
    public static final int h6 = 53;
    public static final int h7 = 1;

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f1990i = {16842960, 16843161};

    /* renamed from: i0  reason: collision with root package name */
    public static final int f1991i0 = 64;
    public static final int i1 = 119;
    public static final int i2 = 63;
    public static final int[] i3 = {R.attr.reactiveGuide_animateChange, R.attr.reactiveGuide_applyToAllConstraintSets, R.attr.reactiveGuide_applyToConstraintSet, R.attr.reactiveGuide_valueId};
    public static final int i4 = 76;
    public static final int[] i5 = {R.attr.curveFit, R.attr.drawPath, R.attr.framePosition, R.attr.keyPositionType, R.attr.motionTarget, R.attr.pathMotionArc, R.attr.percentHeight, R.attr.percentWidth, R.attr.percentX, R.attr.percentY, R.attr.sizePercent, R.attr.transitionEasing};
    public static final int i6 = 54;
    public static final int[] i7 = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};

    /* renamed from: j  reason: collision with root package name */
    public static final int[] f1992j = {16843161, 16843849, 16843850, 16843851};

    /* renamed from: j0  reason: collision with root package name */
    public static final int f1993j0 = 65;
    public static final int j1 = 120;
    public static final int j2 = 64;
    public static final int[] j3 = {R.attr.content, R.attr.placeholder_emptyVisibility};
    public static final int j4 = 77;
    public static final int[] j5 = {16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveDecay, R.attr.waveOffset, R.attr.wavePeriod, R.attr.wavePhase, R.attr.waveShape};
    public static final int j6 = 55;
    public static final int[] j7 = {16843161};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f1994k = {16843033, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};

    /* renamed from: k0  reason: collision with root package name */
    public static final int f1995k0 = 66;
    public static final int k1 = 121;
    public static final int k2 = 65;
    public static final int[] k3 = {16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, R.attr.animateCircleAngleTo, R.attr.animateRelativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintRight_creator, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.motionProgress, R.attr.motionStagger, R.attr.motionTarget, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.polarRelativeTo, R.attr.quantizeMotionInterpolator, R.attr.quantizeMotionPhase, R.attr.quantizeMotionSteps, R.attr.transformPivotTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.visibilityMode};
    public static final int k4 = 78;
    public static final int[] k5 = {R.attr.framePosition, R.attr.motionTarget, R.attr.motion_postLayoutCollision, R.attr.motion_triggerOnCollision, R.attr.onCross, R.attr.onNegativeCross, R.attr.onPositiveCross, R.attr.triggerId, R.attr.triggerReceiver, R.attr.triggerSlack, R.attr.viewTransitionOnCross, R.attr.viewTransitionOnNegativeCross, R.attr.viewTransitionOnPositiveCross};
    public static final int k6 = 56;
    public static final int[] k7 = {R.attr.defaultState};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f1996l = {16843074, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};

    /* renamed from: l0  reason: collision with root package name */
    public static final int f1997l0 = 67;
    public static final int l1 = 122;
    public static final int l2 = 66;
    public static final int l3 = 0;
    public static final int l4 = 79;
    public static final int[] l5 = {16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.guidelineUseRtl, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_wrapBehaviorInParent, R.attr.maxHeight, R.attr.maxWidth, R.attr.minHeight, R.attr.minWidth};
    public static final int l6 = 60;
    public static final int[] l7 = {16843044, 16843045, 16843074, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f1998m = {16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667};

    /* renamed from: m0  reason: collision with root package name */
    public static final int f1999m0 = 68;
    public static final int m1 = 123;
    public static final int m2 = 67;
    public static final int m3 = 1;
    public static final int m4 = 80;
    public static final int m5 = 0;
    public static final int m6 = 61;
    public static final int[] m7 = {16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 16844165, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: n  reason: collision with root package name */
    public static final int[] f2000n = {16842804, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.emojiCompatEnabled, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: n0  reason: collision with root package name */
    public static final int f2001n0 = 69;
    public static final int[] n1 = {16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16842996, 16842997, 16842998, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843699, 16843700, 16843701, 16843702, 16843840, 16844091, 16844092, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.circularflow_angles, R.attr.circularflow_defaultAngle, R.attr.circularflow_defaultRadius, R.attr.circularflow_radiusInDP, R.attr.circularflow_viewCenter, R.attr.constraintSet, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.guidelineUseRtl, R.attr.layoutDescription, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBaseline_toBottomOf, R.attr.layout_constraintBaseline_toTopOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBaseline, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_marginBaseline, R.attr.layout_optimizationLevel, R.attr.layout_wrapBehaviorInParent};
    public static final int n2 = 68;
    public static final int n3 = 2;
    public static final int n4 = 81;
    public static final int n5 = 1;
    public static final int n6 = 62;
    public static final int[] n7 = {16842901, 16842902, 16842903, 16843087, 16843105, 16843106, 16843107, 16843108, 16843692, R.attr.borderRound, R.attr.borderRoundPercent, R.attr.textFillColor, R.attr.textOutlineColor, R.attr.textOutlineThickness};

    /* renamed from: o  reason: collision with root package name */
    public static final int[] f2002o = {16842839, 16842926, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseContentDescription, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeTheme, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};

    /* renamed from: o0  reason: collision with root package name */
    public static final int f2003o0 = 70;
    public static final int o1 = 0;
    public static final int o2 = 69;
    public static final int o3 = 3;
    public static final int o4 = 82;
    public static final int o5 = 2;
    public static final int o6 = 64;
    public static final int[] o7 = {16842927, 16843072, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};

    /* renamed from: p  reason: collision with root package name */
    public static final int[] f2004p = {R.attr.allowStacking};

    /* renamed from: p0  reason: collision with root package name */
    public static final int f2005p0 = 71;
    public static final int p1 = 1;
    public static final int p2 = 70;
    public static final int p3 = 4;
    public static final int p4 = 83;
    public static final int p5 = 3;
    public static final int p6 = 65;
    public static final int[] p7 = {16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.transformPivotTarget};

    /* renamed from: q  reason: collision with root package name */
    public static final int[] f2006q = {R.attr.carousel_alignment, R.attr.carousel_backwardTransition, R.attr.carousel_emptyViewsBehavior, R.attr.carousel_firstView, R.attr.carousel_forwardTransition, R.attr.carousel_infinite, R.attr.carousel_nextState, R.attr.carousel_previousState, R.attr.carousel_touchUpMode, R.attr.carousel_touchUp_dampeningFactor, R.attr.carousel_touchUp_velocityThreshold};

    /* renamed from: q0  reason: collision with root package name */
    public static final int f2007q0 = 72;
    public static final int q1 = 2;
    public static final int q2 = 71;
    public static final int q3 = 5;
    public static final int q4 = 85;
    public static final int q5 = 4;
    public static final int q6 = 66;
    public static final int q7 = 0;

    /* renamed from: r  reason: collision with root package name */
    public static final int[] f2008r = {16843173, 16843551, 16844359, R.attr.alpha, R.attr.lStar};

    /* renamed from: r0  reason: collision with root package name */
    public static final int f2009r0 = 73;
    public static final int r1 = 3;
    public static final int r2 = 72;
    public static final int r3 = 6;
    public static final int r4 = 87;
    public static final int r5 = 5;
    public static final int r6 = 67;
    public static final int r7 = 1;

    /* renamed from: s  reason: collision with root package name */
    public static final int[] f2010s = {16843015, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};

    /* renamed from: s0  reason: collision with root package name */
    public static final int f2011s0 = 74;
    public static final int s1 = 4;
    public static final int s2 = 73;
    public static final int s3 = 7;
    public static final int s4 = 88;
    public static final int s5 = 6;
    public static final int s6 = 68;
    public static final int s7 = 2;

    /* renamed from: t  reason: collision with root package name */
    public static final int[] f2012t;

    /* renamed from: t0  reason: collision with root package name */
    public static final int f2013t0 = 75;
    public static final int t1 = 5;
    public static final int t2 = 74;
    public static final int t3 = 8;
    public static final int t4 = 89;
    public static final int t5 = 7;
    public static final int t6 = 69;
    public static final int t7 = 3;

    /* renamed from: u  reason: collision with root package name */
    public static final int f2014u = 0;

    /* renamed from: u0  reason: collision with root package name */
    public static final int f2015u0 = 76;
    public static final int u1 = 6;
    public static final int u2 = 75;
    public static final int u3 = 13;
    public static final int u4 = 90;
    public static final int u5 = 8;
    public static final int u6 = 71;
    public static final int u7 = 4;

    /* renamed from: v  reason: collision with root package name */
    public static final int f2016v = 1;

    /* renamed from: v0  reason: collision with root package name */
    public static final int f2017v0 = 77;
    public static final int v1 = 14;
    public static final int v2 = 76;
    public static final int v3 = 14;
    public static final int v4 = 91;
    public static final int v5 = 9;
    public static final int[] v6 = {16842927, 16842948, 16843046, 16843047, 16843048, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
    public static final int v7 = 5;

    /* renamed from: w  reason: collision with root package name */
    public static final int f2018w = 2;

    /* renamed from: w0  reason: collision with root package name */
    public static final int f2019w0 = 78;
    public static final int w1 = 15;
    public static final int w2 = 77;
    public static final int w3 = 15;
    public static final int w4 = 92;
    public static final int w5 = 10;
    public static final int[] w6 = {16842931, 16842996, 16842997, 16843137};
    public static final int w7 = 6;

    /* renamed from: x  reason: collision with root package name */
    public static final int f2020x = 3;

    /* renamed from: x0  reason: collision with root package name */
    public static final int f2021x0 = 79;
    public static final int x1 = 16;
    public static final int x2 = 78;
    public static final int x3 = 16;
    public static final int x4 = 94;
    public static final int x5 = 11;
    public static final int[] x6 = {16843436, 16843437};
    public static final int x7 = 7;

    /* renamed from: y  reason: collision with root package name */
    public static final int f2022y = 4;

    /* renamed from: y0  reason: collision with root package name */
    public static final int f2023y0 = 80;
    public static final int y1 = 17;
    public static final int y2 = 79;
    public static final int y3 = 17;
    public static final int y4 = 95;
    public static final int y5 = 12;
    public static final int[] y6 = {16842766, 16842960, 16843156, 16843230, 16843231, 16843232};
    public static final int y7 = 8;

    /* renamed from: z  reason: collision with root package name */
    public static final int f2024z = 5;

    /* renamed from: z0  reason: collision with root package name */
    public static final int f2025z0 = 81;
    public static final int z1 = 18;
    public static final int z2 = 80;
    public static final int z3 = 18;
    public static final int z4 = 96;
    public static final int z5 = 13;
    public static final int[] z6 = {16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int z7 = 9;

    static {
        int[] iArr = new int[j.K0];
        // fill-array-data instruction
        iArr[0] = 16842948;
        iArr[1] = 16842960;
        iArr[2] = 16842972;
        iArr[3] = 16842996;
        iArr[4] = 16842997;
        iArr[5] = 16842999;
        iArr[6] = 16843000;
        iArr[7] = 16843001;
        iArr[8] = 16843002;
        iArr[9] = 16843039;
        iArr[10] = 16843040;
        iArr[11] = 16843071;
        iArr[12] = 16843072;
        iArr[13] = 16843551;
        iArr[14] = 16843552;
        iArr[15] = 16843553;
        iArr[16] = 16843554;
        iArr[17] = 16843555;
        iArr[18] = 16843556;
        iArr[19] = 16843557;
        iArr[20] = 16843558;
        iArr[21] = 16843559;
        iArr[22] = 16843560;
        iArr[23] = 16843701;
        iArr[24] = 16843702;
        iArr[25] = 16843770;
        iArr[26] = 16843840;
        iArr[27] = 2130903089;
        iArr[28] = 2130903092;
        iArr[29] = 2130903140;
        iArr[30] = 2130903141;
        iArr[31] = 2130903142;
        iArr[32] = 2130903214;
        iArr[33] = 2130903349;
        iArr[34] = 2130903350;
        iArr[35] = 2130903431;
        iArr[36] = 2130903528;
        iArr[37] = 2130903529;
        iArr[38] = 2130903530;
        iArr[39] = 2130903531;
        iArr[40] = 2130903532;
        iArr[41] = 2130903533;
        iArr[42] = 2130903534;
        iArr[43] = 2130903535;
        iArr[44] = 2130903536;
        iArr[45] = 2130903537;
        iArr[46] = 2130903538;
        iArr[47] = 2130903539;
        iArr[48] = 2130903540;
        iArr[49] = 2130903542;
        iArr[50] = 2130903543;
        iArr[51] = 2130903544;
        iArr[52] = 2130903545;
        iArr[53] = 2130903546;
        iArr[54] = 2130903566;
        iArr[55] = 2130903668;
        iArr[56] = 2130903669;
        iArr[57] = 2130903670;
        iArr[58] = 2130903671;
        iArr[59] = 2130903672;
        iArr[60] = 2130903673;
        iArr[61] = 2130903674;
        iArr[62] = 2130903675;
        iArr[63] = 2130903676;
        iArr[64] = 2130903677;
        iArr[65] = 2130903678;
        iArr[66] = 2130903679;
        iArr[67] = 2130903680;
        iArr[68] = 2130903681;
        iArr[69] = 2130903682;
        iArr[70] = 2130903683;
        iArr[71] = 2130903684;
        iArr[72] = 2130903685;
        iArr[73] = 2130903686;
        iArr[74] = 2130903687;
        iArr[75] = 2130903688;
        iArr[76] = 2130903689;
        iArr[77] = 2130903690;
        iArr[78] = 2130903691;
        iArr[79] = 2130903692;
        iArr[80] = 2130903693;
        iArr[81] = 2130903694;
        iArr[82] = 2130903695;
        iArr[83] = 2130903696;
        iArr[84] = 2130903697;
        iArr[85] = 2130903698;
        iArr[86] = 2130903699;
        iArr[87] = 2130903700;
        iArr[88] = 2130903701;
        iArr[89] = 2130903702;
        iArr[90] = 2130903703;
        iArr[91] = 2130903704;
        iArr[92] = 2130903705;
        iArr[93] = 2130903706;
        iArr[94] = 2130903707;
        iArr[95] = 2130903708;
        iArr[96] = 2130903709;
        iArr[97] = 2130903710;
        iArr[98] = 2130903711;
        iArr[99] = 2130903712;
        iArr[100] = 2130903713;
        iArr[101] = 2130903715;
        iArr[102] = 2130903716;
        iArr[103] = 2130903717;
        iArr[104] = 2130903718;
        iArr[105] = 2130903719;
        iArr[106] = 2130903720;
        iArr[107] = 2130903721;
        iArr[108] = 2130903722;
        iArr[109] = 2130903723;
        iArr[110] = 2130903726;
        iArr[111] = 2130903731;
        iArr[112] = 2130903875;
        iArr[113] = 2130903876;
        iArr[114] = 2130903920;
        iArr[115] = 2130903927;
        iArr[116] = 2130903932;
        iArr[117] = 2130903944;
        iArr[118] = 2130903945;
        iArr[119] = 2130903946;
        iArr[120] = 2130904244;
        iArr[121] = 2130904246;
        iArr[122] = 2130904248;
        iArr[123] = 2130904266;
        f2012t = iArr;
    }
}
