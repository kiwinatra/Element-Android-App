package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import n.C0262a;
import org.xmlpull.v1.XmlPullParserException;
import r.C0280a;

public class e {
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public static final int[] f1811f = {0, 4, 8};

    /* renamed from: g  reason: collision with root package name */
    private static SparseIntArray f1812g = new SparseIntArray();

    /* renamed from: h  reason: collision with root package name */
    private static SparseIntArray f1813h = new SparseIntArray();

    /* renamed from: a  reason: collision with root package name */
    public String f1814a = "";

    /* renamed from: b  reason: collision with root package name */
    public int f1815b = 0;

    /* renamed from: c  reason: collision with root package name */
    private HashMap f1816c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    private boolean f1817d = true;

    /* renamed from: e  reason: collision with root package name */
    private HashMap f1818e = new HashMap();

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        int f1819a;

        /* renamed from: b  reason: collision with root package name */
        String f1820b;

        /* renamed from: c  reason: collision with root package name */
        public final d f1821c = new d();

        /* renamed from: d  reason: collision with root package name */
        public final c f1822d = new c();

        /* renamed from: e  reason: collision with root package name */
        public final b f1823e = new b();

        /* renamed from: f  reason: collision with root package name */
        public final C0023e f1824f = new C0023e();

        /* renamed from: g  reason: collision with root package name */
        public HashMap f1825g = new HashMap();

        /* renamed from: h  reason: collision with root package name */
        C0022a f1826h;

        /* renamed from: androidx.constraintlayout.widget.e$a$a  reason: collision with other inner class name */
        static class C0022a {

            /* renamed from: a  reason: collision with root package name */
            int[] f1827a = new int[10];

            /* renamed from: b  reason: collision with root package name */
            int[] f1828b = new int[10];

            /* renamed from: c  reason: collision with root package name */
            int f1829c = 0;

            /* renamed from: d  reason: collision with root package name */
            int[] f1830d = new int[10];

            /* renamed from: e  reason: collision with root package name */
            float[] f1831e = new float[10];

            /* renamed from: f  reason: collision with root package name */
            int f1832f = 0;

            /* renamed from: g  reason: collision with root package name */
            int[] f1833g = new int[5];

            /* renamed from: h  reason: collision with root package name */
            String[] f1834h = new String[5];

            /* renamed from: i  reason: collision with root package name */
            int f1835i = 0;

            /* renamed from: j  reason: collision with root package name */
            int[] f1836j = new int[4];

            /* renamed from: k  reason: collision with root package name */
            boolean[] f1837k = new boolean[4];

            /* renamed from: l  reason: collision with root package name */
            int f1838l = 0;

            C0022a() {
            }

            /* access modifiers changed from: package-private */
            public void a(int i2, float f2) {
                int i3 = this.f1832f;
                int[] iArr = this.f1830d;
                if (i3 >= iArr.length) {
                    this.f1830d = Arrays.copyOf(iArr, iArr.length * 2);
                    float[] fArr = this.f1831e;
                    this.f1831e = Arrays.copyOf(fArr, fArr.length * 2);
                }
                int[] iArr2 = this.f1830d;
                int i4 = this.f1832f;
                iArr2[i4] = i2;
                float[] fArr2 = this.f1831e;
                this.f1832f = i4 + 1;
                fArr2[i4] = f2;
            }

            /* access modifiers changed from: package-private */
            public void b(int i2, int i3) {
                int i4 = this.f1829c;
                int[] iArr = this.f1827a;
                if (i4 >= iArr.length) {
                    this.f1827a = Arrays.copyOf(iArr, iArr.length * 2);
                    int[] iArr2 = this.f1828b;
                    this.f1828b = Arrays.copyOf(iArr2, iArr2.length * 2);
                }
                int[] iArr3 = this.f1827a;
                int i5 = this.f1829c;
                iArr3[i5] = i2;
                int[] iArr4 = this.f1828b;
                this.f1829c = i5 + 1;
                iArr4[i5] = i3;
            }

            /* access modifiers changed from: package-private */
            public void c(int i2, String str) {
                int i3 = this.f1835i;
                int[] iArr = this.f1833g;
                if (i3 >= iArr.length) {
                    this.f1833g = Arrays.copyOf(iArr, iArr.length * 2);
                    String[] strArr = this.f1834h;
                    this.f1834h = (String[]) Arrays.copyOf(strArr, strArr.length * 2);
                }
                int[] iArr2 = this.f1833g;
                int i4 = this.f1835i;
                iArr2[i4] = i2;
                String[] strArr2 = this.f1834h;
                this.f1835i = i4 + 1;
                strArr2[i4] = str;
            }

            /* access modifiers changed from: package-private */
            public void d(int i2, boolean z2) {
                int i3 = this.f1838l;
                int[] iArr = this.f1836j;
                if (i3 >= iArr.length) {
                    this.f1836j = Arrays.copyOf(iArr, iArr.length * 2);
                    boolean[] zArr = this.f1837k;
                    this.f1837k = Arrays.copyOf(zArr, zArr.length * 2);
                }
                int[] iArr2 = this.f1836j;
                int i4 = this.f1838l;
                iArr2[i4] = i2;
                boolean[] zArr2 = this.f1837k;
                this.f1838l = i4 + 1;
                zArr2[i4] = z2;
            }
        }

        /* access modifiers changed from: private */
        public void d(int i2, ConstraintLayout.b bVar) {
            this.f1819a = i2;
            b bVar2 = this.f1823e;
            bVar2.f1884j = bVar.f1716e;
            bVar2.f1886k = bVar.f1718f;
            bVar2.f1888l = bVar.f1720g;
            bVar2.f1890m = bVar.f1722h;
            bVar2.f1892n = bVar.f1724i;
            bVar2.f1894o = bVar.f1726j;
            bVar2.f1896p = bVar.f1728k;
            bVar2.f1898q = bVar.f1730l;
            bVar2.f1900r = bVar.f1732m;
            bVar2.f1901s = bVar.f1734n;
            bVar2.f1902t = bVar.f1736o;
            bVar2.f1903u = bVar.f1744s;
            bVar2.f1904v = bVar.f1746t;
            bVar2.f1905w = bVar.f1748u;
            bVar2.f1906x = bVar.f1750v;
            bVar2.f1907y = bVar.f1688G;
            bVar2.f1908z = bVar.f1689H;
            bVar2.f1840A = bVar.f1690I;
            bVar2.f1841B = bVar.f1738p;
            bVar2.f1842C = bVar.f1740q;
            bVar2.f1843D = bVar.f1742r;
            bVar2.f1844E = bVar.f1705X;
            bVar2.f1845F = bVar.f1706Y;
            bVar2.f1846G = bVar.f1707Z;
            bVar2.f1880h = bVar.f1712c;
            bVar2.f1876f = bVar.f1708a;
            bVar2.f1878g = bVar.f1710b;
            bVar2.f1872d = bVar.width;
            bVar2.f1874e = bVar.height;
            bVar2.f1847H = bVar.leftMargin;
            bVar2.f1848I = bVar.rightMargin;
            bVar2.f1849J = bVar.topMargin;
            bVar2.f1850K = bVar.bottomMargin;
            bVar2.f1853N = bVar.f1685D;
            bVar2.f1861V = bVar.f1694M;
            bVar2.f1862W = bVar.f1693L;
            bVar2.f1864Y = bVar.f1696O;
            bVar2.f1863X = bVar.f1695N;
            bVar2.f1893n0 = bVar.f1709a0;
            bVar2.f1895o0 = bVar.f1711b0;
            bVar2.f1865Z = bVar.f1697P;
            bVar2.f1867a0 = bVar.f1698Q;
            bVar2.f1869b0 = bVar.f1701T;
            bVar2.f1871c0 = bVar.f1702U;
            bVar2.f1873d0 = bVar.f1699R;
            bVar2.f1875e0 = bVar.f1700S;
            bVar2.f1877f0 = bVar.f1703V;
            bVar2.f1879g0 = bVar.f1704W;
            bVar2.f1891m0 = bVar.f1713c0;
            bVar2.f1855P = bVar.f1754x;
            bVar2.f1857R = bVar.f1756z;
            bVar2.f1854O = bVar.f1752w;
            bVar2.f1856Q = bVar.f1755y;
            bVar2.f1859T = bVar.f1682A;
            bVar2.f1858S = bVar.f1683B;
            bVar2.f1860U = bVar.f1684C;
            bVar2.f1899q0 = bVar.f1715d0;
            bVar2.f1851L = bVar.getMarginEnd();
            this.f1823e.f1852M = bVar.getMarginStart();
        }

        public void b(ConstraintLayout.b bVar) {
            b bVar2 = this.f1823e;
            bVar.f1716e = bVar2.f1884j;
            bVar.f1718f = bVar2.f1886k;
            bVar.f1720g = bVar2.f1888l;
            bVar.f1722h = bVar2.f1890m;
            bVar.f1724i = bVar2.f1892n;
            bVar.f1726j = bVar2.f1894o;
            bVar.f1728k = bVar2.f1896p;
            bVar.f1730l = bVar2.f1898q;
            bVar.f1732m = bVar2.f1900r;
            bVar.f1734n = bVar2.f1901s;
            bVar.f1736o = bVar2.f1902t;
            bVar.f1744s = bVar2.f1903u;
            bVar.f1746t = bVar2.f1904v;
            bVar.f1748u = bVar2.f1905w;
            bVar.f1750v = bVar2.f1906x;
            bVar.leftMargin = bVar2.f1847H;
            bVar.rightMargin = bVar2.f1848I;
            bVar.topMargin = bVar2.f1849J;
            bVar.bottomMargin = bVar2.f1850K;
            bVar.f1682A = bVar2.f1859T;
            bVar.f1683B = bVar2.f1858S;
            bVar.f1754x = bVar2.f1855P;
            bVar.f1756z = bVar2.f1857R;
            bVar.f1688G = bVar2.f1907y;
            bVar.f1689H = bVar2.f1908z;
            bVar.f1738p = bVar2.f1841B;
            bVar.f1740q = bVar2.f1842C;
            bVar.f1742r = bVar2.f1843D;
            bVar.f1690I = bVar2.f1840A;
            bVar.f1705X = bVar2.f1844E;
            bVar.f1706Y = bVar2.f1845F;
            bVar.f1694M = bVar2.f1861V;
            bVar.f1693L = bVar2.f1862W;
            bVar.f1696O = bVar2.f1864Y;
            bVar.f1695N = bVar2.f1863X;
            bVar.f1709a0 = bVar2.f1893n0;
            bVar.f1711b0 = bVar2.f1895o0;
            bVar.f1697P = bVar2.f1865Z;
            bVar.f1698Q = bVar2.f1867a0;
            bVar.f1701T = bVar2.f1869b0;
            bVar.f1702U = bVar2.f1871c0;
            bVar.f1699R = bVar2.f1873d0;
            bVar.f1700S = bVar2.f1875e0;
            bVar.f1703V = bVar2.f1877f0;
            bVar.f1704W = bVar2.f1879g0;
            bVar.f1707Z = bVar2.f1846G;
            bVar.f1712c = bVar2.f1880h;
            bVar.f1708a = bVar2.f1876f;
            bVar.f1710b = bVar2.f1878g;
            bVar.width = bVar2.f1872d;
            bVar.height = bVar2.f1874e;
            String str = bVar2.f1891m0;
            if (str != null) {
                bVar.f1713c0 = str;
            }
            bVar.f1715d0 = bVar2.f1899q0;
            bVar.setMarginStart(bVar2.f1852M);
            bVar.setMarginEnd(this.f1823e.f1851L);
            bVar.a();
        }

        /* renamed from: c */
        public a clone() {
            a aVar = new a();
            aVar.f1823e.a(this.f1823e);
            aVar.f1822d.a(this.f1822d);
            aVar.f1821c.a(this.f1821c);
            aVar.f1824f.a(this.f1824f);
            aVar.f1819a = this.f1819a;
            aVar.f1826h = this.f1826h;
            return aVar;
        }
    }

    public static class b {

        /* renamed from: r0  reason: collision with root package name */
        private static SparseIntArray f1839r0;

        /* renamed from: A  reason: collision with root package name */
        public String f1840A = null;

        /* renamed from: B  reason: collision with root package name */
        public int f1841B = -1;

        /* renamed from: C  reason: collision with root package name */
        public int f1842C = 0;

        /* renamed from: D  reason: collision with root package name */
        public float f1843D = 0.0f;

        /* renamed from: E  reason: collision with root package name */
        public int f1844E = -1;

        /* renamed from: F  reason: collision with root package name */
        public int f1845F = -1;

        /* renamed from: G  reason: collision with root package name */
        public int f1846G = -1;

        /* renamed from: H  reason: collision with root package name */
        public int f1847H = 0;

        /* renamed from: I  reason: collision with root package name */
        public int f1848I = 0;

        /* renamed from: J  reason: collision with root package name */
        public int f1849J = 0;

        /* renamed from: K  reason: collision with root package name */
        public int f1850K = 0;

        /* renamed from: L  reason: collision with root package name */
        public int f1851L = 0;

        /* renamed from: M  reason: collision with root package name */
        public int f1852M = 0;

        /* renamed from: N  reason: collision with root package name */
        public int f1853N = 0;

        /* renamed from: O  reason: collision with root package name */
        public int f1854O = Integer.MIN_VALUE;

        /* renamed from: P  reason: collision with root package name */
        public int f1855P = Integer.MIN_VALUE;

        /* renamed from: Q  reason: collision with root package name */
        public int f1856Q = Integer.MIN_VALUE;

        /* renamed from: R  reason: collision with root package name */
        public int f1857R = Integer.MIN_VALUE;

        /* renamed from: S  reason: collision with root package name */
        public int f1858S = Integer.MIN_VALUE;

        /* renamed from: T  reason: collision with root package name */
        public int f1859T = Integer.MIN_VALUE;

        /* renamed from: U  reason: collision with root package name */
        public int f1860U = Integer.MIN_VALUE;

        /* renamed from: V  reason: collision with root package name */
        public float f1861V = -1.0f;

        /* renamed from: W  reason: collision with root package name */
        public float f1862W = -1.0f;

        /* renamed from: X  reason: collision with root package name */
        public int f1863X = 0;

        /* renamed from: Y  reason: collision with root package name */
        public int f1864Y = 0;

        /* renamed from: Z  reason: collision with root package name */
        public int f1865Z = 0;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1866a = false;

        /* renamed from: a0  reason: collision with root package name */
        public int f1867a0 = 0;

        /* renamed from: b  reason: collision with root package name */
        public boolean f1868b = false;

        /* renamed from: b0  reason: collision with root package name */
        public int f1869b0 = 0;

        /* renamed from: c  reason: collision with root package name */
        public boolean f1870c = false;

        /* renamed from: c0  reason: collision with root package name */
        public int f1871c0 = 0;

        /* renamed from: d  reason: collision with root package name */
        public int f1872d;

        /* renamed from: d0  reason: collision with root package name */
        public int f1873d0 = 0;

        /* renamed from: e  reason: collision with root package name */
        public int f1874e;

        /* renamed from: e0  reason: collision with root package name */
        public int f1875e0 = 0;

        /* renamed from: f  reason: collision with root package name */
        public int f1876f = -1;

        /* renamed from: f0  reason: collision with root package name */
        public float f1877f0 = 1.0f;

        /* renamed from: g  reason: collision with root package name */
        public int f1878g = -1;

        /* renamed from: g0  reason: collision with root package name */
        public float f1879g0 = 1.0f;

        /* renamed from: h  reason: collision with root package name */
        public float f1880h = -1.0f;

        /* renamed from: h0  reason: collision with root package name */
        public int f1881h0 = -1;

        /* renamed from: i  reason: collision with root package name */
        public boolean f1882i = true;

        /* renamed from: i0  reason: collision with root package name */
        public int f1883i0 = 0;

        /* renamed from: j  reason: collision with root package name */
        public int f1884j = -1;

        /* renamed from: j0  reason: collision with root package name */
        public int f1885j0 = -1;

        /* renamed from: k  reason: collision with root package name */
        public int f1886k = -1;

        /* renamed from: k0  reason: collision with root package name */
        public int[] f1887k0;

        /* renamed from: l  reason: collision with root package name */
        public int f1888l = -1;

        /* renamed from: l0  reason: collision with root package name */
        public String f1889l0;

        /* renamed from: m  reason: collision with root package name */
        public int f1890m = -1;

        /* renamed from: m0  reason: collision with root package name */
        public String f1891m0;

        /* renamed from: n  reason: collision with root package name */
        public int f1892n = -1;

        /* renamed from: n0  reason: collision with root package name */
        public boolean f1893n0 = false;

        /* renamed from: o  reason: collision with root package name */
        public int f1894o = -1;

        /* renamed from: o0  reason: collision with root package name */
        public boolean f1895o0 = false;

        /* renamed from: p  reason: collision with root package name */
        public int f1896p = -1;

        /* renamed from: p0  reason: collision with root package name */
        public boolean f1897p0 = true;

        /* renamed from: q  reason: collision with root package name */
        public int f1898q = -1;

        /* renamed from: q0  reason: collision with root package name */
        public int f1899q0 = 0;

        /* renamed from: r  reason: collision with root package name */
        public int f1900r = -1;

        /* renamed from: s  reason: collision with root package name */
        public int f1901s = -1;

        /* renamed from: t  reason: collision with root package name */
        public int f1902t = -1;

        /* renamed from: u  reason: collision with root package name */
        public int f1903u = -1;

        /* renamed from: v  reason: collision with root package name */
        public int f1904v = -1;

        /* renamed from: w  reason: collision with root package name */
        public int f1905w = -1;

        /* renamed from: x  reason: collision with root package name */
        public int f1906x = -1;

        /* renamed from: y  reason: collision with root package name */
        public float f1907y = 0.5f;

        /* renamed from: z  reason: collision with root package name */
        public float f1908z = 0.5f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1839r0 = sparseIntArray;
            sparseIntArray.append(i.X5, 24);
            f1839r0.append(i.Y5, 25);
            f1839r0.append(i.a6, 28);
            f1839r0.append(i.b6, 29);
            f1839r0.append(i.g6, 35);
            f1839r0.append(i.f6, 34);
            f1839r0.append(i.H5, 4);
            f1839r0.append(i.G5, 3);
            f1839r0.append(i.E5, 1);
            f1839r0.append(i.m6, 6);
            f1839r0.append(i.n6, 7);
            f1839r0.append(i.O5, 17);
            f1839r0.append(i.P5, 18);
            f1839r0.append(i.Q5, 19);
            f1839r0.append(i.A5, 90);
            f1839r0.append(i.m5, 26);
            f1839r0.append(i.c6, 31);
            f1839r0.append(i.d6, 32);
            f1839r0.append(i.N5, 10);
            f1839r0.append(i.M5, 9);
            f1839r0.append(i.q6, 13);
            f1839r0.append(i.t6, 16);
            f1839r0.append(i.r6, 14);
            f1839r0.append(i.o6, 11);
            f1839r0.append(i.s6, 15);
            f1839r0.append(i.p6, 12);
            f1839r0.append(i.j6, 38);
            f1839r0.append(i.V5, 37);
            f1839r0.append(i.U5, 39);
            f1839r0.append(i.i6, 40);
            f1839r0.append(i.T5, 20);
            f1839r0.append(i.h6, 36);
            f1839r0.append(i.L5, 5);
            f1839r0.append(i.W5, 91);
            f1839r0.append(i.e6, 91);
            f1839r0.append(i.Z5, 91);
            f1839r0.append(i.F5, 91);
            f1839r0.append(i.D5, 91);
            f1839r0.append(i.p5, 23);
            f1839r0.append(i.r5, 27);
            f1839r0.append(i.t5, 30);
            f1839r0.append(i.u5, 8);
            f1839r0.append(i.q5, 33);
            f1839r0.append(i.s5, 2);
            f1839r0.append(i.n5, 22);
            f1839r0.append(i.o5, 21);
            f1839r0.append(i.k6, 41);
            f1839r0.append(i.R5, 42);
            f1839r0.append(i.C5, 41);
            f1839r0.append(i.B5, 42);
            f1839r0.append(i.u6, 76);
            f1839r0.append(i.I5, 61);
            f1839r0.append(i.K5, 62);
            f1839r0.append(i.J5, 63);
            f1839r0.append(i.l6, 69);
            f1839r0.append(i.S5, 70);
            f1839r0.append(i.y5, 71);
            f1839r0.append(i.w5, 72);
            f1839r0.append(i.x5, 73);
            f1839r0.append(i.z5, 74);
            f1839r0.append(i.v5, 75);
        }

        public void a(b bVar) {
            this.f1866a = bVar.f1866a;
            this.f1872d = bVar.f1872d;
            this.f1868b = bVar.f1868b;
            this.f1874e = bVar.f1874e;
            this.f1876f = bVar.f1876f;
            this.f1878g = bVar.f1878g;
            this.f1880h = bVar.f1880h;
            this.f1882i = bVar.f1882i;
            this.f1884j = bVar.f1884j;
            this.f1886k = bVar.f1886k;
            this.f1888l = bVar.f1888l;
            this.f1890m = bVar.f1890m;
            this.f1892n = bVar.f1892n;
            this.f1894o = bVar.f1894o;
            this.f1896p = bVar.f1896p;
            this.f1898q = bVar.f1898q;
            this.f1900r = bVar.f1900r;
            this.f1901s = bVar.f1901s;
            this.f1902t = bVar.f1902t;
            this.f1903u = bVar.f1903u;
            this.f1904v = bVar.f1904v;
            this.f1905w = bVar.f1905w;
            this.f1906x = bVar.f1906x;
            this.f1907y = bVar.f1907y;
            this.f1908z = bVar.f1908z;
            this.f1840A = bVar.f1840A;
            this.f1841B = bVar.f1841B;
            this.f1842C = bVar.f1842C;
            this.f1843D = bVar.f1843D;
            this.f1844E = bVar.f1844E;
            this.f1845F = bVar.f1845F;
            this.f1846G = bVar.f1846G;
            this.f1847H = bVar.f1847H;
            this.f1848I = bVar.f1848I;
            this.f1849J = bVar.f1849J;
            this.f1850K = bVar.f1850K;
            this.f1851L = bVar.f1851L;
            this.f1852M = bVar.f1852M;
            this.f1853N = bVar.f1853N;
            this.f1854O = bVar.f1854O;
            this.f1855P = bVar.f1855P;
            this.f1856Q = bVar.f1856Q;
            this.f1857R = bVar.f1857R;
            this.f1858S = bVar.f1858S;
            this.f1859T = bVar.f1859T;
            this.f1860U = bVar.f1860U;
            this.f1861V = bVar.f1861V;
            this.f1862W = bVar.f1862W;
            this.f1863X = bVar.f1863X;
            this.f1864Y = bVar.f1864Y;
            this.f1865Z = bVar.f1865Z;
            this.f1867a0 = bVar.f1867a0;
            this.f1869b0 = bVar.f1869b0;
            this.f1871c0 = bVar.f1871c0;
            this.f1873d0 = bVar.f1873d0;
            this.f1875e0 = bVar.f1875e0;
            this.f1877f0 = bVar.f1877f0;
            this.f1879g0 = bVar.f1879g0;
            this.f1881h0 = bVar.f1881h0;
            this.f1883i0 = bVar.f1883i0;
            this.f1885j0 = bVar.f1885j0;
            this.f1891m0 = bVar.f1891m0;
            int[] iArr = bVar.f1887k0;
            if (iArr == null || bVar.f1889l0 != null) {
                this.f1887k0 = null;
            } else {
                this.f1887k0 = Arrays.copyOf(iArr, iArr.length);
            }
            this.f1889l0 = bVar.f1889l0;
            this.f1893n0 = bVar.f1893n0;
            this.f1895o0 = bVar.f1895o0;
            this.f1897p0 = bVar.f1897p0;
            this.f1899q0 = bVar.f1899q0;
        }

        /* access modifiers changed from: package-private */
        public void b(Context context, AttributeSet attributeSet) {
            StringBuilder sb;
            String str;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.l5);
            this.f1868b = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                int i3 = f1839r0.get(index);
                switch (i3) {
                    case 1:
                        this.f1900r = e.m(obtainStyledAttributes, index, this.f1900r);
                        break;
                    case 2:
                        this.f1850K = obtainStyledAttributes.getDimensionPixelSize(index, this.f1850K);
                        break;
                    case 3:
                        this.f1898q = e.m(obtainStyledAttributes, index, this.f1898q);
                        break;
                    case 4:
                        this.f1896p = e.m(obtainStyledAttributes, index, this.f1896p);
                        break;
                    case 5:
                        this.f1840A = obtainStyledAttributes.getString(index);
                        break;
                    case 6:
                        this.f1844E = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1844E);
                        break;
                    case 7:
                        this.f1845F = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1845F);
                        break;
                    case 8:
                        this.f1851L = obtainStyledAttributes.getDimensionPixelSize(index, this.f1851L);
                        break;
                    case 9:
                        this.f1906x = e.m(obtainStyledAttributes, index, this.f1906x);
                        break;
                    case 10:
                        this.f1905w = e.m(obtainStyledAttributes, index, this.f1905w);
                        break;
                    case 11:
                        this.f1857R = obtainStyledAttributes.getDimensionPixelSize(index, this.f1857R);
                        break;
                    case 12:
                        this.f1858S = obtainStyledAttributes.getDimensionPixelSize(index, this.f1858S);
                        break;
                    case 13:
                        this.f1854O = obtainStyledAttributes.getDimensionPixelSize(index, this.f1854O);
                        break;
                    case 14:
                        this.f1856Q = obtainStyledAttributes.getDimensionPixelSize(index, this.f1856Q);
                        break;
                    case 15:
                        this.f1859T = obtainStyledAttributes.getDimensionPixelSize(index, this.f1859T);
                        break;
                    case 16:
                        this.f1855P = obtainStyledAttributes.getDimensionPixelSize(index, this.f1855P);
                        break;
                    case 17:
                        this.f1876f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1876f);
                        break;
                    case 18:
                        this.f1878g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1878g);
                        break;
                    case 19:
                        this.f1880h = obtainStyledAttributes.getFloat(index, this.f1880h);
                        break;
                    case 20:
                        this.f1907y = obtainStyledAttributes.getFloat(index, this.f1907y);
                        break;
                    case 21:
                        this.f1874e = obtainStyledAttributes.getLayoutDimension(index, this.f1874e);
                        break;
                    case 22:
                        this.f1872d = obtainStyledAttributes.getLayoutDimension(index, this.f1872d);
                        break;
                    case 23:
                        this.f1847H = obtainStyledAttributes.getDimensionPixelSize(index, this.f1847H);
                        break;
                    case 24:
                        this.f1884j = e.m(obtainStyledAttributes, index, this.f1884j);
                        break;
                    case 25:
                        this.f1886k = e.m(obtainStyledAttributes, index, this.f1886k);
                        break;
                    case 26:
                        this.f1846G = obtainStyledAttributes.getInt(index, this.f1846G);
                        break;
                    case 27:
                        this.f1848I = obtainStyledAttributes.getDimensionPixelSize(index, this.f1848I);
                        break;
                    case 28:
                        this.f1888l = e.m(obtainStyledAttributes, index, this.f1888l);
                        break;
                    case 29:
                        this.f1890m = e.m(obtainStyledAttributes, index, this.f1890m);
                        break;
                    case 30:
                        this.f1852M = obtainStyledAttributes.getDimensionPixelSize(index, this.f1852M);
                        break;
                    case 31:
                        this.f1903u = e.m(obtainStyledAttributes, index, this.f1903u);
                        break;
                    case 32:
                        this.f1904v = e.m(obtainStyledAttributes, index, this.f1904v);
                        break;
                    case 33:
                        this.f1849J = obtainStyledAttributes.getDimensionPixelSize(index, this.f1849J);
                        break;
                    case 34:
                        this.f1894o = e.m(obtainStyledAttributes, index, this.f1894o);
                        break;
                    case 35:
                        this.f1892n = e.m(obtainStyledAttributes, index, this.f1892n);
                        break;
                    case 36:
                        this.f1908z = obtainStyledAttributes.getFloat(index, this.f1908z);
                        break;
                    case 37:
                        this.f1862W = obtainStyledAttributes.getFloat(index, this.f1862W);
                        break;
                    case 38:
                        this.f1861V = obtainStyledAttributes.getFloat(index, this.f1861V);
                        break;
                    case 39:
                        this.f1863X = obtainStyledAttributes.getInt(index, this.f1863X);
                        break;
                    case 40:
                        this.f1864Y = obtainStyledAttributes.getInt(index, this.f1864Y);
                        break;
                    case 41:
                        e.n(this, obtainStyledAttributes, index, 0);
                        break;
                    case 42:
                        e.n(this, obtainStyledAttributes, index, 1);
                        break;
                    default:
                        switch (i3) {
                            case 61:
                                this.f1841B = e.m(obtainStyledAttributes, index, this.f1841B);
                                break;
                            case 62:
                                this.f1842C = obtainStyledAttributes.getDimensionPixelSize(index, this.f1842C);
                                break;
                            case 63:
                                this.f1843D = obtainStyledAttributes.getFloat(index, this.f1843D);
                                break;
                            default:
                                switch (i3) {
                                    case 69:
                                        this.f1877f0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                        continue;
                                    case 70:
                                        this.f1879g0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                        continue;
                                    case 71:
                                        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                        continue;
                                    case 72:
                                        this.f1881h0 = obtainStyledAttributes.getInt(index, this.f1881h0);
                                        continue;
                                    case 73:
                                        this.f1883i0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1883i0);
                                        continue;
                                    case 74:
                                        this.f1889l0 = obtainStyledAttributes.getString(index);
                                        continue;
                                    case 75:
                                        this.f1897p0 = obtainStyledAttributes.getBoolean(index, this.f1897p0);
                                        continue;
                                    case 76:
                                        this.f1899q0 = obtainStyledAttributes.getInt(index, this.f1899q0);
                                        continue;
                                    case 77:
                                        this.f1901s = e.m(obtainStyledAttributes, index, this.f1901s);
                                        continue;
                                    case 78:
                                        this.f1902t = e.m(obtainStyledAttributes, index, this.f1902t);
                                        continue;
                                    case 79:
                                        this.f1860U = obtainStyledAttributes.getDimensionPixelSize(index, this.f1860U);
                                        continue;
                                    case 80:
                                        this.f1853N = obtainStyledAttributes.getDimensionPixelSize(index, this.f1853N);
                                        continue;
                                    case 81:
                                        this.f1865Z = obtainStyledAttributes.getInt(index, this.f1865Z);
                                        continue;
                                    case 82:
                                        this.f1867a0 = obtainStyledAttributes.getInt(index, this.f1867a0);
                                        continue;
                                    case 83:
                                        this.f1871c0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1871c0);
                                        continue;
                                    case 84:
                                        this.f1869b0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1869b0);
                                        continue;
                                    case 85:
                                        this.f1875e0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1875e0);
                                        continue;
                                    case 86:
                                        this.f1873d0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1873d0);
                                        continue;
                                    case 87:
                                        this.f1893n0 = obtainStyledAttributes.getBoolean(index, this.f1893n0);
                                        continue;
                                    case 88:
                                        this.f1895o0 = obtainStyledAttributes.getBoolean(index, this.f1895o0);
                                        continue;
                                    case 89:
                                        this.f1891m0 = obtainStyledAttributes.getString(index);
                                        continue;
                                    case 90:
                                        this.f1882i = obtainStyledAttributes.getBoolean(index, this.f1882i);
                                        continue;
                                    case 91:
                                        sb = new StringBuilder();
                                        str = "unused attribute 0x";
                                        break;
                                    default:
                                        sb = new StringBuilder();
                                        str = "Unknown attribute 0x";
                                        break;
                                }
                                sb.append(str);
                                sb.append(Integer.toHexString(index));
                                sb.append("   ");
                                sb.append(f1839r0.get(index));
                                Log.w("ConstraintSet", sb.toString());
                                break;
                        }
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public static class c {

        /* renamed from: o  reason: collision with root package name */
        private static SparseIntArray f1909o;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1910a = false;

        /* renamed from: b  reason: collision with root package name */
        public int f1911b = -1;

        /* renamed from: c  reason: collision with root package name */
        public int f1912c = 0;

        /* renamed from: d  reason: collision with root package name */
        public String f1913d = null;

        /* renamed from: e  reason: collision with root package name */
        public int f1914e = -1;

        /* renamed from: f  reason: collision with root package name */
        public int f1915f = 0;

        /* renamed from: g  reason: collision with root package name */
        public float f1916g = Float.NaN;

        /* renamed from: h  reason: collision with root package name */
        public int f1917h = -1;

        /* renamed from: i  reason: collision with root package name */
        public float f1918i = Float.NaN;

        /* renamed from: j  reason: collision with root package name */
        public float f1919j = Float.NaN;

        /* renamed from: k  reason: collision with root package name */
        public int f1920k = -1;

        /* renamed from: l  reason: collision with root package name */
        public String f1921l = null;

        /* renamed from: m  reason: collision with root package name */
        public int f1922m = -3;

        /* renamed from: n  reason: collision with root package name */
        public int f1923n = -1;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1909o = sparseIntArray;
            sparseIntArray.append(i.G6, 1);
            f1909o.append(i.I6, 2);
            f1909o.append(i.M6, 3);
            f1909o.append(i.F6, 4);
            f1909o.append(i.E6, 5);
            f1909o.append(i.D6, 6);
            f1909o.append(i.H6, 7);
            f1909o.append(i.L6, 8);
            f1909o.append(i.K6, 9);
            f1909o.append(i.J6, 10);
        }

        public void a(c cVar) {
            this.f1910a = cVar.f1910a;
            this.f1911b = cVar.f1911b;
            this.f1913d = cVar.f1913d;
            this.f1914e = cVar.f1914e;
            this.f1915f = cVar.f1915f;
            this.f1918i = cVar.f1918i;
            this.f1916g = cVar.f1916g;
            this.f1917h = cVar.f1917h;
        }

        /* access modifiers changed from: package-private */
        public void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.C6);
            this.f1910a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (f1909o.get(index)) {
                    case 1:
                        this.f1918i = obtainStyledAttributes.getFloat(index, this.f1918i);
                        break;
                    case 2:
                        this.f1914e = obtainStyledAttributes.getInt(index, this.f1914e);
                        break;
                    case 3:
                        this.f1913d = obtainStyledAttributes.peekValue(index).type == 3 ? obtainStyledAttributes.getString(index) : C0262a.f5907c[obtainStyledAttributes.getInteger(index, 0)];
                        break;
                    case 4:
                        this.f1915f = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        this.f1911b = e.m(obtainStyledAttributes, index, this.f1911b);
                        break;
                    case 6:
                        this.f1912c = obtainStyledAttributes.getInteger(index, this.f1912c);
                        break;
                    case 7:
                        this.f1916g = obtainStyledAttributes.getFloat(index, this.f1916g);
                        break;
                    case 8:
                        this.f1920k = obtainStyledAttributes.getInteger(index, this.f1920k);
                        break;
                    case 9:
                        this.f1919j = obtainStyledAttributes.getFloat(index, this.f1919j);
                        break;
                    case 10:
                        int i3 = obtainStyledAttributes.peekValue(index).type;
                        if (i3 != 1) {
                            if (i3 != 3) {
                                this.f1922m = obtainStyledAttributes.getInteger(index, this.f1923n);
                                break;
                            } else {
                                String string = obtainStyledAttributes.getString(index);
                                this.f1921l = string;
                                if (string.indexOf("/") <= 0) {
                                    this.f1922m = -1;
                                    break;
                                } else {
                                    this.f1923n = obtainStyledAttributes.getResourceId(index, -1);
                                }
                            }
                        } else {
                            int resourceId = obtainStyledAttributes.getResourceId(index, -1);
                            this.f1923n = resourceId;
                            if (resourceId == -1) {
                                break;
                            }
                        }
                        this.f1922m = -2;
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public boolean f1924a = false;

        /* renamed from: b  reason: collision with root package name */
        public int f1925b = 0;

        /* renamed from: c  reason: collision with root package name */
        public int f1926c = 0;

        /* renamed from: d  reason: collision with root package name */
        public float f1927d = 1.0f;

        /* renamed from: e  reason: collision with root package name */
        public float f1928e = Float.NaN;

        public void a(d dVar) {
            this.f1924a = dVar.f1924a;
            this.f1925b = dVar.f1925b;
            this.f1927d = dVar.f1927d;
            this.f1928e = dVar.f1928e;
            this.f1926c = dVar.f1926c;
        }

        /* access modifiers changed from: package-private */
        public void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.X6);
            this.f1924a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.Z6) {
                    this.f1927d = obtainStyledAttributes.getFloat(index, this.f1927d);
                } else if (index == i.Y6) {
                    this.f1925b = obtainStyledAttributes.getInt(index, this.f1925b);
                    this.f1925b = e.f1811f[this.f1925b];
                } else if (index == i.b7) {
                    this.f1926c = obtainStyledAttributes.getInt(index, this.f1926c);
                } else if (index == i.a7) {
                    this.f1928e = obtainStyledAttributes.getFloat(index, this.f1928e);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.e$e  reason: collision with other inner class name */
    public static class C0023e {

        /* renamed from: o  reason: collision with root package name */
        private static SparseIntArray f1929o;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1930a = false;

        /* renamed from: b  reason: collision with root package name */
        public float f1931b = 0.0f;

        /* renamed from: c  reason: collision with root package name */
        public float f1932c = 0.0f;

        /* renamed from: d  reason: collision with root package name */
        public float f1933d = 0.0f;

        /* renamed from: e  reason: collision with root package name */
        public float f1934e = 1.0f;

        /* renamed from: f  reason: collision with root package name */
        public float f1935f = 1.0f;

        /* renamed from: g  reason: collision with root package name */
        public float f1936g = Float.NaN;

        /* renamed from: h  reason: collision with root package name */
        public float f1937h = Float.NaN;

        /* renamed from: i  reason: collision with root package name */
        public int f1938i = -1;

        /* renamed from: j  reason: collision with root package name */
        public float f1939j = 0.0f;

        /* renamed from: k  reason: collision with root package name */
        public float f1940k = 0.0f;

        /* renamed from: l  reason: collision with root package name */
        public float f1941l = 0.0f;

        /* renamed from: m  reason: collision with root package name */
        public boolean f1942m = false;

        /* renamed from: n  reason: collision with root package name */
        public float f1943n = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1929o = sparseIntArray;
            sparseIntArray.append(i.w7, 1);
            f1929o.append(i.x7, 2);
            f1929o.append(i.y7, 3);
            f1929o.append(i.u7, 4);
            f1929o.append(i.v7, 5);
            f1929o.append(i.q7, 6);
            f1929o.append(i.r7, 7);
            f1929o.append(i.s7, 8);
            f1929o.append(i.t7, 9);
            f1929o.append(i.z7, 10);
            f1929o.append(i.A7, 11);
            f1929o.append(i.B7, 12);
        }

        public void a(C0023e eVar) {
            this.f1930a = eVar.f1930a;
            this.f1931b = eVar.f1931b;
            this.f1932c = eVar.f1932c;
            this.f1933d = eVar.f1933d;
            this.f1934e = eVar.f1934e;
            this.f1935f = eVar.f1935f;
            this.f1936g = eVar.f1936g;
            this.f1937h = eVar.f1937h;
            this.f1938i = eVar.f1938i;
            this.f1939j = eVar.f1939j;
            this.f1940k = eVar.f1940k;
            this.f1941l = eVar.f1941l;
            this.f1942m = eVar.f1942m;
            this.f1943n = eVar.f1943n;
        }

        /* access modifiers changed from: package-private */
        public void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.p7);
            this.f1930a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (f1929o.get(index)) {
                    case 1:
                        this.f1931b = obtainStyledAttributes.getFloat(index, this.f1931b);
                        break;
                    case 2:
                        this.f1932c = obtainStyledAttributes.getFloat(index, this.f1932c);
                        break;
                    case 3:
                        this.f1933d = obtainStyledAttributes.getFloat(index, this.f1933d);
                        break;
                    case 4:
                        this.f1934e = obtainStyledAttributes.getFloat(index, this.f1934e);
                        break;
                    case 5:
                        this.f1935f = obtainStyledAttributes.getFloat(index, this.f1935f);
                        break;
                    case 6:
                        this.f1936g = obtainStyledAttributes.getDimension(index, this.f1936g);
                        break;
                    case 7:
                        this.f1937h = obtainStyledAttributes.getDimension(index, this.f1937h);
                        break;
                    case 8:
                        this.f1939j = obtainStyledAttributes.getDimension(index, this.f1939j);
                        break;
                    case 9:
                        this.f1940k = obtainStyledAttributes.getDimension(index, this.f1940k);
                        break;
                    case 10:
                        this.f1941l = obtainStyledAttributes.getDimension(index, this.f1941l);
                        break;
                    case 11:
                        this.f1942m = true;
                        this.f1943n = obtainStyledAttributes.getDimension(index, this.f1943n);
                        break;
                    case 12:
                        this.f1938i = e.m(obtainStyledAttributes, index, this.f1938i);
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    static {
        f1812g.append(i.f1946A0, 25);
        f1812g.append(i.f1948B0, 26);
        f1812g.append(i.D0, 29);
        f1812g.append(i.E0, 30);
        f1812g.append(i.K0, 36);
        f1812g.append(i.J0, 35);
        f1812g.append(i.f1989h0, 4);
        f1812g.append(i.f1987g0, 3);
        f1812g.append(i.f1979c0, 1);
        f1812g.append(i.f1983e0, 91);
        f1812g.append(i.f1981d0, 92);
        f1812g.append(i.T0, 6);
        f1812g.append(i.U0, 7);
        f1812g.append(i.f2003o0, 17);
        f1812g.append(i.f2005p0, 18);
        f1812g.append(i.f2007q0, 19);
        f1812g.append(i.f1972Y, 99);
        f1812g.append(i.f2014u, 27);
        f1812g.append(i.F0, 32);
        f1812g.append(i.G0, 33);
        f1812g.append(i.f2001n0, 10);
        f1812g.append(i.f1999m0, 9);
        f1812g.append(i.X0, 13);
        f1812g.append(i.a1, 16);
        f1812g.append(i.Y0, 14);
        f1812g.append(i.V0, 11);
        f1812g.append(i.Z0, 15);
        f1812g.append(i.W0, 12);
        f1812g.append(i.N0, 40);
        f1812g.append(i.f2023y0, 39);
        f1812g.append(i.f2021x0, 41);
        f1812g.append(i.M0, 42);
        f1812g.append(i.f2019w0, 20);
        f1812g.append(i.L0, 37);
        f1812g.append(i.f1997l0, 5);
        f1812g.append(i.f2025z0, 87);
        f1812g.append(i.I0, 87);
        f1812g.append(i.f1950C0, 87);
        f1812g.append(i.f1985f0, 87);
        f1812g.append(i.f1977b0, 87);
        f1812g.append(i.f2024z, 24);
        f1812g.append(i.f1947B, 28);
        f1812g.append(i.f1961N, 31);
        f1812g.append(i.f1962O, 8);
        f1812g.append(i.f1945A, 34);
        f1812g.append(i.f1949C, 2);
        f1812g.append(i.f2020x, 23);
        f1812g.append(i.f2022y, 21);
        f1812g.append(i.O0, 95);
        f1812g.append(i.f2009r0, 96);
        f1812g.append(i.f2018w, 22);
        f1812g.append(i.f1951D, 43);
        f1812g.append(i.f1964Q, 44);
        f1812g.append(i.f1959L, 45);
        f1812g.append(i.f1960M, 46);
        f1812g.append(i.f1958K, 60);
        f1812g.append(i.f1956I, 47);
        f1812g.append(i.f1957J, 48);
        f1812g.append(i.f1952E, 49);
        f1812g.append(i.f1953F, 50);
        f1812g.append(i.f1954G, 51);
        f1812g.append(i.f1955H, 52);
        f1812g.append(i.f1963P, 53);
        f1812g.append(i.P0, 54);
        f1812g.append(i.f2011s0, 55);
        f1812g.append(i.Q0, 56);
        f1812g.append(i.f2013t0, 57);
        f1812g.append(i.R0, 58);
        f1812g.append(i.f2015u0, 59);
        f1812g.append(i.f1991i0, 61);
        f1812g.append(i.f1995k0, 62);
        f1812g.append(i.f1993j0, 63);
        f1812g.append(i.f1965R, 64);
        f1812g.append(i.k1, 65);
        f1812g.append(i.f1971X, 66);
        f1812g.append(i.l1, 67);
        f1812g.append(i.d1, 79);
        f1812g.append(i.f2016v, 38);
        f1812g.append(i.c1, 68);
        f1812g.append(i.S0, 69);
        f1812g.append(i.f2017v0, 70);
        f1812g.append(i.b1, 97);
        f1812g.append(i.f1969V, 71);
        f1812g.append(i.f1967T, 72);
        f1812g.append(i.f1968U, 73);
        f1812g.append(i.f1970W, 74);
        f1812g.append(i.f1966S, 75);
        f1812g.append(i.e1, 76);
        f1812g.append(i.H0, 77);
        f1812g.append(i.m1, 78);
        f1812g.append(i.f1975a0, 80);
        f1812g.append(i.f1973Z, 81);
        f1812g.append(i.f1, 82);
        f1812g.append(i.j1, 83);
        f1812g.append(i.i1, 84);
        f1812g.append(i.h1, 85);
        f1812g.append(i.g1, 86);
        SparseIntArray sparseIntArray = f1813h;
        int i2 = i.q4;
        sparseIntArray.append(i2, 6);
        f1813h.append(i2, 7);
        f1813h.append(i.l3, 27);
        f1813h.append(i.t4, 13);
        f1813h.append(i.w4, 16);
        f1813h.append(i.u4, 14);
        f1813h.append(i.r4, 11);
        f1813h.append(i.v4, 15);
        f1813h.append(i.s4, 12);
        f1813h.append(i.k4, 40);
        f1813h.append(i.d4, 39);
        f1813h.append(i.c4, 41);
        f1813h.append(i.j4, 42);
        f1813h.append(i.b4, 20);
        f1813h.append(i.i4, 37);
        f1813h.append(i.V3, 5);
        f1813h.append(i.e4, 87);
        f1813h.append(i.h4, 87);
        f1813h.append(i.f4, 87);
        f1813h.append(i.S3, 87);
        f1813h.append(i.R3, 87);
        f1813h.append(i.q3, 24);
        f1813h.append(i.s3, 28);
        f1813h.append(i.E3, 31);
        f1813h.append(i.F3, 8);
        f1813h.append(i.r3, 34);
        f1813h.append(i.t3, 2);
        f1813h.append(i.o3, 23);
        f1813h.append(i.p3, 21);
        f1813h.append(i.l4, 95);
        f1813h.append(i.W3, 96);
        f1813h.append(i.n3, 22);
        f1813h.append(i.u3, 43);
        f1813h.append(i.H3, 44);
        f1813h.append(i.C3, 45);
        f1813h.append(i.D3, 46);
        f1813h.append(i.B3, 60);
        f1813h.append(i.z3, 47);
        f1813h.append(i.A3, 48);
        f1813h.append(i.v3, 49);
        f1813h.append(i.w3, 50);
        f1813h.append(i.x3, 51);
        f1813h.append(i.y3, 52);
        f1813h.append(i.G3, 53);
        f1813h.append(i.m4, 54);
        f1813h.append(i.X3, 55);
        f1813h.append(i.n4, 56);
        f1813h.append(i.Y3, 57);
        f1813h.append(i.o4, 58);
        f1813h.append(i.Z3, 59);
        f1813h.append(i.U3, 62);
        f1813h.append(i.T3, 63);
        f1813h.append(i.I3, 64);
        f1813h.append(i.H4, 65);
        f1813h.append(i.O3, 66);
        f1813h.append(i.I4, 67);
        f1813h.append(i.z4, 79);
        f1813h.append(i.m3, 38);
        f1813h.append(i.A4, 98);
        f1813h.append(i.y4, 68);
        f1813h.append(i.p4, 69);
        f1813h.append(i.a4, 70);
        f1813h.append(i.M3, 71);
        f1813h.append(i.K3, 72);
        f1813h.append(i.L3, 73);
        f1813h.append(i.N3, 74);
        f1813h.append(i.J3, 75);
        f1813h.append(i.B4, 76);
        f1813h.append(i.g4, 77);
        f1813h.append(i.J4, 78);
        f1813h.append(i.Q3, 80);
        f1813h.append(i.P3, 81);
        f1813h.append(i.C4, 82);
        f1813h.append(i.G4, 83);
        f1813h.append(i.F4, 84);
        f1813h.append(i.E4, 85);
        f1813h.append(i.D4, 86);
        f1813h.append(i.x4, 97);
    }

    private int[] h(View view, String str) {
        int i2;
        Object g2;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i3 = 0;
        int i4 = 0;
        while (i3 < split.length) {
            String trim = split[i3].trim();
            try {
                i2 = h.class.getField(trim).getInt((Object) null);
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 == 0) {
                i2 = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i2 == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (g2 = ((ConstraintLayout) view.getParent()).g(0, trim)) != null && (g2 instanceof Integer)) {
                i2 = ((Integer) g2).intValue();
            }
            iArr[i4] = i2;
            i3++;
            i4++;
        }
        return i4 != split.length ? Arrays.copyOf(iArr, i4) : iArr;
    }

    private a i(Context context, AttributeSet attributeSet, boolean z2) {
        a aVar = new a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z2 ? i.k3 : i.f2012t);
        q(context, aVar, obtainStyledAttributes, z2);
        obtainStyledAttributes.recycle();
        return aVar;
    }

    private a j(int i2) {
        if (!this.f1818e.containsKey(Integer.valueOf(i2))) {
            this.f1818e.put(Integer.valueOf(i2), new a());
        }
        return (a) this.f1818e.get(Integer.valueOf(i2));
    }

    /* access modifiers changed from: private */
    public static int m(TypedArray typedArray, int i2, int i3) {
        int resourceId = typedArray.getResourceId(i2, i3);
        return resourceId == -1 ? typedArray.getInt(i2, -1) : resourceId;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x001e, code lost:
        if (r4 == -1) goto L_0x0022;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0031  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x003f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void n(java.lang.Object r3, android.content.res.TypedArray r4, int r5, int r6) {
        /*
            if (r3 != 0) goto L_0x0003
            return
        L_0x0003:
            android.util.TypedValue r0 = r4.peekValue(r5)
            int r0 = r0.type
            r1 = 3
            if (r0 == r1) goto L_0x006d
            r1 = 5
            r2 = 0
            if (r0 == r1) goto L_0x0028
            int r4 = r4.getInt(r5, r2)
            r5 = -4
            r0 = -2
            if (r4 == r5) goto L_0x0024
            r5 = -3
            if (r4 == r5) goto L_0x0020
            if (r4 == r0) goto L_0x0022
            r5 = -1
            if (r4 == r5) goto L_0x0022
        L_0x0020:
            r4 = 0
            goto L_0x002d
        L_0x0022:
            r2 = r4
            goto L_0x0020
        L_0x0024:
            r2 = 1
            r4 = 1
            r2 = -2
            goto L_0x002d
        L_0x0028:
            int r4 = r4.getDimensionPixelSize(r5, r2)
            goto L_0x0022
        L_0x002d:
            boolean r5 = r3 instanceof androidx.constraintlayout.widget.ConstraintLayout.b
            if (r5 == 0) goto L_0x003f
            androidx.constraintlayout.widget.ConstraintLayout$b r3 = (androidx.constraintlayout.widget.ConstraintLayout.b) r3
            if (r6 != 0) goto L_0x003a
            r3.width = r2
            r3.f1709a0 = r4
            goto L_0x006c
        L_0x003a:
            r3.height = r2
            r3.f1711b0 = r4
            goto L_0x006c
        L_0x003f:
            boolean r5 = r3 instanceof androidx.constraintlayout.widget.e.b
            if (r5 == 0) goto L_0x0051
            androidx.constraintlayout.widget.e$b r3 = (androidx.constraintlayout.widget.e.b) r3
            if (r6 != 0) goto L_0x004c
            r3.f1872d = r2
            r3.f1893n0 = r4
            goto L_0x006c
        L_0x004c:
            r3.f1874e = r2
            r3.f1895o0 = r4
            goto L_0x006c
        L_0x0051:
            boolean r5 = r3 instanceof androidx.constraintlayout.widget.e.a.C0022a
            if (r5 == 0) goto L_0x006c
            androidx.constraintlayout.widget.e$a$a r3 = (androidx.constraintlayout.widget.e.a.C0022a) r3
            if (r6 != 0) goto L_0x0064
            r5 = 23
            r3.b(r5, r2)
            r5 = 80
        L_0x0060:
            r3.d(r5, r4)
            goto L_0x006c
        L_0x0064:
            r5 = 21
            r3.b(r5, r2)
            r5 = 81
            goto L_0x0060
        L_0x006c:
            return
        L_0x006d:
            java.lang.String r4 = r4.getString(r5)
            o(r3, r4, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.e.n(java.lang.Object, android.content.res.TypedArray, int, int):void");
    }

    static void o(Object obj, String str, int i2) {
        int i3;
        int i4;
        if (str != null) {
            int indexOf = str.indexOf(61);
            int length = str.length();
            if (indexOf > 0 && indexOf < length - 1) {
                String substring = str.substring(0, indexOf);
                String substring2 = str.substring(indexOf + 1);
                if (substring2.length() > 0) {
                    String trim = substring.trim();
                    String trim2 = substring2.trim();
                    if ("ratio".equalsIgnoreCase(trim)) {
                        if (obj instanceof ConstraintLayout.b) {
                            ConstraintLayout.b bVar = (ConstraintLayout.b) obj;
                            if (i2 == 0) {
                                bVar.width = 0;
                            } else {
                                bVar.height = 0;
                            }
                            p(bVar, trim2);
                        } else if (obj instanceof b) {
                            ((b) obj).f1840A = trim2;
                        } else if (obj instanceof a.C0022a) {
                            ((a.C0022a) obj).c(5, trim2);
                        }
                    } else if ("weight".equalsIgnoreCase(trim)) {
                        try {
                            float parseFloat = Float.parseFloat(trim2);
                            if (obj instanceof ConstraintLayout.b) {
                                ConstraintLayout.b bVar2 = (ConstraintLayout.b) obj;
                                if (i2 == 0) {
                                    bVar2.width = 0;
                                    bVar2.f1693L = parseFloat;
                                    return;
                                }
                                bVar2.height = 0;
                                bVar2.f1694M = parseFloat;
                            } else if (obj instanceof b) {
                                b bVar3 = (b) obj;
                                if (i2 == 0) {
                                    bVar3.f1872d = 0;
                                    bVar3.f1862W = parseFloat;
                                    return;
                                }
                                bVar3.f1874e = 0;
                                bVar3.f1861V = parseFloat;
                            } else if (obj instanceof a.C0022a) {
                                a.C0022a aVar = (a.C0022a) obj;
                                if (i2 == 0) {
                                    aVar.b(23, 0);
                                    i4 = 39;
                                } else {
                                    aVar.b(21, 0);
                                    i4 = 40;
                                }
                                aVar.a(i4, parseFloat);
                            }
                        } catch (NumberFormatException unused) {
                        }
                    } else if ("parent".equalsIgnoreCase(trim)) {
                        float max = Math.max(0.0f, Math.min(1.0f, Float.parseFloat(trim2)));
                        if (obj instanceof ConstraintLayout.b) {
                            ConstraintLayout.b bVar4 = (ConstraintLayout.b) obj;
                            if (i2 == 0) {
                                bVar4.width = 0;
                                bVar4.f1703V = max;
                                bVar4.f1697P = 2;
                                return;
                            }
                            bVar4.height = 0;
                            bVar4.f1704W = max;
                            bVar4.f1698Q = 2;
                        } else if (obj instanceof b) {
                            b bVar5 = (b) obj;
                            if (i2 == 0) {
                                bVar5.f1872d = 0;
                                bVar5.f1877f0 = max;
                                bVar5.f1865Z = 2;
                                return;
                            }
                            bVar5.f1874e = 0;
                            bVar5.f1879g0 = max;
                            bVar5.f1867a0 = 2;
                        } else if (obj instanceof a.C0022a) {
                            a.C0022a aVar2 = (a.C0022a) obj;
                            if (i2 == 0) {
                                aVar2.b(23, 0);
                                i3 = 54;
                            } else {
                                aVar2.b(21, 0);
                                i3 = 55;
                            }
                            aVar2.b(i3, 2);
                        }
                    }
                }
            }
        }
    }

    static void p(ConstraintLayout.b bVar, String str) {
        float f2 = Float.NaN;
        int i2 = -1;
        if (str != null) {
            int length = str.length();
            int indexOf = str.indexOf(44);
            int i3 = 0;
            if (indexOf > 0 && indexOf < length - 1) {
                String substring = str.substring(0, indexOf);
                if (substring.equalsIgnoreCase("W")) {
                    i2 = 0;
                } else if (substring.equalsIgnoreCase("H")) {
                    i2 = 1;
                }
                i3 = indexOf + 1;
            }
            int indexOf2 = str.indexOf(58);
            if (indexOf2 < 0 || indexOf2 >= length - 1) {
                String substring2 = str.substring(i3);
                if (substring2.length() > 0) {
                    f2 = Float.parseFloat(substring2);
                }
            } else {
                String substring3 = str.substring(i3, indexOf2);
                String substring4 = str.substring(indexOf2 + 1);
                if (substring3.length() > 0 && substring4.length() > 0) {
                    try {
                        float parseFloat = Float.parseFloat(substring3);
                        float parseFloat2 = Float.parseFloat(substring4);
                        if (parseFloat > 0.0f && parseFloat2 > 0.0f) {
                            f2 = i2 == 1 ? Math.abs(parseFloat2 / parseFloat) : Math.abs(parseFloat / parseFloat2);
                        }
                    } catch (NumberFormatException unused) {
                    }
                }
            }
        }
        bVar.f1690I = str;
        bVar.f1691J = f2;
        bVar.f1692K = i2;
    }

    private void q(Context context, a aVar, TypedArray typedArray, boolean z2) {
        c cVar;
        String str;
        c cVar2;
        StringBuilder sb;
        String str2;
        if (z2) {
            r(context, aVar, typedArray);
            return;
        }
        int indexCount = typedArray.getIndexCount();
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            if (!(index == i.f2016v || i.f1961N == index || i.f1962O == index)) {
                aVar.f1822d.f1910a = true;
                aVar.f1823e.f1868b = true;
                aVar.f1821c.f1924a = true;
                aVar.f1824f.f1930a = true;
            }
            switch (f1812g.get(index)) {
                case 1:
                    b bVar = aVar.f1823e;
                    bVar.f1900r = m(typedArray, index, bVar.f1900r);
                    continue;
                case 2:
                    b bVar2 = aVar.f1823e;
                    bVar2.f1850K = typedArray.getDimensionPixelSize(index, bVar2.f1850K);
                    continue;
                case 3:
                    b bVar3 = aVar.f1823e;
                    bVar3.f1898q = m(typedArray, index, bVar3.f1898q);
                    continue;
                case 4:
                    b bVar4 = aVar.f1823e;
                    bVar4.f1896p = m(typedArray, index, bVar4.f1896p);
                    continue;
                case 5:
                    aVar.f1823e.f1840A = typedArray.getString(index);
                    continue;
                case 6:
                    b bVar5 = aVar.f1823e;
                    bVar5.f1844E = typedArray.getDimensionPixelOffset(index, bVar5.f1844E);
                    continue;
                case 7:
                    b bVar6 = aVar.f1823e;
                    bVar6.f1845F = typedArray.getDimensionPixelOffset(index, bVar6.f1845F);
                    continue;
                case 8:
                    b bVar7 = aVar.f1823e;
                    bVar7.f1851L = typedArray.getDimensionPixelSize(index, bVar7.f1851L);
                    continue;
                case 9:
                    b bVar8 = aVar.f1823e;
                    bVar8.f1906x = m(typedArray, index, bVar8.f1906x);
                    continue;
                case 10:
                    b bVar9 = aVar.f1823e;
                    bVar9.f1905w = m(typedArray, index, bVar9.f1905w);
                    continue;
                case 11:
                    b bVar10 = aVar.f1823e;
                    bVar10.f1857R = typedArray.getDimensionPixelSize(index, bVar10.f1857R);
                    continue;
                case 12:
                    b bVar11 = aVar.f1823e;
                    bVar11.f1858S = typedArray.getDimensionPixelSize(index, bVar11.f1858S);
                    continue;
                case 13:
                    b bVar12 = aVar.f1823e;
                    bVar12.f1854O = typedArray.getDimensionPixelSize(index, bVar12.f1854O);
                    continue;
                case 14:
                    b bVar13 = aVar.f1823e;
                    bVar13.f1856Q = typedArray.getDimensionPixelSize(index, bVar13.f1856Q);
                    continue;
                case 15:
                    b bVar14 = aVar.f1823e;
                    bVar14.f1859T = typedArray.getDimensionPixelSize(index, bVar14.f1859T);
                    continue;
                case 16:
                    b bVar15 = aVar.f1823e;
                    bVar15.f1855P = typedArray.getDimensionPixelSize(index, bVar15.f1855P);
                    continue;
                case 17:
                    b bVar16 = aVar.f1823e;
                    bVar16.f1876f = typedArray.getDimensionPixelOffset(index, bVar16.f1876f);
                    continue;
                case 18:
                    b bVar17 = aVar.f1823e;
                    bVar17.f1878g = typedArray.getDimensionPixelOffset(index, bVar17.f1878g);
                    continue;
                case 19:
                    b bVar18 = aVar.f1823e;
                    bVar18.f1880h = typedArray.getFloat(index, bVar18.f1880h);
                    continue;
                case 20:
                    b bVar19 = aVar.f1823e;
                    bVar19.f1907y = typedArray.getFloat(index, bVar19.f1907y);
                    continue;
                case 21:
                    b bVar20 = aVar.f1823e;
                    bVar20.f1874e = typedArray.getLayoutDimension(index, bVar20.f1874e);
                    continue;
                case 22:
                    d dVar = aVar.f1821c;
                    dVar.f1925b = typedArray.getInt(index, dVar.f1925b);
                    d dVar2 = aVar.f1821c;
                    dVar2.f1925b = f1811f[dVar2.f1925b];
                    continue;
                case 23:
                    b bVar21 = aVar.f1823e;
                    bVar21.f1872d = typedArray.getLayoutDimension(index, bVar21.f1872d);
                    continue;
                case 24:
                    b bVar22 = aVar.f1823e;
                    bVar22.f1847H = typedArray.getDimensionPixelSize(index, bVar22.f1847H);
                    continue;
                case 25:
                    b bVar23 = aVar.f1823e;
                    bVar23.f1884j = m(typedArray, index, bVar23.f1884j);
                    continue;
                case 26:
                    b bVar24 = aVar.f1823e;
                    bVar24.f1886k = m(typedArray, index, bVar24.f1886k);
                    continue;
                case 27:
                    b bVar25 = aVar.f1823e;
                    bVar25.f1846G = typedArray.getInt(index, bVar25.f1846G);
                    continue;
                case 28:
                    b bVar26 = aVar.f1823e;
                    bVar26.f1848I = typedArray.getDimensionPixelSize(index, bVar26.f1848I);
                    continue;
                case 29:
                    b bVar27 = aVar.f1823e;
                    bVar27.f1888l = m(typedArray, index, bVar27.f1888l);
                    continue;
                case 30:
                    b bVar28 = aVar.f1823e;
                    bVar28.f1890m = m(typedArray, index, bVar28.f1890m);
                    continue;
                case 31:
                    b bVar29 = aVar.f1823e;
                    bVar29.f1852M = typedArray.getDimensionPixelSize(index, bVar29.f1852M);
                    continue;
                case 32:
                    b bVar30 = aVar.f1823e;
                    bVar30.f1903u = m(typedArray, index, bVar30.f1903u);
                    continue;
                case 33:
                    b bVar31 = aVar.f1823e;
                    bVar31.f1904v = m(typedArray, index, bVar31.f1904v);
                    continue;
                case 34:
                    b bVar32 = aVar.f1823e;
                    bVar32.f1849J = typedArray.getDimensionPixelSize(index, bVar32.f1849J);
                    continue;
                case 35:
                    b bVar33 = aVar.f1823e;
                    bVar33.f1894o = m(typedArray, index, bVar33.f1894o);
                    continue;
                case 36:
                    b bVar34 = aVar.f1823e;
                    bVar34.f1892n = m(typedArray, index, bVar34.f1892n);
                    continue;
                case 37:
                    b bVar35 = aVar.f1823e;
                    bVar35.f1908z = typedArray.getFloat(index, bVar35.f1908z);
                    continue;
                case 38:
                    aVar.f1819a = typedArray.getResourceId(index, aVar.f1819a);
                    continue;
                case 39:
                    b bVar36 = aVar.f1823e;
                    bVar36.f1862W = typedArray.getFloat(index, bVar36.f1862W);
                    continue;
                case 40:
                    b bVar37 = aVar.f1823e;
                    bVar37.f1861V = typedArray.getFloat(index, bVar37.f1861V);
                    continue;
                case 41:
                    b bVar38 = aVar.f1823e;
                    bVar38.f1863X = typedArray.getInt(index, bVar38.f1863X);
                    continue;
                case 42:
                    b bVar39 = aVar.f1823e;
                    bVar39.f1864Y = typedArray.getInt(index, bVar39.f1864Y);
                    continue;
                case 43:
                    d dVar3 = aVar.f1821c;
                    dVar3.f1927d = typedArray.getFloat(index, dVar3.f1927d);
                    continue;
                case 44:
                    C0023e eVar = aVar.f1824f;
                    eVar.f1942m = true;
                    eVar.f1943n = typedArray.getDimension(index, eVar.f1943n);
                    continue;
                case 45:
                    C0023e eVar2 = aVar.f1824f;
                    eVar2.f1932c = typedArray.getFloat(index, eVar2.f1932c);
                    continue;
                case 46:
                    C0023e eVar3 = aVar.f1824f;
                    eVar3.f1933d = typedArray.getFloat(index, eVar3.f1933d);
                    continue;
                case 47:
                    C0023e eVar4 = aVar.f1824f;
                    eVar4.f1934e = typedArray.getFloat(index, eVar4.f1934e);
                    continue;
                case 48:
                    C0023e eVar5 = aVar.f1824f;
                    eVar5.f1935f = typedArray.getFloat(index, eVar5.f1935f);
                    continue;
                case 49:
                    C0023e eVar6 = aVar.f1824f;
                    eVar6.f1936g = typedArray.getDimension(index, eVar6.f1936g);
                    continue;
                case 50:
                    C0023e eVar7 = aVar.f1824f;
                    eVar7.f1937h = typedArray.getDimension(index, eVar7.f1937h);
                    continue;
                case 51:
                    C0023e eVar8 = aVar.f1824f;
                    eVar8.f1939j = typedArray.getDimension(index, eVar8.f1939j);
                    continue;
                case 52:
                    C0023e eVar9 = aVar.f1824f;
                    eVar9.f1940k = typedArray.getDimension(index, eVar9.f1940k);
                    continue;
                case 53:
                    C0023e eVar10 = aVar.f1824f;
                    eVar10.f1941l = typedArray.getDimension(index, eVar10.f1941l);
                    continue;
                case 54:
                    b bVar40 = aVar.f1823e;
                    bVar40.f1865Z = typedArray.getInt(index, bVar40.f1865Z);
                    continue;
                case 55:
                    b bVar41 = aVar.f1823e;
                    bVar41.f1867a0 = typedArray.getInt(index, bVar41.f1867a0);
                    continue;
                case 56:
                    b bVar42 = aVar.f1823e;
                    bVar42.f1869b0 = typedArray.getDimensionPixelSize(index, bVar42.f1869b0);
                    continue;
                case 57:
                    b bVar43 = aVar.f1823e;
                    bVar43.f1871c0 = typedArray.getDimensionPixelSize(index, bVar43.f1871c0);
                    continue;
                case 58:
                    b bVar44 = aVar.f1823e;
                    bVar44.f1873d0 = typedArray.getDimensionPixelSize(index, bVar44.f1873d0);
                    continue;
                case 59:
                    b bVar45 = aVar.f1823e;
                    bVar45.f1875e0 = typedArray.getDimensionPixelSize(index, bVar45.f1875e0);
                    continue;
                case 60:
                    C0023e eVar11 = aVar.f1824f;
                    eVar11.f1931b = typedArray.getFloat(index, eVar11.f1931b);
                    continue;
                case 61:
                    b bVar46 = aVar.f1823e;
                    bVar46.f1841B = m(typedArray, index, bVar46.f1841B);
                    continue;
                case 62:
                    b bVar47 = aVar.f1823e;
                    bVar47.f1842C = typedArray.getDimensionPixelSize(index, bVar47.f1842C);
                    continue;
                case 63:
                    b bVar48 = aVar.f1823e;
                    bVar48.f1843D = typedArray.getFloat(index, bVar48.f1843D);
                    continue;
                case 64:
                    c cVar3 = aVar.f1822d;
                    cVar3.f1911b = m(typedArray, index, cVar3.f1911b);
                    continue;
                case 65:
                    if (typedArray.peekValue(index).type == 3) {
                        cVar = aVar.f1822d;
                        str = typedArray.getString(index);
                    } else {
                        cVar = aVar.f1822d;
                        str = C0262a.f5907c[typedArray.getInteger(index, 0)];
                    }
                    cVar.f1913d = str;
                    continue;
                case 66:
                    aVar.f1822d.f1915f = typedArray.getInt(index, 0);
                    continue;
                case 67:
                    c cVar4 = aVar.f1822d;
                    cVar4.f1918i = typedArray.getFloat(index, cVar4.f1918i);
                    continue;
                case 68:
                    d dVar4 = aVar.f1821c;
                    dVar4.f1928e = typedArray.getFloat(index, dVar4.f1928e);
                    continue;
                case 69:
                    aVar.f1823e.f1877f0 = typedArray.getFloat(index, 1.0f);
                    continue;
                case 70:
                    aVar.f1823e.f1879g0 = typedArray.getFloat(index, 1.0f);
                    continue;
                case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    continue;
                case 72:
                    b bVar49 = aVar.f1823e;
                    bVar49.f1881h0 = typedArray.getInt(index, bVar49.f1881h0);
                    continue;
                case 73:
                    b bVar50 = aVar.f1823e;
                    bVar50.f1883i0 = typedArray.getDimensionPixelSize(index, bVar50.f1883i0);
                    continue;
                case 74:
                    aVar.f1823e.f1889l0 = typedArray.getString(index);
                    continue;
                case 75:
                    b bVar51 = aVar.f1823e;
                    bVar51.f1897p0 = typedArray.getBoolean(index, bVar51.f1897p0);
                    continue;
                case 76:
                    c cVar5 = aVar.f1822d;
                    cVar5.f1914e = typedArray.getInt(index, cVar5.f1914e);
                    continue;
                case 77:
                    aVar.f1823e.f1891m0 = typedArray.getString(index);
                    continue;
                case 78:
                    d dVar5 = aVar.f1821c;
                    dVar5.f1926c = typedArray.getInt(index, dVar5.f1926c);
                    continue;
                case 79:
                    c cVar6 = aVar.f1822d;
                    cVar6.f1916g = typedArray.getFloat(index, cVar6.f1916g);
                    continue;
                case 80:
                    b bVar52 = aVar.f1823e;
                    bVar52.f1893n0 = typedArray.getBoolean(index, bVar52.f1893n0);
                    continue;
                case 81:
                    b bVar53 = aVar.f1823e;
                    bVar53.f1895o0 = typedArray.getBoolean(index, bVar53.f1895o0);
                    continue;
                case 82:
                    c cVar7 = aVar.f1822d;
                    cVar7.f1912c = typedArray.getInteger(index, cVar7.f1912c);
                    continue;
                case 83:
                    C0023e eVar12 = aVar.f1824f;
                    eVar12.f1938i = m(typedArray, index, eVar12.f1938i);
                    continue;
                case 84:
                    c cVar8 = aVar.f1822d;
                    cVar8.f1920k = typedArray.getInteger(index, cVar8.f1920k);
                    continue;
                case 85:
                    c cVar9 = aVar.f1822d;
                    cVar9.f1919j = typedArray.getFloat(index, cVar9.f1919j);
                    continue;
                case 86:
                    int i3 = typedArray.peekValue(index).type;
                    if (i3 != 1) {
                        if (i3 != 3) {
                            c cVar10 = aVar.f1822d;
                            cVar10.f1922m = typedArray.getInteger(index, cVar10.f1923n);
                            break;
                        } else {
                            aVar.f1822d.f1921l = typedArray.getString(index);
                            if (aVar.f1822d.f1921l.indexOf("/") <= 0) {
                                aVar.f1822d.f1922m = -1;
                                break;
                            } else {
                                aVar.f1822d.f1923n = typedArray.getResourceId(index, -1);
                                cVar2 = aVar.f1822d;
                            }
                        }
                    } else {
                        aVar.f1822d.f1923n = typedArray.getResourceId(index, -1);
                        cVar2 = aVar.f1822d;
                        if (cVar2.f1923n == -1) {
                            continue;
                        }
                    }
                    cVar2.f1922m = -2;
                    break;
                case 87:
                    sb = new StringBuilder();
                    str2 = "unused attribute 0x";
                    break;
                case 91:
                    b bVar54 = aVar.f1823e;
                    bVar54.f1901s = m(typedArray, index, bVar54.f1901s);
                    continue;
                case 92:
                    b bVar55 = aVar.f1823e;
                    bVar55.f1902t = m(typedArray, index, bVar55.f1902t);
                    continue;
                case 93:
                    b bVar56 = aVar.f1823e;
                    bVar56.f1853N = typedArray.getDimensionPixelSize(index, bVar56.f1853N);
                    continue;
                case 94:
                    b bVar57 = aVar.f1823e;
                    bVar57.f1860U = typedArray.getDimensionPixelSize(index, bVar57.f1860U);
                    continue;
                case 95:
                    n(aVar.f1823e, typedArray, index, 0);
                    continue;
                case 96:
                    n(aVar.f1823e, typedArray, index, 1);
                    continue;
                case 97:
                    b bVar58 = aVar.f1823e;
                    bVar58.f1899q0 = typedArray.getInt(index, bVar58.f1899q0);
                    continue;
                default:
                    sb = new StringBuilder();
                    str2 = "Unknown attribute 0x";
                    break;
            }
            sb.append(str2);
            sb.append(Integer.toHexString(index));
            sb.append("   ");
            sb.append(f1812g.get(index));
            Log.w("ConstraintSet", sb.toString());
        }
        b bVar59 = aVar.f1823e;
        if (bVar59.f1889l0 != null) {
            bVar59.f1887k0 = null;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:112:0x0482, code lost:
        r1 = r1 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x009d, code lost:
        r0.b(r4, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x014b, code lost:
        r0.a(r4, r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x01a5, code lost:
        r0.c(r4, r13.getString(r3));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x01ea, code lost:
        r3 = r13.getFloat(r3, 1.0f);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x003c, code lost:
        r4.append(r5);
        r4.append(java.lang.Integer.toHexString(r3));
        r4.append("   ");
        r4.append(f1812g.get(r3));
        android.util.Log.w("ConstraintSet", r4.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0065, code lost:
        r0.d(r4, r3);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void r(android.content.Context r11, androidx.constraintlayout.widget.e.a r12, android.content.res.TypedArray r13) {
        /*
            int r11 = r13.getIndexCount()
            androidx.constraintlayout.widget.e$a$a r0 = new androidx.constraintlayout.widget.e$a$a
            r0.<init>()
            r12.f1826h = r0
            androidx.constraintlayout.widget.e$c r1 = r12.f1822d
            r2 = 0
            r1.f1910a = r2
            androidx.constraintlayout.widget.e$b r1 = r12.f1823e
            r1.f1868b = r2
            androidx.constraintlayout.widget.e$d r1 = r12.f1821c
            r1.f1924a = r2
            androidx.constraintlayout.widget.e$e r1 = r12.f1824f
            r1.f1930a = r2
            r1 = 0
        L_0x001d:
            if (r1 >= r11) goto L_0x0486
            int r3 = r13.getIndex(r1)
            android.util.SparseIntArray r4 = f1813h
            int r4 = r4.get(r3)
            r5 = 1065353216(0x3f800000, float:1.0)
            java.lang.String r6 = "   "
            r7 = 3
            java.lang.String r8 = "ConstraintSet"
            r9 = 1
            r10 = -1
            switch(r4) {
                case 2: goto L_0x0477;
                case 3: goto L_0x0035;
                case 4: goto L_0x0035;
                case 5: goto L_0x0474;
                case 6: goto L_0x0469;
                case 7: goto L_0x045e;
                case 8: goto L_0x0452;
                case 9: goto L_0x0035;
                case 10: goto L_0x0035;
                case 11: goto L_0x0446;
                case 12: goto L_0x043a;
                case 13: goto L_0x042e;
                case 14: goto L_0x0422;
                case 15: goto L_0x0416;
                case 16: goto L_0x040a;
                case 17: goto L_0x03fe;
                case 18: goto L_0x03f2;
                case 19: goto L_0x03e6;
                case 20: goto L_0x03da;
                case 21: goto L_0x03ce;
                case 22: goto L_0x03be;
                case 23: goto L_0x03b2;
                case 24: goto L_0x03a6;
                case 25: goto L_0x0035;
                case 26: goto L_0x0035;
                case 27: goto L_0x039a;
                case 28: goto L_0x038e;
                case 29: goto L_0x0035;
                case 30: goto L_0x0035;
                case 31: goto L_0x0382;
                case 32: goto L_0x0035;
                case 33: goto L_0x0035;
                case 34: goto L_0x0376;
                case 35: goto L_0x0035;
                case 36: goto L_0x0035;
                case 37: goto L_0x036a;
                case 38: goto L_0x035e;
                case 39: goto L_0x0352;
                case 40: goto L_0x0346;
                case 41: goto L_0x033a;
                case 42: goto L_0x032e;
                case 43: goto L_0x0322;
                case 44: goto L_0x0313;
                case 45: goto L_0x0307;
                case 46: goto L_0x02fb;
                case 47: goto L_0x02ef;
                case 48: goto L_0x02e3;
                case 49: goto L_0x02d7;
                case 50: goto L_0x02cb;
                case 51: goto L_0x02bf;
                case 52: goto L_0x02b3;
                case 53: goto L_0x02a7;
                case 54: goto L_0x029b;
                case 55: goto L_0x028f;
                case 56: goto L_0x0283;
                case 57: goto L_0x0277;
                case 58: goto L_0x026b;
                case 59: goto L_0x025f;
                case 60: goto L_0x0253;
                case 61: goto L_0x0035;
                case 62: goto L_0x0247;
                case 63: goto L_0x023b;
                case 64: goto L_0x022f;
                case 65: goto L_0x0213;
                case 66: goto L_0x020b;
                case 67: goto L_0x01ff;
                case 68: goto L_0x01f3;
                case 69: goto L_0x01f0;
                case 70: goto L_0x01e8;
                case 71: goto L_0x01e1;
                case 72: goto L_0x01d5;
                case 73: goto L_0x01c9;
                case 74: goto L_0x01c6;
                case 75: goto L_0x01ba;
                case 76: goto L_0x01ae;
                case 77: goto L_0x01a3;
                case 78: goto L_0x0197;
                case 79: goto L_0x018c;
                case 80: goto L_0x0180;
                case 81: goto L_0x0174;
                case 82: goto L_0x0168;
                case 83: goto L_0x015c;
                case 84: goto L_0x0150;
                case 85: goto L_0x0141;
                case 86: goto L_0x00cb;
                case 87: goto L_0x00c2;
                case 88: goto L_0x0035;
                case 89: goto L_0x0035;
                case 90: goto L_0x0035;
                case 91: goto L_0x0035;
                case 92: goto L_0x0035;
                case 93: goto L_0x00b7;
                case 94: goto L_0x00ac;
                case 95: goto L_0x00a7;
                case 96: goto L_0x00a2;
                case 97: goto L_0x0093;
                case 98: goto L_0x006a;
                case 99: goto L_0x005b;
                default: goto L_0x0035;
            }
        L_0x0035:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "Unknown attribute 0x"
        L_0x003c:
            r4.append(r5)
            java.lang.String r5 = java.lang.Integer.toHexString(r3)
            r4.append(r5)
            r4.append(r6)
            android.util.SparseIntArray r5 = f1812g
            int r3 = r5.get(r3)
            r4.append(r3)
            java.lang.String r3 = r4.toString()
            android.util.Log.w(r8, r3)
            goto L_0x0482
        L_0x005b:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            boolean r4 = r4.f1882i
            boolean r3 = r13.getBoolean(r3, r4)
            r4 = 99
        L_0x0065:
            r0.d(r4, r3)
            goto L_0x0482
        L_0x006a:
            boolean r4 = r.b.f6194y
            if (r4 == 0) goto L_0x0080
            int r4 = r12.f1819a
            int r4 = r13.getResourceId(r3, r4)
            r12.f1819a = r4
            if (r4 != r10) goto L_0x0482
        L_0x0078:
            java.lang.String r3 = r13.getString(r3)
            r12.f1820b = r3
            goto L_0x0482
        L_0x0080:
            android.util.TypedValue r4 = r13.peekValue(r3)
            int r4 = r4.type
            if (r4 != r7) goto L_0x0089
            goto L_0x0078
        L_0x0089:
            int r4 = r12.f1819a
            int r3 = r13.getResourceId(r3, r4)
            r12.f1819a = r3
            goto L_0x0482
        L_0x0093:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1899q0
            int r3 = r13.getInt(r3, r4)
            r4 = 97
        L_0x009d:
            r0.b(r4, r3)
            goto L_0x0482
        L_0x00a2:
            n(r0, r13, r3, r9)
            goto L_0x0482
        L_0x00a7:
            n(r0, r13, r3, r2)
            goto L_0x0482
        L_0x00ac:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1860U
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 94
            goto L_0x009d
        L_0x00b7:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1853N
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 93
            goto L_0x009d
        L_0x00c2:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "unused attribute 0x"
            goto L_0x003c
        L_0x00cb:
            android.util.TypedValue r4 = r13.peekValue(r3)
            int r4 = r4.type
            r5 = -2
            r6 = 89
            r8 = 88
            if (r4 != r9) goto L_0x00f4
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r3 = r13.getResourceId(r3, r10)
            r4.f1923n = r3
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            int r3 = r3.f1923n
            r0.b(r6, r3)
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            int r4 = r3.f1923n
            if (r4 == r10) goto L_0x0482
        L_0x00ed:
            r3.f1922m = r5
            r0.b(r8, r5)
            goto L_0x0482
        L_0x00f4:
            if (r4 != r7) goto L_0x012e
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            java.lang.String r7 = r13.getString(r3)
            r4.f1921l = r7
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            java.lang.String r4 = r4.f1921l
            r7 = 90
            r0.c(r7, r4)
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            java.lang.String r4 = r4.f1921l
            java.lang.String r7 = "/"
            int r4 = r4.indexOf(r7)
            if (r4 <= 0) goto L_0x0125
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r3 = r13.getResourceId(r3, r10)
            r4.f1923n = r3
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            int r3 = r3.f1923n
            r0.b(r6, r3)
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            goto L_0x00ed
        L_0x0125:
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            r3.f1922m = r10
            r0.b(r8, r10)
            goto L_0x0482
        L_0x012e:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r5 = r4.f1923n
            int r3 = r13.getInteger(r3, r5)
            r4.f1922m = r3
            androidx.constraintlayout.widget.e$c r3 = r12.f1822d
            int r3 = r3.f1922m
            r0.b(r8, r3)
            goto L_0x0482
        L_0x0141:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            float r4 = r4.f1919j
            float r3 = r13.getFloat(r3, r4)
            r4 = 85
        L_0x014b:
            r0.a(r4, r3)
            goto L_0x0482
        L_0x0150:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r4 = r4.f1920k
            int r3 = r13.getInteger(r3, r4)
            r4 = 84
            goto L_0x009d
        L_0x015c:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            int r4 = r4.f1938i
            int r3 = m(r13, r3, r4)
            r4 = 83
            goto L_0x009d
        L_0x0168:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r4 = r4.f1912c
            int r3 = r13.getInteger(r3, r4)
            r4 = 82
            goto L_0x009d
        L_0x0174:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            boolean r4 = r4.f1895o0
            boolean r3 = r13.getBoolean(r3, r4)
            r4 = 81
            goto L_0x0065
        L_0x0180:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            boolean r4 = r4.f1893n0
            boolean r3 = r13.getBoolean(r3, r4)
            r4 = 80
            goto L_0x0065
        L_0x018c:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            float r4 = r4.f1916g
            float r3 = r13.getFloat(r3, r4)
            r4 = 79
            goto L_0x014b
        L_0x0197:
            androidx.constraintlayout.widget.e$d r4 = r12.f1821c
            int r4 = r4.f1926c
            int r3 = r13.getInt(r3, r4)
            r4 = 78
            goto L_0x009d
        L_0x01a3:
            r4 = 77
        L_0x01a5:
            java.lang.String r3 = r13.getString(r3)
            r0.c(r4, r3)
            goto L_0x0482
        L_0x01ae:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r4 = r4.f1914e
            int r3 = r13.getInt(r3, r4)
            r4 = 76
            goto L_0x009d
        L_0x01ba:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            boolean r4 = r4.f1897p0
            boolean r3 = r13.getBoolean(r3, r4)
            r4 = 75
            goto L_0x0065
        L_0x01c6:
            r4 = 74
            goto L_0x01a5
        L_0x01c9:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1883i0
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 73
            goto L_0x009d
        L_0x01d5:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1881h0
            int r3 = r13.getInt(r3, r4)
            r4 = 72
            goto L_0x009d
        L_0x01e1:
            java.lang.String r3 = "CURRENTLY UNSUPPORTED"
            android.util.Log.e(r8, r3)
            goto L_0x0482
        L_0x01e8:
            r4 = 70
        L_0x01ea:
            float r3 = r13.getFloat(r3, r5)
            goto L_0x014b
        L_0x01f0:
            r4 = 69
            goto L_0x01ea
        L_0x01f3:
            androidx.constraintlayout.widget.e$d r4 = r12.f1821c
            float r4 = r4.f1928e
            float r3 = r13.getFloat(r3, r4)
            r4 = 68
            goto L_0x014b
        L_0x01ff:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            float r4 = r4.f1918i
            float r3 = r13.getFloat(r3, r4)
            r4 = 67
            goto L_0x014b
        L_0x020b:
            r4 = 66
            int r3 = r13.getInt(r3, r2)
            goto L_0x009d
        L_0x0213:
            android.util.TypedValue r4 = r13.peekValue(r3)
            int r4 = r4.type
            r5 = 65
            if (r4 != r7) goto L_0x0226
            java.lang.String r3 = r13.getString(r3)
        L_0x0221:
            r0.c(r5, r3)
            goto L_0x0482
        L_0x0226:
            java.lang.String[] r4 = n.C0262a.f5907c
            int r3 = r13.getInteger(r3, r2)
            r3 = r4[r3]
            goto L_0x0221
        L_0x022f:
            androidx.constraintlayout.widget.e$c r4 = r12.f1822d
            int r4 = r4.f1911b
            int r3 = m(r13, r3, r4)
            r4 = 64
            goto L_0x009d
        L_0x023b:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1843D
            float r3 = r13.getFloat(r3, r4)
            r4 = 63
            goto L_0x014b
        L_0x0247:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1842C
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 62
            goto L_0x009d
        L_0x0253:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1931b
            float r3 = r13.getFloat(r3, r4)
            r4 = 60
            goto L_0x014b
        L_0x025f:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1875e0
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 59
            goto L_0x009d
        L_0x026b:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1873d0
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 58
            goto L_0x009d
        L_0x0277:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1871c0
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 57
            goto L_0x009d
        L_0x0283:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1869b0
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 56
            goto L_0x009d
        L_0x028f:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1867a0
            int r3 = r13.getInt(r3, r4)
            r4 = 55
            goto L_0x009d
        L_0x029b:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1865Z
            int r3 = r13.getInt(r3, r4)
            r4 = 54
            goto L_0x009d
        L_0x02a7:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1941l
            float r3 = r13.getDimension(r3, r4)
            r4 = 53
            goto L_0x014b
        L_0x02b3:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1940k
            float r3 = r13.getDimension(r3, r4)
            r4 = 52
            goto L_0x014b
        L_0x02bf:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1939j
            float r3 = r13.getDimension(r3, r4)
            r4 = 51
            goto L_0x014b
        L_0x02cb:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1937h
            float r3 = r13.getDimension(r3, r4)
            r4 = 50
            goto L_0x014b
        L_0x02d7:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1936g
            float r3 = r13.getDimension(r3, r4)
            r4 = 49
            goto L_0x014b
        L_0x02e3:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1935f
            float r3 = r13.getFloat(r3, r4)
            r4 = 48
            goto L_0x014b
        L_0x02ef:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1934e
            float r3 = r13.getFloat(r3, r4)
            r4 = 47
            goto L_0x014b
        L_0x02fb:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1933d
            float r3 = r13.getFloat(r3, r4)
            r4 = 46
            goto L_0x014b
        L_0x0307:
            androidx.constraintlayout.widget.e$e r4 = r12.f1824f
            float r4 = r4.f1932c
            float r3 = r13.getFloat(r3, r4)
            r4 = 45
            goto L_0x014b
        L_0x0313:
            r4 = 44
            r0.d(r4, r9)
            androidx.constraintlayout.widget.e$e r5 = r12.f1824f
            float r5 = r5.f1943n
            float r3 = r13.getDimension(r3, r5)
            goto L_0x014b
        L_0x0322:
            androidx.constraintlayout.widget.e$d r4 = r12.f1821c
            float r4 = r4.f1927d
            float r3 = r13.getFloat(r3, r4)
            r4 = 43
            goto L_0x014b
        L_0x032e:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1864Y
            int r3 = r13.getInt(r3, r4)
            r4 = 42
            goto L_0x009d
        L_0x033a:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1863X
            int r3 = r13.getInt(r3, r4)
            r4 = 41
            goto L_0x009d
        L_0x0346:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1861V
            float r3 = r13.getFloat(r3, r4)
            r4 = 40
            goto L_0x014b
        L_0x0352:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1862W
            float r3 = r13.getFloat(r3, r4)
            r4 = 39
            goto L_0x014b
        L_0x035e:
            int r4 = r12.f1819a
            int r3 = r13.getResourceId(r3, r4)
            r12.f1819a = r3
            r4 = 38
            goto L_0x009d
        L_0x036a:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1908z
            float r3 = r13.getFloat(r3, r4)
            r4 = 37
            goto L_0x014b
        L_0x0376:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1849J
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 34
            goto L_0x009d
        L_0x0382:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1852M
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 31
            goto L_0x009d
        L_0x038e:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1848I
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 28
            goto L_0x009d
        L_0x039a:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1846G
            int r3 = r13.getInt(r3, r4)
            r4 = 27
            goto L_0x009d
        L_0x03a6:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1847H
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 24
            goto L_0x009d
        L_0x03b2:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1872d
            int r3 = r13.getLayoutDimension(r3, r4)
            r4 = 23
            goto L_0x009d
        L_0x03be:
            int[] r4 = f1811f
            androidx.constraintlayout.widget.e$d r5 = r12.f1821c
            int r5 = r5.f1925b
            int r3 = r13.getInt(r3, r5)
            r3 = r4[r3]
            r4 = 22
            goto L_0x009d
        L_0x03ce:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1874e
            int r3 = r13.getLayoutDimension(r3, r4)
            r4 = 21
            goto L_0x009d
        L_0x03da:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1907y
            float r3 = r13.getFloat(r3, r4)
            r4 = 20
            goto L_0x014b
        L_0x03e6:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            float r4 = r4.f1880h
            float r3 = r13.getFloat(r3, r4)
            r4 = 19
            goto L_0x014b
        L_0x03f2:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1878g
            int r3 = r13.getDimensionPixelOffset(r3, r4)
            r4 = 18
            goto L_0x009d
        L_0x03fe:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1876f
            int r3 = r13.getDimensionPixelOffset(r3, r4)
            r4 = 17
            goto L_0x009d
        L_0x040a:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1855P
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 16
            goto L_0x009d
        L_0x0416:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1859T
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 15
            goto L_0x009d
        L_0x0422:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1856Q
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 14
            goto L_0x009d
        L_0x042e:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1854O
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 13
            goto L_0x009d
        L_0x043a:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1858S
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 12
            goto L_0x009d
        L_0x0446:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1857R
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 11
            goto L_0x009d
        L_0x0452:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1851L
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 8
            goto L_0x009d
        L_0x045e:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1845F
            int r3 = r13.getDimensionPixelOffset(r3, r4)
            r4 = 7
            goto L_0x009d
        L_0x0469:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1844E
            int r3 = r13.getDimensionPixelOffset(r3, r4)
            r4 = 6
            goto L_0x009d
        L_0x0474:
            r4 = 5
            goto L_0x01a5
        L_0x0477:
            androidx.constraintlayout.widget.e$b r4 = r12.f1823e
            int r4 = r4.f1850K
            int r3 = r13.getDimensionPixelSize(r3, r4)
            r4 = 2
            goto L_0x009d
        L_0x0482:
            int r1 = r1 + 1
            goto L_0x001d
        L_0x0486:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.e.r(android.content.Context, androidx.constraintlayout.widget.e$a, android.content.res.TypedArray):void");
    }

    public void c(ConstraintLayout constraintLayout) {
        d(constraintLayout, true);
        constraintLayout.setConstraintSet((e) null);
        constraintLayout.requestLayout();
    }

    /* access modifiers changed from: package-private */
    public void d(ConstraintLayout constraintLayout, boolean z2) {
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.f1818e.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (!this.f1818e.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + C0280a.a(childAt));
            } else if (this.f1817d && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            } else if (id != -1) {
                if (this.f1818e.containsKey(Integer.valueOf(id))) {
                    hashSet.remove(Integer.valueOf(id));
                    a aVar = (a) this.f1818e.get(Integer.valueOf(id));
                    if (aVar != null) {
                        if (childAt instanceof a) {
                            aVar.f1823e.f1885j0 = 1;
                            a aVar2 = (a) childAt;
                            aVar2.setId(id);
                            aVar2.setType(aVar.f1823e.f1881h0);
                            aVar2.setMargin(aVar.f1823e.f1883i0);
                            aVar2.setAllowsGoneWidget(aVar.f1823e.f1897p0);
                            b bVar = aVar.f1823e;
                            int[] iArr = bVar.f1887k0;
                            if (iArr != null) {
                                aVar2.setReferencedIds(iArr);
                            } else {
                                String str = bVar.f1889l0;
                                if (str != null) {
                                    bVar.f1887k0 = h(aVar2, str);
                                    aVar2.setReferencedIds(aVar.f1823e.f1887k0);
                                }
                            }
                        }
                        ConstraintLayout.b bVar2 = (ConstraintLayout.b) childAt.getLayoutParams();
                        bVar2.a();
                        aVar.b(bVar2);
                        if (z2) {
                            b.c(childAt, aVar.f1825g);
                        }
                        childAt.setLayoutParams(bVar2);
                        d dVar = aVar.f1821c;
                        if (dVar.f1926c == 0) {
                            childAt.setVisibility(dVar.f1925b);
                        }
                        childAt.setAlpha(aVar.f1821c.f1927d);
                        childAt.setRotation(aVar.f1824f.f1931b);
                        childAt.setRotationX(aVar.f1824f.f1932c);
                        childAt.setRotationY(aVar.f1824f.f1933d);
                        childAt.setScaleX(aVar.f1824f.f1934e);
                        childAt.setScaleY(aVar.f1824f.f1935f);
                        C0023e eVar = aVar.f1824f;
                        if (eVar.f1938i != -1) {
                            View findViewById = ((View) childAt.getParent()).findViewById(aVar.f1824f.f1938i);
                            if (findViewById != null) {
                                float top = ((float) (findViewById.getTop() + findViewById.getBottom())) / 2.0f;
                                float left = ((float) (findViewById.getLeft() + findViewById.getRight())) / 2.0f;
                                if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                    childAt.setPivotX(left - ((float) childAt.getLeft()));
                                    childAt.setPivotY(top - ((float) childAt.getTop()));
                                }
                            }
                        } else {
                            if (!Float.isNaN(eVar.f1936g)) {
                                childAt.setPivotX(aVar.f1824f.f1936g);
                            }
                            if (!Float.isNaN(aVar.f1824f.f1937h)) {
                                childAt.setPivotY(aVar.f1824f.f1937h);
                            }
                        }
                        childAt.setTranslationX(aVar.f1824f.f1939j);
                        childAt.setTranslationY(aVar.f1824f.f1940k);
                        childAt.setTranslationZ(aVar.f1824f.f1941l);
                        C0023e eVar2 = aVar.f1824f;
                        if (eVar2.f1942m) {
                            childAt.setElevation(eVar2.f1943n);
                        }
                    }
                } else {
                    Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                }
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            a aVar3 = (a) this.f1818e.get(num);
            if (aVar3 != null) {
                if (aVar3.f1823e.f1885j0 == 1) {
                    a aVar4 = new a(constraintLayout.getContext());
                    aVar4.setId(num.intValue());
                    b bVar3 = aVar3.f1823e;
                    int[] iArr2 = bVar3.f1887k0;
                    if (iArr2 != null) {
                        aVar4.setReferencedIds(iArr2);
                    } else {
                        String str2 = bVar3.f1889l0;
                        if (str2 != null) {
                            bVar3.f1887k0 = h(aVar4, str2);
                            aVar4.setReferencedIds(aVar3.f1823e.f1887k0);
                        }
                    }
                    aVar4.setType(aVar3.f1823e.f1881h0);
                    aVar4.setMargin(aVar3.f1823e.f1883i0);
                    ConstraintLayout.b e2 = constraintLayout.generateDefaultLayoutParams();
                    aVar4.o();
                    aVar3.b(e2);
                    constraintLayout.addView(aVar4, e2);
                }
                if (aVar3.f1823e.f1866a) {
                    g gVar = new g(constraintLayout.getContext());
                    gVar.setId(num.intValue());
                    ConstraintLayout.b e3 = constraintLayout.generateDefaultLayoutParams();
                    aVar3.b(e3);
                    constraintLayout.addView(gVar, e3);
                }
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = constraintLayout.getChildAt(i3);
            if (childAt2 instanceof c) {
                ((c) childAt2).f(constraintLayout);
            }
        }
    }

    public void e(Context context, int i2) {
        f((ConstraintLayout) LayoutInflater.from(context).inflate(i2, (ViewGroup) null));
    }

    public void f(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        this.f1818e.clear();
        int i2 = 0;
        while (i2 < childCount) {
            View childAt = constraintLayout.getChildAt(i2);
            ConstraintLayout.b bVar = (ConstraintLayout.b) childAt.getLayoutParams();
            int id = childAt.getId();
            if (!this.f1817d || id != -1) {
                if (!this.f1818e.containsKey(Integer.valueOf(id))) {
                    this.f1818e.put(Integer.valueOf(id), new a());
                }
                a aVar = (a) this.f1818e.get(Integer.valueOf(id));
                if (aVar != null) {
                    aVar.f1825g = b.a(this.f1816c, childAt);
                    aVar.d(id, bVar);
                    aVar.f1821c.f1925b = childAt.getVisibility();
                    aVar.f1821c.f1927d = childAt.getAlpha();
                    aVar.f1824f.f1931b = childAt.getRotation();
                    aVar.f1824f.f1932c = childAt.getRotationX();
                    aVar.f1824f.f1933d = childAt.getRotationY();
                    aVar.f1824f.f1934e = childAt.getScaleX();
                    aVar.f1824f.f1935f = childAt.getScaleY();
                    float pivotX = childAt.getPivotX();
                    float pivotY = childAt.getPivotY();
                    if (!(((double) pivotX) == 0.0d && ((double) pivotY) == 0.0d)) {
                        C0023e eVar = aVar.f1824f;
                        eVar.f1936g = pivotX;
                        eVar.f1937h = pivotY;
                    }
                    aVar.f1824f.f1939j = childAt.getTranslationX();
                    aVar.f1824f.f1940k = childAt.getTranslationY();
                    aVar.f1824f.f1941l = childAt.getTranslationZ();
                    C0023e eVar2 = aVar.f1824f;
                    if (eVar2.f1942m) {
                        eVar2.f1943n = childAt.getElevation();
                    }
                    if (childAt instanceof a) {
                        a aVar2 = (a) childAt;
                        aVar.f1823e.f1897p0 = aVar2.getAllowsGoneWidget();
                        aVar.f1823e.f1887k0 = aVar2.getReferencedIds();
                        aVar.f1823e.f1881h0 = aVar2.getType();
                        aVar.f1823e.f1883i0 = aVar2.getMargin();
                    }
                }
                i2++;
            } else {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
        }
    }

    public void g(int i2, int i3, int i4, float f2) {
        b bVar = j(i2).f1823e;
        bVar.f1841B = i3;
        bVar.f1842C = i4;
        bVar.f1843D = f2;
    }

    public void k(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    a i3 = i(context, Xml.asAttributeSet(xml), false);
                    if (name.equalsIgnoreCase("Guideline")) {
                        i3.f1823e.f1866a = true;
                    }
                    this.f1818e.put(Integer.valueOf(i3.f1819a), i3);
                }
            }
        } catch (XmlPullParserException e2) {
            e2.printStackTrace();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:119:0x01cf, code lost:
        continue;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void l(android.content.Context r10, org.xmlpull.v1.XmlPullParser r11) {
        /*
            r9 = this;
            int r0 = r11.getEventType()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1 = 0
            r2 = r1
        L_0x0006:
            r3 = 1
            if (r0 == r3) goto L_0x01dc
            if (r0 == 0) goto L_0x01cc
            r4 = -1
            r5 = 3
            r6 = 2
            r7 = 0
            if (r0 == r6) goto L_0x006d
            if (r0 == r5) goto L_0x0015
            goto L_0x01cf
        L_0x0015:
            java.lang.String r0 = r11.getName()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.util.Locale r8 = java.util.Locale.ROOT     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r0 = r0.toLowerCase(r8)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r8 = r0.hashCode()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            switch(r8) {
                case -2075718416: goto L_0x004b;
                case -190376483: goto L_0x0041;
                case 426575017: goto L_0x0037;
                case 2146106725: goto L_0x0027;
                default: goto L_0x0026;
            }     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x0026:
            goto L_0x0054
        L_0x0027:
            java.lang.String r8 = "constraintset"
            boolean r0 = r0.equals(r8)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x0054
            r4 = 0
            goto L_0x0054
        L_0x0031:
            r10 = move-exception
            goto L_0x01d5
        L_0x0034:
            r10 = move-exception
            goto L_0x01d9
        L_0x0037:
            java.lang.String r7 = "constraintoverride"
            boolean r0 = r0.equals(r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x0054
            r4 = 2
            goto L_0x0054
        L_0x0041:
            java.lang.String r7 = "constraint"
            boolean r0 = r0.equals(r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x0054
            r4 = 1
            goto L_0x0054
        L_0x004b:
            java.lang.String r7 = "guideline"
            boolean r0 = r0.equals(r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x0054
            r4 = 3
        L_0x0054:
            if (r4 == 0) goto L_0x006c
            if (r4 == r3) goto L_0x005e
            if (r4 == r6) goto L_0x005e
            if (r4 == r5) goto L_0x005e
            goto L_0x01cf
        L_0x005e:
            java.util.HashMap r0 = r9.f1818e     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r3 = r2.f1819a     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.put(r3, r2)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r2 = r1
            goto L_0x01cf
        L_0x006c:
            return
        L_0x006d:
            java.lang.String r0 = r11.getName()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r8 = r0.hashCode()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            switch(r8) {
                case -2025855158: goto L_0x00d6;
                case -1984451626: goto L_0x00cc;
                case -1962203927: goto L_0x00c2;
                case -1269513683: goto L_0x00b8;
                case -1238332596: goto L_0x00ae;
                case -71750448: goto L_0x00a4;
                case 366511058: goto L_0x0099;
                case 1331510167: goto L_0x008f;
                case 1791837707: goto L_0x0084;
                case 1803088381: goto L_0x007a;
                default: goto L_0x0078;
            }     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x0078:
            goto L_0x00df
        L_0x007a:
            java.lang.String r5 = "Constraint"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 0
            goto L_0x00df
        L_0x0084:
            java.lang.String r5 = "CustomAttribute"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 8
            goto L_0x00df
        L_0x008f:
            java.lang.String r6 = "Barrier"
            boolean r0 = r0.equals(r6)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 3
            goto L_0x00df
        L_0x0099:
            java.lang.String r5 = "CustomMethod"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 9
            goto L_0x00df
        L_0x00a4:
            java.lang.String r5 = "Guideline"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 2
            goto L_0x00df
        L_0x00ae:
            java.lang.String r5 = "Transform"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 5
            goto L_0x00df
        L_0x00b8:
            java.lang.String r5 = "PropertySet"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 4
            goto L_0x00df
        L_0x00c2:
            java.lang.String r5 = "ConstraintOverride"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 1
            goto L_0x00df
        L_0x00cc:
            java.lang.String r5 = "Motion"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 7
            goto L_0x00df
        L_0x00d6:
            java.lang.String r5 = "Layout"
            boolean r0 = r0.equals(r5)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            if (r0 == 0) goto L_0x00df
            r4 = 6
        L_0x00df:
            java.lang.String r0 = "XML parser error must be within a Constraint "
            switch(r4) {
                case 0: goto L_0x01c3;
                case 1: goto L_0x01ba;
                case 2: goto L_0x01ab;
                case 3: goto L_0x019e;
                case 4: goto L_0x0179;
                case 5: goto L_0x0154;
                case 6: goto L_0x012e;
                case 7: goto L_0x0108;
                case 8: goto L_0x00e6;
                case 9: goto L_0x00e6;
                default: goto L_0x00e4;
            }
        L_0x00e4:
            goto L_0x01cf
        L_0x00e6:
            if (r2 == 0) goto L_0x00ef
            java.util.HashMap r0 = r2.f1825g     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.b.b(r10, r11, r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x00ef:
            java.lang.RuntimeException r10 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r11 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r11 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r10.<init>(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            throw r10     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x0108:
            if (r2 == 0) goto L_0x0115
            androidx.constraintlayout.widget.e$c r0 = r2.f1822d     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.b(r10, r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x0115:
            java.lang.RuntimeException r10 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r11 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r11 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r10.<init>(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            throw r10     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x012e:
            if (r2 == 0) goto L_0x013b
            androidx.constraintlayout.widget.e$b r0 = r2.f1823e     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.b(r10, r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x013b:
            java.lang.RuntimeException r10 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r11 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r11 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r10.<init>(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            throw r10     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x0154:
            if (r2 == 0) goto L_0x0160
            androidx.constraintlayout.widget.e$e r0 = r2.f1824f     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.b(r10, r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x0160:
            java.lang.RuntimeException r10 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r11 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r11 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r10.<init>(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            throw r10     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x0179:
            if (r2 == 0) goto L_0x0185
            androidx.constraintlayout.widget.e$d r0 = r2.f1821c     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            android.util.AttributeSet r3 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.b(r10, r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x0185:
            java.lang.RuntimeException r10 = new java.lang.RuntimeException     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.<init>()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r0)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            int r11 = r11.getLineNumber()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r1.append(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            java.lang.String r11 = r1.toString()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r10.<init>(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            throw r10     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x019e:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$a r2 = r9.i(r10, r0, r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$b r0 = r2.f1823e     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.f1885j0 = r3     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x01ab:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$a r2 = r9.i(r10, r0, r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$b r0 = r2.f1823e     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.f1866a = r3     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            r0.f1868b = r3     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x01ba:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$a r2 = r9.i(r10, r0, r3)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x01c3:
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r11)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            androidx.constraintlayout.widget.e$a r2 = r9.i(r10, r0, r7)     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x01cf
        L_0x01cc:
            r11.getName()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
        L_0x01cf:
            int r0 = r11.next()     // Catch:{ XmlPullParserException -> 0x0034, IOException -> 0x0031 }
            goto L_0x0006
        L_0x01d5:
            r10.printStackTrace()
            goto L_0x01dc
        L_0x01d9:
            r10.printStackTrace()
        L_0x01dc:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.e.l(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }
}
