package androidx.constraintlayout.widget;

import android.util.SparseIntArray;
import java.util.HashMap;

public class j {

    /* renamed from: a  reason: collision with root package name */
    private SparseIntArray f2026a = new SparseIntArray();

    /* renamed from: b  reason: collision with root package name */
    private HashMap f2027b = new HashMap();
}
