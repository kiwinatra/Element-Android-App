package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import p.C0264a;
import p.e;

public class a extends c {

    /* renamed from: j  reason: collision with root package name */
    private int f1766j;

    /* renamed from: k  reason: collision with root package name */
    private int f1767k;

    /* renamed from: l  reason: collision with root package name */
    private C0264a f1768l;

    public a(Context context) {
        super(context);
        super.setVisibility(8);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x000f, code lost:
        if (r6 == 6) goto L_0x0011;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0019, code lost:
        if (r6 == 6) goto L_0x000c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:14:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void p(p.e r4, int r5, boolean r6) {
        /*
            r3 = this;
            r3.f1767k = r5
            r5 = 0
            r0 = 6
            r1 = 1
            r2 = 5
            if (r6 == 0) goto L_0x0014
            int r6 = r3.f1766j
            if (r6 != r2) goto L_0x000f
        L_0x000c:
            r3.f1767k = r1
            goto L_0x001c
        L_0x000f:
            if (r6 != r0) goto L_0x001c
        L_0x0011:
            r3.f1767k = r5
            goto L_0x001c
        L_0x0014:
            int r6 = r3.f1766j
            if (r6 != r2) goto L_0x0019
            goto L_0x0011
        L_0x0019:
            if (r6 != r0) goto L_0x001c
            goto L_0x000c
        L_0x001c:
            boolean r5 = r4 instanceof p.C0264a
            if (r5 == 0) goto L_0x0027
            p.a r4 = (p.C0264a) r4
            int r5 = r3.f1767k
            r4.A1(r5)
        L_0x0027:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.a.p(p.e, int, boolean):void");
    }

    public boolean getAllowsGoneWidget() {
        return this.f1768l.u1();
    }

    public int getMargin() {
        return this.f1768l.w1();
    }

    public int getType() {
        return this.f1766j;
    }

    /* access modifiers changed from: protected */
    public void i(AttributeSet attributeSet) {
        super.i(attributeSet);
        this.f1768l = new C0264a();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.n1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.D1) {
                    setType(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.C1) {
                    this.f1768l.z1(obtainStyledAttributes.getBoolean(index, true));
                } else if (index == i.E1) {
                    this.f1768l.B1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1790d = this.f1768l;
        o();
    }

    public void j(e eVar, boolean z2) {
        p(eVar, this.f1766j, z2);
    }

    public void setAllowsGoneWidget(boolean z2) {
        this.f1768l.z1(z2);
    }

    public void setDpMargin(int i2) {
        C0264a aVar = this.f1768l;
        aVar.B1((int) ((((float) i2) * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i2) {
        this.f1768l.B1(i2);
    }

    public void setType(int i2) {
        this.f1766j = i2;
    }
}
