package androidx.core.os;

import android.os.LocaleList;

public abstract /* synthetic */ class j {
    public static /* bridge */ /* synthetic */ LocaleList a(Object obj) {
        return (LocaleList) obj;
    }
}
