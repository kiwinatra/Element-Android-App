package androidx.core.os;

import java.util.Locale;

interface d {
    Object a();

    String b();

    Locale get(int i2);

    boolean isEmpty();

    int size();
}
