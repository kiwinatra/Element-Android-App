package androidx.core.os;

public abstract /* synthetic */ class g {
}
