package androidx.core.os;

import android.os.LocaleList;
import java.util.Locale;

final class k implements d {

    /* renamed from: a  reason: collision with root package name */
    private final LocaleList f2248a;

    k(Object obj) {
        this.f2248a = j.a(obj);
    }

    public Object a() {
        return this.f2248a;
    }

    public String b() {
        return this.f2248a.toLanguageTags();
    }

    public boolean equals(Object obj) {
        return this.f2248a.equals(((d) obj).a());
    }

    public Locale get(int i2) {
        return this.f2248a.get(i2);
    }

    public int hashCode() {
        return this.f2248a.hashCode();
    }

    public boolean isEmpty() {
        return this.f2248a.isEmpty();
    }

    public int size() {
        return this.f2248a.size();
    }

    public String toString() {
        return this.f2248a.toString();
    }
}
