package androidx.core.app;

import R.a;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements a {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f2083a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f2084b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f2085c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f2086d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f2087e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f2088f;
}
