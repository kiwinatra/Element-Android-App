package androidx.core.app;

import android.content.res.Configuration;
import w0.i;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    private final boolean f2112a;

    /* renamed from: b  reason: collision with root package name */
    private Configuration f2113b;

    public g(boolean z2) {
        this.f2112a = z2;
    }

    public final boolean a() {
        return this.f2112a;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public g(boolean z2, Configuration configuration) {
        this(z2);
        i.e(configuration, "newConfig");
        this.f2113b = configuration;
    }
}
