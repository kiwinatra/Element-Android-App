package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import androidx.core.content.a;

public abstract class b extends a {
    public static void h(Activity activity) {
        activity.finishAffinity();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void i(Activity activity) {
        if (!activity.isFinishing() && !c.i(activity)) {
            activity.recreate();
        }
    }

    public static void j(Activity activity) {
        if (Build.VERSION.SDK_INT >= 28) {
            activity.recreate();
        } else {
            new Handler(activity.getMainLooper()).post(new a(activity));
        }
    }
}
