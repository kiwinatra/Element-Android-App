package androidx.core.app;

import android.content.res.Configuration;
import w0.i;

public final class k {

    /* renamed from: a  reason: collision with root package name */
    private final boolean f2114a;

    /* renamed from: b  reason: collision with root package name */
    private Configuration f2115b;

    public k(boolean z2) {
        this.f2114a = z2;
    }

    public final boolean a() {
        return this.f2114a;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public k(boolean z2, Configuration configuration) {
        this(z2);
        i.e(configuration, "newConfig");
        this.f2115b = configuration;
    }
}
