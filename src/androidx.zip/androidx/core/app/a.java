package androidx.core.app;

import android.app.Activity;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Activity f2089a;

    public /* synthetic */ a(Activity activity) {
        this.f2089a = activity;
    }

    public final void run() {
        b.i(this.f2089a);
    }
}
