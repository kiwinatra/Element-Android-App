package androidx.core.app;

import x.C0290a;

public interface i {
    void c(C0290a aVar);

    void g(C0290a aVar);
}
