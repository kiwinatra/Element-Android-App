package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import androidx.core.view.C0158t;
import androidx.lifecycle.C0190g;
import androidx.lifecycle.l;
import androidx.lifecycle.m;
import androidx.lifecycle.u;
import l.g;
import w0.i;

public abstract class f extends Activity implements l, C0158t.a {

    /* renamed from: a  reason: collision with root package name */
    private final g f2110a = new g();

    /* renamed from: b  reason: collision with root package name */
    private final m f2111b = new m(this);

    private final boolean y(String[] strArr) {
        if (strArr == null || strArr.length == 0) {
            return false;
        }
        String str = strArr[0];
        switch (str.hashCode()) {
            case -645125871:
                return str.equals("--translation") && Build.VERSION.SDK_INT >= 31;
            case 100470631:
                if (!str.equals("--dump-dumpable")) {
                    return false;
                }
                break;
            case 472614934:
                if (!str.equals("--list-dumpables")) {
                    return false;
                }
                break;
            case 1159329357:
                return str.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29;
            case 1455016274:
                return str.equals("--autofill") && Build.VERSION.SDK_INT >= 26;
            default:
                return false;
        }
        return Build.VERSION.SDK_INT >= 33;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        i.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        i.d(decorView, "window.decorView");
        if (C0158t.d(decorView, keyEvent)) {
            return true;
        }
        return C0158t.e(this, decorView, this, keyEvent);
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        i.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        i.d(decorView, "window.decorView");
        if (C0158t.d(decorView, keyEvent)) {
            return true;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    public boolean n(KeyEvent keyEvent) {
        i.e(keyEvent, "event");
        return super.dispatchKeyEvent(keyEvent);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        u.f3182b.c(this);
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle bundle) {
        i.e(bundle, "outState");
        this.f2111b.m(C0190g.b.CREATED);
        super.onSaveInstanceState(bundle);
    }

    /* access modifiers changed from: protected */
    public final boolean x(String[] strArr) {
        return !y(strArr);
    }
}
