package androidx.core.app;

import x.C0290a;

public interface j {
    void b(C0290a aVar);

    void i(C0290a aVar);
}
