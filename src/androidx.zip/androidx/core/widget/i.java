package androidx.core.widget;

public abstract /* synthetic */ class i {
}
