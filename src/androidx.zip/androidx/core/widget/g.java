package androidx.core.widget;

import android.widget.ListView;

public abstract class g {
    public static boolean a(ListView listView, int i2) {
        return listView.canScrollList(i2);
    }
}
