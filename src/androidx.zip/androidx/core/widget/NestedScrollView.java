package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.core.view.A;
import androidx.core.view.B;
import androidx.core.view.C0121a;
import androidx.core.view.C0149o;
import androidx.core.view.C0151p;
import androidx.core.view.D;
import androidx.core.view.E;
import androidx.core.view.W;
import java.util.ArrayList;
import t.C0283a;
import y.I;
import y.K;

public class NestedScrollView extends FrameLayout implements D {

    /* renamed from: D  reason: collision with root package name */
    private static final float f2457D = ((float) (Math.log(0.78d) / Math.log(0.9d)));

    /* renamed from: E  reason: collision with root package name */
    private static final a f2458E = new a();

    /* renamed from: F  reason: collision with root package name */
    private static final int[] f2459F = {16843130};

    /* renamed from: A  reason: collision with root package name */
    private d f2460A;

    /* renamed from: B  reason: collision with root package name */
    final c f2461B;

    /* renamed from: C  reason: collision with root package name */
    C0149o f2462C;

    /* renamed from: a  reason: collision with root package name */
    private final float f2463a;

    /* renamed from: b  reason: collision with root package name */
    private long f2464b;

    /* renamed from: c  reason: collision with root package name */
    private final Rect f2465c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public OverScroller f2466d;

    /* renamed from: e  reason: collision with root package name */
    public EdgeEffect f2467e;

    /* renamed from: f  reason: collision with root package name */
    public EdgeEffect f2468f;

    /* renamed from: g  reason: collision with root package name */
    private int f2469g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f2470h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f2471i;

    /* renamed from: j  reason: collision with root package name */
    private View f2472j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f2473k;

    /* renamed from: l  reason: collision with root package name */
    private VelocityTracker f2474l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f2475m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f2476n;

    /* renamed from: o  reason: collision with root package name */
    private int f2477o;

    /* renamed from: p  reason: collision with root package name */
    private int f2478p;

    /* renamed from: q  reason: collision with root package name */
    private int f2479q;

    /* renamed from: r  reason: collision with root package name */
    private int f2480r;

    /* renamed from: s  reason: collision with root package name */
    private final int[] f2481s;

    /* renamed from: t  reason: collision with root package name */
    private final int[] f2482t;

    /* renamed from: u  reason: collision with root package name */
    private int f2483u;

    /* renamed from: v  reason: collision with root package name */
    private int f2484v;

    /* renamed from: w  reason: collision with root package name */
    private e f2485w;

    /* renamed from: x  reason: collision with root package name */
    private final E f2486x;

    /* renamed from: y  reason: collision with root package name */
    private final B f2487y;

    /* renamed from: z  reason: collision with root package name */
    private float f2488z;

    static class a extends C0121a {
        a() {
        }

        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            K.a(accessibilityEvent, nestedScrollView.getScrollX());
            K.b(accessibilityEvent, nestedScrollView.getScrollRange());
        }

        public void g(View view, I i2) {
            int scrollRange;
            super.g(view, i2);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            i2.m0(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                i2.E0(true);
                if (nestedScrollView.getScrollY() > 0) {
                    i2.b(I.a.f6375r);
                    i2.b(I.a.f6342C);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    i2.b(I.a.f6374q);
                    i2.b(I.a.f6344E);
                }
            }
        }

        public boolean j(View view, int i2, Bundle bundle) {
            if (super.j(view, i2, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            int height = nestedScrollView.getHeight();
            Rect rect = new Rect();
            if (nestedScrollView.getMatrix().isIdentity() && nestedScrollView.getGlobalVisibleRect(rect)) {
                height = rect.height();
            }
            if (i2 != 4096) {
                if (i2 == 8192 || i2 == 16908344) {
                    int max = Math.max(nestedScrollView.getScrollY() - ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (max == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.W(0, max, true);
                    return true;
                } else if (i2 != 16908346) {
                    return false;
                }
            }
            int min = Math.min(nestedScrollView.getScrollY() + ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (min == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.W(0, min, true);
            return true;
        }
    }

    static class b {
        static boolean a(ViewGroup viewGroup) {
            return viewGroup.getClipToPadding();
        }
    }

    class c implements C0151p {
        c() {
        }

        public boolean a(float f2) {
            if (f2 == 0.0f) {
                return false;
            }
            c();
            NestedScrollView.this.v((int) f2);
            return true;
        }

        public float b() {
            return -NestedScrollView.this.getVerticalScrollFactorCompat();
        }

        public void c() {
            NestedScrollView.this.f2466d.abortAnimation();
        }
    }

    public interface d {
        void a(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5);
    }

    static class e extends View.BaseSavedState {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: a  reason: collision with root package name */
        public int f2490a;

        class a implements Parcelable.Creator {
            a() {
            }

            /* renamed from: a */
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            /* renamed from: b */
            public e[] newArray(int i2) {
                return new e[i2];
            }
        }

        e(Parcel parcel) {
            super(parcel);
            this.f2490a = parcel.readInt();
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f2490a + "}";
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f2490a);
        }

        e(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0283a.nestedScrollViewStyle);
    }

    private void A() {
        VelocityTracker velocityTracker = this.f2474l;
        if (velocityTracker == null) {
            this.f2474l = VelocityTracker.obtain();
        } else {
            velocityTracker.clear();
        }
    }

    private void B() {
        this.f2466d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f2477o = viewConfiguration.getScaledTouchSlop();
        this.f2478p = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2479q = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    private void C() {
        if (this.f2474l == null) {
            this.f2474l = VelocityTracker.obtain();
        }
    }

    private void D(int i2, int i3) {
        this.f2469g = i2;
        this.f2480r = i3;
        X(2, 0);
    }

    private boolean E(View view) {
        return !G(view, 0, getHeight());
    }

    private static boolean F(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && F((View) parent, view2);
    }

    private boolean G(View view, int i2, int i3) {
        view.getDrawingRect(this.f2465c);
        offsetDescendantRectToMyCoords(view, this.f2465c);
        return this.f2465c.bottom + i2 >= getScrollY() && this.f2465c.top - i2 <= getScrollY() + i3;
    }

    private void H(int i2, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i2);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f2487y.e(0, scrollY2, 0, i2 - scrollY2, (int[]) null, i3, iArr);
    }

    private void I(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f2480r) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f2469g = (int) motionEvent.getY(i2);
            this.f2480r = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.f2474l;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    private void L() {
        VelocityTracker velocityTracker = this.f2474l;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f2474l = null;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x005e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int M(int r4, float r5) {
        /*
            r3 = this;
            int r0 = r3.getWidth()
            float r0 = (float) r0
            float r5 = r5 / r0
            float r4 = (float) r4
            int r0 = r3.getHeight()
            float r0 = (float) r0
            float r4 = r4 / r0
            android.widget.EdgeEffect r0 = r3.f2467e
            float r0 = androidx.core.widget.d.b(r0)
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x0031
            android.widget.EdgeEffect r0 = r3.f2467e
            float r4 = -r4
            float r4 = androidx.core.widget.d.d(r0, r4, r5)
            float r4 = -r4
            android.widget.EdgeEffect r5 = r3.f2467e
            float r5 = androidx.core.widget.d.b(r5)
            int r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r5 != 0) goto L_0x002f
            android.widget.EdgeEffect r5 = r3.f2467e
        L_0x002c:
            r5.onRelease()
        L_0x002f:
            r1 = r4
            goto L_0x0051
        L_0x0031:
            android.widget.EdgeEffect r0 = r3.f2468f
            float r0 = androidx.core.widget.d.b(r0)
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 == 0) goto L_0x0051
            android.widget.EdgeEffect r0 = r3.f2468f
            r2 = 1065353216(0x3f800000, float:1.0)
            float r2 = r2 - r5
            float r4 = androidx.core.widget.d.d(r0, r4, r2)
            android.widget.EdgeEffect r5 = r3.f2468f
            float r5 = androidx.core.widget.d.b(r5)
            int r5 = (r5 > r1 ? 1 : (r5 == r1 ? 0 : -1))
            if (r5 != 0) goto L_0x002f
            android.widget.EdgeEffect r5 = r3.f2468f
            goto L_0x002c
        L_0x0051:
            int r4 = r3.getHeight()
            float r4 = (float) r4
            float r1 = r1 * r4
            int r4 = java.lang.Math.round(r1)
            if (r4 == 0) goto L_0x0061
            r3.invalidate()
        L_0x0061:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.M(int, float):int");
    }

    private void N(boolean z2) {
        if (z2) {
            X(2, 1);
        } else {
            Z(1);
        }
        this.f2484v = getScrollY();
        postInvalidateOnAnimation();
    }

    private boolean O(int i2, int i3, int i4) {
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = height + scrollY;
        boolean z2 = false;
        boolean z3 = i2 == 33;
        View u2 = u(z3, i3, i4);
        if (u2 == null) {
            u2 = this;
        }
        if (i3 < scrollY || i4 > i5) {
            P(z3 ? i3 - scrollY : i4 - i5, 0, 1, true);
            z2 = true;
        }
        if (u2 != findFocus()) {
            u2.requestFocus(i2);
        }
        return z2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x00e8  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00fa  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int P(int r22, int r23, int r24, boolean r25) {
        /*
            r21 = this;
            r10 = r21
            r11 = r23
            r12 = r24
            r13 = 1
            if (r12 != r13) goto L_0x000d
            r0 = 2
            r10.X(r0, r12)
        L_0x000d:
            int[] r3 = r10.f2482t
            int[] r4 = r10.f2481s
            r1 = 0
            r0 = r21
            r2 = r22
            r5 = r24
            boolean r0 = r0.l(r1, r2, r3, r4, r5)
            r14 = 0
            if (r0 == 0) goto L_0x002d
            int[] r0 = r10.f2482t
            r0 = r0[r13]
            int r0 = r22 - r0
            int[] r1 = r10.f2481s
            r1 = r1[r13]
            r15 = r0
            r16 = r1
            goto L_0x0031
        L_0x002d:
            r15 = r22
            r16 = 0
        L_0x0031:
            int r17 = r21.getScrollY()
            int r9 = r21.getScrollRange()
            boolean r0 = r21.d()
            if (r0 == 0) goto L_0x0044
            if (r25 != 0) goto L_0x0044
            r18 = 1
            goto L_0x0046
        L_0x0044:
            r18 = 0
        L_0x0046:
            r8 = 0
            r19 = 1
            r1 = 0
            r3 = 0
            r5 = 0
            r7 = 0
            r0 = r21
            r2 = r15
            r4 = r17
            r6 = r9
            r20 = r9
            r9 = r19
            boolean r0 = r0.J(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            if (r0 == 0) goto L_0x0065
            boolean r0 = r10.y(r12)
            if (r0 != 0) goto L_0x0065
            r8 = 1
            goto L_0x0066
        L_0x0065:
            r8 = 0
        L_0x0066:
            int r0 = r21.getScrollY()
            int r2 = r0 - r17
            int r4 = r15 - r2
            int[] r7 = r10.f2482t
            r7[r13] = r14
            r3 = 0
            int[] r5 = r10.f2481s
            r1 = 0
            r0 = r21
            r6 = r24
            r0.p(r1, r2, r3, r4, r5, r6, r7)
            int[] r0 = r10.f2481s
            r0 = r0[r13]
            int r16 = r16 + r0
            int[] r0 = r10.f2482t
            r0 = r0[r13]
            int r15 = r15 - r0
            int r0 = r17 + r15
            if (r0 >= 0) goto L_0x00b0
            if (r18 == 0) goto L_0x00d7
            android.widget.EdgeEffect r0 = r10.f2467e
            int r1 = -r15
            float r1 = (float) r1
            int r2 = r21.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = (float) r11
            int r3 = r21.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            androidx.core.widget.d.d(r0, r1, r2)
            android.widget.EdgeEffect r0 = r10.f2468f
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x00d7
            android.widget.EdgeEffect r0 = r10.f2468f
        L_0x00ac:
            r0.onRelease()
            goto L_0x00d7
        L_0x00b0:
            r1 = r20
            if (r0 <= r1) goto L_0x00d7
            if (r18 == 0) goto L_0x00d7
            android.widget.EdgeEffect r0 = r10.f2468f
            float r1 = (float) r15
            int r2 = r21.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = (float) r11
            int r3 = r21.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            r3 = 1065353216(0x3f800000, float:1.0)
            float r3 = r3 - r2
            androidx.core.widget.d.d(r0, r1, r3)
            android.widget.EdgeEffect r0 = r10.f2467e
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x00d7
            android.widget.EdgeEffect r0 = r10.f2467e
            goto L_0x00ac
        L_0x00d7:
            android.widget.EdgeEffect r0 = r10.f2467e
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x00ea
            android.widget.EdgeEffect r0 = r10.f2468f
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x00e8
            goto L_0x00ea
        L_0x00e8:
            r14 = r8
            goto L_0x00ed
        L_0x00ea:
            r21.postInvalidateOnAnimation()
        L_0x00ed:
            if (r14 == 0) goto L_0x00f8
            if (r12 != 0) goto L_0x00f8
            android.view.VelocityTracker r0 = r10.f2474l
            if (r0 == 0) goto L_0x00f8
            r0.clear()
        L_0x00f8:
            if (r12 != r13) goto L_0x0107
            r10.Z(r12)
            android.widget.EdgeEffect r0 = r10.f2467e
            r0.onRelease()
            android.widget.EdgeEffect r0 = r10.f2468f
            r0.onRelease()
        L_0x0107:
            return r16
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.P(int, int, int, boolean):int");
    }

    private void Q(View view) {
        view.getDrawingRect(this.f2465c);
        offsetDescendantRectToMyCoords(view, this.f2465c);
        int g2 = g(this.f2465c);
        if (g2 != 0) {
            scrollBy(0, g2);
        }
    }

    private boolean R(Rect rect, boolean z2) {
        int g2 = g(rect);
        boolean z3 = g2 != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, g2);
            } else {
                T(0, g2);
            }
        }
        return z3;
    }

    private boolean S(EdgeEffect edgeEffect, int i2) {
        if (i2 > 0) {
            return true;
        }
        return x(-i2) < d.b(edgeEffect) * ((float) getHeight());
    }

    private void U(int i2, int i3, int i4, boolean z2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f2464b > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f2466d;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, i4);
                N(z2);
            } else {
                if (!this.f2466d.isFinished()) {
                    a();
                }
                scrollBy(i2, i3);
            }
            this.f2464b = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    private boolean Y(MotionEvent motionEvent) {
        boolean z2;
        if (d.b(this.f2467e) != 0.0f) {
            d.d(this.f2467e, 0.0f, motionEvent.getX() / ((float) getWidth()));
            z2 = true;
        } else {
            z2 = false;
        }
        if (d.b(this.f2468f) == 0.0f) {
            return z2;
        }
        d.d(this.f2468f, 0.0f, 1.0f - (motionEvent.getX() / ((float) getWidth())));
        return true;
    }

    private void a() {
        this.f2466d.abortAnimation();
        Z(1);
    }

    private boolean d() {
        int overScrollMode = getOverScrollMode();
        if (overScrollMode != 0) {
            return overScrollMode == 1 && getScrollRange() > 0;
        }
        return true;
    }

    private boolean e() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom();
    }

    private static int f(int i2, int i3, int i4) {
        if (i3 >= i4 || i2 < 0) {
            return 0;
        }
        return i3 + i2 > i4 ? i4 - i3 : i2;
    }

    private void q(int i2) {
        if (i2 == 0) {
            return;
        }
        if (this.f2476n) {
            T(0, i2);
        } else {
            scrollBy(0, i2);
        }
    }

    private boolean r(int i2) {
        EdgeEffect edgeEffect;
        if (d.b(this.f2467e) != 0.0f) {
            if (S(this.f2467e, i2)) {
                edgeEffect = this.f2467e;
            } else {
                i2 = -i2;
                v(i2);
                return true;
            }
        } else if (d.b(this.f2468f) == 0.0f) {
            return false;
        } else {
            i2 = -i2;
            if (S(this.f2468f, i2)) {
                edgeEffect = this.f2468f;
            }
            v(i2);
            return true;
        }
        edgeEffect.onAbsorb(i2);
        return true;
    }

    private void s() {
        this.f2480r = -1;
        this.f2473k = false;
        L();
        Z(0);
        this.f2467e.onRelease();
        this.f2468f.onRelease();
    }

    private View u(boolean z2, int i2, int i3) {
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view2 = focusables.get(i4);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i2 < bottom && top < i3) {
                boolean z4 = i2 < top && bottom < i3;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        return view;
    }

    private float x(int i2) {
        double log = Math.log((double) ((((float) Math.abs(i2)) * 0.35f) / (this.f2463a * 0.015f)));
        float f2 = f2457D;
        return (float) (((double) (this.f2463a * 0.015f)) * Math.exp((((double) f2) / (((double) f2) - 1.0d)) * log));
    }

    private boolean z(int i2, int i3) {
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View childAt = getChildAt(0);
        return i3 >= childAt.getTop() - scrollY && i3 < childAt.getBottom() - scrollY && i2 >= childAt.getLeft() && i2 < childAt.getRight();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x0083 A[ADDED_TO_REGION] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean J(int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20, boolean r21) {
        /*
            r12 = this;
            r0 = r12
            int r1 = r12.getOverScrollMode()
            int r2 = r12.computeHorizontalScrollRange()
            int r3 = r12.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0013
            r2 = 1
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            int r3 = r12.computeVerticalScrollRange()
            int r6 = r12.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = 0
        L_0x0021:
            if (r1 == 0) goto L_0x002a
            if (r1 != r5) goto L_0x0028
            if (r2 == 0) goto L_0x0028
            goto L_0x002a
        L_0x0028:
            r2 = 0
            goto L_0x002b
        L_0x002a:
            r2 = 1
        L_0x002b:
            if (r1 == 0) goto L_0x0034
            if (r1 != r5) goto L_0x0032
            if (r3 == 0) goto L_0x0032
            goto L_0x0034
        L_0x0032:
            r1 = 0
            goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            int r3 = r15 + r13
            if (r2 != 0) goto L_0x003b
            r2 = 0
            goto L_0x003d
        L_0x003b:
            r2 = r19
        L_0x003d:
            int r6 = r16 + r14
            if (r1 != 0) goto L_0x0043
            r1 = 0
            goto L_0x0045
        L_0x0043:
            r1 = r20
        L_0x0045:
            int r7 = -r2
            int r2 = r2 + r17
            int r8 = -r1
            int r1 = r1 + r18
            if (r3 <= r2) goto L_0x0050
            r3 = r2
        L_0x004e:
            r2 = 1
            goto L_0x0055
        L_0x0050:
            if (r3 >= r7) goto L_0x0054
            r3 = r7
            goto L_0x004e
        L_0x0054:
            r2 = 0
        L_0x0055:
            if (r6 <= r1) goto L_0x005a
            r6 = r1
        L_0x0058:
            r1 = 1
            goto L_0x005f
        L_0x005a:
            if (r6 >= r8) goto L_0x005e
            r6 = r8
            goto L_0x0058
        L_0x005e:
            r1 = 0
        L_0x005f:
            if (r1 == 0) goto L_0x007e
            boolean r7 = r12.y(r5)
            if (r7 != 0) goto L_0x007e
            android.widget.OverScroller r7 = r0.f2466d
            r8 = 0
            int r9 = r12.getScrollRange()
            r10 = 0
            r11 = 0
            r13 = r7
            r14 = r3
            r15 = r6
            r16 = r10
            r17 = r11
            r18 = r8
            r19 = r9
            r13.springBack(r14, r15, r16, r17, r18, r19)
        L_0x007e:
            r12.onOverScrolled(r3, r6, r2, r1)
            if (r2 != 0) goto L_0x0085
            if (r1 == 0) goto L_0x0086
        L_0x0085:
            r4 = 1
        L_0x0086:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.J(int, int, int, int, int, int, int, int, boolean):boolean");
    }

    public boolean K(int i2) {
        boolean z2 = i2 == 130;
        int height = getHeight();
        if (z2) {
            this.f2465c.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
                Rect rect = this.f2465c;
                if (rect.top + height > bottom) {
                    rect.top = bottom - height;
                }
            }
        } else {
            this.f2465c.top = getScrollY() - height;
            Rect rect2 = this.f2465c;
            if (rect2.top < 0) {
                rect2.top = 0;
            }
        }
        Rect rect3 = this.f2465c;
        int i3 = rect3.top;
        int i4 = height + i3;
        rect3.bottom = i4;
        return O(i2, i3, i4);
    }

    public final void T(int i2, int i3) {
        U(i2, i3, 250, false);
    }

    /* access modifiers changed from: package-private */
    public void V(int i2, int i3, int i4, boolean z2) {
        U(i2 - getScrollX(), i3 - getScrollY(), i4, z2);
    }

    /* access modifiers changed from: package-private */
    public void W(int i2, int i3, boolean z2) {
        V(i2, i3, 250, z2);
    }

    public boolean X(int i2, int i3) {
        return this.f2487y.p(i2, i3);
    }

    public void Z(int i2) {
        this.f2487y.r(i2);
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public boolean c(int i2) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !G(findNextFocus, maxScrollAmount, getHeight())) {
            if (i2 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i2 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            P(maxScrollAmount, 0, 1, true);
        } else {
            findNextFocus.getDrawingRect(this.f2465c);
            offsetDescendantRectToMyCoords(findNextFocus, this.f2465c);
            P(g(this.f2465c), 0, 1, true);
            findNextFocus.requestFocus(i2);
        }
        if (findFocus != null && findFocus.isFocused() && E(findFocus)) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.f2466d.isFinished()) {
            this.f2466d.computeScrollOffset();
            int currY = this.f2466d.getCurrY();
            int k2 = k(currY - this.f2484v);
            this.f2484v = currY;
            int[] iArr = this.f2482t;
            iArr[1] = 0;
            l(0, k2, iArr, (int[]) null, 1);
            int i2 = k2 - this.f2482t[1];
            int scrollRange = getScrollRange();
            if (i2 != 0) {
                int scrollY = getScrollY();
                J(0, i2, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i2 - scrollY2;
                int[] iArr2 = this.f2482t;
                iArr2[1] = 0;
                p(0, scrollY2, 0, i3, this.f2481s, 1, iArr2);
                i2 = i3 - this.f2482t[1];
            }
            if (i2 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i2 < 0) {
                        if (this.f2467e.isFinished()) {
                            edgeEffect = this.f2467e;
                        }
                    } else if (this.f2468f.isFinished()) {
                        edgeEffect = this.f2468f;
                    }
                    edgeEffect.onAbsorb((int) this.f2466d.getCurrVelocity());
                }
                a();
            }
            if (!this.f2466d.isFinished()) {
                postInvalidateOnAnimation();
            } else {
                Z(1);
            }
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || t(keyEvent);
    }

    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return this.f2487y.a(f2, f3, z2);
    }

    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.f2487y.b(f2, f3);
    }

    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return l(i2, i3, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.f2487y.f(i2, i3, i4, i5, iArr);
    }

    public void draw(Canvas canvas) {
        int i2;
        super.draw(canvas);
        int scrollY = getScrollY();
        int i3 = 0;
        if (!this.f2467e.isFinished()) {
            int save = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int min = Math.min(0, scrollY);
            if (b.a(this)) {
                width -= getPaddingLeft() + getPaddingRight();
                i2 = getPaddingLeft();
            } else {
                i2 = 0;
            }
            if (b.a(this)) {
                height -= getPaddingTop() + getPaddingBottom();
                min += getPaddingTop();
            }
            canvas.translate((float) i2, (float) min);
            this.f2467e.setSize(width, height);
            if (this.f2467e.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save);
        }
        if (!this.f2468f.isFinished()) {
            int save2 = canvas.save();
            int width2 = getWidth();
            int height2 = getHeight();
            int max = Math.max(getScrollRange(), scrollY) + height2;
            if (b.a(this)) {
                width2 -= getPaddingLeft() + getPaddingRight();
                i3 = getPaddingLeft();
            }
            if (b.a(this)) {
                height2 -= getPaddingTop() + getPaddingBottom();
                max -= getPaddingBottom();
            }
            canvas.translate((float) (i3 - width2), (float) max);
            canvas.rotate(180.0f, (float) width2, 0.0f);
            this.f2468f.setSize(width2, height2);
            if (this.f2468f.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(save2);
        }
    }

    /* access modifiers changed from: protected */
    public int g(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i2 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i3 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i2 - verticalFadingEdgeLength : i2;
        int i4 = rect.bottom;
        if (i4 > i3 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i3, (childAt.getBottom() + layoutParams.bottomMargin) - i2);
        } else if (rect.top >= scrollY || i4 >= i3) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i3 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    /* access modifiers changed from: protected */
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        return this.f2486x.a();
    }

    /* access modifiers changed from: package-private */
    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    /* access modifiers changed from: protected */
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    /* access modifiers changed from: package-private */
    public float getVerticalScrollFactorCompat() {
        if (this.f2488z == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f2488z = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f2488z;
    }

    public void h(View view, View view2, int i2, int i3) {
        this.f2486x.c(view, view2, i2, i3);
        X(2, i3);
    }

    public boolean hasNestedScrollingParent() {
        return y(0);
    }

    public void i(View view, int i2) {
        this.f2486x.e(view, i2);
        Z(i2);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f2487y.l();
    }

    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        l(i2, i3, iArr, (int[]) null, i4);
    }

    /* access modifiers changed from: package-private */
    public int k(int i2) {
        int height = getHeight();
        if (i2 > 0 && d.b(this.f2467e) != 0.0f) {
            int round = Math.round((((float) (-height)) / 4.0f) * d.d(this.f2467e, (((float) (-i2)) * 4.0f) / ((float) height), 0.5f));
            if (round != i2) {
                this.f2467e.finish();
            }
            return i2 - round;
        } else if (i2 >= 0 || d.b(this.f2468f) == 0.0f) {
            return i2;
        } else {
            float f2 = (float) height;
            int round2 = Math.round((f2 / 4.0f) * d.d(this.f2468f, (((float) i2) * 4.0f) / f2, 0.5f));
            if (round2 != i2) {
                this.f2468f.finish();
            }
            return i2 - round2;
        }
    }

    public boolean l(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return this.f2487y.d(i2, i3, iArr, iArr2, i4);
    }

    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        H(i5, i6, iArr);
    }

    /* access modifiers changed from: protected */
    public void measureChild(View view, int i2, int i3) {
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* access modifiers changed from: protected */
    public void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        H(i5, i6, (int[]) null);
    }

    public boolean o(View view, View view2, int i2, int i3) {
        return (i2 & 2) != 0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2471i = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        int i2;
        float f2;
        int i3;
        if (motionEvent.getAction() == 8 && !this.f2473k) {
            if (A.a(motionEvent, 2)) {
                i3 = 9;
                f2 = motionEvent.getAxisValue(9);
                i2 = (int) motionEvent.getX();
            } else if (A.a(motionEvent, 4194304)) {
                f2 = motionEvent.getAxisValue(26);
                i2 = getWidth() / 2;
                i3 = 26;
            } else {
                i3 = 0;
                f2 = 0.0f;
                i2 = 0;
            }
            if (f2 != 0.0f) {
                P(-((int) (f2 * getVerticalScrollFactorCompat())), i2, 1, A.a(motionEvent, 8194));
                if (i3 != 0) {
                    this.f2462C.g(motionEvent, i3);
                }
                return true;
            }
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z2 = true;
        if (action == 2 && this.f2473k) {
            return true;
        }
        int i2 = action & 255;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 == 2) {
                    int i3 = this.f2480r;
                    if (i3 != -1) {
                        int findPointerIndex = motionEvent.findPointerIndex(i3);
                        if (findPointerIndex == -1) {
                            Log.e("NestedScrollView", "Invalid pointerId=" + i3 + " in onInterceptTouchEvent");
                        } else {
                            int y2 = (int) motionEvent.getY(findPointerIndex);
                            if (Math.abs(y2 - this.f2469g) > this.f2477o && (2 & getNestedScrollAxes()) == 0) {
                                this.f2473k = true;
                                this.f2469g = y2;
                                C();
                                this.f2474l.addMovement(motionEvent);
                                this.f2483u = 0;
                                ViewParent parent = getParent();
                                if (parent != null) {
                                    parent.requestDisallowInterceptTouchEvent(true);
                                }
                            }
                        }
                    }
                } else if (i2 != 3) {
                    if (i2 == 6) {
                        I(motionEvent);
                    }
                }
            }
            this.f2473k = false;
            this.f2480r = -1;
            L();
            if (this.f2466d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            Z(0);
        } else {
            int y3 = (int) motionEvent.getY();
            if (!z((int) motionEvent.getX(), y3)) {
                if (!Y(motionEvent) && this.f2466d.isFinished()) {
                    z2 = false;
                }
                this.f2473k = z2;
                L();
            } else {
                this.f2469g = y3;
                this.f2480r = motionEvent.getPointerId(0);
                A();
                this.f2474l.addMovement(motionEvent);
                this.f2466d.computeScrollOffset();
                if (!Y(motionEvent) && this.f2466d.isFinished()) {
                    z2 = false;
                }
                this.f2473k = z2;
                X(2, 0);
            }
        }
        return this.f2473k;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int i6 = 0;
        this.f2470h = false;
        View view = this.f2472j;
        if (view != null && F(view, this)) {
            Q(this.f2472j);
        }
        this.f2472j = null;
        if (!this.f2471i) {
            if (this.f2485w != null) {
                scrollTo(getScrollX(), this.f2485w.f2490a);
                this.f2485w = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i6 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int f2 = f(scrollY, paddingTop, i6);
            if (f2 != scrollY) {
                scrollTo(getScrollX(), f2);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f2471i = true;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f2475m && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(0.0f, f3, true);
        v((int) f3);
        return true;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        j(view, i2, i3, iArr, 0);
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        H(i5, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        h(view, view2, i2, 0);
    }

    /* access modifiers changed from: protected */
    public void onOverScrolled(int i2, int i3, boolean z2, boolean z3) {
        super.scrollTo(i2, i3);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        View findNextFocus = rect == null ? instance.findNextFocus(this, (View) null, i2) : instance.findNextFocusFromRect(this, rect, i2);
        if (findNextFocus != null && !E(findNextFocus)) {
            return findNextFocus.requestFocus(i2, rect);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof e)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        e eVar = (e) parcelable;
        super.onRestoreInstanceState(eVar.getSuperState());
        this.f2485w = eVar;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        e eVar = new e(super.onSaveInstanceState());
        eVar.f2490a = getScrollY();
        return eVar;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        d dVar = this.f2460A;
        if (dVar != null) {
            dVar.a(this, i2, i3, i4, i5);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && G(findFocus, 0, i5)) {
            findFocus.getDrawingRect(this.f2465c);
            offsetDescendantRectToMyCoords(findFocus, this.f2465c);
            q(g(this.f2465c));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return o(view, view2, i2, 0);
    }

    public void onStopNestedScroll(View view) {
        i(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x006e, code lost:
        if (r12.f2466d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0070;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x012a, code lost:
        if (r12.f2466d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0070;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r13) {
        /*
            r12 = this;
            r12.C()
            int r0 = r13.getActionMasked()
            r1 = 0
            if (r0 != 0) goto L_0x000c
            r12.f2483u = r1
        L_0x000c:
            android.view.MotionEvent r2 = android.view.MotionEvent.obtain(r13)
            int r3 = r12.f2483u
            float r3 = (float) r3
            r4 = 0
            r2.offsetLocation(r4, r3)
            r3 = 1
            if (r0 == 0) goto L_0x012e
            if (r0 == r3) goto L_0x00e6
            r4 = 2
            if (r0 == r4) goto L_0x0078
            r1 = 3
            if (r0 == r1) goto L_0x004f
            r1 = 5
            if (r0 == r1) goto L_0x003c
            r1 = 6
            if (r0 == r1) goto L_0x002a
            goto L_0x0159
        L_0x002a:
            r12.I(r13)
            int r0 = r12.f2480r
            int r0 = r13.findPointerIndex(r0)
            float r13 = r13.getY(r0)
            int r13 = (int) r13
            r12.f2469g = r13
            goto L_0x0159
        L_0x003c:
            int r0 = r13.getActionIndex()
            float r1 = r13.getY(r0)
            int r1 = (int) r1
            r12.f2469g = r1
            int r13 = r13.getPointerId(r0)
            r12.f2480r = r13
            goto L_0x0159
        L_0x004f:
            boolean r13 = r12.f2473k
            if (r13 == 0) goto L_0x0073
            int r13 = r12.getChildCount()
            if (r13 <= 0) goto L_0x0073
            android.widget.OverScroller r4 = r12.f2466d
            int r5 = r12.getScrollX()
            int r6 = r12.getScrollY()
            r9 = 0
            int r10 = r12.getScrollRange()
            r7 = 0
            r8 = 0
            boolean r13 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r13 == 0) goto L_0x0073
        L_0x0070:
            r12.postInvalidateOnAnimation()
        L_0x0073:
            r12.s()
            goto L_0x0159
        L_0x0078:
            int r0 = r12.f2480r
            int r0 = r13.findPointerIndex(r0)
            r4 = -1
            if (r0 != r4) goto L_0x00a0
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            java.lang.String r0 = "Invalid pointerId="
            r13.append(r0)
            int r0 = r12.f2480r
            r13.append(r0)
            java.lang.String r0 = " in onTouchEvent"
            r13.append(r0)
            java.lang.String r13 = r13.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r13)
            goto L_0x0159
        L_0x00a0:
            float r4 = r13.getY(r0)
            int r4 = (int) r4
            int r5 = r12.f2469g
            int r5 = r5 - r4
            float r6 = r13.getX(r0)
            int r6 = r12.M(r5, r6)
            int r5 = r5 - r6
            boolean r6 = r12.f2473k
            if (r6 != 0) goto L_0x00cf
            int r6 = java.lang.Math.abs(r5)
            int r7 = r12.f2477o
            if (r6 <= r7) goto L_0x00cf
            android.view.ViewParent r6 = r12.getParent()
            if (r6 == 0) goto L_0x00c6
            r6.requestDisallowInterceptTouchEvent(r3)
        L_0x00c6:
            r12.f2473k = r3
            int r6 = r12.f2477o
            if (r5 <= 0) goto L_0x00ce
            int r5 = r5 - r6
            goto L_0x00cf
        L_0x00ce:
            int r5 = r5 + r6
        L_0x00cf:
            boolean r6 = r12.f2473k
            if (r6 == 0) goto L_0x0159
            float r13 = r13.getX(r0)
            int r13 = (int) r13
            int r13 = r12.P(r5, r13, r1, r1)
            int r4 = r4 - r13
            r12.f2469g = r4
            int r0 = r12.f2483u
            int r0 = r0 + r13
            r12.f2483u = r0
            goto L_0x0159
        L_0x00e6:
            android.view.VelocityTracker r13 = r12.f2474l
            int r0 = r12.f2479q
            float r0 = (float) r0
            r1 = 1000(0x3e8, float:1.401E-42)
            r13.computeCurrentVelocity(r1, r0)
            int r0 = r12.f2480r
            float r13 = r13.getYVelocity(r0)
            int r13 = (int) r13
            int r0 = java.lang.Math.abs(r13)
            int r1 = r12.f2478p
            if (r0 < r1) goto L_0x0115
            boolean r0 = r12.r(r13)
            if (r0 != 0) goto L_0x0073
            int r13 = -r13
            float r0 = (float) r13
            boolean r1 = r12.dispatchNestedPreFling(r4, r0)
            if (r1 != 0) goto L_0x0073
            r12.dispatchNestedFling(r4, r0, r3)
            r12.v(r13)
            goto L_0x0073
        L_0x0115:
            android.widget.OverScroller r5 = r12.f2466d
            int r6 = r12.getScrollX()
            int r7 = r12.getScrollY()
            r10 = 0
            int r11 = r12.getScrollRange()
            r8 = 0
            r9 = 0
            boolean r13 = r5.springBack(r6, r7, r8, r9, r10, r11)
            if (r13 == 0) goto L_0x0073
            goto L_0x0070
        L_0x012e:
            int r0 = r12.getChildCount()
            if (r0 != 0) goto L_0x0135
            return r1
        L_0x0135:
            boolean r0 = r12.f2473k
            if (r0 == 0) goto L_0x0142
            android.view.ViewParent r0 = r12.getParent()
            if (r0 == 0) goto L_0x0142
            r0.requestDisallowInterceptTouchEvent(r3)
        L_0x0142:
            android.widget.OverScroller r0 = r12.f2466d
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x014d
            r12.a()
        L_0x014d:
            float r0 = r13.getY()
            int r0 = (int) r0
            int r13 = r13.getPointerId(r1)
            r12.D(r0, r13)
        L_0x0159:
            android.view.VelocityTracker r13 = r12.f2474l
            if (r13 == 0) goto L_0x0160
            r13.addMovement(r2)
        L_0x0160:
            r2.recycle()
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void p(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        this.f2487y.e(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f2470h) {
            Q(view2);
        } else {
            this.f2472j = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        return R(rect, z2);
    }

    public void requestDisallowInterceptTouchEvent(boolean z2) {
        if (z2) {
            L();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void requestLayout() {
        this.f2470h = true;
        super.requestLayout();
    }

    public void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int f2 = f(i2, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int f3 = f(i3, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (f2 != getScrollX() || f3 != getScrollY()) {
                super.scrollTo(f2, f3);
            }
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.f2475m) {
            this.f2475m = z2;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z2) {
        this.f2487y.m(z2);
    }

    public void setOnScrollChangeListener(d dVar) {
        this.f2460A = dVar;
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.f2476n = z2;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i2) {
        return X(i2, 0);
    }

    public void stopNestedScroll() {
        Z(0);
    }

    public boolean t(KeyEvent keyEvent) {
        this.f2465c.setEmpty();
        int i2 = 130;
        if (!e()) {
            if (!isFocused() || keyEvent.getKeyCode() == 4) {
                return false;
            }
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            return (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) ? false : true;
        } else if (keyEvent.getAction() != 0) {
            return false;
        } else {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 19) {
                if (keyCode != 20) {
                    if (keyCode != 62) {
                        if (keyCode != 92) {
                            if (keyCode != 93) {
                                if (keyCode == 122) {
                                    K(33);
                                    return false;
                                } else if (keyCode != 123) {
                                    return false;
                                }
                            }
                        }
                    } else if (keyEvent.isShiftPressed()) {
                        i2 = 33;
                    }
                    K(i2);
                    return false;
                } else if (!keyEvent.isAltPressed()) {
                    return c(130);
                }
                return w(130);
            } else if (!keyEvent.isAltPressed()) {
                return c(33);
            }
            return w(33);
        }
    }

    public void v(int i2) {
        if (getChildCount() > 0) {
            this.f2466d.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            N(true);
        }
    }

    public boolean w(int i2) {
        int childCount;
        boolean z2 = i2 == 130;
        int height = getHeight();
        Rect rect = this.f2465c;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f2465c.bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
            Rect rect2 = this.f2465c;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f2465c;
        return O(i2, rect3.top, rect3.bottom);
    }

    public boolean y(int i2) {
        return this.f2487y.k(i2);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2465c = new Rect();
        this.f2470h = true;
        this.f2471i = false;
        this.f2472j = null;
        this.f2473k = false;
        this.f2476n = true;
        this.f2480r = -1;
        this.f2481s = new int[2];
        this.f2482t = new int[2];
        c cVar = new c();
        this.f2461B = cVar;
        this.f2462C = new C0149o(getContext(), cVar);
        this.f2467e = d.a(context, attributeSet);
        this.f2468f = d.a(context, attributeSet);
        this.f2463a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        B();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f2459F, i2, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f2486x = new E(this);
        this.f2487y = new B(this);
        setNestedScrollingEnabled(true);
        W.q0(this, f2458E);
    }

    public void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
