package androidx.core.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import androidx.core.view.W;

public abstract class a implements View.OnTouchListener {

    /* renamed from: r  reason: collision with root package name */
    private static final int f2491r = ViewConfiguration.getTapTimeout();

    /* renamed from: a  reason: collision with root package name */
    final C0039a f2492a = new C0039a();

    /* renamed from: b  reason: collision with root package name */
    private final Interpolator f2493b = new AccelerateInterpolator();

    /* renamed from: c  reason: collision with root package name */
    final View f2494c;

    /* renamed from: d  reason: collision with root package name */
    private Runnable f2495d;

    /* renamed from: e  reason: collision with root package name */
    private float[] f2496e = {0.0f, 0.0f};

    /* renamed from: f  reason: collision with root package name */
    private float[] f2497f = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: g  reason: collision with root package name */
    private int f2498g;

    /* renamed from: h  reason: collision with root package name */
    private int f2499h;

    /* renamed from: i  reason: collision with root package name */
    private float[] f2500i = {0.0f, 0.0f};

    /* renamed from: j  reason: collision with root package name */
    private float[] f2501j = {0.0f, 0.0f};

    /* renamed from: k  reason: collision with root package name */
    private float[] f2502k = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: l  reason: collision with root package name */
    private boolean f2503l;

    /* renamed from: m  reason: collision with root package name */
    boolean f2504m;

    /* renamed from: n  reason: collision with root package name */
    boolean f2505n;

    /* renamed from: o  reason: collision with root package name */
    boolean f2506o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f2507p;

    /* renamed from: q  reason: collision with root package name */
    private boolean f2508q;

    /* renamed from: androidx.core.widget.a$a  reason: collision with other inner class name */
    private static class C0039a {

        /* renamed from: a  reason: collision with root package name */
        private int f2509a;

        /* renamed from: b  reason: collision with root package name */
        private int f2510b;

        /* renamed from: c  reason: collision with root package name */
        private float f2511c;

        /* renamed from: d  reason: collision with root package name */
        private float f2512d;

        /* renamed from: e  reason: collision with root package name */
        private long f2513e = Long.MIN_VALUE;

        /* renamed from: f  reason: collision with root package name */
        private long f2514f = 0;

        /* renamed from: g  reason: collision with root package name */
        private int f2515g = 0;

        /* renamed from: h  reason: collision with root package name */
        private int f2516h = 0;

        /* renamed from: i  reason: collision with root package name */
        private long f2517i = -1;

        /* renamed from: j  reason: collision with root package name */
        private float f2518j;

        /* renamed from: k  reason: collision with root package name */
        private int f2519k;

        C0039a() {
        }

        private float e(long j2) {
            long j3 = this.f2513e;
            if (j2 < j3) {
                return 0.0f;
            }
            long j4 = this.f2517i;
            if (j4 < 0 || j2 < j4) {
                return a.e(((float) (j2 - j3)) / ((float) this.f2509a), 0.0f, 1.0f) * 0.5f;
            }
            float f2 = this.f2518j;
            return (1.0f - f2) + (f2 * a.e(((float) (j2 - j4)) / ((float) this.f2519k), 0.0f, 1.0f));
        }

        private float g(float f2) {
            return (-4.0f * f2 * f2) + (f2 * 4.0f);
        }

        public void a() {
            if (this.f2514f != 0) {
                long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                float g2 = g(e(currentAnimationTimeMillis));
                this.f2514f = currentAnimationTimeMillis;
                float f2 = ((float) (currentAnimationTimeMillis - this.f2514f)) * g2;
                this.f2515g = (int) (this.f2511c * f2);
                this.f2516h = (int) (f2 * this.f2512d);
                return;
            }
            throw new RuntimeException("Cannot compute scroll delta before calling start()");
        }

        public int b() {
            return this.f2515g;
        }

        public int c() {
            return this.f2516h;
        }

        public int d() {
            float f2 = this.f2511c;
            return (int) (f2 / Math.abs(f2));
        }

        public int f() {
            float f2 = this.f2512d;
            return (int) (f2 / Math.abs(f2));
        }

        public boolean h() {
            return this.f2517i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f2517i + ((long) this.f2519k);
        }

        public void i() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f2519k = a.f((int) (currentAnimationTimeMillis - this.f2513e), 0, this.f2510b);
            this.f2518j = e(currentAnimationTimeMillis);
            this.f2517i = currentAnimationTimeMillis;
        }

        public void j(int i2) {
            this.f2510b = i2;
        }

        public void k(int i2) {
            this.f2509a = i2;
        }

        public void l(float f2, float f3) {
            this.f2511c = f2;
            this.f2512d = f3;
        }

        public void m() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f2513e = currentAnimationTimeMillis;
            this.f2517i = -1;
            this.f2514f = currentAnimationTimeMillis;
            this.f2518j = 0.5f;
            this.f2515g = 0;
            this.f2516h = 0;
        }
    }

    private class b implements Runnable {
        b() {
        }

        public void run() {
            a aVar = a.this;
            if (aVar.f2506o) {
                if (aVar.f2504m) {
                    aVar.f2504m = false;
                    aVar.f2492a.m();
                }
                C0039a aVar2 = a.this.f2492a;
                if (aVar2.h() || !a.this.u()) {
                    a.this.f2506o = false;
                    return;
                }
                a aVar3 = a.this;
                if (aVar3.f2505n) {
                    aVar3.f2505n = false;
                    aVar3.c();
                }
                aVar2.a();
                a.this.j(aVar2.b(), aVar2.c());
                W.i0(a.this.f2494c, this);
            }
        }
    }

    public a(View view) {
        this.f2494c = view;
        float f2 = Resources.getSystem().getDisplayMetrics().density;
        float f3 = (float) ((int) ((1575.0f * f2) + 0.5f));
        o(f3, f3);
        float f4 = (float) ((int) ((f2 * 315.0f) + 0.5f));
        p(f4, f4);
        l(1);
        n(Float.MAX_VALUE, Float.MAX_VALUE);
        s(0.2f, 0.2f);
        t(1.0f, 1.0f);
        k(f2491r);
        r(500);
        q(500);
    }

    private float d(int i2, float f2, float f3, float f4) {
        float h2 = h(this.f2496e[i2], f3, this.f2497f[i2], f2);
        int i3 = (h2 > 0.0f ? 1 : (h2 == 0.0f ? 0 : -1));
        if (i3 == 0) {
            return 0.0f;
        }
        float f5 = this.f2500i[i2];
        float f6 = this.f2501j[i2];
        float f7 = this.f2502k[i2];
        float f8 = f5 * f4;
        return i3 > 0 ? e(h2 * f8, f6, f7) : -e((-h2) * f8, f6, f7);
    }

    static float e(float f2, float f3, float f4) {
        if (f2 > f4) {
            return f4;
        }
        return f2 < f3 ? f3 : f2;
    }

    static int f(int i2, int i3, int i4) {
        if (i2 > i4) {
            return i4;
        }
        return i2 < i3 ? i3 : i2;
    }

    private float g(float f2, float f3) {
        if (f3 == 0.0f) {
            return 0.0f;
        }
        int i2 = this.f2498g;
        if (i2 == 0 || i2 == 1) {
            if (f2 < f3) {
                if (f2 >= 0.0f) {
                    return 1.0f - (f2 / f3);
                }
                return (!this.f2506o || i2 != 1) ? 0.0f : 1.0f;
            }
        } else if (i2 == 2 && f2 < 0.0f) {
            return f2 / (-f3);
        }
    }

    private float h(float f2, float f3, float f4, float f5) {
        float f6;
        float e2 = e(f2 * f3, 0.0f, f4);
        float g2 = g(f3 - f5, e2) - g(f5, e2);
        if (g2 < 0.0f) {
            f6 = -this.f2493b.getInterpolation(-g2);
        } else if (g2 <= 0.0f) {
            return 0.0f;
        } else {
            f6 = this.f2493b.getInterpolation(g2);
        }
        return e(f6, -1.0f, 1.0f);
    }

    private void i() {
        if (this.f2504m) {
            this.f2506o = false;
        } else {
            this.f2492a.i();
        }
    }

    private void v() {
        int i2;
        if (this.f2495d == null) {
            this.f2495d = new b();
        }
        this.f2506o = true;
        this.f2504m = true;
        if (this.f2503l || (i2 = this.f2499h) <= 0) {
            this.f2495d.run();
        } else {
            W.j0(this.f2494c, this.f2495d, (long) i2);
        }
        this.f2503l = true;
    }

    public abstract boolean a(int i2);

    public abstract boolean b(int i2);

    /* access modifiers changed from: package-private */
    public void c() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        this.f2494c.onTouchEvent(obtain);
        obtain.recycle();
    }

    public abstract void j(int i2, int i3);

    public a k(int i2) {
        this.f2499h = i2;
        return this;
    }

    public a l(int i2) {
        this.f2498g = i2;
        return this;
    }

    public a m(boolean z2) {
        if (this.f2507p && !z2) {
            i();
        }
        this.f2507p = z2;
        return this;
    }

    public a n(float f2, float f3) {
        float[] fArr = this.f2497f;
        fArr[0] = f2;
        fArr[1] = f3;
        return this;
    }

    public a o(float f2, float f3) {
        float[] fArr = this.f2502k;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0013, code lost:
        if (r0 != 3) goto L_0x0058;
     */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0060 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouch(android.view.View r6, android.view.MotionEvent r7) {
        /*
            r5 = this;
            boolean r0 = r5.f2507p
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            int r0 = r7.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L_0x001a
            if (r0 == r2) goto L_0x0016
            r3 = 2
            if (r0 == r3) goto L_0x001e
            r6 = 3
            if (r0 == r6) goto L_0x0016
            goto L_0x0058
        L_0x0016:
            r5.i()
            goto L_0x0058
        L_0x001a:
            r5.f2505n = r2
            r5.f2503l = r1
        L_0x001e:
            float r0 = r7.getX()
            int r3 = r6.getWidth()
            float r3 = (float) r3
            android.view.View r4 = r5.f2494c
            int r4 = r4.getWidth()
            float r4 = (float) r4
            float r0 = r5.d(r1, r0, r3, r4)
            float r7 = r7.getY()
            int r6 = r6.getHeight()
            float r6 = (float) r6
            android.view.View r3 = r5.f2494c
            int r3 = r3.getHeight()
            float r3 = (float) r3
            float r6 = r5.d(r2, r7, r6, r3)
            androidx.core.widget.a$a r7 = r5.f2492a
            r7.l(r0, r6)
            boolean r6 = r5.f2506o
            if (r6 != 0) goto L_0x0058
            boolean r6 = r5.u()
            if (r6 == 0) goto L_0x0058
            r5.v()
        L_0x0058:
            boolean r6 = r5.f2508q
            if (r6 == 0) goto L_0x0061
            boolean r6 = r5.f2506o
            if (r6 == 0) goto L_0x0061
            r1 = 1
        L_0x0061:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.a.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    public a p(float f2, float f3) {
        float[] fArr = this.f2501j;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    public a q(int i2) {
        this.f2492a.j(i2);
        return this;
    }

    public a r(int i2) {
        this.f2492a.k(i2);
        return this;
    }

    public a s(float f2, float f3) {
        float[] fArr = this.f2496e;
        fArr[0] = f2;
        fArr[1] = f3;
        return this;
    }

    public a t(float f2, float f3) {
        float[] fArr = this.f2500i;
        fArr[0] = f2 / 1000.0f;
        fArr[1] = f3 / 1000.0f;
        return this;
    }

    /* access modifiers changed from: package-private */
    public boolean u() {
        C0039a aVar = this.f2492a;
        int f2 = aVar.f();
        int d2 = aVar.d();
        return (f2 != 0 && b(f2)) || (d2 != 0 && a(d2));
    }
}
