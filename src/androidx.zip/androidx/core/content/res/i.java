package androidx.core.content.res;

import android.graphics.Typeface;
import androidx.core.content.res.h;

public final /* synthetic */ class i implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h.e f2161a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Typeface f2162b;

    public /* synthetic */ i(h.e eVar, Typeface typeface) {
        this.f2161a = eVar;
        this.f2162b = typeface;
    }

    public final void run() {
        this.f2161a.g(this.f2162b);
    }
}
