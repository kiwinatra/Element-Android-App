package androidx.core.content.res;

import androidx.core.content.res.h;

public final /* synthetic */ class j implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h.e f2163a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f2164b;

    public /* synthetic */ j(h.e eVar, int i2) {
        this.f2163a = eVar;
        this.f2164b = i2;
    }

    public final void run() {
        this.f2163a.f(this.f2164b);
    }
}
