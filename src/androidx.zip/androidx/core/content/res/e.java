package androidx.core.content.res;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.Base64;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import t.C0285c;
import w.f;

public abstract class e {

    static class a {
        static int a(TypedArray typedArray, int i2) {
            return typedArray.getType(i2);
        }
    }

    public interface b {
    }

    public static final class c implements b {

        /* renamed from: a  reason: collision with root package name */
        private final d[] f2137a;

        public c(d[] dVarArr) {
            this.f2137a = dVarArr;
        }

        public d[] a() {
            return this.f2137a;
        }
    }

    public static final class d {

        /* renamed from: a  reason: collision with root package name */
        private final String f2138a;

        /* renamed from: b  reason: collision with root package name */
        private final int f2139b;

        /* renamed from: c  reason: collision with root package name */
        private final boolean f2140c;

        /* renamed from: d  reason: collision with root package name */
        private final String f2141d;

        /* renamed from: e  reason: collision with root package name */
        private final int f2142e;

        /* renamed from: f  reason: collision with root package name */
        private final int f2143f;

        public d(String str, int i2, boolean z2, String str2, int i3, int i4) {
            this.f2138a = str;
            this.f2139b = i2;
            this.f2140c = z2;
            this.f2141d = str2;
            this.f2142e = i3;
            this.f2143f = i4;
        }

        public String a() {
            return this.f2138a;
        }

        public int b() {
            return this.f2143f;
        }

        public int c() {
            return this.f2142e;
        }

        public String d() {
            return this.f2141d;
        }

        public int e() {
            return this.f2139b;
        }

        public boolean f() {
            return this.f2140c;
        }
    }

    /* renamed from: androidx.core.content.res.e$e  reason: collision with other inner class name */
    public static final class C0026e implements b {

        /* renamed from: a  reason: collision with root package name */
        private final f f2144a;

        /* renamed from: b  reason: collision with root package name */
        private final int f2145b;

        /* renamed from: c  reason: collision with root package name */
        private final int f2146c;

        /* renamed from: d  reason: collision with root package name */
        private final String f2147d;

        public C0026e(f fVar, int i2, int i3, String str) {
            this.f2144a = fVar;
            this.f2146c = i2;
            this.f2145b = i3;
            this.f2147d = str;
        }

        public int a() {
            return this.f2146c;
        }

        public f b() {
            return this.f2144a;
        }

        public String c() {
            return this.f2147d;
        }

        public int d() {
            return this.f2145b;
        }
    }

    private static int a(TypedArray typedArray, int i2) {
        return a.a(typedArray, i2);
    }

    /*  JADX ERROR: StackOverflow in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: 
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    public static androidx.core.content.res.e.b b(org.xmlpull.v1.XmlPullParser r3, android.content.res.Resources r4) {
        /*
        L_0x0000:
            int r0 = r3.next()
            r1 = 2
            if (r0 == r1) goto L_0x000b
            r2 = 1
            if (r0 == r2) goto L_0x000b
            goto L_0x0000
        L_0x000b:
            if (r0 != r1) goto L_0x0012
            androidx.core.content.res.e$b r3 = d(r3, r4)
            return r3
        L_0x0012:
            org.xmlpull.v1.XmlPullParserException r3 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r4 = "No start tag found"
            r3.<init>(r4)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.content.res.e.b(org.xmlpull.v1.XmlPullParser, android.content.res.Resources):androidx.core.content.res.e$b");
    }

    public static List c(Resources resources, int i2) {
        if (i2 == 0) {
            return Collections.emptyList();
        }
        TypedArray obtainTypedArray = resources.obtainTypedArray(i2);
        try {
            if (obtainTypedArray.length() == 0) {
                return Collections.emptyList();
            }
            ArrayList arrayList = new ArrayList();
            if (a(obtainTypedArray, 0) == 1) {
                for (int i3 = 0; i3 < obtainTypedArray.length(); i3++) {
                    int resourceId = obtainTypedArray.getResourceId(i3, 0);
                    if (resourceId != 0) {
                        arrayList.add(h(resources.getStringArray(resourceId)));
                    }
                }
            } else {
                arrayList.add(h(resources.getStringArray(i2)));
            }
            obtainTypedArray.recycle();
            return arrayList;
        } finally {
            obtainTypedArray.recycle();
        }
    }

    private static b d(XmlPullParser xmlPullParser, Resources resources) {
        xmlPullParser.require(2, (String) null, "font-family");
        if (xmlPullParser.getName().equals("font-family")) {
            return e(xmlPullParser, resources);
        }
        g(xmlPullParser);
        return null;
    }

    private static b e(XmlPullParser xmlPullParser, Resources resources) {
        TypedArray obtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), C0285c.f6235h);
        String string = obtainAttributes.getString(C0285c.f6236i);
        String string2 = obtainAttributes.getString(C0285c.f6240m);
        String string3 = obtainAttributes.getString(C0285c.f6241n);
        int resourceId = obtainAttributes.getResourceId(C0285c.f6237j, 0);
        int integer = obtainAttributes.getInteger(C0285c.f6238k, 1);
        int integer2 = obtainAttributes.getInteger(C0285c.f6239l, 500);
        String string4 = obtainAttributes.getString(C0285c.f6242o);
        obtainAttributes.recycle();
        if (string == null || string2 == null || string3 == null) {
            ArrayList arrayList = new ArrayList();
            while (xmlPullParser.next() != 3) {
                if (xmlPullParser.getEventType() == 2) {
                    if (xmlPullParser.getName().equals("font")) {
                        arrayList.add(f(xmlPullParser, resources));
                    } else {
                        g(xmlPullParser);
                    }
                }
            }
            if (arrayList.isEmpty()) {
                return null;
            }
            return new c((d[]) arrayList.toArray(new d[0]));
        }
        while (xmlPullParser.next() != 3) {
            g(xmlPullParser);
        }
        return new C0026e(new f(string, string2, string3, c(resources, resourceId)), integer, integer2, string4);
    }

    private static d f(XmlPullParser xmlPullParser, Resources resources) {
        TypedArray obtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), C0285c.f6243p);
        int i2 = C0285c.f6252y;
        if (!obtainAttributes.hasValue(i2)) {
            i2 = C0285c.f6245r;
        }
        int i3 = obtainAttributes.getInt(i2, 400);
        int i4 = C0285c.f6250w;
        if (!obtainAttributes.hasValue(i4)) {
            i4 = C0285c.f6246s;
        }
        boolean z2 = 1 == obtainAttributes.getInt(i4, 0);
        int i5 = C0285c.f6253z;
        if (!obtainAttributes.hasValue(i5)) {
            i5 = C0285c.f6247t;
        }
        int i6 = C0285c.f6251x;
        if (!obtainAttributes.hasValue(i6)) {
            i6 = C0285c.f6248u;
        }
        String string = obtainAttributes.getString(i6);
        int i7 = obtainAttributes.getInt(i5, 0);
        int i8 = C0285c.f6249v;
        if (!obtainAttributes.hasValue(i8)) {
            i8 = C0285c.f6244q;
        }
        int resourceId = obtainAttributes.getResourceId(i8, 0);
        String string2 = obtainAttributes.getString(i8);
        obtainAttributes.recycle();
        while (xmlPullParser.next() != 3) {
            g(xmlPullParser);
        }
        return new d(string2, i3, z2, string, i7, resourceId);
    }

    private static void g(XmlPullParser xmlPullParser) {
        int i2 = 1;
        while (i2 > 0) {
            int next = xmlPullParser.next();
            if (next == 2) {
                i2++;
            } else if (next == 3) {
                i2--;
            }
        }
    }

    private static List h(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (String decode : strArr) {
            arrayList.add(Base64.decode(decode, 0));
        }
        return arrayList;
    }
}
