package androidx.core.content;

import x.C0290a;

public interface d {
    void j(C0290a aVar);

    void l(C0290a aVar);
}
