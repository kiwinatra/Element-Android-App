package androidx.core.content;

import x.C0290a;

public interface c {
    void p(C0290a aVar);

    void r(C0290a aVar);
}
