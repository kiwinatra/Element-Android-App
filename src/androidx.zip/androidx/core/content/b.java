package androidx.core.content;

import android.telephony.SubscriptionManager;

public abstract /* synthetic */ class b {
    public static /* bridge */ /* synthetic */ Class a() {
        return SubscriptionManager.class;
    }
}
