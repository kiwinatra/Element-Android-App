package androidx.core.text;

import android.text.PrecomputedText;
import android.text.TextPaint;

public abstract /* synthetic */ class d {
    public static /* synthetic */ PrecomputedText.Params.Builder a(TextPaint textPaint) {
        return new PrecomputedText.Params.Builder(textPaint);
    }
}
