package androidx.core.text;

public interface o {
    boolean a(CharSequence charSequence, int i2, int i3);
}
