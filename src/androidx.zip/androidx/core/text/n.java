package androidx.core.text;

import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import x.c;

public abstract class n implements Spannable {

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final TextPaint f2272a;

        /* renamed from: b  reason: collision with root package name */
        private final TextDirectionHeuristic f2273b;

        /* renamed from: c  reason: collision with root package name */
        private final int f2274c;

        /* renamed from: d  reason: collision with root package name */
        private final int f2275d;

        /* renamed from: e  reason: collision with root package name */
        final PrecomputedText.Params f2276e;

        /* renamed from: androidx.core.text.n$a$a  reason: collision with other inner class name */
        public static class C0032a {

            /* renamed from: a  reason: collision with root package name */
            private final TextPaint f2277a;

            /* renamed from: b  reason: collision with root package name */
            private TextDirectionHeuristic f2278b;

            /* renamed from: c  reason: collision with root package name */
            private int f2279c;

            /* renamed from: d  reason: collision with root package name */
            private int f2280d;

            public C0032a(TextPaint textPaint) {
                this.f2277a = textPaint;
                if (Build.VERSION.SDK_INT >= 23) {
                    this.f2279c = 1;
                    this.f2280d = 1;
                } else {
                    this.f2280d = 0;
                    this.f2279c = 0;
                }
                this.f2278b = TextDirectionHeuristics.FIRSTSTRONG_LTR;
            }

            public a a() {
                return new a(this.f2277a, this.f2278b, this.f2279c, this.f2280d);
            }

            public C0032a b(int i2) {
                this.f2279c = i2;
                return this;
            }

            public C0032a c(int i2) {
                this.f2280d = i2;
                return this;
            }

            public C0032a d(TextDirectionHeuristic textDirectionHeuristic) {
                this.f2278b = textDirectionHeuristic;
                return this;
            }
        }

        public a(PrecomputedText.Params params) {
            this.f2272a = params.getTextPaint();
            this.f2273b = params.getTextDirection();
            this.f2274c = params.getBreakStrategy();
            this.f2275d = params.getHyphenationFrequency();
            this.f2276e = Build.VERSION.SDK_INT < 29 ? null : params;
        }

        public boolean a(a aVar) {
            int i2 = Build.VERSION.SDK_INT;
            if ((i2 >= 23 && (this.f2274c != aVar.b() || this.f2275d != aVar.c())) || this.f2272a.getTextSize() != aVar.e().getTextSize() || this.f2272a.getTextScaleX() != aVar.e().getTextScaleX() || this.f2272a.getTextSkewX() != aVar.e().getTextSkewX() || this.f2272a.getLetterSpacing() != aVar.e().getLetterSpacing() || !TextUtils.equals(this.f2272a.getFontFeatureSettings(), aVar.e().getFontFeatureSettings()) || this.f2272a.getFlags() != aVar.e().getFlags()) {
                return false;
            }
            if (i2 >= 24) {
                if (!this.f2272a.getTextLocales().equals(aVar.e().getTextLocales())) {
                    return false;
                }
            } else if (!this.f2272a.getTextLocale().equals(aVar.e().getTextLocale())) {
                return false;
            }
            return this.f2272a.getTypeface() == null ? aVar.e().getTypeface() == null : this.f2272a.getTypeface().equals(aVar.e().getTypeface());
        }

        public int b() {
            return this.f2274c;
        }

        public int c() {
            return this.f2275d;
        }

        public TextDirectionHeuristic d() {
            return this.f2273b;
        }

        public TextPaint e() {
            return this.f2272a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return a(aVar) && this.f2273b == aVar.d();
        }

        public int hashCode() {
            if (Build.VERSION.SDK_INT >= 24) {
                return c.b(Float.valueOf(this.f2272a.getTextSize()), Float.valueOf(this.f2272a.getTextScaleX()), Float.valueOf(this.f2272a.getTextSkewX()), Float.valueOf(this.f2272a.getLetterSpacing()), Integer.valueOf(this.f2272a.getFlags()), this.f2272a.getTextLocales(), this.f2272a.getTypeface(), Boolean.valueOf(this.f2272a.isElegantTextHeight()), this.f2273b, Integer.valueOf(this.f2274c), Integer.valueOf(this.f2275d));
            }
            return c.b(Float.valueOf(this.f2272a.getTextSize()), Float.valueOf(this.f2272a.getTextScaleX()), Float.valueOf(this.f2272a.getTextSkewX()), Float.valueOf(this.f2272a.getLetterSpacing()), Integer.valueOf(this.f2272a.getFlags()), this.f2272a.getTextLocale(), this.f2272a.getTypeface(), Boolean.valueOf(this.f2272a.isElegantTextHeight()), this.f2273b, Integer.valueOf(this.f2274c), Integer.valueOf(this.f2275d));
        }

        public String toString() {
            StringBuilder sb;
            Object textLocale;
            StringBuilder sb2 = new StringBuilder("{");
            sb2.append("textSize=" + this.f2272a.getTextSize());
            sb2.append(", textScaleX=" + this.f2272a.getTextScaleX());
            sb2.append(", textSkewX=" + this.f2272a.getTextSkewX());
            int i2 = Build.VERSION.SDK_INT;
            sb2.append(", letterSpacing=" + this.f2272a.getLetterSpacing());
            sb2.append(", elegantTextHeight=" + this.f2272a.isElegantTextHeight());
            if (i2 >= 24) {
                sb = new StringBuilder();
                sb.append(", textLocale=");
                textLocale = this.f2272a.getTextLocales();
            } else {
                sb = new StringBuilder();
                sb.append(", textLocale=");
                textLocale = this.f2272a.getTextLocale();
            }
            sb.append(textLocale);
            sb2.append(sb.toString());
            sb2.append(", typeface=" + this.f2272a.getTypeface());
            if (i2 >= 26) {
                sb2.append(", variationSettings=" + this.f2272a.getFontVariationSettings());
            }
            sb2.append(", textDir=" + this.f2273b);
            sb2.append(", breakStrategy=" + this.f2274c);
            sb2.append(", hyphenationFrequency=" + this.f2275d);
            sb2.append("}");
            return sb2.toString();
        }

        a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
            this.f2276e = Build.VERSION.SDK_INT >= 29 ? d.a(textPaint).setBreakStrategy(i2).setHyphenationFrequency(i3).setTextDirection(textDirectionHeuristic).build() : null;
            this.f2272a = textPaint;
            this.f2273b = textDirectionHeuristic;
            this.f2274c = i2;
            this.f2275d = i3;
        }
    }
}
