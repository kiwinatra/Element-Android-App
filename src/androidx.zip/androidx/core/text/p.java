package androidx.core.text;

import java.util.Locale;

public abstract class p {

    /* renamed from: a  reason: collision with root package name */
    public static final o f2281a = new e((c) null, false);

    /* renamed from: b  reason: collision with root package name */
    public static final o f2282b = new e((c) null, true);

    /* renamed from: c  reason: collision with root package name */
    public static final o f2283c;

    /* renamed from: d  reason: collision with root package name */
    public static final o f2284d;

    /* renamed from: e  reason: collision with root package name */
    public static final o f2285e = new e(a.f2287b, false);

    /* renamed from: f  reason: collision with root package name */
    public static final o f2286f = f.f2292b;

    private static class a implements c {

        /* renamed from: b  reason: collision with root package name */
        static final a f2287b = new a(true);

        /* renamed from: a  reason: collision with root package name */
        private final boolean f2288a;

        private a(boolean z2) {
            this.f2288a = z2;
        }

        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            boolean z2 = false;
            while (i2 < i4) {
                int a2 = p.a(Character.getDirectionality(charSequence.charAt(i2)));
                if (a2 != 0) {
                    if (a2 != 1) {
                        continue;
                        i2++;
                    } else if (!this.f2288a) {
                        return 1;
                    }
                } else if (this.f2288a) {
                    return 0;
                }
                z2 = true;
                i2++;
            }
            if (z2) {
                return this.f2288a ? 1 : 0;
            }
            return 2;
        }
    }

    private static class b implements c {

        /* renamed from: a  reason: collision with root package name */
        static final b f2289a = new b();

        private b() {
        }

        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            int i5 = 2;
            while (i2 < i4 && i5 == 2) {
                i5 = p.b(Character.getDirectionality(charSequence.charAt(i2)));
                i2++;
            }
            return i5;
        }
    }

    private interface c {
        int a(CharSequence charSequence, int i2, int i3);
    }

    private static abstract class d implements o {

        /* renamed from: a  reason: collision with root package name */
        private final c f2290a;

        d(c cVar) {
            this.f2290a = cVar;
        }

        private boolean c(CharSequence charSequence, int i2, int i3) {
            int a2 = this.f2290a.a(charSequence, i2, i3);
            if (a2 == 0) {
                return true;
            }
            if (a2 != 1) {
                return b();
            }
            return false;
        }

        public boolean a(CharSequence charSequence, int i2, int i3) {
            if (charSequence != null && i2 >= 0 && i3 >= 0 && charSequence.length() - i3 >= i2) {
                return this.f2290a == null ? b() : c(charSequence, i2, i3);
            }
            throw new IllegalArgumentException();
        }

        /* access modifiers changed from: protected */
        public abstract boolean b();
    }

    private static class e extends d {

        /* renamed from: b  reason: collision with root package name */
        private final boolean f2291b;

        e(c cVar, boolean z2) {
            super(cVar);
            this.f2291b = z2;
        }

        /* access modifiers changed from: protected */
        public boolean b() {
            return this.f2291b;
        }
    }

    private static class f extends d {

        /* renamed from: b  reason: collision with root package name */
        static final f f2292b = new f();

        f() {
            super((c) null);
        }

        /* access modifiers changed from: protected */
        public boolean b() {
            return q.a(Locale.getDefault()) == 1;
        }
    }

    static {
        b bVar = b.f2289a;
        f2283c = new e(bVar, false);
        f2284d = new e(bVar, true);
    }

    static int a(int i2) {
        if (i2 != 0) {
            return (i2 == 1 || i2 == 2) ? 0 : 2;
        }
        return 1;
    }

    static int b(int i2) {
        if (i2 != 0) {
            if (i2 == 1 || i2 == 2) {
                return 0;
            }
            switch (i2) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
