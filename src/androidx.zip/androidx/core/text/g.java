package androidx.core.text;

public abstract /* synthetic */ class g {
}
