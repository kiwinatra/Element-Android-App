package androidx.core.graphics;

import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import x.d;

public abstract class g {

    /* renamed from: a  reason: collision with root package name */
    private static final ThreadLocal f2209a = new ThreadLocal();

    static class a {
        static boolean a(Paint paint, String str) {
            return paint.hasGlyph(str);
        }
    }

    public static boolean a(Paint paint, String str) {
        if (Build.VERSION.SDK_INT >= 23) {
            return a.a(paint, str);
        }
        int length = str.length();
        if (length == 1 && Character.isWhitespace(str.charAt(0))) {
            return true;
        }
        float measureText = paint.measureText("󟿽");
        float measureText2 = paint.measureText("m");
        float measureText3 = paint.measureText(str);
        float f2 = 0.0f;
        if (measureText3 == 0.0f) {
            return false;
        }
        if (str.codePointCount(0, str.length()) > 1) {
            if (measureText3 > measureText2 * 2.0f) {
                return false;
            }
            int i2 = 0;
            while (i2 < length) {
                int charCount = Character.charCount(str.codePointAt(i2)) + i2;
                f2 += paint.measureText(str, i2, charCount);
                i2 = charCount;
            }
            if (measureText3 >= f2) {
                return false;
            }
        }
        if (measureText3 != measureText) {
            return true;
        }
        d b2 = b();
        paint.getTextBounds("󟿽", 0, 2, (Rect) b2.f6328a);
        paint.getTextBounds(str, 0, length, (Rect) b2.f6329b);
        return !((Rect) b2.f6328a).equals(b2.f6329b);
    }

    private static d b() {
        ThreadLocal threadLocal = f2209a;
        d dVar = (d) threadLocal.get();
        if (dVar == null) {
            d dVar2 = new d(new Rect(), new Rect());
            threadLocal.set(dVar2);
            return dVar2;
        }
        ((Rect) dVar.f6328a).setEmpty();
        ((Rect) dVar.f6329b).setEmpty();
        return dVar;
    }
}
