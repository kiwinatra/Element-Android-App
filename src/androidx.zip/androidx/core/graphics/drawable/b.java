package androidx.core.graphics.drawable;

public interface b {
}
