package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.a;

public class IconCompatParcelizer {
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f2178a = aVar.p(iconCompat.f2178a, 1);
        iconCompat.f2180c = aVar.j(iconCompat.f2180c, 2);
        iconCompat.f2181d = aVar.r(iconCompat.f2181d, 3);
        iconCompat.f2182e = aVar.p(iconCompat.f2182e, 4);
        iconCompat.f2183f = aVar.p(iconCompat.f2183f, 5);
        iconCompat.f2184g = (ColorStateList) aVar.r(iconCompat.f2184g, 6);
        iconCompat.f2186i = aVar.t(iconCompat.f2186i, 7);
        iconCompat.f2187j = aVar.t(iconCompat.f2187j, 8);
        iconCompat.f();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.x(true, true);
        iconCompat.g(aVar.f());
        int i2 = iconCompat.f2178a;
        if (-1 != i2) {
            aVar.F(i2, 1);
        }
        byte[] bArr = iconCompat.f2180c;
        if (bArr != null) {
            aVar.B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f2181d;
        if (parcelable != null) {
            aVar.H(parcelable, 3);
        }
        int i3 = iconCompat.f2182e;
        if (i3 != 0) {
            aVar.F(i3, 4);
        }
        int i4 = iconCompat.f2183f;
        if (i4 != 0) {
            aVar.F(i4, 5);
        }
        ColorStateList colorStateList = iconCompat.f2184g;
        if (colorStateList != null) {
            aVar.H(colorStateList, 6);
        }
        String str = iconCompat.f2186i;
        if (str != null) {
            aVar.J(str, 7);
        }
        String str2 = iconCompat.f2187j;
        if (str2 != null) {
            aVar.J(str2, 8);
        }
    }
}
