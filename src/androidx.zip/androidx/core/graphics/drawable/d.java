package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

abstract class d extends Drawable implements Drawable.Callback, c, b {

    /* renamed from: g  reason: collision with root package name */
    static final PorterDuff.Mode f2192g = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    private int f2193a;

    /* renamed from: b  reason: collision with root package name */
    private PorterDuff.Mode f2194b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f2195c;

    /* renamed from: d  reason: collision with root package name */
    f f2196d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f2197e;

    /* renamed from: f  reason: collision with root package name */
    Drawable f2198f;

    d(Drawable drawable) {
        this.f2196d = d();
        b(drawable);
    }

    private f d() {
        return new f(this.f2196d);
    }

    private void e(Resources resources) {
        Drawable.ConstantState constantState;
        f fVar = this.f2196d;
        if (fVar != null && (constantState = fVar.f2201b) != null) {
            b(constantState.newDrawable(resources));
        }
    }

    private boolean f(int[] iArr) {
        if (!c()) {
            return false;
        }
        f fVar = this.f2196d;
        ColorStateList colorStateList = fVar.f2202c;
        PorterDuff.Mode mode = fVar.f2203d;
        if (colorStateList == null || mode == null) {
            this.f2195c = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!(this.f2195c && colorForState == this.f2193a && mode == this.f2194b)) {
                setColorFilter(colorForState, mode);
                this.f2193a = colorForState;
                this.f2194b = mode;
                this.f2195c = true;
                return true;
            }
        }
        return false;
    }

    public final Drawable a() {
        return this.f2198f;
    }

    public final void b(Drawable drawable) {
        Drawable drawable2 = this.f2198f;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f2198f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            f fVar = this.f2196d;
            if (fVar != null) {
                fVar.f2201b = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    /* access modifiers changed from: protected */
    public abstract boolean c();

    public void draw(Canvas canvas) {
        this.f2198f.draw(canvas);
    }

    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        f fVar = this.f2196d;
        return changingConfigurations | (fVar != null ? fVar.getChangingConfigurations() : 0) | this.f2198f.getChangingConfigurations();
    }

    public Drawable.ConstantState getConstantState() {
        f fVar = this.f2196d;
        if (fVar == null || !fVar.a()) {
            return null;
        }
        this.f2196d.f2200a = getChangingConfigurations();
        return this.f2196d;
    }

    public Drawable getCurrent() {
        return this.f2198f.getCurrent();
    }

    public int getIntrinsicHeight() {
        return this.f2198f.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        return this.f2198f.getIntrinsicWidth();
    }

    public int getLayoutDirection() {
        return a.f(this.f2198f);
    }

    public int getMinimumHeight() {
        return this.f2198f.getMinimumHeight();
    }

    public int getMinimumWidth() {
        return this.f2198f.getMinimumWidth();
    }

    public int getOpacity() {
        return this.f2198f.getOpacity();
    }

    public boolean getPadding(Rect rect) {
        return this.f2198f.getPadding(rect);
    }

    public int[] getState() {
        return this.f2198f.getState();
    }

    public Region getTransparentRegion() {
        return this.f2198f.getTransparentRegion();
    }

    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public boolean isAutoMirrored() {
        return a.h(this.f2198f);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f2196d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            boolean r0 = r1.c()
            if (r0 == 0) goto L_0x000d
            androidx.core.graphics.drawable.f r0 = r1.f2196d
            if (r0 == 0) goto L_0x000d
            android.content.res.ColorStateList r0 = r0.f2202c
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001e
        L_0x0016:
            android.graphics.drawable.Drawable r0 = r1.f2198f
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0020
        L_0x001e:
            r0 = 1
            goto L_0x0021
        L_0x0020:
            r0 = 0
        L_0x0021:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.d.isStateful():boolean");
    }

    public void jumpToCurrentState() {
        this.f2198f.jumpToCurrentState();
    }

    public Drawable mutate() {
        if (!this.f2197e && super.mutate() == this) {
            this.f2196d = d();
            Drawable drawable = this.f2198f;
            if (drawable != null) {
                drawable.mutate();
            }
            f fVar = this.f2196d;
            if (fVar != null) {
                Drawable drawable2 = this.f2198f;
                fVar.f2201b = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f2197e = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2198f;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    public boolean onLayoutDirectionChanged(int i2) {
        return a.m(this.f2198f, i2);
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i2) {
        return this.f2198f.setLevel(i2);
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        scheduleSelf(runnable, j2);
    }

    public void setAlpha(int i2) {
        this.f2198f.setAlpha(i2);
    }

    public void setAutoMirrored(boolean z2) {
        a.j(this.f2198f, z2);
    }

    public void setChangingConfigurations(int i2) {
        this.f2198f.setChangingConfigurations(i2);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f2198f.setColorFilter(colorFilter);
    }

    public void setDither(boolean z2) {
        this.f2198f.setDither(z2);
    }

    public void setFilterBitmap(boolean z2) {
        this.f2198f.setFilterBitmap(z2);
    }

    public boolean setState(int[] iArr) {
        return f(iArr) || this.f2198f.setState(iArr);
    }

    public void setTint(int i2) {
        setTintList(ColorStateList.valueOf(i2));
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f2196d.f2202c = colorStateList;
        f(getState());
    }

    public void setTintMode(PorterDuff.Mode mode) {
        this.f2196d.f2203d = mode;
        f(getState());
    }

    public boolean setVisible(boolean z2, boolean z3) {
        return super.setVisible(z2, z3) || this.f2198f.setVisible(z2, z3);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }

    d(f fVar, Resources resources) {
        this.f2196d = fVar;
        e(resources);
    }
}
