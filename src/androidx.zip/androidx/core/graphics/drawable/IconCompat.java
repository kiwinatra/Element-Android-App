package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k  reason: collision with root package name */
    static final PorterDuff.Mode f2177k = PorterDuff.Mode.SRC_IN;

    /* renamed from: a  reason: collision with root package name */
    public int f2178a = -1;

    /* renamed from: b  reason: collision with root package name */
    Object f2179b;

    /* renamed from: c  reason: collision with root package name */
    public byte[] f2180c = null;

    /* renamed from: d  reason: collision with root package name */
    public Parcelable f2181d = null;

    /* renamed from: e  reason: collision with root package name */
    public int f2182e = 0;

    /* renamed from: f  reason: collision with root package name */
    public int f2183f = 0;

    /* renamed from: g  reason: collision with root package name */
    public ColorStateList f2184g = null;

    /* renamed from: h  reason: collision with root package name */
    PorterDuff.Mode f2185h = f2177k;

    /* renamed from: i  reason: collision with root package name */
    public String f2186i = null;

    /* renamed from: j  reason: collision with root package name */
    public String f2187j;

    static class a {
        static int a(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.a(obj);
            }
            try {
                return ((Integer) obj.getClass().getMethod("getResId", (Class[]) null).invoke(obj, (Object[]) null)).intValue();
            } catch (IllegalAccessException e2) {
                Log.e("IconCompat", "Unable to get icon resource", e2);
                return 0;
            } catch (InvocationTargetException e3) {
                Log.e("IconCompat", "Unable to get icon resource", e3);
                return 0;
            } catch (NoSuchMethodException e4) {
                Log.e("IconCompat", "Unable to get icon resource", e4);
                return 0;
            }
        }

        static String b(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.b(obj);
            }
            try {
                return (String) obj.getClass().getMethod("getResPackage", (Class[]) null).invoke(obj, (Object[]) null);
            } catch (IllegalAccessException e2) {
                Log.e("IconCompat", "Unable to get icon package", e2);
                return null;
            } catch (InvocationTargetException e3) {
                Log.e("IconCompat", "Unable to get icon package", e3);
                return null;
            } catch (NoSuchMethodException e4) {
                Log.e("IconCompat", "Unable to get icon package", e4);
                return null;
            }
        }

        static Uri c(Object obj) {
            if (Build.VERSION.SDK_INT >= 28) {
                return c.d(obj);
            }
            try {
                return (Uri) obj.getClass().getMethod("getUri", (Class[]) null).invoke(obj, (Object[]) null);
            } catch (IllegalAccessException e2) {
                Log.e("IconCompat", "Unable to get icon uri", e2);
                return null;
            } catch (InvocationTargetException e3) {
                Log.e("IconCompat", "Unable to get icon uri", e3);
                return null;
            } catch (NoSuchMethodException e4) {
                Log.e("IconCompat", "Unable to get icon uri", e4);
                return null;
            }
        }

        static Drawable d(Icon icon, Context context) {
            return icon.loadDrawable(context);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x002c, code lost:
            if (r0 >= 26) goto L_0x002e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:12:0x002e, code lost:
            r5 = androidx.core.graphics.drawable.IconCompat.b.b(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:13:0x0034, code lost:
            r5 = androidx.core.graphics.drawable.IconCompat.a(r5, false);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0038, code lost:
            r5 = android.graphics.drawable.Icon.createWithBitmap(r5);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:27:0x00a7, code lost:
            r0 = r4.f2184g;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:28:0x00a9, code lost:
            if (r0 == null) goto L_0x00ae;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:29:0x00ab, code lost:
            r5.setTintList(r0);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:30:0x00ae, code lost:
            r4 = r4.f2185h;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:31:0x00b2, code lost:
            if (r4 == androidx.core.graphics.drawable.IconCompat.f2177k) goto L_0x00b7;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:32:0x00b4, code lost:
            r5.setTintMode(r4);
         */
        /* JADX WARNING: Code restructure failed: missing block: B:33:0x00b7, code lost:
            return r5;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        static android.graphics.drawable.Icon e(androidx.core.graphics.drawable.IconCompat r4, android.content.Context r5) {
            /*
                int r0 = r4.f2178a
                r1 = 0
                r2 = 26
                switch(r0) {
                    case -1: goto L_0x00b8;
                    case 0: goto L_0x0008;
                    case 1: goto L_0x00a2;
                    case 2: goto L_0x0097;
                    case 3: goto L_0x008a;
                    case 4: goto L_0x0081;
                    case 5: goto L_0x0073;
                    case 6: goto L_0x0010;
                    default: goto L_0x0008;
                }
            L_0x0008:
                java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
                java.lang.String r5 = "Unknown type"
                r4.<init>(r5)
                throw r4
            L_0x0010:
                int r0 = android.os.Build.VERSION.SDK_INT
                r3 = 30
                if (r0 < r3) goto L_0x0020
                android.net.Uri r5 = r4.d()
                android.graphics.drawable.Icon r5 = androidx.core.graphics.drawable.IconCompat.d.a(r5)
                goto L_0x00a7
            L_0x0020:
                if (r5 == 0) goto L_0x0058
                java.io.InputStream r5 = r4.e(r5)
                if (r5 == 0) goto L_0x003d
                android.graphics.Bitmap r5 = android.graphics.BitmapFactory.decodeStream(r5)
                if (r0 < r2) goto L_0x0034
            L_0x002e:
                android.graphics.drawable.Icon r5 = androidx.core.graphics.drawable.IconCompat.b.b(r5)
                goto L_0x00a7
            L_0x0034:
                android.graphics.Bitmap r5 = androidx.core.graphics.drawable.IconCompat.a(r5, r1)
            L_0x0038:
                android.graphics.drawable.Icon r5 = android.graphics.drawable.Icon.createWithBitmap(r5)
                goto L_0x00a7
            L_0x003d:
                java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "Cannot load adaptive icon from uri: "
                r0.append(r1)
                android.net.Uri r4 = r4.d()
                r0.append(r4)
                java.lang.String r4 = r0.toString()
                r5.<init>(r4)
                throw r5
            L_0x0058:
                java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "Context is required to resolve the file uri of the icon: "
                r0.append(r1)
                android.net.Uri r4 = r4.d()
                r0.append(r4)
                java.lang.String r4 = r0.toString()
                r5.<init>(r4)
                throw r5
            L_0x0073:
                int r5 = android.os.Build.VERSION.SDK_INT
                if (r5 < r2) goto L_0x007c
                java.lang.Object r5 = r4.f2179b
                android.graphics.Bitmap r5 = (android.graphics.Bitmap) r5
                goto L_0x002e
            L_0x007c:
                java.lang.Object r5 = r4.f2179b
                android.graphics.Bitmap r5 = (android.graphics.Bitmap) r5
                goto L_0x0034
            L_0x0081:
                java.lang.Object r5 = r4.f2179b
                java.lang.String r5 = (java.lang.String) r5
                android.graphics.drawable.Icon r5 = android.graphics.drawable.Icon.createWithContentUri(r5)
                goto L_0x00a7
            L_0x008a:
                java.lang.Object r5 = r4.f2179b
                byte[] r5 = (byte[]) r5
                int r0 = r4.f2182e
                int r1 = r4.f2183f
                android.graphics.drawable.Icon r5 = android.graphics.drawable.Icon.createWithData(r5, r0, r1)
                goto L_0x00a7
            L_0x0097:
                java.lang.String r5 = r4.c()
                int r0 = r4.f2182e
                android.graphics.drawable.Icon r5 = android.graphics.drawable.Icon.createWithResource(r5, r0)
                goto L_0x00a7
            L_0x00a2:
                java.lang.Object r5 = r4.f2179b
                android.graphics.Bitmap r5 = (android.graphics.Bitmap) r5
                goto L_0x0038
            L_0x00a7:
                android.content.res.ColorStateList r0 = r4.f2184g
                if (r0 == 0) goto L_0x00ae
                r5.setTintList(r0)
            L_0x00ae:
                android.graphics.PorterDuff$Mode r4 = r4.f2185h
                android.graphics.PorterDuff$Mode r0 = androidx.core.graphics.drawable.IconCompat.f2177k
                if (r4 == r0) goto L_0x00b7
                r5.setTintMode(r4)
            L_0x00b7:
                return r5
            L_0x00b8:
                java.lang.Object r4 = r4.f2179b
                android.graphics.drawable.Icon r4 = (android.graphics.drawable.Icon) r4
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.a.e(androidx.core.graphics.drawable.IconCompat, android.content.Context):android.graphics.drawable.Icon");
        }
    }

    static class b {
        static Drawable a(Drawable drawable, Drawable drawable2) {
            return new AdaptiveIconDrawable(drawable, drawable2);
        }

        static Icon b(Bitmap bitmap) {
            return Icon.createWithAdaptiveBitmap(bitmap);
        }
    }

    static class c {
        static int a(Object obj) {
            return ((Icon) obj).getResId();
        }

        static String b(Object obj) {
            return ((Icon) obj).getResPackage();
        }

        static int c(Object obj) {
            return ((Icon) obj).getType();
        }

        static Uri d(Object obj) {
            return ((Icon) obj).getUri();
        }
    }

    static class d {
        static Icon a(Uri uri) {
            return Icon.createWithAdaptiveBitmapContentUri(uri);
        }
    }

    static Bitmap a(Bitmap bitmap, boolean z2) {
        int min = (int) (((float) Math.min(bitmap.getWidth(), bitmap.getHeight())) * 0.6666667f);
        Bitmap createBitmap = Bitmap.createBitmap(min, min, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        Paint paint = new Paint(3);
        float f2 = (float) min;
        float f3 = 0.5f * f2;
        float f4 = 0.9166667f * f3;
        if (z2) {
            float f5 = 0.010416667f * f2;
            paint.setColor(0);
            paint.setShadowLayer(f5, 0.0f, f2 * 0.020833334f, 1023410176);
            canvas.drawCircle(f3, f3, f4, paint);
            paint.setShadowLayer(f5, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f3, f3, f4, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate(((float) (-(bitmap.getWidth() - min))) / 2.0f, ((float) (-(bitmap.getHeight() - min))) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f3, f3, f4, paint);
        canvas.setBitmap((Bitmap) null);
        return createBitmap;
    }

    private static String h(int i2) {
        switch (i2) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case 5:
                return "BITMAP_MASKABLE";
            case 6:
                return "URI_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    public int b() {
        int i2 = this.f2178a;
        if (i2 == -1 && Build.VERSION.SDK_INT >= 23) {
            return a.a(this.f2179b);
        }
        if (i2 == 2) {
            return this.f2182e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public String c() {
        int i2 = this.f2178a;
        if (i2 == -1 && Build.VERSION.SDK_INT >= 23) {
            return a.b(this.f2179b);
        }
        if (i2 == 2) {
            String str = this.f2187j;
            return (str == null || TextUtils.isEmpty(str)) ? ((String) this.f2179b).split(":", -1)[0] : this.f2187j;
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public Uri d() {
        int i2 = this.f2178a;
        if (i2 == -1 && Build.VERSION.SDK_INT >= 23) {
            return a.c(this.f2179b);
        }
        if (i2 == 4 || i2 == 6) {
            return Uri.parse((String) this.f2179b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public InputStream e(Context context) {
        StringBuilder sb;
        String str;
        Uri d2 = d();
        String scheme = d2.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(d2);
            } catch (Exception e2) {
                e = e2;
                sb = new StringBuilder();
                str = "Unable to load image from URI: ";
                sb.append(str);
                sb.append(d2);
                Log.w("IconCompat", sb.toString(), e);
                return null;
            }
        } else {
            try {
                return new FileInputStream(new File((String) this.f2179b));
            } catch (FileNotFoundException e3) {
                e = e3;
                sb = new StringBuilder();
                str = "Unable to load image from path: ";
                sb.append(str);
                sb.append(d2);
                Log.w("IconCompat", sb.toString(), e);
                return null;
            }
        }
    }

    public void f() {
        Parcelable parcelable;
        this.f2185h = PorterDuff.Mode.valueOf(this.f2186i);
        switch (this.f2178a) {
            case -1:
                parcelable = this.f2181d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                break;
            case 1:
            case 5:
                parcelable = this.f2181d;
                if (parcelable == null) {
                    byte[] bArr = this.f2180c;
                    this.f2179b = bArr;
                    this.f2178a = 3;
                    this.f2182e = 0;
                    this.f2183f = bArr.length;
                    return;
                }
                break;
            case 2:
            case 4:
            case 6:
                String str = new String(this.f2180c, Charset.forName("UTF-16"));
                this.f2179b = str;
                if (this.f2178a == 2 && this.f2187j == null) {
                    this.f2187j = str.split(":", -1)[0];
                    return;
                }
                return;
            case 3:
                this.f2179b = this.f2180c;
                return;
            default:
                return;
        }
        this.f2179b = parcelable;
    }

    public void g(boolean z2) {
        this.f2186i = this.f2185h.name();
        switch (this.f2178a) {
            case -1:
                if (z2) {
                    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
                }
                break;
            case 1:
            case 5:
                if (z2) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    ((Bitmap) this.f2179b).compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                    this.f2180c = byteArrayOutputStream.toByteArray();
                    return;
                }
                break;
            case 2:
                this.f2180c = ((String) this.f2179b).getBytes(Charset.forName("UTF-16"));
                return;
            case 3:
                this.f2180c = (byte[]) this.f2179b;
                return;
            case 4:
            case 6:
                this.f2180c = this.f2179b.toString().getBytes(Charset.forName("UTF-16"));
                return;
            default:
                return;
        }
        this.f2181d = (Parcelable) this.f2179b;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r4 = this;
            int r0 = r4.f2178a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r4.f2179b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r4.f2178a
            java.lang.String r1 = h(r1)
            r0.append(r1)
            int r1 = r4.f2178a
            switch(r1) {
                case 1: goto L_0x006d;
                case 2: goto L_0x0046;
                case 3: goto L_0x002d;
                case 4: goto L_0x0022;
                case 5: goto L_0x006d;
                case 6: goto L_0x0022;
                default: goto L_0x0021;
            }
        L_0x0021:
            goto L_0x008b
        L_0x0022:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r4.f2179b
            r0.append(r1)
            goto L_0x008b
        L_0x002d:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r4.f2182e
            r0.append(r1)
            int r1 = r4.f2183f
            if (r1 == 0) goto L_0x008b
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r4.f2183f
        L_0x0042:
            r0.append(r1)
            goto L_0x008b
        L_0x0046:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r4.f2187j
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            int r1 = r4.b()
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]
            r3 = 0
            r2[r3] = r1
            java.lang.String r1 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r1, r2)
            r0.append(r1)
            goto L_0x008b
        L_0x006d:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r4.f2179b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r4.f2179b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
            goto L_0x0042
        L_0x008b:
            android.content.res.ColorStateList r1 = r4.f2184g
            if (r1 == 0) goto L_0x0099
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r4.f2184g
            r0.append(r1)
        L_0x0099:
            android.graphics.PorterDuff$Mode r1 = r4.f2185h
            android.graphics.PorterDuff$Mode r2 = f2177k
            if (r1 == r2) goto L_0x00a9
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r4.f2185h
            r0.append(r1)
        L_0x00a9:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
