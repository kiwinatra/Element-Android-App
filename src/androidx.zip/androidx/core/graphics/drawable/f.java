package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

final class f extends Drawable.ConstantState {

    /* renamed from: a  reason: collision with root package name */
    int f2200a;

    /* renamed from: b  reason: collision with root package name */
    Drawable.ConstantState f2201b;

    /* renamed from: c  reason: collision with root package name */
    ColorStateList f2202c = null;

    /* renamed from: d  reason: collision with root package name */
    PorterDuff.Mode f2203d = d.f2192g;

    f(f fVar) {
        if (fVar != null) {
            this.f2200a = fVar.f2200a;
            this.f2201b = fVar.f2201b;
            this.f2202c = fVar.f2202c;
            this.f2203d = fVar.f2203d;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean a() {
        return this.f2201b != null;
    }

    public int getChangingConfigurations() {
        int i2 = this.f2200a;
        Drawable.ConstantState constantState = this.f2201b;
        return i2 | (constantState != null ? constantState.getChangingConfigurations() : 0);
    }

    public Drawable newDrawable() {
        return newDrawable((Resources) null);
    }

    public Drawable newDrawable(Resources resources) {
        return new e(this, resources);
    }
}
