package androidx.core.graphics;

import android.graphics.Insets;
import android.graphics.Rect;

public final class f {

    /* renamed from: e  reason: collision with root package name */
    public static final f f2204e = new f(0, 0, 0, 0);

    /* renamed from: a  reason: collision with root package name */
    public final int f2205a;

    /* renamed from: b  reason: collision with root package name */
    public final int f2206b;

    /* renamed from: c  reason: collision with root package name */
    public final int f2207c;

    /* renamed from: d  reason: collision with root package name */
    public final int f2208d;

    static class a {
        static Insets a(int i2, int i3, int i4, int i5) {
            return Insets.of(i2, i3, i4, i5);
        }
    }

    private f(int i2, int i3, int i4, int i5) {
        this.f2205a = i2;
        this.f2206b = i3;
        this.f2207c = i4;
        this.f2208d = i5;
    }

    public static f a(f fVar, f fVar2) {
        return b(Math.max(fVar.f2205a, fVar2.f2205a), Math.max(fVar.f2206b, fVar2.f2206b), Math.max(fVar.f2207c, fVar2.f2207c), Math.max(fVar.f2208d, fVar2.f2208d));
    }

    public static f b(int i2, int i3, int i4, int i5) {
        return (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? f2204e : new f(i2, i3, i4, i5);
    }

    public static f c(Rect rect) {
        return b(rect.left, rect.top, rect.right, rect.bottom);
    }

    public static f d(Insets insets) {
        return b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public Insets e() {
        return a.a(this.f2205a, this.f2206b, this.f2207c, this.f2208d);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || f.class != obj.getClass()) {
            return false;
        }
        f fVar = (f) obj;
        return this.f2208d == fVar.f2208d && this.f2205a == fVar.f2205a && this.f2207c == fVar.f2207c && this.f2206b == fVar.f2206b;
    }

    public int hashCode() {
        return (((((this.f2205a * 31) + this.f2206b) * 31) + this.f2207c) * 31) + this.f2208d;
    }

    public String toString() {
        return "Insets{left=" + this.f2205a + ", top=" + this.f2206b + ", right=" + this.f2207c + ", bottom=" + this.f2208d + '}';
    }
}
