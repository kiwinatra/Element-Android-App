package androidx.core.graphics;

public abstract /* synthetic */ class d {
}
