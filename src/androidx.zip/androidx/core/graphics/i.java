package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.core.content.res.e;
import androidx.core.content.res.h;
import l.e;
import w.h;

public abstract class i {

    /* renamed from: a  reason: collision with root package name */
    private static final o f2214a;

    /* renamed from: b  reason: collision with root package name */
    private static final e f2215b = new e(16);

    public static class a extends h.c {

        /* renamed from: a  reason: collision with root package name */
        private h.e f2216a;

        public a(h.e eVar) {
            this.f2216a = eVar;
        }

        public void a(int i2) {
            h.e eVar = this.f2216a;
            if (eVar != null) {
                eVar.f(i2);
            }
        }

        public void b(Typeface typeface) {
            h.e eVar = this.f2216a;
            if (eVar != null) {
                eVar.g(typeface);
            }
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        f2214a = i2 >= 29 ? new n() : i2 >= 28 ? new m() : i2 >= 26 ? new l() : (i2 < 24 || !k.j()) ? new j() : new k();
    }

    public static Typeface a(Context context, Typeface typeface, int i2) {
        if (context != null) {
            return Typeface.create(typeface, i2);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    public static Typeface b(Context context, CancellationSignal cancellationSignal, h.b[] bVarArr, int i2) {
        return f2214a.b(context, cancellationSignal, bVarArr, i2);
    }

    public static Typeface c(Context context, e.b bVar, Resources resources, int i2, String str, int i3, int i4, h.e eVar, Handler handler, boolean z2) {
        Typeface typeface;
        e.b bVar2 = bVar;
        h.e eVar2 = eVar;
        Handler handler2 = handler;
        if (bVar2 instanceof e.C0026e) {
            e.C0026e eVar3 = (e.C0026e) bVar2;
            Typeface g2 = g(eVar3.c());
            if (g2 != null) {
                if (eVar2 != null) {
                    eVar2.d(g2, handler2);
                }
                return g2;
            }
            typeface = w.h.c(context, eVar3.b(), i4, !z2 ? eVar2 == null : eVar3.a() == 0, z2 ? eVar3.d() : -1, h.e.e(handler), new a(eVar2));
            Resources resources2 = resources;
            int i5 = i4;
        } else {
            Context context2 = context;
            Resources resources3 = resources;
            typeface = f2214a.a(context, (e.c) bVar2, resources, i4);
            if (eVar2 != null) {
                if (typeface != null) {
                    eVar2.d(typeface, handler2);
                } else {
                    eVar2.c(-3, handler2);
                }
            }
        }
        if (typeface != null) {
            f2215b.d(e(resources, i2, str, i3, i4), typeface);
        }
        return typeface;
    }

    public static Typeface d(Context context, Resources resources, int i2, String str, int i3, int i4) {
        Typeface d2 = f2214a.d(context, resources, i2, str, i4);
        if (d2 != null) {
            f2215b.d(e(resources, i2, str, i3, i4), d2);
        }
        return d2;
    }

    private static String e(Resources resources, int i2, String str, int i3, int i4) {
        return resources.getResourcePackageName(i2) + '-' + str + '-' + i3 + '-' + i2 + '-' + i4;
    }

    public static Typeface f(Resources resources, int i2, String str, int i3, int i4) {
        return (Typeface) f2215b.c(e(resources, i2, str, i3, i4));
    }

    private static Typeface g(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        Typeface create = Typeface.create(str, 0);
        Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
        if (create == null || create.equals(create2)) {
            return null;
        }
        return create;
    }
}
