package androidx.core.graphics;

public abstract /* synthetic */ class c {
}
