package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.res.e;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;
import l.g;
import w.h;

class k extends o {

    /* renamed from: b  reason: collision with root package name */
    private static final Class f2222b;

    /* renamed from: c  reason: collision with root package name */
    private static final Constructor f2223c;

    /* renamed from: d  reason: collision with root package name */
    private static final Method f2224d;

    /* renamed from: e  reason: collision with root package name */
    private static final Method f2225e;

    static {
        Method method;
        Class<?> cls;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor((Class[]) null);
            Class cls2 = Integer.TYPE;
            method = cls.getMethod("addFontWeightStyle", new Class[]{ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE});
            method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(cls, 1).getClass()});
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi24Impl", e2.getClass().getName(), e2);
            method2 = null;
            cls = null;
            method = null;
        }
        f2223c = constructor;
        f2222b = cls;
        f2224d = method;
        f2225e = method2;
    }

    k() {
    }

    private static boolean h(Object obj, ByteBuffer byteBuffer, int i2, int i3, boolean z2) {
        try {
            return ((Boolean) f2224d.invoke(obj, new Object[]{byteBuffer, Integer.valueOf(i2), null, Integer.valueOf(i3), Boolean.valueOf(z2)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    private static Typeface i(Object obj) {
        try {
            Object newInstance = Array.newInstance(f2222b, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) f2225e.invoke((Object) null, new Object[]{newInstance});
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public static boolean j() {
        Method method = f2224d;
        if (method == null) {
            Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
        }
        return method != null;
    }

    private static Object k() {
        try {
            return f2223c.newInstance((Object[]) null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            return null;
        }
    }

    public Typeface a(Context context, e.c cVar, Resources resources, int i2) {
        Object k2 = k();
        if (k2 == null) {
            return null;
        }
        for (e.d dVar : cVar.a()) {
            ByteBuffer b2 = p.b(context, resources, dVar.b());
            if (b2 == null || !h(k2, b2, dVar.c(), dVar.e(), dVar.f())) {
                return null;
            }
        }
        return i(k2);
    }

    public Typeface b(Context context, CancellationSignal cancellationSignal, h.b[] bVarArr, int i2) {
        Object k2 = k();
        if (k2 == null) {
            return null;
        }
        g gVar = new g();
        for (h.b bVar : bVarArr) {
            Uri d2 = bVar.d();
            ByteBuffer byteBuffer = (ByteBuffer) gVar.get(d2);
            if (byteBuffer == null) {
                byteBuffer = p.f(context, cancellationSignal, d2);
                gVar.put(d2, byteBuffer);
            }
            if (byteBuffer == null || !h(k2, byteBuffer, bVar.c(), bVar.e(), bVar.f())) {
                return null;
            }
        }
        Typeface i3 = i(k2);
        if (i3 == null) {
            return null;
        }
        return Typeface.create(i3, i2);
    }
}
