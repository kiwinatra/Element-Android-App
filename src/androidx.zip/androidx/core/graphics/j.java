package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import androidx.core.content.res.e;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import w.h;

class j extends o {

    /* renamed from: b  reason: collision with root package name */
    private static Class f2217b = null;

    /* renamed from: c  reason: collision with root package name */
    private static Constructor f2218c = null;

    /* renamed from: d  reason: collision with root package name */
    private static Method f2219d = null;

    /* renamed from: e  reason: collision with root package name */
    private static Method f2220e = null;

    /* renamed from: f  reason: collision with root package name */
    private static boolean f2221f = false;

    j() {
    }

    private static boolean h(Object obj, String str, int i2, boolean z2) {
        k();
        try {
            return ((Boolean) f2219d.invoke(obj, new Object[]{str, Integer.valueOf(i2), Boolean.valueOf(z2)})).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    private static Typeface i(Object obj) {
        k();
        try {
            Object newInstance = Array.newInstance(f2217b, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) f2220e.invoke((Object) null, new Object[]{newInstance});
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    private File j(ParcelFileDescriptor parcelFileDescriptor) {
        try {
            String readlink = Os.readlink("/proc/self/fd/" + parcelFileDescriptor.getFd());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
        } catch (ErrnoException unused) {
        }
        return null;
    }

    private static void k() {
        Method method;
        Class<?> cls;
        Method method2;
        if (!f2221f) {
            f2221f = true;
            Constructor<?> constructor = null;
            try {
                cls = Class.forName("android.graphics.FontFamily");
                Constructor<?> constructor2 = cls.getConstructor((Class[]) null);
                method = cls.getMethod("addFontWeightStyle", new Class[]{String.class, Integer.TYPE, Boolean.TYPE});
                method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(cls, 1).getClass()});
                constructor = constructor2;
            } catch (ClassNotFoundException | NoSuchMethodException e2) {
                Log.e("TypefaceCompatApi21Impl", e2.getClass().getName(), e2);
                method2 = null;
                cls = null;
                method = null;
            }
            f2218c = constructor;
            f2217b = cls;
            f2219d = method;
            f2220e = method2;
        }
    }

    private static Object l() {
        k();
        try {
            return f2218c.newInstance((Object[]) null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public Typeface a(Context context, e.c cVar, Resources resources, int i2) {
        Object l2 = l();
        e.d[] a2 = cVar.a();
        int length = a2.length;
        int i3 = 0;
        while (i3 < length) {
            e.d dVar = a2[i3];
            File e2 = p.e(context);
            if (e2 == null) {
                return null;
            }
            try {
                if (!p.c(e2, resources, dVar.b())) {
                    e2.delete();
                    return null;
                } else if (!h(l2, e2.getPath(), dVar.e(), dVar.f())) {
                    return null;
                } else {
                    i3++;
                }
            } catch (RuntimeException unused) {
                return null;
            } finally {
                e2.delete();
            }
        }
        return i(l2);
    }

    public Typeface b(Context context, CancellationSignal cancellationSignal, h.b[] bVarArr, int i2) {
        ParcelFileDescriptor openFileDescriptor;
        FileInputStream fileInputStream;
        if (bVarArr.length < 1) {
            return null;
        }
        h.b g2 = g(bVarArr, i2);
        try {
            openFileDescriptor = context.getContentResolver().openFileDescriptor(g2.d(), "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            File j2 = j(openFileDescriptor);
            if (j2 != null) {
                if (j2.canRead()) {
                    Typeface createFromFile = Typeface.createFromFile(j2);
                    openFileDescriptor.close();
                    return createFromFile;
                }
            }
            fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
            Typeface c2 = super.c(context, fileInputStream);
            fileInputStream.close();
            openFileDescriptor.close();
            return c2;
        } catch (IOException unused) {
            return null;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
        throw th;
    }
}
