package androidx.core.view;

/* renamed from: androidx.core.view.w  reason: case insensitive filesystem */
public interface C0164w {
    void f(C0170z zVar);

    void h(C0170z zVar);
}
