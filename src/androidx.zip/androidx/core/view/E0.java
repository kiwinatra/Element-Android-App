package androidx.core.view;

import android.view.WindowInsets;

public abstract /* synthetic */ class E0 {
    public static /* synthetic */ WindowInsets.Builder a() {
        return new WindowInsets.Builder();
    }
}
