package androidx.core.view;

/* renamed from: androidx.core.view.k  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0141k {
}
