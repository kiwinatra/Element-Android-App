package androidx.core.view;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* renamed from: androidx.core.view.w0  reason: case insensitive filesystem */
public class C0165w0 {

    /* renamed from: b  reason: collision with root package name */
    public static final C0165w0 f2421b = (Build.VERSION.SDK_INT >= 30 ? k.f2451q : l.f2452b);

    /* renamed from: a  reason: collision with root package name */
    private final l f2422a;

    /* renamed from: androidx.core.view.w0$a */
    static class a {

        /* renamed from: a  reason: collision with root package name */
        private static Field f2423a;

        /* renamed from: b  reason: collision with root package name */
        private static Field f2424b;

        /* renamed from: c  reason: collision with root package name */
        private static Field f2425c;

        /* renamed from: d  reason: collision with root package name */
        private static boolean f2426d = true;

        static {
            try {
                Field declaredField = View.class.getDeclaredField("mAttachInfo");
                f2423a = declaredField;
                declaredField.setAccessible(true);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                Field declaredField2 = cls.getDeclaredField("mStableInsets");
                f2424b = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = cls.getDeclaredField("mContentInsets");
                f2425c = declaredField3;
                declaredField3.setAccessible(true);
            } catch (ReflectiveOperationException e2) {
                Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e2.getMessage(), e2);
            }
        }

        public static C0165w0 a(View view) {
            if (f2426d && view.isAttachedToWindow()) {
                try {
                    Object obj = f2423a.get(view.getRootView());
                    if (obj != null) {
                        Rect rect = (Rect) f2424b.get(obj);
                        Rect rect2 = (Rect) f2425c.get(obj);
                        if (!(rect == null || rect2 == null)) {
                            C0165w0 a2 = new b().c(androidx.core.graphics.f.c(rect)).d(androidx.core.graphics.f.c(rect2)).a();
                            a2.t(a2);
                            a2.d(view.getRootView());
                            return a2;
                        }
                    }
                } catch (IllegalAccessException e2) {
                    Log.w("WindowInsetsCompat", "Failed to get insets from AttachInfo. " + e2.getMessage(), e2);
                }
            }
            return null;
        }
    }

    /* renamed from: androidx.core.view.w0$b */
    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        private final f f2427a;

        public b() {
            int i2 = Build.VERSION.SDK_INT;
            this.f2427a = i2 >= 30 ? new e() : i2 >= 29 ? new d() : new c();
        }

        public C0165w0 a() {
            return this.f2427a.b();
        }

        public b b(int i2, androidx.core.graphics.f fVar) {
            this.f2427a.c(i2, fVar);
            return this;
        }

        public b c(androidx.core.graphics.f fVar) {
            this.f2427a.e(fVar);
            return this;
        }

        public b d(androidx.core.graphics.f fVar) {
            this.f2427a.g(fVar);
            return this;
        }

        public b(C0165w0 w0Var) {
            int i2 = Build.VERSION.SDK_INT;
            this.f2427a = i2 >= 30 ? new e(w0Var) : i2 >= 29 ? new d(w0Var) : new c(w0Var);
        }
    }

    /* renamed from: androidx.core.view.w0$c */
    private static class c extends f {

        /* renamed from: e  reason: collision with root package name */
        private static Field f2428e = null;

        /* renamed from: f  reason: collision with root package name */
        private static boolean f2429f = false;

        /* renamed from: g  reason: collision with root package name */
        private static Constructor f2430g = null;

        /* renamed from: h  reason: collision with root package name */
        private static boolean f2431h = false;

        /* renamed from: c  reason: collision with root package name */
        private WindowInsets f2432c;

        /* renamed from: d  reason: collision with root package name */
        private androidx.core.graphics.f f2433d;

        c() {
            this.f2432c = i();
        }

        private static WindowInsets i() {
            Class<WindowInsets> cls = WindowInsets.class;
            if (!f2429f) {
                try {
                    f2428e = cls.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                f2429f = true;
            }
            Field field = f2428e;
            if (field != null) {
                try {
                    WindowInsets windowInsets = (WindowInsets) field.get((Object) null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
            }
            if (!f2431h) {
                try {
                    f2430g = cls.getConstructor(new Class[]{Rect.class});
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                f2431h = true;
            }
            Constructor constructor = f2430g;
            if (constructor != null) {
                try {
                    return (WindowInsets) constructor.newInstance(new Object[]{new Rect()});
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 b() {
            a();
            C0165w0 w2 = C0165w0.w(this.f2432c);
            w2.r(this.f2436b);
            w2.u(this.f2433d);
            return w2;
        }

        /* access modifiers changed from: package-private */
        public void e(androidx.core.graphics.f fVar) {
            this.f2433d = fVar;
        }

        /* access modifiers changed from: package-private */
        public void g(androidx.core.graphics.f fVar) {
            WindowInsets windowInsets = this.f2432c;
            if (windowInsets != null) {
                this.f2432c = windowInsets.replaceSystemWindowInsets(fVar.f2205a, fVar.f2206b, fVar.f2207c, fVar.f2208d);
            }
        }

        c(C0165w0 w0Var) {
            super(w0Var);
            this.f2432c = w0Var.v();
        }
    }

    /* renamed from: androidx.core.view.w0$d */
    private static class d extends f {

        /* renamed from: c  reason: collision with root package name */
        final WindowInsets.Builder f2434c;

        d() {
            this.f2434c = E0.a();
        }

        /* access modifiers changed from: package-private */
        public C0165w0 b() {
            a();
            C0165w0 w2 = C0165w0.w(this.f2434c.build());
            w2.r(this.f2436b);
            return w2;
        }

        /* access modifiers changed from: package-private */
        public void d(androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setMandatorySystemGestureInsets(fVar.e());
        }

        /* access modifiers changed from: package-private */
        public void e(androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setStableInsets(fVar.e());
        }

        /* access modifiers changed from: package-private */
        public void f(androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setSystemGestureInsets(fVar.e());
        }

        /* access modifiers changed from: package-private */
        public void g(androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setSystemWindowInsets(fVar.e());
        }

        /* access modifiers changed from: package-private */
        public void h(androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setTappableElementInsets(fVar.e());
        }

        d(C0165w0 w0Var) {
            super(w0Var);
            WindowInsets v2 = w0Var.v();
            this.f2434c = v2 != null ? D0.a(v2) : E0.a();
        }
    }

    /* renamed from: androidx.core.view.w0$e */
    private static class e extends d {
        e() {
        }

        /* access modifiers changed from: package-private */
        public void c(int i2, androidx.core.graphics.f fVar) {
            WindowInsets.Builder unused = this.f2434c.setInsets(n.a(i2), fVar.e());
        }

        e(C0165w0 w0Var) {
            super(w0Var);
        }
    }

    /* renamed from: androidx.core.view.w0$f */
    private static class f {

        /* renamed from: a  reason: collision with root package name */
        private final C0165w0 f2435a;

        /* renamed from: b  reason: collision with root package name */
        androidx.core.graphics.f[] f2436b;

        f() {
            this(new C0165w0((C0165w0) null));
        }

        /* access modifiers changed from: protected */
        public final void a() {
            androidx.core.graphics.f[] fVarArr = this.f2436b;
            if (fVarArr != null) {
                androidx.core.graphics.f fVar = fVarArr[m.b(1)];
                androidx.core.graphics.f fVar2 = this.f2436b[m.b(2)];
                if (fVar2 == null) {
                    fVar2 = this.f2435a.f(2);
                }
                if (fVar == null) {
                    fVar = this.f2435a.f(1);
                }
                g(androidx.core.graphics.f.a(fVar, fVar2));
                androidx.core.graphics.f fVar3 = this.f2436b[m.b(16)];
                if (fVar3 != null) {
                    f(fVar3);
                }
                androidx.core.graphics.f fVar4 = this.f2436b[m.b(32)];
                if (fVar4 != null) {
                    d(fVar4);
                }
                androidx.core.graphics.f fVar5 = this.f2436b[m.b(64)];
                if (fVar5 != null) {
                    h(fVar5);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public abstract C0165w0 b();

        /* access modifiers changed from: package-private */
        public void c(int i2, androidx.core.graphics.f fVar) {
            if (this.f2436b == null) {
                this.f2436b = new androidx.core.graphics.f[9];
            }
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    this.f2436b[m.b(i3)] = fVar;
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d(androidx.core.graphics.f fVar) {
        }

        /* access modifiers changed from: package-private */
        public abstract void e(androidx.core.graphics.f fVar);

        /* access modifiers changed from: package-private */
        public void f(androidx.core.graphics.f fVar) {
        }

        /* access modifiers changed from: package-private */
        public abstract void g(androidx.core.graphics.f fVar);

        /* access modifiers changed from: package-private */
        public void h(androidx.core.graphics.f fVar) {
        }

        f(C0165w0 w0Var) {
            this.f2435a = w0Var;
        }
    }

    /* renamed from: androidx.core.view.w0$g */
    private static class g extends l {

        /* renamed from: h  reason: collision with root package name */
        private static boolean f2437h = false;

        /* renamed from: i  reason: collision with root package name */
        private static Method f2438i;

        /* renamed from: j  reason: collision with root package name */
        private static Class f2439j;

        /* renamed from: k  reason: collision with root package name */
        private static Field f2440k;

        /* renamed from: l  reason: collision with root package name */
        private static Field f2441l;

        /* renamed from: c  reason: collision with root package name */
        final WindowInsets f2442c;

        /* renamed from: d  reason: collision with root package name */
        private androidx.core.graphics.f[] f2443d;

        /* renamed from: e  reason: collision with root package name */
        private androidx.core.graphics.f f2444e;

        /* renamed from: f  reason: collision with root package name */
        private C0165w0 f2445f;

        /* renamed from: g  reason: collision with root package name */
        androidx.core.graphics.f f2446g;

        g(C0165w0 w0Var, WindowInsets windowInsets) {
            super(w0Var);
            this.f2444e = null;
            this.f2442c = windowInsets;
        }

        @SuppressLint({"WrongConstant"})
        private androidx.core.graphics.f t(int i2, boolean z2) {
            androidx.core.graphics.f fVar = androidx.core.graphics.f.f2204e;
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    fVar = androidx.core.graphics.f.a(fVar, u(i3, z2));
                }
            }
            return fVar;
        }

        private androidx.core.graphics.f v() {
            C0165w0 w0Var = this.f2445f;
            return w0Var != null ? w0Var.g() : androidx.core.graphics.f.f2204e;
        }

        private androidx.core.graphics.f w(View view) {
            if (Build.VERSION.SDK_INT < 30) {
                if (!f2437h) {
                    x();
                }
                Method method = f2438i;
                if (!(method == null || f2439j == null || f2440k == null)) {
                    try {
                        Object invoke = method.invoke(view, (Object[]) null);
                        if (invoke == null) {
                            Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                            return null;
                        }
                        Rect rect = (Rect) f2440k.get(f2441l.get(invoke));
                        if (rect != null) {
                            return androidx.core.graphics.f.c(rect);
                        }
                        return null;
                    } catch (ReflectiveOperationException e2) {
                        Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
                    }
                }
                return null;
            }
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }

        @SuppressLint({"PrivateApi"})
        private static void x() {
            try {
                f2438i = View.class.getDeclaredMethod("getViewRootImpl", (Class[]) null);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                f2439j = cls;
                f2440k = cls.getDeclaredField("mVisibleInsets");
                f2441l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
                f2440k.setAccessible(true);
                f2441l.setAccessible(true);
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
            f2437h = true;
        }

        /* access modifiers changed from: package-private */
        public void d(View view) {
            androidx.core.graphics.f w2 = w(view);
            if (w2 == null) {
                w2 = androidx.core.graphics.f.f2204e;
            }
            q(w2);
        }

        /* access modifiers changed from: package-private */
        public void e(C0165w0 w0Var) {
            w0Var.t(this.f2445f);
            w0Var.s(this.f2446g);
        }

        public boolean equals(Object obj) {
            if (!super.equals(obj)) {
                return false;
            }
            return Objects.equals(this.f2446g, ((g) obj).f2446g);
        }

        public androidx.core.graphics.f g(int i2) {
            return t(i2, false);
        }

        /* access modifiers changed from: package-private */
        public final androidx.core.graphics.f k() {
            if (this.f2444e == null) {
                this.f2444e = androidx.core.graphics.f.b(this.f2442c.getSystemWindowInsetLeft(), this.f2442c.getSystemWindowInsetTop(), this.f2442c.getSystemWindowInsetRight(), this.f2442c.getSystemWindowInsetBottom());
            }
            return this.f2444e;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 m(int i2, int i3, int i4, int i5) {
            b bVar = new b(C0165w0.w(this.f2442c));
            bVar.d(C0165w0.o(k(), i2, i3, i4, i5));
            bVar.c(C0165w0.o(i(), i2, i3, i4, i5));
            return bVar.a();
        }

        /* access modifiers changed from: package-private */
        public boolean o() {
            return this.f2442c.isRound();
        }

        public void p(androidx.core.graphics.f[] fVarArr) {
            this.f2443d = fVarArr;
        }

        /* access modifiers changed from: package-private */
        public void q(androidx.core.graphics.f fVar) {
            this.f2446g = fVar;
        }

        /* access modifiers changed from: package-private */
        public void r(C0165w0 w0Var) {
            this.f2445f = w0Var;
        }

        /* access modifiers changed from: protected */
        public androidx.core.graphics.f u(int i2, boolean z2) {
            int i3;
            if (i2 == 1) {
                return z2 ? androidx.core.graphics.f.b(0, Math.max(v().f2206b, k().f2206b), 0, 0) : androidx.core.graphics.f.b(0, k().f2206b, 0, 0);
            }
            androidx.core.graphics.f fVar = null;
            if (i2 != 2) {
                if (i2 == 8) {
                    androidx.core.graphics.f[] fVarArr = this.f2443d;
                    if (fVarArr != null) {
                        fVar = fVarArr[m.b(8)];
                    }
                    if (fVar != null) {
                        return fVar;
                    }
                    androidx.core.graphics.f k2 = k();
                    androidx.core.graphics.f v2 = v();
                    int i4 = k2.f2208d;
                    if (i4 > v2.f2208d) {
                        return androidx.core.graphics.f.b(0, 0, 0, i4);
                    }
                    androidx.core.graphics.f fVar2 = this.f2446g;
                    return (fVar2 == null || fVar2.equals(androidx.core.graphics.f.f2204e) || (i3 = this.f2446g.f2208d) <= v2.f2208d) ? androidx.core.graphics.f.f2204e : androidx.core.graphics.f.b(0, 0, 0, i3);
                } else if (i2 == 16) {
                    return j();
                } else {
                    if (i2 == 32) {
                        return h();
                    }
                    if (i2 == 64) {
                        return l();
                    }
                    if (i2 != 128) {
                        return androidx.core.graphics.f.f2204e;
                    }
                    C0165w0 w0Var = this.f2445f;
                    r e2 = w0Var != null ? w0Var.e() : f();
                    return e2 != null ? androidx.core.graphics.f.b(e2.b(), e2.d(), e2.c(), e2.a()) : androidx.core.graphics.f.f2204e;
                }
            } else if (z2) {
                androidx.core.graphics.f v3 = v();
                androidx.core.graphics.f i5 = i();
                return androidx.core.graphics.f.b(Math.max(v3.f2205a, i5.f2205a), 0, Math.max(v3.f2207c, i5.f2207c), Math.max(v3.f2208d, i5.f2208d));
            } else {
                androidx.core.graphics.f k3 = k();
                C0165w0 w0Var2 = this.f2445f;
                if (w0Var2 != null) {
                    fVar = w0Var2.g();
                }
                int i6 = k3.f2208d;
                if (fVar != null) {
                    i6 = Math.min(i6, fVar.f2208d);
                }
                return androidx.core.graphics.f.b(k3.f2205a, 0, k3.f2207c, i6);
            }
        }

        g(C0165w0 w0Var, g gVar) {
            this(w0Var, new WindowInsets(gVar.f2442c));
        }
    }

    /* renamed from: androidx.core.view.w0$h */
    private static class h extends g {

        /* renamed from: m  reason: collision with root package name */
        private androidx.core.graphics.f f2447m = null;

        h(C0165w0 w0Var, WindowInsets windowInsets) {
            super(w0Var, windowInsets);
        }

        /* access modifiers changed from: package-private */
        public C0165w0 b() {
            return C0165w0.w(this.f2442c.consumeStableInsets());
        }

        /* access modifiers changed from: package-private */
        public C0165w0 c() {
            return C0165w0.w(this.f2442c.consumeSystemWindowInsets());
        }

        /* access modifiers changed from: package-private */
        public final androidx.core.graphics.f i() {
            if (this.f2447m == null) {
                this.f2447m = androidx.core.graphics.f.b(this.f2442c.getStableInsetLeft(), this.f2442c.getStableInsetTop(), this.f2442c.getStableInsetRight(), this.f2442c.getStableInsetBottom());
            }
            return this.f2447m;
        }

        /* access modifiers changed from: package-private */
        public boolean n() {
            return this.f2442c.isConsumed();
        }

        public void s(androidx.core.graphics.f fVar) {
            this.f2447m = fVar;
        }

        h(C0165w0 w0Var, h hVar) {
            super(w0Var, (g) hVar);
            this.f2447m = hVar.f2447m;
        }
    }

    /* renamed from: androidx.core.view.w0$i */
    private static class i extends h {
        i(C0165w0 w0Var, WindowInsets windowInsets) {
            super(w0Var, windowInsets);
        }

        /* access modifiers changed from: package-private */
        public C0165w0 a() {
            return C0165w0.w(this.f2442c.consumeDisplayCutout());
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof i)) {
                return false;
            }
            i iVar = (i) obj;
            return Objects.equals(this.f2442c, iVar.f2442c) && Objects.equals(this.f2446g, iVar.f2446g);
        }

        /* access modifiers changed from: package-private */
        public r f() {
            return r.e(this.f2442c.getDisplayCutout());
        }

        public int hashCode() {
            return this.f2442c.hashCode();
        }

        i(C0165w0 w0Var, i iVar) {
            super(w0Var, (h) iVar);
        }
    }

    /* renamed from: androidx.core.view.w0$j */
    private static class j extends i {

        /* renamed from: n  reason: collision with root package name */
        private androidx.core.graphics.f f2448n = null;

        /* renamed from: o  reason: collision with root package name */
        private androidx.core.graphics.f f2449o = null;

        /* renamed from: p  reason: collision with root package name */
        private androidx.core.graphics.f f2450p = null;

        j(C0165w0 w0Var, WindowInsets windowInsets) {
            super(w0Var, windowInsets);
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f h() {
            if (this.f2449o == null) {
                this.f2449o = androidx.core.graphics.f.d(this.f2442c.getMandatorySystemGestureInsets());
            }
            return this.f2449o;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f j() {
            if (this.f2448n == null) {
                this.f2448n = androidx.core.graphics.f.d(this.f2442c.getSystemGestureInsets());
            }
            return this.f2448n;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f l() {
            if (this.f2450p == null) {
                this.f2450p = androidx.core.graphics.f.d(this.f2442c.getTappableElementInsets());
            }
            return this.f2450p;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 m(int i2, int i3, int i4, int i5) {
            return C0165w0.w(this.f2442c.inset(i2, i3, i4, i5));
        }

        public void s(androidx.core.graphics.f fVar) {
        }

        j(C0165w0 w0Var, j jVar) {
            super(w0Var, (i) jVar);
        }
    }

    /* renamed from: androidx.core.view.w0$k */
    private static class k extends j {

        /* renamed from: q  reason: collision with root package name */
        static final C0165w0 f2451q = C0165w0.w(WindowInsets.CONSUMED);

        k(C0165w0 w0Var, WindowInsets windowInsets) {
            super(w0Var, windowInsets);
        }

        /* access modifiers changed from: package-private */
        public final void d(View view) {
        }

        public androidx.core.graphics.f g(int i2) {
            return androidx.core.graphics.f.d(this.f2442c.getInsets(n.a(i2)));
        }

        k(C0165w0 w0Var, k kVar) {
            super(w0Var, (j) kVar);
        }
    }

    /* renamed from: androidx.core.view.w0$l */
    private static class l {

        /* renamed from: b  reason: collision with root package name */
        static final C0165w0 f2452b = new b().a().a().b().c();

        /* renamed from: a  reason: collision with root package name */
        final C0165w0 f2453a;

        l(C0165w0 w0Var) {
            this.f2453a = w0Var;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 a() {
            return this.f2453a;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 b() {
            return this.f2453a;
        }

        /* access modifiers changed from: package-private */
        public C0165w0 c() {
            return this.f2453a;
        }

        /* access modifiers changed from: package-private */
        public void d(View view) {
        }

        /* access modifiers changed from: package-private */
        public void e(C0165w0 w0Var) {
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof l)) {
                return false;
            }
            l lVar = (l) obj;
            return o() == lVar.o() && n() == lVar.n() && x.c.a(k(), lVar.k()) && x.c.a(i(), lVar.i()) && x.c.a(f(), lVar.f());
        }

        /* access modifiers changed from: package-private */
        public r f() {
            return null;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f g(int i2) {
            return androidx.core.graphics.f.f2204e;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f h() {
            return k();
        }

        public int hashCode() {
            return x.c.b(Boolean.valueOf(o()), Boolean.valueOf(n()), k(), i(), f());
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f i() {
            return androidx.core.graphics.f.f2204e;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f j() {
            return k();
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f k() {
            return androidx.core.graphics.f.f2204e;
        }

        /* access modifiers changed from: package-private */
        public androidx.core.graphics.f l() {
            return k();
        }

        /* access modifiers changed from: package-private */
        public C0165w0 m(int i2, int i3, int i4, int i5) {
            return f2452b;
        }

        /* access modifiers changed from: package-private */
        public boolean n() {
            return false;
        }

        /* access modifiers changed from: package-private */
        public boolean o() {
            return false;
        }

        public void p(androidx.core.graphics.f[] fVarArr) {
        }

        /* access modifiers changed from: package-private */
        public void q(androidx.core.graphics.f fVar) {
        }

        /* access modifiers changed from: package-private */
        public void r(C0165w0 w0Var) {
        }

        public void s(androidx.core.graphics.f fVar) {
        }
    }

    /* renamed from: androidx.core.view.w0$m */
    public static final class m {
        public static int a() {
            return 8;
        }

        static int b(int i2) {
            if (i2 == 1) {
                return 0;
            }
            if (i2 == 2) {
                return 1;
            }
            if (i2 == 4) {
                return 2;
            }
            if (i2 == 8) {
                return 3;
            }
            if (i2 == 16) {
                return 4;
            }
            if (i2 == 32) {
                return 5;
            }
            if (i2 == 64) {
                return 6;
            }
            if (i2 == 128) {
                return 7;
            }
            if (i2 == 256) {
                return 8;
            }
            throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i2);
        }

        public static int c() {
            return 32;
        }

        public static int d() {
            return 7;
        }
    }

    /* renamed from: androidx.core.view.w0$n */
    private static final class n {
        static int a(int i2) {
            int a2;
            int i3 = 0;
            for (int i4 = 1; i4 <= 256; i4 <<= 1) {
                if ((i2 & i4) != 0) {
                    if (i4 == 1) {
                        a2 = WindowInsets.Type.statusBars();
                    } else if (i4 == 2) {
                        a2 = WindowInsets.Type.navigationBars();
                    } else if (i4 == 4) {
                        a2 = WindowInsets.Type.captionBar();
                    } else if (i4 == 8) {
                        a2 = WindowInsets.Type.ime();
                    } else if (i4 == 16) {
                        a2 = WindowInsets.Type.systemGestures();
                    } else if (i4 == 32) {
                        a2 = WindowInsets.Type.mandatorySystemGestures();
                    } else if (i4 == 64) {
                        a2 = WindowInsets.Type.tappableElement();
                    } else if (i4 == 128) {
                        a2 = WindowInsets.Type.displayCutout();
                    }
                    i3 |= a2;
                }
            }
            return i3;
        }
    }

    private C0165w0(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        this.f2422a = i2 >= 30 ? new k(this, windowInsets) : i2 >= 29 ? new j(this, windowInsets) : i2 >= 28 ? new i(this, windowInsets) : new h(this, windowInsets);
    }

    static androidx.core.graphics.f o(androidx.core.graphics.f fVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, fVar.f2205a - i2);
        int max2 = Math.max(0, fVar.f2206b - i3);
        int max3 = Math.max(0, fVar.f2207c - i4);
        int max4 = Math.max(0, fVar.f2208d - i5);
        return (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) ? fVar : androidx.core.graphics.f.b(max, max2, max3, max4);
    }

    public static C0165w0 w(WindowInsets windowInsets) {
        return x(windowInsets, (View) null);
    }

    public static C0165w0 x(WindowInsets windowInsets, View view) {
        C0165w0 w0Var = new C0165w0((WindowInsets) x.h.g(windowInsets));
        if (view != null && view.isAttachedToWindow()) {
            w0Var.t(W.J(view));
            w0Var.d(view.getRootView());
        }
        return w0Var;
    }

    public C0165w0 a() {
        return this.f2422a.a();
    }

    public C0165w0 b() {
        return this.f2422a.b();
    }

    public C0165w0 c() {
        return this.f2422a.c();
    }

    /* access modifiers changed from: package-private */
    public void d(View view) {
        this.f2422a.d(view);
    }

    public r e() {
        return this.f2422a.f();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0165w0)) {
            return false;
        }
        return x.c.a(this.f2422a, ((C0165w0) obj).f2422a);
    }

    public androidx.core.graphics.f f(int i2) {
        return this.f2422a.g(i2);
    }

    public androidx.core.graphics.f g() {
        return this.f2422a.i();
    }

    public androidx.core.graphics.f h() {
        return this.f2422a.j();
    }

    public int hashCode() {
        l lVar = this.f2422a;
        if (lVar == null) {
            return 0;
        }
        return lVar.hashCode();
    }

    public int i() {
        return this.f2422a.k().f2208d;
    }

    public int j() {
        return this.f2422a.k().f2205a;
    }

    public int k() {
        return this.f2422a.k().f2207c;
    }

    public int l() {
        return this.f2422a.k().f2206b;
    }

    public boolean m() {
        return !this.f2422a.k().equals(androidx.core.graphics.f.f2204e);
    }

    public C0165w0 n(int i2, int i3, int i4, int i5) {
        return this.f2422a.m(i2, i3, i4, i5);
    }

    public boolean p() {
        return this.f2422a.n();
    }

    public C0165w0 q(int i2, int i3, int i4, int i5) {
        return new b(this).d(androidx.core.graphics.f.b(i2, i3, i4, i5)).a();
    }

    /* access modifiers changed from: package-private */
    public void r(androidx.core.graphics.f[] fVarArr) {
        this.f2422a.p(fVarArr);
    }

    /* access modifiers changed from: package-private */
    public void s(androidx.core.graphics.f fVar) {
        this.f2422a.q(fVar);
    }

    /* access modifiers changed from: package-private */
    public void t(C0165w0 w0Var) {
        this.f2422a.r(w0Var);
    }

    /* access modifiers changed from: package-private */
    public void u(androidx.core.graphics.f fVar) {
        this.f2422a.s(fVar);
    }

    public WindowInsets v() {
        l lVar = this.f2422a;
        if (lVar instanceof g) {
            return ((g) lVar).f2442c;
        }
        return null;
    }

    public C0165w0(C0165w0 w0Var) {
        if (w0Var != null) {
            l lVar = w0Var.f2422a;
            int i2 = Build.VERSION.SDK_INT;
            this.f2422a = (i2 < 30 || !(lVar instanceof k)) ? (i2 < 29 || !(lVar instanceof j)) ? (i2 < 28 || !(lVar instanceof i)) ? lVar instanceof h ? new h(this, (h) lVar) : lVar instanceof g ? new g(this, (g) lVar) : new l(this) : new i(this, (i) lVar) : new j(this, (j) lVar) : new k(this, (k) lVar);
            lVar.e(this);
            return;
        }
        this.f2422a = new l(this);
    }
}
