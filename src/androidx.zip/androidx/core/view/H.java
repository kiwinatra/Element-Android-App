package androidx.core.view;

public interface H {
    C0127d a(C0127d dVar);
}
