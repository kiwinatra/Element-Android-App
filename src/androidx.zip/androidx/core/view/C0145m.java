package androidx.core.view;

import android.content.Context;
import android.view.MotionEvent;
import androidx.core.view.C0149o;

/* renamed from: androidx.core.view.m  reason: case insensitive filesystem */
public final /* synthetic */ class C0145m implements C0149o.b {
    public final void a(Context context, int[] iArr, MotionEvent motionEvent, int i2) {
        C0149o.c(context, iArr, motionEvent, i2);
    }
}
