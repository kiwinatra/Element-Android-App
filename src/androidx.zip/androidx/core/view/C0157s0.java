package androidx.core.view;

import android.graphics.Insets;
import android.view.WindowInsetsAnimation;

/* renamed from: androidx.core.view.s0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0157s0 {
    public static /* synthetic */ WindowInsetsAnimation.Bounds a(Insets insets, Insets insets2) {
        return new WindowInsetsAnimation.Bounds(insets, insets2);
    }
}
