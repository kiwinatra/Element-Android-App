package androidx.core.view;

import android.view.View;

/* renamed from: androidx.core.view.h0  reason: case insensitive filesystem */
public interface C0136h0 {
    void a(View view);
}
