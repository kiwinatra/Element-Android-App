package androidx.core.view;

import android.content.ClipData;
import android.view.ContentInfo;

/* renamed from: androidx.core.view.i  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0137i {
    public static /* synthetic */ ContentInfo.Builder a(ClipData clipData, int i2) {
        return new ContentInfo.Builder(clipData, i2);
    }
}
