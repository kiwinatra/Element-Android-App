package androidx.core.view;

import android.view.KeyEvent;
import android.view.View;
import androidx.core.view.W;

public final /* synthetic */ class X implements View.OnUnhandledKeyEventListener {
    public /* synthetic */ X(W.p pVar) {
    }

    public final boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent) {
        throw null;
    }
}
