package androidx.core.view;

import android.view.WindowInsetsAnimation;
import android.view.animation.Interpolator;

/* renamed from: androidx.core.view.r0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0155r0 {
    public static /* synthetic */ WindowInsetsAnimation a(int i2, Interpolator interpolator, long j2) {
        return new WindowInsetsAnimation(i2, interpolator, j2);
    }
}
