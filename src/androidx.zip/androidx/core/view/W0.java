package androidx.core.view;

public abstract /* synthetic */ class W0 {
}
