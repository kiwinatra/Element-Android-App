package androidx.core.view;

import android.view.ViewGroup;

/* renamed from: androidx.core.view.b0  reason: case insensitive filesystem */
public abstract class C0124b0 {

    /* renamed from: androidx.core.view.b0$a */
    static class a {
        static int a(ViewGroup viewGroup) {
            return viewGroup.getNestedScrollAxes();
        }

        static boolean b(ViewGroup viewGroup) {
            return viewGroup.isTransitionGroup();
        }

        static void c(ViewGroup viewGroup, boolean z2) {
            viewGroup.setTransitionGroup(z2);
        }
    }

    public static boolean a(ViewGroup viewGroup) {
        return a.b(viewGroup);
    }
}
