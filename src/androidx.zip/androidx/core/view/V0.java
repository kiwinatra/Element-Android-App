package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import l.g;

public final class V0 {

    /* renamed from: a  reason: collision with root package name */
    private final e f2315a;

    private static class a extends e {

        /* renamed from: a  reason: collision with root package name */
        protected final Window f2316a;

        /* renamed from: b  reason: collision with root package name */
        private final K f2317b;

        a(Window window, K k2) {
            this.f2316a = window;
            this.f2317b = k2;
        }

        private void f(int i2) {
            if (i2 == 1) {
                g(4);
            } else if (i2 == 2) {
                g(2);
            } else if (i2 == 8) {
                this.f2317b.a();
            }
        }

        private void i(int i2) {
            if (i2 == 1) {
                j(4);
                k(1024);
            } else if (i2 == 2) {
                j(2);
            } else if (i2 == 8) {
                this.f2317b.b();
            }
        }

        /* access modifiers changed from: package-private */
        public void a(int i2) {
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    f(i3);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d(int i2) {
            if (i2 == 0) {
                j(6144);
            } else if (i2 == 1) {
                j(4096);
                g(2048);
            } else if (i2 == 2) {
                j(2048);
                g(4096);
            }
        }

        /* access modifiers changed from: package-private */
        public void e(int i2) {
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) != 0) {
                    i(i3);
                }
            }
        }

        /* access modifiers changed from: protected */
        public void g(int i2) {
            View decorView = this.f2316a.getDecorView();
            decorView.setSystemUiVisibility(i2 | decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        public void h(int i2) {
            this.f2316a.addFlags(i2);
        }

        /* access modifiers changed from: protected */
        public void j(int i2) {
            View decorView = this.f2316a.getDecorView();
            decorView.setSystemUiVisibility((~i2) & decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        public void k(int i2) {
            this.f2316a.clearFlags(i2);
        }
    }

    private static class b extends a {
        b(Window window, K k2) {
            super(window, k2);
        }

        public void c(boolean z2) {
            if (z2) {
                k(67108864);
                h(Integer.MIN_VALUE);
                g(8192);
                return;
            }
            j(8192);
        }
    }

    private static class c extends b {
        c(Window window, K k2) {
            super(window, k2);
        }

        public void b(boolean z2) {
            if (z2) {
                k(134217728);
                h(Integer.MIN_VALUE);
                g(16);
                return;
            }
            j(16);
        }
    }

    private static class d extends e {

        /* renamed from: a  reason: collision with root package name */
        final V0 f2318a;

        /* renamed from: b  reason: collision with root package name */
        final WindowInsetsController f2319b;

        /* renamed from: c  reason: collision with root package name */
        final K f2320c;

        /* renamed from: d  reason: collision with root package name */
        private final g f2321d;

        /* renamed from: e  reason: collision with root package name */
        protected Window f2322e;

        d(Window window, V0 v02, K k2) {
            this(window.getInsetsController(), v02, k2);
            this.f2322e = window;
        }

        /* access modifiers changed from: package-private */
        public void a(int i2) {
            if ((i2 & 8) != 0) {
                this.f2320c.a();
            }
            this.f2319b.hide(i2 & -9);
        }

        public void b(boolean z2) {
            if (z2) {
                if (this.f2322e != null) {
                    f(16);
                }
                this.f2319b.setSystemBarsAppearance(16, 16);
                return;
            }
            if (this.f2322e != null) {
                g(16);
            }
            this.f2319b.setSystemBarsAppearance(0, 16);
        }

        public void c(boolean z2) {
            if (z2) {
                if (this.f2322e != null) {
                    f(8192);
                }
                this.f2319b.setSystemBarsAppearance(8, 8);
                return;
            }
            if (this.f2322e != null) {
                g(8192);
            }
            this.f2319b.setSystemBarsAppearance(0, 8);
        }

        /* access modifiers changed from: package-private */
        public void d(int i2) {
            this.f2319b.setSystemBarsBehavior(i2);
        }

        /* access modifiers changed from: package-private */
        public void e(int i2) {
            if ((i2 & 8) != 0) {
                this.f2320c.b();
            }
            this.f2319b.show(i2 & -9);
        }

        /* access modifiers changed from: protected */
        public void f(int i2) {
            View decorView = this.f2322e.getDecorView();
            decorView.setSystemUiVisibility(i2 | decorView.getSystemUiVisibility());
        }

        /* access modifiers changed from: protected */
        public void g(int i2) {
            View decorView = this.f2322e.getDecorView();
            decorView.setSystemUiVisibility((~i2) & decorView.getSystemUiVisibility());
        }

        d(WindowInsetsController windowInsetsController, V0 v02, K k2) {
            this.f2321d = new g();
            this.f2319b = windowInsetsController;
            this.f2318a = v02;
            this.f2320c = k2;
        }
    }

    private static class e {
        e() {
        }

        /* access modifiers changed from: package-private */
        public abstract void a(int i2);

        public void b(boolean z2) {
        }

        public void c(boolean z2) {
        }

        /* access modifiers changed from: package-private */
        public abstract void d(int i2);

        /* access modifiers changed from: package-private */
        public abstract void e(int i2);
    }

    public V0(Window window, View view) {
        K k2 = new K(view);
        int i2 = Build.VERSION.SDK_INT;
        this.f2315a = i2 >= 30 ? new d(window, this, k2) : i2 >= 26 ? new c(window, k2) : i2 >= 23 ? new b(window, k2) : new a(window, k2);
    }

    public static V0 f(WindowInsetsController windowInsetsController) {
        return new V0(windowInsetsController);
    }

    public void a(int i2) {
        this.f2315a.a(i2);
    }

    public void b(boolean z2) {
        this.f2315a.b(z2);
    }

    public void c(boolean z2) {
        this.f2315a.c(z2);
    }

    public void d(int i2) {
        this.f2315a.d(i2);
    }

    public void e(int i2) {
        this.f2315a.e(i2);
    }

    private V0(WindowInsetsController windowInsetsController) {
        this.f2315a = new d(windowInsetsController, this, new K(windowInsetsController));
    }
}
