package androidx.core.view;

import android.support.v4.media.session.b;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: androidx.core.view.x  reason: case insensitive filesystem */
public class C0166x {

    /* renamed from: a  reason: collision with root package name */
    private final Runnable f2454a;

    /* renamed from: b  reason: collision with root package name */
    private final CopyOnWriteArrayList f2455b = new CopyOnWriteArrayList();

    /* renamed from: c  reason: collision with root package name */
    private final Map f2456c = new HashMap();

    public C0166x(Runnable runnable) {
        this.f2454a = runnable;
    }

    public void a(C0170z zVar) {
        this.f2455b.add(zVar);
        this.f2454a.run();
    }

    public void b(Menu menu, MenuInflater menuInflater) {
        Iterator it = this.f2455b.iterator();
        while (it.hasNext()) {
            ((C0170z) it.next()).a(menu, menuInflater);
        }
    }

    public void c(Menu menu) {
        Iterator it = this.f2455b.iterator();
        while (it.hasNext()) {
            ((C0170z) it.next()).d(menu);
        }
    }

    public boolean d(MenuItem menuItem) {
        Iterator it = this.f2455b.iterator();
        while (it.hasNext()) {
            if (((C0170z) it.next()).c(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public void e(Menu menu) {
        Iterator it = this.f2455b.iterator();
        while (it.hasNext()) {
            ((C0170z) it.next()).b(menu);
        }
    }

    public void f(C0170z zVar) {
        this.f2455b.remove(zVar);
        b.a(this.f2456c.remove(zVar));
        this.f2454a.run();
    }
}
