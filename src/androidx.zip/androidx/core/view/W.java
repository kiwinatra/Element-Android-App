package androidx.core.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContentInfo;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OnReceiveContentListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;
import androidx.core.view.C0121a;
import androidx.core.view.C0140j0;
import androidx.core.view.C0165w0;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import t.C0284b;
import y.I;
import y.L;
import z.C0309a;

public abstract class W {

    /* renamed from: a  reason: collision with root package name */
    private static WeakHashMap f2323a = null;

    /* renamed from: b  reason: collision with root package name */
    private static Field f2324b = null;

    /* renamed from: c  reason: collision with root package name */
    private static boolean f2325c = false;

    /* renamed from: d  reason: collision with root package name */
    private static ThreadLocal f2326d;

    /* renamed from: e  reason: collision with root package name */
    private static final int[] f2327e = {C0284b.accessibility_custom_action_0, C0284b.accessibility_custom_action_1, C0284b.accessibility_custom_action_2, C0284b.accessibility_custom_action_3, C0284b.accessibility_custom_action_4, C0284b.accessibility_custom_action_5, C0284b.accessibility_custom_action_6, C0284b.accessibility_custom_action_7, C0284b.accessibility_custom_action_8, C0284b.accessibility_custom_action_9, C0284b.accessibility_custom_action_10, C0284b.accessibility_custom_action_11, C0284b.accessibility_custom_action_12, C0284b.accessibility_custom_action_13, C0284b.accessibility_custom_action_14, C0284b.accessibility_custom_action_15, C0284b.accessibility_custom_action_16, C0284b.accessibility_custom_action_17, C0284b.accessibility_custom_action_18, C0284b.accessibility_custom_action_19, C0284b.accessibility_custom_action_20, C0284b.accessibility_custom_action_21, C0284b.accessibility_custom_action_22, C0284b.accessibility_custom_action_23, C0284b.accessibility_custom_action_24, C0284b.accessibility_custom_action_25, C0284b.accessibility_custom_action_26, C0284b.accessibility_custom_action_27, C0284b.accessibility_custom_action_28, C0284b.accessibility_custom_action_29, C0284b.accessibility_custom_action_30, C0284b.accessibility_custom_action_31};

    /* renamed from: f  reason: collision with root package name */
    private static final H f2328f = new V();

    /* renamed from: g  reason: collision with root package name */
    private static final e f2329g = new e();

    class a extends f {
        a(int i2, Class cls, int i3) {
            super(i2, cls, i3);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public Boolean c(View view) {
            return Boolean.valueOf(k.d(view));
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void d(View view, Boolean bool) {
            k.j(view, bool.booleanValue());
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean g(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    class b extends f {
        b(int i2, Class cls, int i3, int i4) {
            super(i2, cls, i3, i4);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public CharSequence c(View view) {
            return k.b(view);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void d(View view, CharSequence charSequence) {
            k.h(view, charSequence);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean g(CharSequence charSequence, CharSequence charSequence2) {
            return !TextUtils.equals(charSequence, charSequence2);
        }
    }

    class c extends f {
        c(int i2, Class cls, int i3, int i4) {
            super(i2, cls, i3, i4);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public CharSequence c(View view) {
            return m.b(view);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void d(View view, CharSequence charSequence) {
            m.f(view, charSequence);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean g(CharSequence charSequence, CharSequence charSequence2) {
            return !TextUtils.equals(charSequence, charSequence2);
        }
    }

    class d extends f {
        d(int i2, Class cls, int i3) {
            super(i2, cls, i3);
        }

        /* access modifiers changed from: package-private */
        /* renamed from: h */
        public Boolean c(View view) {
            return Boolean.valueOf(k.c(view));
        }

        /* access modifiers changed from: package-private */
        /* renamed from: i */
        public void d(View view, Boolean bool) {
            k.g(view, bool.booleanValue());
        }

        /* access modifiers changed from: package-private */
        /* renamed from: j */
        public boolean g(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {

        /* renamed from: a  reason: collision with root package name */
        private final WeakHashMap f2330a = new WeakHashMap();

        e() {
        }

        private void b(Map.Entry entry) {
            View view = (View) entry.getKey();
            boolean booleanValue = ((Boolean) entry.getValue()).booleanValue();
            boolean z2 = view.isShown() && view.getWindowVisibility() == 0;
            if (booleanValue != z2) {
                W.Z(view, z2 ? 16 : 32);
                entry.setValue(Boolean.valueOf(z2));
            }
        }

        private void c(View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        private void e(View view) {
            view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }

        /* access modifiers changed from: package-private */
        public void a(View view) {
            this.f2330a.put(view, Boolean.valueOf(view.isShown() && view.getWindowVisibility() == 0));
            view.addOnAttachStateChangeListener(this);
            if (view.isAttachedToWindow()) {
                c(view);
            }
        }

        /* access modifiers changed from: package-private */
        public void d(View view) {
            this.f2330a.remove(view);
            view.removeOnAttachStateChangeListener(this);
            e(view);
        }

        public void onGlobalLayout() {
            if (Build.VERSION.SDK_INT < 28) {
                for (Map.Entry b2 : this.f2330a.entrySet()) {
                    b(b2);
                }
            }
        }

        public void onViewAttachedToWindow(View view) {
            c(view);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    static abstract class f {

        /* renamed from: a  reason: collision with root package name */
        private final int f2331a;

        /* renamed from: b  reason: collision with root package name */
        private final Class f2332b;

        /* renamed from: c  reason: collision with root package name */
        private final int f2333c;

        /* renamed from: d  reason: collision with root package name */
        private final int f2334d;

        f(int i2, Class cls, int i3) {
            this(i2, cls, 0, i3);
        }

        private boolean b() {
            return Build.VERSION.SDK_INT >= this.f2333c;
        }

        /* access modifiers changed from: package-private */
        public boolean a(Boolean bool, Boolean bool2) {
            return (bool != null && bool.booleanValue()) == (bool2 != null && bool2.booleanValue());
        }

        /* access modifiers changed from: package-private */
        public abstract Object c(View view);

        /* access modifiers changed from: package-private */
        public abstract void d(View view, Object obj);

        /* access modifiers changed from: package-private */
        public Object e(View view) {
            if (b()) {
                return c(view);
            }
            Object tag = view.getTag(this.f2331a);
            if (this.f2332b.isInstance(tag)) {
                return tag;
            }
            return null;
        }

        /* access modifiers changed from: package-private */
        public void f(View view, Object obj) {
            if (b()) {
                d(view, obj);
            } else if (g(e(view), obj)) {
                W.l(view);
                view.setTag(this.f2331a, obj);
                W.Z(view, this.f2334d);
            }
        }

        /* access modifiers changed from: package-private */
        public abstract boolean g(Object obj, Object obj2);

        f(int i2, Class cls, int i3, int i4) {
            this.f2331a = i2;
            this.f2332b = cls;
            this.f2334d = i3;
            this.f2333c = i4;
        }
    }

    static class g {
        static WindowInsets a(View view, WindowInsets windowInsets) {
            return view.dispatchApplyWindowInsets(windowInsets);
        }

        static WindowInsets b(View view, WindowInsets windowInsets) {
            return view.onApplyWindowInsets(windowInsets);
        }

        static void c(View view) {
            view.requestApplyInsets();
        }
    }

    private static class h {

        class a implements View.OnApplyWindowInsetsListener {

            /* renamed from: a  reason: collision with root package name */
            C0165w0 f2335a = null;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ View f2336b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ F f2337c;

            a(View view, F f2) {
                this.f2336b = view;
                this.f2337c = f2;
            }

            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                C0165w0 x2 = C0165w0.x(windowInsets, view);
                int i2 = Build.VERSION.SDK_INT;
                if (i2 < 30) {
                    h.a(windowInsets, this.f2336b);
                    if (x2.equals(this.f2335a)) {
                        return this.f2337c.a(view, x2).v();
                    }
                }
                this.f2335a = x2;
                C0165w0 a2 = this.f2337c.a(view, x2);
                if (i2 >= 30) {
                    return a2.v();
                }
                W.n0(view);
                return a2.v();
            }
        }

        static void a(WindowInsets windowInsets, View view) {
            View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener) view.getTag(C0284b.tag_window_insets_animation_callback);
            if (onApplyWindowInsetsListener != null) {
                onApplyWindowInsetsListener.onApplyWindowInsets(view, windowInsets);
            }
        }

        static C0165w0 b(View view, C0165w0 w0Var, Rect rect) {
            WindowInsets v2 = w0Var.v();
            if (v2 != null) {
                return C0165w0.x(view.computeSystemWindowInsets(v2, rect), view);
            }
            rect.setEmpty();
            return w0Var;
        }

        static boolean c(View view, float f2, float f3, boolean z2) {
            return view.dispatchNestedFling(f2, f3, z2);
        }

        static boolean d(View view, float f2, float f3) {
            return view.dispatchNestedPreFling(f2, f3);
        }

        static boolean e(View view, int i2, int i3, int[] iArr, int[] iArr2) {
            return view.dispatchNestedPreScroll(i2, i3, iArr, iArr2);
        }

        static boolean f(View view, int i2, int i3, int i4, int i5, int[] iArr) {
            return view.dispatchNestedScroll(i2, i3, i4, i5, iArr);
        }

        static ColorStateList g(View view) {
            return view.getBackgroundTintList();
        }

        static PorterDuff.Mode h(View view) {
            return view.getBackgroundTintMode();
        }

        static float i(View view) {
            return view.getElevation();
        }

        public static C0165w0 j(View view) {
            return C0165w0.a.a(view);
        }

        static String k(View view) {
            return view.getTransitionName();
        }

        static float l(View view) {
            return view.getTranslationZ();
        }

        static float m(View view) {
            return view.getZ();
        }

        static boolean n(View view) {
            return view.hasNestedScrollingParent();
        }

        static boolean o(View view) {
            return view.isImportantForAccessibility();
        }

        static boolean p(View view) {
            return view.isNestedScrollingEnabled();
        }

        static void q(View view, ColorStateList colorStateList) {
            view.setBackgroundTintList(colorStateList);
        }

        static void r(View view, PorterDuff.Mode mode) {
            view.setBackgroundTintMode(mode);
        }

        static void s(View view, float f2) {
            view.setElevation(f2);
        }

        static void t(View view, boolean z2) {
            view.setNestedScrollingEnabled(z2);
        }

        static void u(View view, F f2) {
            if (Build.VERSION.SDK_INT < 30) {
                view.setTag(C0284b.tag_on_apply_window_listener, f2);
            }
            if (f2 == null) {
                view.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) view.getTag(C0284b.tag_window_insets_animation_callback));
            } else {
                view.setOnApplyWindowInsetsListener(new a(view, f2));
            }
        }

        static void v(View view, String str) {
            view.setTransitionName(str);
        }

        static void w(View view, float f2) {
            view.setTranslationZ(f2);
        }

        static void x(View view, float f2) {
            view.setZ(f2);
        }

        static boolean y(View view, int i2) {
            return view.startNestedScroll(i2);
        }

        static void z(View view) {
            view.stopNestedScroll();
        }
    }

    private static class i {
        public static C0165w0 a(View view) {
            WindowInsets rootWindowInsets = view.getRootWindowInsets();
            if (rootWindowInsets == null) {
                return null;
            }
            C0165w0 w2 = C0165w0.w(rootWindowInsets);
            w2.t(w2);
            w2.d(view.getRootView());
            return w2;
        }

        static int b(View view) {
            return view.getScrollIndicators();
        }

        static void c(View view, int i2) {
            view.setScrollIndicators(i2);
        }

        static void d(View view, int i2, int i3) {
            view.setScrollIndicators(i2, i3);
        }
    }

    static class j {
        static void a(View view, Collection<View> collection, int i2) {
            view.addKeyboardNavigationClusters(collection, i2);
        }

        public static AutofillId b(View view) {
            return view.getAutofillId();
        }

        static int c(View view) {
            return view.getImportantForAutofill();
        }

        static int d(View view) {
            return view.getNextClusterForwardId();
        }

        static boolean e(View view) {
            return view.hasExplicitFocusable();
        }

        static boolean f(View view) {
            return view.isFocusedByDefault();
        }

        static boolean g(View view) {
            return view.isImportantForAutofill();
        }

        static boolean h(View view) {
            return view.isKeyboardNavigationCluster();
        }

        static View i(View view, View view2, int i2) {
            return view.keyboardNavigationClusterSearch(view2, i2);
        }

        static boolean j(View view) {
            return view.restoreDefaultFocus();
        }

        static void k(View view, String... strArr) {
            view.setAutofillHints(strArr);
        }

        static void l(View view, boolean z2) {
            view.setFocusedByDefault(z2);
        }

        static void m(View view, int i2) {
            view.setImportantForAutofill(i2);
        }

        static void n(View view, boolean z2) {
            view.setKeyboardNavigationCluster(z2);
        }

        static void o(View view, int i2) {
            view.setNextClusterForwardId(i2);
        }

        static void p(View view, CharSequence charSequence) {
            view.setTooltipText(charSequence);
        }
    }

    static class k {
        static void a(View view, p pVar) {
            int i2 = C0284b.tag_unhandled_key_listeners;
            l.g gVar = (l.g) view.getTag(i2);
            if (gVar == null) {
                gVar = new l.g();
                view.setTag(i2, gVar);
            }
            Objects.requireNonNull(pVar);
            X x2 = new X(pVar);
            gVar.put(pVar, x2);
            view.addOnUnhandledKeyEventListener(x2);
        }

        static CharSequence b(View view) {
            return view.getAccessibilityPaneTitle();
        }

        static boolean c(View view) {
            return view.isAccessibilityHeading();
        }

        static boolean d(View view) {
            return view.isScreenReaderFocusable();
        }

        static void e(View view, p pVar) {
            View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
            l.g gVar = (l.g) view.getTag(C0284b.tag_unhandled_key_listeners);
            if (gVar != null && (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) gVar.get(pVar)) != null) {
                view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
            }
        }

        static <T> T f(View view, int i2) {
            return view.requireViewById(i2);
        }

        static void g(View view, boolean z2) {
            view.setAccessibilityHeading(z2);
        }

        static void h(View view, CharSequence charSequence) {
            view.setAccessibilityPaneTitle(charSequence);
        }

        public static void i(View view, C0309a aVar) {
            view.setAutofillId((AutofillId) null);
        }

        static void j(View view, boolean z2) {
            view.setScreenReaderFocusable(z2);
        }
    }

    private static class l {
        static View.AccessibilityDelegate a(View view) {
            return view.getAccessibilityDelegate();
        }

        static ContentCaptureSession b(View view) {
            return view.getContentCaptureSession();
        }

        static List<Rect> c(View view) {
            return view.getSystemGestureExclusionRects();
        }

        static void d(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2, int i3) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i2, i3);
        }

        static void e(View view, A.a aVar) {
            view.setContentCaptureSession((ContentCaptureSession) null);
        }

        static void f(View view, List<Rect> list) {
            view.setSystemGestureExclusionRects(list);
        }
    }

    private static class m {
        static int a(View view) {
            return view.getImportantForContentCapture();
        }

        static CharSequence b(View view) {
            return view.getStateDescription();
        }

        public static V0 c(View view) {
            WindowInsetsController windowInsetsController = view.getWindowInsetsController();
            if (windowInsetsController != null) {
                return V0.f(windowInsetsController);
            }
            return null;
        }

        static boolean d(View view) {
            return view.isImportantForContentCapture();
        }

        static void e(View view, int i2) {
            view.setImportantForContentCapture(i2);
        }

        static void f(View view, CharSequence charSequence) {
            view.setStateDescription(charSequence);
        }
    }

    private static final class n {
        public static String[] a(View view) {
            return view.getReceiveContentMimeTypes();
        }

        public static C0127d b(View view, C0127d dVar) {
            ContentInfo f2 = dVar.f();
            ContentInfo performReceiveContent = view.performReceiveContent(f2);
            if (performReceiveContent == null) {
                return null;
            }
            return performReceiveContent == f2 ? dVar : C0127d.g(performReceiveContent);
        }

        public static void c(View view, String[] strArr, G g2) {
            if (g2 == null) {
                view.setOnReceiveContentListener(strArr, (OnReceiveContentListener) null);
            } else {
                view.setOnReceiveContentListener(strArr, new o(g2));
            }
        }
    }

    private static final class o implements OnReceiveContentListener {

        /* renamed from: a  reason: collision with root package name */
        private final G f2338a;

        o(G g2) {
            this.f2338a = g2;
        }

        public ContentInfo onReceiveContent(View view, ContentInfo contentInfo) {
            C0127d g2 = C0127d.g(contentInfo);
            C0127d a2 = this.f2338a.a(view, g2);
            if (a2 == null) {
                return null;
            }
            return a2 == g2 ? contentInfo : a2.f();
        }
    }

    public interface p {
    }

    static class q {

        /* renamed from: d  reason: collision with root package name */
        private static final ArrayList f2339d = new ArrayList();

        /* renamed from: a  reason: collision with root package name */
        private WeakHashMap f2340a = null;

        /* renamed from: b  reason: collision with root package name */
        private SparseArray f2341b = null;

        /* renamed from: c  reason: collision with root package name */
        private WeakReference f2342c = null;

        q() {
        }

        static q a(View view) {
            int i2 = C0284b.tag_unhandled_key_event_manager;
            q qVar = (q) view.getTag(i2);
            if (qVar != null) {
                return qVar;
            }
            q qVar2 = new q();
            view.setTag(i2, qVar2);
            return qVar2;
        }

        private View c(View view, KeyEvent keyEvent) {
            WeakHashMap weakHashMap = this.f2340a;
            if (weakHashMap != null && weakHashMap.containsKey(view)) {
                if (view instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view;
                    for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                        View c2 = c(viewGroup.getChildAt(childCount), keyEvent);
                        if (c2 != null) {
                            return c2;
                        }
                    }
                }
                if (e(view, keyEvent)) {
                    return view;
                }
            }
            return null;
        }

        private SparseArray d() {
            if (this.f2341b == null) {
                this.f2341b = new SparseArray();
            }
            return this.f2341b;
        }

        private boolean e(View view, KeyEvent keyEvent) {
            int size;
            ArrayList arrayList = (ArrayList) view.getTag(C0284b.tag_unhandled_key_listeners);
            if (arrayList == null || arrayList.size() - 1 < 0) {
                return false;
            }
            android.support.v4.media.session.b.a(arrayList.get(size));
            throw null;
        }

        private void g() {
            WeakHashMap weakHashMap = this.f2340a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList arrayList = f2339d;
            if (!arrayList.isEmpty()) {
                synchronized (arrayList) {
                    try {
                        if (this.f2340a == null) {
                            this.f2340a = new WeakHashMap();
                        }
                        for (int size = arrayList.size() - 1; size >= 0; size--) {
                            ArrayList arrayList2 = f2339d;
                            View view = (View) ((WeakReference) arrayList2.get(size)).get();
                            if (view == null) {
                                arrayList2.remove(size);
                            } else {
                                this.f2340a.put(view, Boolean.TRUE);
                                for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                                    this.f2340a.put((View) parent, Boolean.TRUE);
                                }
                            }
                        }
                    } finally {
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        public boolean b(View view, KeyEvent keyEvent) {
            if (keyEvent.getAction() == 0) {
                g();
            }
            View c2 = c(view, keyEvent);
            if (keyEvent.getAction() == 0) {
                int keyCode = keyEvent.getKeyCode();
                if (c2 != null && !KeyEvent.isModifierKey(keyCode)) {
                    d().put(keyCode, new WeakReference(c2));
                }
            }
            return c2 != null;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v2, resolved type: java.lang.ref.WeakReference} */
        /* access modifiers changed from: package-private */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean f(android.view.KeyEvent r6) {
            /*
                r5 = this;
                java.lang.ref.WeakReference r0 = r5.f2342c
                r1 = 0
                if (r0 == 0) goto L_0x000c
                java.lang.Object r0 = r0.get()
                if (r0 != r6) goto L_0x000c
                return r1
            L_0x000c:
                java.lang.ref.WeakReference r0 = new java.lang.ref.WeakReference
                r0.<init>(r6)
                r5.f2342c = r0
                android.util.SparseArray r0 = r5.d()
                int r2 = r6.getAction()
                r3 = 1
                if (r2 != r3) goto L_0x0032
                int r2 = r6.getKeyCode()
                int r2 = r0.indexOfKey(r2)
                if (r2 < 0) goto L_0x0032
                java.lang.Object r4 = r0.valueAt(r2)
                java.lang.ref.WeakReference r4 = (java.lang.ref.WeakReference) r4
                r0.removeAt(r2)
                goto L_0x0033
            L_0x0032:
                r4 = 0
            L_0x0033:
                if (r4 != 0) goto L_0x0040
                int r2 = r6.getKeyCode()
                java.lang.Object r0 = r0.get(r2)
                r4 = r0
                java.lang.ref.WeakReference r4 = (java.lang.ref.WeakReference) r4
            L_0x0040:
                if (r4 == 0) goto L_0x0054
                java.lang.Object r0 = r4.get()
                android.view.View r0 = (android.view.View) r0
                if (r0 == 0) goto L_0x0053
                boolean r1 = r0.isAttachedToWindow()
                if (r1 == 0) goto L_0x0053
                r5.e(r0, r6)
            L_0x0053:
                return r3
            L_0x0054:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.core.view.W.q.f(android.view.KeyEvent):boolean");
        }
    }

    public static int A(View view) {
        return view.getImportantForAccessibility();
    }

    public static void A0(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 26) {
            j.m(view, i2);
        }
    }

    public static int B(View view) {
        if (Build.VERSION.SDK_INT >= 26) {
            return j.c(view);
        }
        return 0;
    }

    public static void B0(View view, int i2) {
        view.setLabelFor(i2);
    }

    public static int C(View view) {
        return view.getLayoutDirection();
    }

    public static void C0(View view, F f2) {
        h.u(view, f2);
    }

    public static int D(View view) {
        return view.getMinimumHeight();
    }

    public static void D0(View view, int i2, int i3, int i4, int i5) {
        view.setPaddingRelative(i2, i3, i4, i5);
    }

    public static int E(View view) {
        return view.getMinimumWidth();
    }

    public static void E0(View view, boolean z2) {
        p0().f(view, Boolean.valueOf(z2));
    }

    public static String[] F(View view) {
        return Build.VERSION.SDK_INT >= 31 ? n.a(view) : (String[]) view.getTag(C0284b.tag_on_receive_content_mime_types);
    }

    public static void F0(View view, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 23) {
            i.d(view, i2, i3);
        }
    }

    public static int G(View view) {
        return view.getPaddingEnd();
    }

    public static void G0(View view, String str) {
        h.v(view, str);
    }

    public static int H(View view) {
        return view.getPaddingStart();
    }

    public static void H0(View view, C0140j0.b bVar) {
        C0140j0.d(view, bVar);
    }

    public static ViewParent I(View view) {
        return view.getParentForAccessibility();
    }

    private static f I0() {
        return new c(C0284b.tag_state_description, CharSequence.class, 64, 30);
    }

    public static C0165w0 J(View view) {
        return Build.VERSION.SDK_INT >= 23 ? i.a(view) : h.j(view);
    }

    public static void J0(View view) {
        h.z(view);
    }

    public static CharSequence K(View view) {
        return (CharSequence) I0().e(view);
    }

    private static void K0(View view) {
        float translationY = view.getTranslationY();
        view.setTranslationY(1.0f + translationY);
        view.setTranslationY(translationY);
    }

    public static String L(View view) {
        return h.k(view);
    }

    public static V0 M(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            return m.c(view);
        }
        for (Context context = view.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof Activity) {
                Window window = ((Activity) context).getWindow();
                if (window != null) {
                    return C0138i0.a(window, view);
                }
                return null;
            }
        }
        return null;
    }

    public static int N(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static float O(View view) {
        return h.m(view);
    }

    public static boolean P(View view) {
        return o(view) != null;
    }

    public static boolean Q(View view) {
        return view.hasOnClickListeners();
    }

    public static boolean R(View view) {
        return view.hasTransientState();
    }

    public static boolean S(View view) {
        Boolean bool = (Boolean) b().e(view);
        return bool != null && bool.booleanValue();
    }

    public static boolean T(View view) {
        return view.isAttachedToWindow();
    }

    public static boolean U(View view) {
        return view.isLaidOut();
    }

    public static boolean V(View view) {
        return h.p(view);
    }

    public static boolean W(View view) {
        return view.isPaddingRelative();
    }

    public static boolean X(View view) {
        Boolean bool = (Boolean) p0().e(view);
        return bool != null && bool.booleanValue();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ C0127d Y(C0127d dVar) {
        return dVar;
    }

    static void Z(View view, int i2) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            boolean z2 = q(view) != null && view.isShown() && view.getWindowVisibility() == 0;
            int i3 = 32;
            if (view.getAccessibilityLiveRegion() != 0 || z2) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                if (!z2) {
                    i3 = 2048;
                }
                obtain.setEventType(i3);
                obtain.setContentChangeTypes(i2);
                if (z2) {
                    obtain.getText().add(q(view));
                    z0(view);
                }
                view.sendAccessibilityEventUnchecked(obtain);
            } else if (i2 == 32) {
                AccessibilityEvent obtain2 = AccessibilityEvent.obtain();
                view.onInitializeAccessibilityEvent(obtain2);
                obtain2.setEventType(32);
                obtain2.setContentChangeTypes(i2);
                obtain2.setSource(view);
                view.onPopulateAccessibilityEvent(obtain2);
                obtain2.getText().add(q(view));
                accessibilityManager.sendAccessibilityEvent(obtain2);
            } else if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName() + " does not fully implement ViewParent", e2);
                }
            }
        }
    }

    public static void a0(View view, int i2) {
        boolean z2;
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetLeftAndRight(i2);
            return;
        }
        Rect x2 = x();
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            x2.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z2 = !x2.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        } else {
            z2 = false;
        }
        f(view, i2);
        if (z2 && x2.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(x2);
        }
    }

    private static f b() {
        return new d(C0284b.tag_accessibility_heading, Boolean.class, 28);
    }

    public static void b0(View view, int i2) {
        boolean z2;
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetTopAndBottom(i2);
            return;
        }
        Rect x2 = x();
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            x2.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z2 = !x2.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        } else {
            z2 = false;
        }
        g(view, i2);
        if (z2 && x2.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(x2);
        }
    }

    public static int c(View view, CharSequence charSequence, L l2) {
        int s2 = s(view, charSequence);
        if (s2 != -1) {
            d(view, new I.a(s2, charSequence, l2));
        }
        return s2;
    }

    public static C0165w0 c0(View view, C0165w0 w0Var) {
        WindowInsets v2 = w0Var.v();
        if (v2 != null) {
            WindowInsets b2 = g.b(view, v2);
            if (!b2.equals(v2)) {
                return C0165w0.x(b2, view);
            }
        }
        return w0Var;
    }

    private static void d(View view, I.a aVar) {
        l(view);
        l0(aVar.b(), view);
        r(view).add(aVar);
        Z(view, 0);
    }

    public static void d0(View view, I i2) {
        view.onInitializeAccessibilityNodeInfo(i2.N0());
    }

    public static C0130e0 e(View view) {
        if (f2323a == null) {
            f2323a = new WeakHashMap();
        }
        C0130e0 e0Var = (C0130e0) f2323a.get(view);
        if (e0Var != null) {
            return e0Var;
        }
        C0130e0 e0Var2 = new C0130e0(view);
        f2323a.put(view, e0Var2);
        return e0Var2;
    }

    private static f e0() {
        return new b(C0284b.tag_accessibility_pane_title, CharSequence.class, 8, 28);
    }

    private static void f(View view, int i2) {
        view.offsetLeftAndRight(i2);
        if (view.getVisibility() == 0) {
            K0(view);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                K0((View) parent);
            }
        }
    }

    public static boolean f0(View view, int i2, Bundle bundle) {
        return view.performAccessibilityAction(i2, bundle);
    }

    private static void g(View view, int i2) {
        view.offsetTopAndBottom(i2);
        if (view.getVisibility() == 0) {
            K0(view);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                K0((View) parent);
            }
        }
    }

    public static C0127d g0(View view, C0127d dVar) {
        if (Log.isLoggable("ViewCompat", 3)) {
            Log.d("ViewCompat", "performReceiveContent: " + dVar + ", view=" + view.getClass().getSimpleName() + "[" + view.getId() + "]");
        }
        if (Build.VERSION.SDK_INT >= 31) {
            return n.b(view, dVar);
        }
        G g2 = (G) view.getTag(C0284b.tag_on_receive_content_listener);
        if (g2 == null) {
            return y(view).a(dVar);
        }
        C0127d a2 = g2.a(view, dVar);
        if (a2 == null) {
            return null;
        }
        return y(view).a(a2);
    }

    public static C0165w0 h(View view, C0165w0 w0Var, Rect rect) {
        return h.b(view, w0Var, rect);
    }

    public static void h0(View view) {
        view.postInvalidateOnAnimation();
    }

    public static C0165w0 i(View view, C0165w0 w0Var) {
        WindowInsets v2 = w0Var.v();
        if (v2 != null) {
            WindowInsets a2 = g.a(view, v2);
            if (!a2.equals(v2)) {
                return C0165w0.x(a2, view);
            }
        }
        return w0Var;
    }

    public static void i0(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    static boolean j(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return q.a(view).b(view, keyEvent);
    }

    public static void j0(View view, Runnable runnable, long j2) {
        view.postOnAnimationDelayed(runnable, j2);
    }

    static boolean k(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return q.a(view).f(keyEvent);
    }

    public static void k0(View view, int i2) {
        l0(i2, view);
        Z(view, 0);
    }

    static void l(View view) {
        C0121a n2 = n(view);
        if (n2 == null) {
            n2 = new C0121a();
        }
        q0(view, n2);
    }

    private static void l0(int i2, View view) {
        List r2 = r(view);
        for (int i3 = 0; i3 < r2.size(); i3++) {
            if (((I.a) r2.get(i3)).b() == i2) {
                r2.remove(i3);
                return;
            }
        }
    }

    public static int m() {
        return View.generateViewId();
    }

    public static void m0(View view, I.a aVar, CharSequence charSequence, L l2) {
        if (l2 == null && charSequence == null) {
            k0(view, aVar.b());
        } else {
            d(view, aVar.a(charSequence, l2));
        }
    }

    public static C0121a n(View view) {
        View.AccessibilityDelegate o2 = o(view);
        if (o2 == null) {
            return null;
        }
        return o2 instanceof C0121a.C0033a ? ((C0121a.C0033a) o2).f2348a : new C0121a(o2);
    }

    public static void n0(View view) {
        g.c(view);
    }

    private static View.AccessibilityDelegate o(View view) {
        return Build.VERSION.SDK_INT >= 29 ? l.a(view) : p(view);
    }

    public static void o0(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 29) {
            l.d(view, context, iArr, attributeSet, typedArray, i2, i3);
        }
    }

    private static View.AccessibilityDelegate p(View view) {
        if (f2325c) {
            return null;
        }
        if (f2324b == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f2324b = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f2325c = true;
                return null;
            }
        }
        try {
            Object obj = f2324b.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f2325c = true;
            return null;
        }
    }

    private static f p0() {
        return new a(C0284b.tag_screen_reader_focusable, Boolean.class, 28);
    }

    public static CharSequence q(View view) {
        return (CharSequence) e0().e(view);
    }

    public static void q0(View view, C0121a aVar) {
        if (aVar == null && (o(view) instanceof C0121a.C0033a)) {
            aVar = new C0121a();
        }
        z0(view);
        view.setAccessibilityDelegate(aVar == null ? null : aVar.d());
    }

    private static List r(View view) {
        int i2 = C0284b.tag_accessibility_actions;
        ArrayList arrayList = (ArrayList) view.getTag(i2);
        if (arrayList != null) {
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        view.setTag(i2, arrayList2);
        return arrayList2;
    }

    public static void r0(View view, boolean z2) {
        b().f(view, Boolean.valueOf(z2));
    }

    private static int s(View view, CharSequence charSequence) {
        List r2 = r(view);
        for (int i2 = 0; i2 < r2.size(); i2++) {
            if (TextUtils.equals(charSequence, ((I.a) r2.get(i2)).c())) {
                return ((I.a) r2.get(i2)).b();
            }
        }
        int i3 = 0;
        int i4 = -1;
        while (true) {
            int[] iArr = f2327e;
            if (i3 >= iArr.length || i4 != -1) {
                return i4;
            }
            int i5 = iArr[i3];
            boolean z2 = true;
            for (int i6 = 0; i6 < r2.size(); i6++) {
                z2 &= ((I.a) r2.get(i6)).b() != i5;
            }
            if (z2) {
                i4 = i5;
            }
            i3++;
        }
        return i4;
    }

    public static void s0(View view, int i2) {
        view.setAccessibilityLiveRegion(i2);
    }

    public static ColorStateList t(View view) {
        return h.g(view);
    }

    public static void t0(View view, CharSequence charSequence) {
        e0().f(view, charSequence);
        if (charSequence != null) {
            f2329g.a(view);
        } else {
            f2329g.d(view);
        }
    }

    public static PorterDuff.Mode u(View view) {
        return h.h(view);
    }

    public static void u0(View view, Drawable drawable) {
        view.setBackground(drawable);
    }

    public static Display v(View view) {
        return view.getDisplay();
    }

    public static void v0(View view, ColorStateList colorStateList) {
        int i2 = Build.VERSION.SDK_INT;
        h.q(view, colorStateList);
        if (i2 == 21) {
            Drawable background = view.getBackground();
            boolean z2 = (h.g(view) == null && h.h(view) == null) ? false : true;
            if (background != null && z2) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    public static float w(View view) {
        return h.i(view);
    }

    public static void w0(View view, PorterDuff.Mode mode) {
        int i2 = Build.VERSION.SDK_INT;
        h.r(view, mode);
        if (i2 == 21) {
            Drawable background = view.getBackground();
            boolean z2 = (h.g(view) == null && h.h(view) == null) ? false : true;
            if (background != null && z2) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    private static Rect x() {
        if (f2326d == null) {
            f2326d = new ThreadLocal();
        }
        Rect rect = (Rect) f2326d.get();
        if (rect == null) {
            rect = new Rect();
            f2326d.set(rect);
        }
        rect.setEmpty();
        return rect;
    }

    public static void x0(View view, float f2) {
        h.s(view, f2);
    }

    private static H y(View view) {
        return view instanceof H ? (H) view : f2328f;
    }

    public static void y0(View view, int i2) {
        view.setImportantForAccessibility(i2);
    }

    public static boolean z(View view) {
        return view.getFitsSystemWindows();
    }

    private static void z0(View view) {
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
    }
}
