package androidx.core.view;

import android.view.WindowInsets;

public abstract /* synthetic */ class D0 {
    public static /* synthetic */ WindowInsets.Builder a(WindowInsets windowInsets) {
        return new WindowInsets.Builder(windowInsets);
    }
}
