package androidx.core.view;

/* renamed from: androidx.core.view.o0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0150o0 {
}
