package androidx.core.view;

import android.view.WindowInsetsController;
import androidx.core.view.K;
import java.util.concurrent.atomic.AtomicBoolean;

public final /* synthetic */ class S implements WindowInsetsController.OnControllableInsetsChangedListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AtomicBoolean f2308a;

    public /* synthetic */ S(AtomicBoolean atomicBoolean) {
        this.f2308a = atomicBoolean;
    }

    public final void onControllableInsetsChanged(WindowInsetsController windowInsetsController, int i2) {
        K.b.f(this.f2308a, windowInsetsController, i2);
    }
}
