package androidx.core.view;

public final /* synthetic */ class V implements H {
    public final C0127d a(C0127d dVar) {
        return W.Y(dVar);
    }
}
