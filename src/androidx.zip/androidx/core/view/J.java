package androidx.core.view;

import android.view.View;
import android.view.inputmethod.InputMethodManager;

public final /* synthetic */ class J implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ View f2303a;

    public /* synthetic */ J(View view) {
        this.f2303a = view;
    }

    public final void run() {
        ((InputMethodManager) this.f2303a.getContext().getSystemService("input_method")).showSoftInput(this.f2303a, 0);
    }
}
