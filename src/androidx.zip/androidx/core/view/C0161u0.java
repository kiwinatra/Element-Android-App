package androidx.core.view;

import android.view.WindowInsetsAnimation;

/* renamed from: androidx.core.view.u0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0161u0 {
    public static /* bridge */ /* synthetic */ WindowInsetsAnimation a(Object obj) {
        return (WindowInsetsAnimation) obj;
    }
}
