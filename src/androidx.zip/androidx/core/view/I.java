package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;

public final class I implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: a  reason: collision with root package name */
    private final View f2300a;

    /* renamed from: b  reason: collision with root package name */
    private ViewTreeObserver f2301b;

    /* renamed from: c  reason: collision with root package name */
    private final Runnable f2302c;

    private I(View view, Runnable runnable) {
        this.f2300a = view;
        this.f2301b = view.getViewTreeObserver();
        this.f2302c = runnable;
    }

    public static I a(View view, Runnable runnable) {
        if (view == null) {
            throw new NullPointerException("view == null");
        } else if (runnable != null) {
            I i2 = new I(view, runnable);
            view.getViewTreeObserver().addOnPreDrawListener(i2);
            view.addOnAttachStateChangeListener(i2);
            return i2;
        } else {
            throw new NullPointerException("runnable == null");
        }
    }

    public void b() {
        (this.f2301b.isAlive() ? this.f2301b : this.f2300a.getViewTreeObserver()).removeOnPreDrawListener(this);
        this.f2300a.removeOnAttachStateChangeListener(this);
    }

    public boolean onPreDraw() {
        b();
        this.f2302c.run();
        return true;
    }

    public void onViewAttachedToWindow(View view) {
        this.f2301b = view.getViewTreeObserver();
    }

    public void onViewDetachedFromWindow(View view) {
        b();
    }
}
