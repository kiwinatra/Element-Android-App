package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

/* renamed from: androidx.core.view.z  reason: case insensitive filesystem */
public interface C0170z {
    void a(Menu menu, MenuInflater menuInflater);

    void b(Menu menu);

    boolean c(MenuItem menuItem);

    void d(Menu menu);
}
