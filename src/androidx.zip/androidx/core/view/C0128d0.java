package androidx.core.view;

import android.animation.ValueAnimator;
import android.view.View;

/* renamed from: androidx.core.view.d0  reason: case insensitive filesystem */
public final /* synthetic */ class C0128d0 implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0136h0 f2367a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f2368b;

    public /* synthetic */ C0128d0(C0136h0 h0Var, View view) {
        this.f2367a = h0Var;
        this.f2368b = view;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f2367a.a(this.f2368b);
    }
}
