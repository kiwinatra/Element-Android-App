package androidx.core.view;

import android.view.View;
import android.view.ViewGroup;

public class E {

    /* renamed from: a  reason: collision with root package name */
    private int f2298a;

    /* renamed from: b  reason: collision with root package name */
    private int f2299b;

    public E(ViewGroup viewGroup) {
    }

    public int a() {
        return this.f2298a | this.f2299b;
    }

    public void b(View view, View view2, int i2) {
        c(view, view2, i2, 0);
    }

    public void c(View view, View view2, int i2, int i3) {
        if (i3 == 1) {
            this.f2299b = i2;
        } else {
            this.f2298a = i2;
        }
    }

    public void d(View view) {
        e(view, 0);
    }

    public void e(View view, int i2) {
        if (i2 == 1) {
            this.f2299b = 0;
        } else {
            this.f2298a = 0;
        }
    }
}
