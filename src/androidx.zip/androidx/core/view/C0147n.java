package androidx.core.view;

import android.view.MotionEvent;
import android.view.VelocityTracker;
import androidx.core.view.C0149o;

/* renamed from: androidx.core.view.n  reason: case insensitive filesystem */
public final /* synthetic */ class C0147n implements C0149o.a {
    public final float a(VelocityTracker velocityTracker, MotionEvent motionEvent, int i2) {
        return C0149o.f(velocityTracker, motionEvent, i2);
    }
}
