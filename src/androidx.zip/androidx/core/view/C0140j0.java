package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import androidx.core.graphics.f;
import androidx.core.view.C0165w0;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import t.C0284b;

/* renamed from: androidx.core.view.j0  reason: case insensitive filesystem */
public final class C0140j0 {

    /* renamed from: a  reason: collision with root package name */
    private e f2373a;

    /* renamed from: androidx.core.view.j0$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final f f2374a;

        /* renamed from: b  reason: collision with root package name */
        private final f f2375b;

        private a(WindowInsetsAnimation.Bounds bounds) {
            this.f2374a = d.g(bounds);
            this.f2375b = d.f(bounds);
        }

        public static a d(WindowInsetsAnimation.Bounds bounds) {
            return new a(bounds);
        }

        public f a() {
            return this.f2374a;
        }

        public f b() {
            return this.f2375b;
        }

        public WindowInsetsAnimation.Bounds c() {
            return d.e(this);
        }

        public String toString() {
            return "Bounds{lower=" + this.f2374a + " upper=" + this.f2375b + "}";
        }

        public a(f fVar, f fVar2) {
            this.f2374a = fVar;
            this.f2375b = fVar2;
        }
    }

    /* renamed from: androidx.core.view.j0$b */
    public static abstract class b {

        /* renamed from: a  reason: collision with root package name */
        WindowInsets f2376a;

        /* renamed from: b  reason: collision with root package name */
        private final int f2377b;

        public b(int i2) {
            this.f2377b = i2;
        }

        public final int a() {
            return this.f2377b;
        }

        public abstract void b(C0140j0 j0Var);

        public abstract void c(C0140j0 j0Var);

        public abstract C0165w0 d(C0165w0 w0Var, List list);

        public abstract a e(C0140j0 j0Var, a aVar);
    }

    /* renamed from: androidx.core.view.j0$c */
    private static class c extends e {

        /* renamed from: e  reason: collision with root package name */
        private static final Interpolator f2378e = new PathInterpolator(0.0f, 1.1f, 0.0f, 1.0f);

        /* renamed from: f  reason: collision with root package name */
        private static final Interpolator f2379f = new K.a();

        /* renamed from: g  reason: collision with root package name */
        private static final Interpolator f2380g = new DecelerateInterpolator();

        /* renamed from: androidx.core.view.j0$c$a */
        private static class a implements View.OnApplyWindowInsetsListener {

            /* renamed from: a  reason: collision with root package name */
            final b f2381a;

            /* renamed from: b  reason: collision with root package name */
            private C0165w0 f2382b;

            /* renamed from: androidx.core.view.j0$c$a$a  reason: collision with other inner class name */
            class C0037a implements ValueAnimator.AnimatorUpdateListener {

                /* renamed from: a  reason: collision with root package name */
                final /* synthetic */ C0140j0 f2383a;

                /* renamed from: b  reason: collision with root package name */
                final /* synthetic */ C0165w0 f2384b;

                /* renamed from: c  reason: collision with root package name */
                final /* synthetic */ C0165w0 f2385c;

                /* renamed from: d  reason: collision with root package name */
                final /* synthetic */ int f2386d;

                /* renamed from: e  reason: collision with root package name */
                final /* synthetic */ View f2387e;

                C0037a(C0140j0 j0Var, C0165w0 w0Var, C0165w0 w0Var2, int i2, View view) {
                    this.f2383a = j0Var;
                    this.f2384b = w0Var;
                    this.f2385c = w0Var2;
                    this.f2386d = i2;
                    this.f2387e = view;
                }

                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.f2383a.e(valueAnimator.getAnimatedFraction());
                    c.k(this.f2387e, c.o(this.f2384b, this.f2385c, this.f2383a.b(), this.f2386d), Collections.singletonList(this.f2383a));
                }
            }

            /* renamed from: androidx.core.view.j0$c$a$b */
            class b extends AnimatorListenerAdapter {

                /* renamed from: a  reason: collision with root package name */
                final /* synthetic */ C0140j0 f2389a;

                /* renamed from: b  reason: collision with root package name */
                final /* synthetic */ View f2390b;

                b(C0140j0 j0Var, View view) {
                    this.f2389a = j0Var;
                    this.f2390b = view;
                }

                public void onAnimationEnd(Animator animator) {
                    this.f2389a.e(1.0f);
                    c.i(this.f2390b, this.f2389a);
                }
            }

            /* renamed from: androidx.core.view.j0$c$a$c  reason: collision with other inner class name */
            class C0038c implements Runnable {

                /* renamed from: a  reason: collision with root package name */
                final /* synthetic */ View f2392a;

                /* renamed from: b  reason: collision with root package name */
                final /* synthetic */ C0140j0 f2393b;

                /* renamed from: c  reason: collision with root package name */
                final /* synthetic */ a f2394c;

                /* renamed from: d  reason: collision with root package name */
                final /* synthetic */ ValueAnimator f2395d;

                C0038c(View view, C0140j0 j0Var, a aVar, ValueAnimator valueAnimator) {
                    this.f2392a = view;
                    this.f2393b = j0Var;
                    this.f2394c = aVar;
                    this.f2395d = valueAnimator;
                }

                public void run() {
                    c.l(this.f2392a, this.f2393b, this.f2394c);
                    this.f2395d.start();
                }
            }

            a(View view, b bVar) {
                this.f2381a = bVar;
                C0165w0 J2 = W.J(view);
                this.f2382b = J2 != null ? new C0165w0.b(J2).a() : null;
            }

            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                View view2 = view;
                WindowInsets windowInsets2 = windowInsets;
                if (!view.isLaidOut()) {
                    this.f2382b = C0165w0.x(windowInsets2, view2);
                } else {
                    C0165w0 x2 = C0165w0.x(windowInsets2, view2);
                    if (this.f2382b == null) {
                        this.f2382b = W.J(view);
                    }
                    if (this.f2382b != null) {
                        b n2 = c.n(view);
                        if (n2 != null && Objects.equals(n2.f2376a, windowInsets2)) {
                            return c.m(view, windowInsets);
                        }
                        int e2 = c.e(x2, this.f2382b);
                        if (e2 == 0) {
                            return c.m(view, windowInsets);
                        }
                        C0165w0 w0Var = this.f2382b;
                        C0140j0 j0Var = new C0140j0(e2, c.g(e2, x2, w0Var), 160);
                        j0Var.e(0.0f);
                        ValueAnimator duration = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f}).setDuration(j0Var.a());
                        a f2 = c.f(x2, w0Var, e2);
                        c.j(view2, j0Var, windowInsets2, false);
                        duration.addUpdateListener(new C0037a(j0Var, x2, w0Var, e2, view));
                        duration.addListener(new b(j0Var, view2));
                        I.a(view2, new C0038c(view, j0Var, f2, duration));
                    }
                    this.f2382b = x2;
                }
                return c.m(view, windowInsets);
            }
        }

        c(int i2, Interpolator interpolator, long j2) {
            super(i2, interpolator, j2);
        }

        static int e(C0165w0 w0Var, C0165w0 w0Var2) {
            int i2 = 0;
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if (!w0Var.f(i3).equals(w0Var2.f(i3))) {
                    i2 |= i3;
                }
            }
            return i2;
        }

        static a f(C0165w0 w0Var, C0165w0 w0Var2, int i2) {
            f f2 = w0Var.f(i2);
            f f3 = w0Var2.f(i2);
            return new a(f.b(Math.min(f2.f2205a, f3.f2205a), Math.min(f2.f2206b, f3.f2206b), Math.min(f2.f2207c, f3.f2207c), Math.min(f2.f2208d, f3.f2208d)), f.b(Math.max(f2.f2205a, f3.f2205a), Math.max(f2.f2206b, f3.f2206b), Math.max(f2.f2207c, f3.f2207c), Math.max(f2.f2208d, f3.f2208d)));
        }

        static Interpolator g(int i2, C0165w0 w0Var, C0165w0 w0Var2) {
            if ((i2 & 8) != 0) {
                return w0Var.f(C0165w0.m.a()).f2208d > w0Var2.f(C0165w0.m.a()).f2208d ? f2378e : f2379f;
            }
            return f2380g;
        }

        private static View.OnApplyWindowInsetsListener h(View view, b bVar) {
            return new a(view, bVar);
        }

        static void i(View view, C0140j0 j0Var) {
            b n2 = n(view);
            if (n2 != null) {
                n2.b(j0Var);
                if (n2.a() == 0) {
                    return;
                }
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    i(viewGroup.getChildAt(i2), j0Var);
                }
            }
        }

        static void j(View view, C0140j0 j0Var, WindowInsets windowInsets, boolean z2) {
            b n2 = n(view);
            if (n2 != null) {
                n2.f2376a = windowInsets;
                if (!z2) {
                    n2.c(j0Var);
                    z2 = n2.a() == 0;
                }
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    j(viewGroup.getChildAt(i2), j0Var, windowInsets, z2);
                }
            }
        }

        static void k(View view, C0165w0 w0Var, List list) {
            b n2 = n(view);
            if (n2 != null) {
                w0Var = n2.d(w0Var, list);
                if (n2.a() == 0) {
                    return;
                }
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    k(viewGroup.getChildAt(i2), w0Var, list);
                }
            }
        }

        static void l(View view, C0140j0 j0Var, a aVar) {
            b n2 = n(view);
            if (n2 != null) {
                n2.e(j0Var, aVar);
                if (n2.a() == 0) {
                    return;
                }
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                    l(viewGroup.getChildAt(i2), j0Var, aVar);
                }
            }
        }

        static WindowInsets m(View view, WindowInsets windowInsets) {
            return view.getTag(C0284b.tag_on_apply_window_listener) != null ? windowInsets : view.onApplyWindowInsets(windowInsets);
        }

        static b n(View view) {
            Object tag = view.getTag(C0284b.tag_window_insets_animation_callback);
            if (tag instanceof a) {
                return ((a) tag).f2381a;
            }
            return null;
        }

        static C0165w0 o(C0165w0 w0Var, C0165w0 w0Var2, float f2, int i2) {
            f o2;
            C0165w0.b bVar = new C0165w0.b(w0Var);
            for (int i3 = 1; i3 <= 256; i3 <<= 1) {
                if ((i2 & i3) == 0) {
                    o2 = w0Var.f(i3);
                } else {
                    f f3 = w0Var.f(i3);
                    f f4 = w0Var2.f(i3);
                    float f5 = 1.0f - f2;
                    o2 = C0165w0.o(f3, (int) (((double) (((float) (f3.f2205a - f4.f2205a)) * f5)) + 0.5d), (int) (((double) (((float) (f3.f2206b - f4.f2206b)) * f5)) + 0.5d), (int) (((double) (((float) (f3.f2207c - f4.f2207c)) * f5)) + 0.5d), (int) (((double) (((float) (f3.f2208d - f4.f2208d)) * f5)) + 0.5d));
                }
                bVar.b(i3, o2);
            }
            return bVar.a();
        }

        static void p(View view, b bVar) {
            Object tag = view.getTag(C0284b.tag_on_apply_window_listener);
            if (bVar == null) {
                view.setTag(C0284b.tag_window_insets_animation_callback, (Object) null);
                if (tag == null) {
                    view.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) null);
                    return;
                }
                return;
            }
            View.OnApplyWindowInsetsListener h2 = h(view, bVar);
            view.setTag(C0284b.tag_window_insets_animation_callback, h2);
            if (tag == null) {
                view.setOnApplyWindowInsetsListener(h2);
            }
        }
    }

    /* renamed from: androidx.core.view.j0$d */
    private static class d extends e {

        /* renamed from: e  reason: collision with root package name */
        private final WindowInsetsAnimation f2397e;

        /* renamed from: androidx.core.view.j0$d$a */
        private static class a extends WindowInsetsAnimation.Callback {

            /* renamed from: a  reason: collision with root package name */
            private final b f2398a;

            /* renamed from: b  reason: collision with root package name */
            private List f2399b;

            /* renamed from: c  reason: collision with root package name */
            private ArrayList f2400c;

            /* renamed from: d  reason: collision with root package name */
            private final HashMap f2401d = new HashMap();

            a(b bVar) {
                super(bVar.a());
                this.f2398a = bVar;
            }

            private C0140j0 a(WindowInsetsAnimation windowInsetsAnimation) {
                C0140j0 j0Var = (C0140j0) this.f2401d.get(windowInsetsAnimation);
                if (j0Var != null) {
                    return j0Var;
                }
                C0140j0 f2 = C0140j0.f(windowInsetsAnimation);
                this.f2401d.put(windowInsetsAnimation, f2);
                return f2;
            }

            public void onEnd(WindowInsetsAnimation windowInsetsAnimation) {
                this.f2398a.b(a(windowInsetsAnimation));
                this.f2401d.remove(windowInsetsAnimation);
            }

            public void onPrepare(WindowInsetsAnimation windowInsetsAnimation) {
                this.f2398a.c(a(windowInsetsAnimation));
            }

            public WindowInsets onProgress(WindowInsets windowInsets, List list) {
                ArrayList arrayList = this.f2400c;
                if (arrayList == null) {
                    ArrayList arrayList2 = new ArrayList(list.size());
                    this.f2400c = arrayList2;
                    this.f2399b = Collections.unmodifiableList(arrayList2);
                } else {
                    arrayList.clear();
                }
                for (int size = list.size() - 1; size >= 0; size--) {
                    WindowInsetsAnimation a2 = C0161u0.a(list.get(size));
                    C0140j0 a3 = a(a2);
                    a3.e(a2.getFraction());
                    this.f2400c.add(a3);
                }
                return this.f2398a.d(C0165w0.w(windowInsets), this.f2399b).v();
            }

            public WindowInsetsAnimation.Bounds onStart(WindowInsetsAnimation windowInsetsAnimation, WindowInsetsAnimation.Bounds bounds) {
                return this.f2398a.e(a(windowInsetsAnimation), a.d(bounds)).c();
            }
        }

        d(int i2, Interpolator interpolator, long j2) {
            this(C0155r0.a(i2, interpolator, j2));
        }

        public static WindowInsetsAnimation.Bounds e(a aVar) {
            C0159t0.a();
            return C0157s0.a(aVar.a().e(), aVar.b().e());
        }

        public static f f(WindowInsetsAnimation.Bounds bounds) {
            return f.d(bounds.getUpperBound());
        }

        public static f g(WindowInsetsAnimation.Bounds bounds) {
            return f.d(bounds.getLowerBound());
        }

        public static void h(View view, b bVar) {
            view.setWindowInsetsAnimationCallback(bVar != null ? new a(bVar) : null);
        }

        public long a() {
            return this.f2397e.getDurationMillis();
        }

        public float b() {
            return this.f2397e.getInterpolatedFraction();
        }

        public int c() {
            return this.f2397e.getTypeMask();
        }

        public void d(float f2) {
            this.f2397e.setFraction(f2);
        }

        d(WindowInsetsAnimation windowInsetsAnimation) {
            super(0, (Interpolator) null, 0);
            this.f2397e = windowInsetsAnimation;
        }
    }

    /* renamed from: androidx.core.view.j0$e */
    private static class e {

        /* renamed from: a  reason: collision with root package name */
        private final int f2402a;

        /* renamed from: b  reason: collision with root package name */
        private float f2403b;

        /* renamed from: c  reason: collision with root package name */
        private final Interpolator f2404c;

        /* renamed from: d  reason: collision with root package name */
        private final long f2405d;

        e(int i2, Interpolator interpolator, long j2) {
            this.f2402a = i2;
            this.f2404c = interpolator;
            this.f2405d = j2;
        }

        public long a() {
            return this.f2405d;
        }

        public float b() {
            Interpolator interpolator = this.f2404c;
            return interpolator != null ? interpolator.getInterpolation(this.f2403b) : this.f2403b;
        }

        public int c() {
            return this.f2402a;
        }

        public void d(float f2) {
            this.f2403b = f2;
        }
    }

    public C0140j0(int i2, Interpolator interpolator, long j2) {
        this.f2373a = Build.VERSION.SDK_INT >= 30 ? new d(i2, interpolator, j2) : new c(i2, interpolator, j2);
    }

    static void d(View view, b bVar) {
        if (Build.VERSION.SDK_INT >= 30) {
            d.h(view, bVar);
        } else {
            c.p(view, bVar);
        }
    }

    static C0140j0 f(WindowInsetsAnimation windowInsetsAnimation) {
        return new C0140j0(windowInsetsAnimation);
    }

    public long a() {
        return this.f2373a.a();
    }

    public float b() {
        return this.f2373a.b();
    }

    public int c() {
        return this.f2373a.c();
    }

    public void e(float f2) {
        this.f2373a.d(f2);
    }

    private C0140j0(WindowInsetsAnimation windowInsetsAnimation) {
        this(0, (Interpolator) null, 0);
        if (Build.VERSION.SDK_INT >= 30) {
            this.f2373a = new d(windowInsetsAnimation);
        }
    }
}
