package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import java.util.concurrent.atomic.AtomicBoolean;

public final class K {

    /* renamed from: a  reason: collision with root package name */
    private final c f2304a;

    private static class a extends c {

        /* renamed from: a  reason: collision with root package name */
        private final View f2305a;

        a(View view) {
            this.f2305a = view;
        }

        /* access modifiers changed from: package-private */
        public void a() {
            View view = this.f2305a;
            if (view != null) {
                ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.f2305a.getWindowToken(), 0);
            }
        }

        /* access modifiers changed from: package-private */
        public void b() {
            View view = this.f2305a;
            if (view != null) {
                if (view.isInEditMode() || view.onCheckIsTextEditor()) {
                    view.requestFocus();
                } else {
                    view = view.getRootView().findFocus();
                }
                if (view == null) {
                    view = this.f2305a.getRootView().findViewById(16908290);
                }
                if (view != null && view.hasWindowFocus()) {
                    view.post(new J(view));
                }
            }
        }
    }

    private static class b extends a {

        /* renamed from: b  reason: collision with root package name */
        private View f2306b;

        /* renamed from: c  reason: collision with root package name */
        private WindowInsetsController f2307c;

        b(View view) {
            super(view);
            this.f2306b = view;
        }

        /* access modifiers changed from: private */
        public static /* synthetic */ void f(AtomicBoolean atomicBoolean, WindowInsetsController windowInsetsController, int i2) {
            atomicBoolean.set((i2 & 8) != 0);
        }

        /* access modifiers changed from: package-private */
        public void a() {
            View view;
            WindowInsetsController windowInsetsController = this.f2307c;
            if (windowInsetsController == null) {
                View view2 = this.f2306b;
                windowInsetsController = view2 != null ? view2.getWindowInsetsController() : null;
            }
            if (windowInsetsController != null) {
                AtomicBoolean atomicBoolean = new AtomicBoolean(false);
                S s2 = new S(atomicBoolean);
                windowInsetsController.addOnControllableInsetsChangedListener(s2);
                if (!atomicBoolean.get() && (view = this.f2306b) != null) {
                    ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.f2306b.getWindowToken(), 0);
                }
                windowInsetsController.removeOnControllableInsetsChangedListener(s2);
                windowInsetsController.hide(WindowInsets.Type.ime());
                return;
            }
            super.a();
        }

        /* access modifiers changed from: package-private */
        public void b() {
            View view = this.f2306b;
            if (view != null && Build.VERSION.SDK_INT < 33) {
                ((InputMethodManager) view.getContext().getSystemService("input_method")).isActive();
            }
            WindowInsetsController windowInsetsController = this.f2307c;
            if (windowInsetsController == null) {
                View view2 = this.f2306b;
                windowInsetsController = view2 != null ? view2.getWindowInsetsController() : null;
            }
            if (windowInsetsController != null) {
                windowInsetsController.show(WindowInsets.Type.ime());
            } else {
                super.b();
            }
        }

        b(WindowInsetsController windowInsetsController) {
            super((View) null);
            this.f2307c = windowInsetsController;
        }
    }

    private static class c {
        c() {
        }

        /* access modifiers changed from: package-private */
        public abstract void a();

        /* access modifiers changed from: package-private */
        public abstract void b();
    }

    public K(View view) {
        this.f2304a = Build.VERSION.SDK_INT >= 30 ? new b(view) : new a(view);
    }

    public void a() {
        this.f2304a.a();
    }

    public void b() {
        this.f2304a.b();
    }

    K(WindowInsetsController windowInsetsController) {
        this.f2304a = new b(windowInsetsController);
    }
}
