package androidx.core.view;

public abstract /* synthetic */ class P {
}
