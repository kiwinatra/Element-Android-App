package androidx.core.view;

/* renamed from: androidx.core.view.l0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0144l0 {
}
