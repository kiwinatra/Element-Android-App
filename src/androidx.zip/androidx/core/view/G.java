package androidx.core.view;

import android.view.View;

public interface G {
    C0127d a(View view, C0127d dVar);
}
