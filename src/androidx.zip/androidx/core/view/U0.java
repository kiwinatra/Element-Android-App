package androidx.core.view;

public abstract /* synthetic */ class U0 {
}
