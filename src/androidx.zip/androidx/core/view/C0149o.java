package androidx.core.view;

import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

/* renamed from: androidx.core.view.o  reason: case insensitive filesystem */
public class C0149o {

    /* renamed from: a  reason: collision with root package name */
    private final Context f2406a;

    /* renamed from: b  reason: collision with root package name */
    private final C0151p f2407b;

    /* renamed from: c  reason: collision with root package name */
    private final b f2408c;

    /* renamed from: d  reason: collision with root package name */
    private final a f2409d;

    /* renamed from: e  reason: collision with root package name */
    private VelocityTracker f2410e;

    /* renamed from: f  reason: collision with root package name */
    private float f2411f;

    /* renamed from: g  reason: collision with root package name */
    private int f2412g;

    /* renamed from: h  reason: collision with root package name */
    private int f2413h;

    /* renamed from: i  reason: collision with root package name */
    private int f2414i;

    /* renamed from: j  reason: collision with root package name */
    private final int[] f2415j;

    /* renamed from: androidx.core.view.o$a */
    interface a {
        float a(VelocityTracker velocityTracker, MotionEvent motionEvent, int i2);
    }

    /* renamed from: androidx.core.view.o$b */
    interface b {
        void a(Context context, int[] iArr, MotionEvent motionEvent, int i2);
    }

    public C0149o(Context context, C0151p pVar) {
        this(context, pVar, new C0145m(), new C0147n());
    }

    /* access modifiers changed from: private */
    public static void c(Context context, int[] iArr, MotionEvent motionEvent, int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        iArr[0] = C0122a0.i(context, viewConfiguration, motionEvent.getDeviceId(), i2, motionEvent.getSource());
        iArr[1] = C0122a0.h(context, viewConfiguration, motionEvent.getDeviceId(), i2, motionEvent.getSource());
    }

    private boolean d(MotionEvent motionEvent, int i2) {
        int source = motionEvent.getSource();
        int deviceId = motionEvent.getDeviceId();
        if (this.f2413h == source && this.f2414i == deviceId && this.f2412g == i2) {
            return false;
        }
        this.f2408c.a(this.f2406a, this.f2415j, motionEvent, i2);
        this.f2413h = source;
        this.f2414i = deviceId;
        this.f2412g = i2;
        return true;
    }

    private float e(MotionEvent motionEvent, int i2) {
        if (this.f2410e == null) {
            this.f2410e = VelocityTracker.obtain();
        }
        return this.f2409d.a(this.f2410e, motionEvent, i2);
    }

    /* access modifiers changed from: private */
    public static float f(VelocityTracker velocityTracker, MotionEvent motionEvent, int i2) {
        T.a(velocityTracker, motionEvent);
        T.b(velocityTracker, 1000);
        return T.d(velocityTracker, i2);
    }

    public void g(MotionEvent motionEvent, int i2) {
        boolean d2 = d(motionEvent, i2);
        if (this.f2415j[0] == Integer.MAX_VALUE) {
            VelocityTracker velocityTracker = this.f2410e;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.f2410e = null;
                return;
            }
            return;
        }
        float e2 = e(motionEvent, i2) * this.f2407b.b();
        float signum = Math.signum(e2);
        float f2 = 0.0f;
        if (d2 || !(signum == Math.signum(this.f2411f) || signum == 0.0f)) {
            this.f2407b.c();
        }
        float abs = Math.abs(e2);
        int[] iArr = this.f2415j;
        if (abs >= ((float) iArr[0])) {
            int i3 = iArr[1];
            float max = Math.max((float) (-i3), Math.min(e2, (float) i3));
            if (this.f2407b.a(max)) {
                f2 = max;
            }
            this.f2411f = f2;
        }
    }

    C0149o(Context context, C0151p pVar, b bVar, a aVar) {
        this.f2412g = -1;
        this.f2413h = -1;
        this.f2414i = -1;
        this.f2415j = new int[]{Integer.MAX_VALUE, 0};
        this.f2406a = context;
        this.f2407b = pVar;
        this.f2408c = bVar;
        this.f2409d = aVar;
    }
}
