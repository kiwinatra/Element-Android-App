package androidx.core.view;

import android.view.ViewConfiguration;
import x.i;

public final /* synthetic */ class Z implements i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewConfiguration f2344a;

    public /* synthetic */ Z(ViewConfiguration viewConfiguration) {
        this.f2344a = viewConfiguration;
    }

    public final Object get() {
        return Integer.valueOf(this.f2344a.getScaledMinimumFlingVelocity());
    }
}
