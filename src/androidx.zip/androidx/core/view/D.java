package androidx.core.view;

import android.view.View;

public interface D extends C {
    void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
