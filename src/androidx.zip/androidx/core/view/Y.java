package androidx.core.view;

import android.view.ViewConfiguration;
import x.i;

public final /* synthetic */ class Y implements i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ViewConfiguration f2343a;

    public /* synthetic */ Y(ViewConfiguration viewConfiguration) {
        this.f2343a = viewConfiguration;
    }

    public final Object get() {
        return Integer.valueOf(this.f2343a.getScaledMaximumFlingVelocity());
    }
}
