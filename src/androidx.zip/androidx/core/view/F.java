package androidx.core.view;

import android.view.View;

public interface F {
    C0165w0 a(View view, C0165w0 w0Var);
}
