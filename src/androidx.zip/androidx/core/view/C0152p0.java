package androidx.core.view;

/* renamed from: androidx.core.view.p0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0152p0 {
}
