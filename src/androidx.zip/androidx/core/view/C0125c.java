package androidx.core.view;

import android.view.ContentInfo;

/* renamed from: androidx.core.view.c  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0125c {
    public static /* bridge */ /* synthetic */ ContentInfo a(Object obj) {
        return (ContentInfo) obj;
    }
}
