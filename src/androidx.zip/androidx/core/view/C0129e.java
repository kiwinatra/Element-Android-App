package androidx.core.view;

/* renamed from: androidx.core.view.e  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0129e {
}
