package androidx.core.view;

import android.os.Build;
import android.view.View;
import android.view.Window;

/* renamed from: androidx.core.view.i0  reason: case insensitive filesystem */
public abstract class C0138i0 {

    /* renamed from: androidx.core.view.i0$a */
    static class a {
        static void a(Window window, boolean z2) {
            View decorView = window.getDecorView();
            int systemUiVisibility = decorView.getSystemUiVisibility();
            decorView.setSystemUiVisibility(z2 ? systemUiVisibility & -1793 : systemUiVisibility | 1792);
        }
    }

    /* renamed from: androidx.core.view.i0$b */
    static class b {
        static void a(Window window, boolean z2) {
            window.setDecorFitsSystemWindows(z2);
        }
    }

    public static V0 a(Window window, View view) {
        return new V0(window, view);
    }

    public static void b(Window window, boolean z2) {
        if (Build.VERSION.SDK_INT >= 30) {
            b.a(window, z2);
        } else {
            a.a(window, z2);
        }
    }
}
