package androidx.core.view;

/* renamed from: androidx.core.view.v0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0163v0 {
}
