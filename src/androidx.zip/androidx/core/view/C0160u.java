package androidx.core.view;

import android.view.LayoutInflater;

/* renamed from: androidx.core.view.u  reason: case insensitive filesystem */
public abstract class C0160u {
    public static void a(LayoutInflater layoutInflater, LayoutInflater.Factory2 factory2) {
        layoutInflater.setFactory2(factory2);
    }
}
