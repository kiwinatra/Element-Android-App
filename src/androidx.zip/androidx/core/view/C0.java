package androidx.core.view;

public abstract /* synthetic */ class C0 {
}
