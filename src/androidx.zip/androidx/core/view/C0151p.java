package androidx.core.view;

/* renamed from: androidx.core.view.p  reason: case insensitive filesystem */
public interface C0151p {
    boolean a(float f2);

    float b();

    void c();
}
