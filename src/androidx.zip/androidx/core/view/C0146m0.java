package androidx.core.view;

/* renamed from: androidx.core.view.m0  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0146m0 {
}
