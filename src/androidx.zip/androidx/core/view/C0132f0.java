package androidx.core.view;

import android.view.View;

/* renamed from: androidx.core.view.f0  reason: case insensitive filesystem */
public interface C0132f0 {
    void a(View view);

    void b(View view);

    void c(View view);
}
