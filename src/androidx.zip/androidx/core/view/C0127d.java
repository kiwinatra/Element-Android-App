package androidx.core.view;

import android.content.ClipData;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ContentInfo;
import java.util.Objects;
import x.h;

/* renamed from: androidx.core.view.d  reason: case insensitive filesystem */
public final class C0127d {

    /* renamed from: a  reason: collision with root package name */
    private final f f2353a;

    /* renamed from: androidx.core.view.d$a */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final c f2354a;

        public a(ClipData clipData, int i2) {
            this.f2354a = Build.VERSION.SDK_INT >= 31 ? new b(clipData, i2) : new C0036d(clipData, i2);
        }

        public C0127d a() {
            return this.f2354a.a();
        }

        public a b(Bundle bundle) {
            this.f2354a.b(bundle);
            return this;
        }

        public a c(int i2) {
            this.f2354a.d(i2);
            return this;
        }

        public a d(Uri uri) {
            this.f2354a.c(uri);
            return this;
        }
    }

    /* renamed from: androidx.core.view.d$b */
    private static final class b implements c {

        /* renamed from: a  reason: collision with root package name */
        private final ContentInfo.Builder f2355a;

        b(ClipData clipData, int i2) {
            this.f2355a = C0137i.a(clipData, i2);
        }

        public C0127d a() {
            return new C0127d(new e(this.f2355a.build()));
        }

        public void b(Bundle bundle) {
            ContentInfo.Builder unused = this.f2355a.setExtras(bundle);
        }

        public void c(Uri uri) {
            ContentInfo.Builder unused = this.f2355a.setLinkUri(uri);
        }

        public void d(int i2) {
            ContentInfo.Builder unused = this.f2355a.setFlags(i2);
        }
    }

    /* renamed from: androidx.core.view.d$c */
    private interface c {
        C0127d a();

        void b(Bundle bundle);

        void c(Uri uri);

        void d(int i2);
    }

    /* renamed from: androidx.core.view.d$d  reason: collision with other inner class name */
    private static final class C0036d implements c {

        /* renamed from: a  reason: collision with root package name */
        ClipData f2356a;

        /* renamed from: b  reason: collision with root package name */
        int f2357b;

        /* renamed from: c  reason: collision with root package name */
        int f2358c;

        /* renamed from: d  reason: collision with root package name */
        Uri f2359d;

        /* renamed from: e  reason: collision with root package name */
        Bundle f2360e;

        C0036d(ClipData clipData, int i2) {
            this.f2356a = clipData;
            this.f2357b = i2;
        }

        public C0127d a() {
            return new C0127d(new g(this));
        }

        public void b(Bundle bundle) {
            this.f2360e = bundle;
        }

        public void c(Uri uri) {
            this.f2359d = uri;
        }

        public void d(int i2) {
            this.f2358c = i2;
        }
    }

    /* renamed from: androidx.core.view.d$e */
    private static final class e implements f {

        /* renamed from: a  reason: collision with root package name */
        private final ContentInfo f2361a;

        e(ContentInfo contentInfo) {
            this.f2361a = C0125c.a(h.g(contentInfo));
        }

        public ClipData a() {
            return this.f2361a.getClip();
        }

        public int b() {
            return this.f2361a.getFlags();
        }

        public ContentInfo c() {
            return this.f2361a;
        }

        public int d() {
            return this.f2361a.getSource();
        }

        public String toString() {
            return "ContentInfoCompat{" + this.f2361a + "}";
        }
    }

    /* renamed from: androidx.core.view.d$f */
    private interface f {
        ClipData a();

        int b();

        ContentInfo c();

        int d();
    }

    /* renamed from: androidx.core.view.d$g */
    private static final class g implements f {

        /* renamed from: a  reason: collision with root package name */
        private final ClipData f2362a;

        /* renamed from: b  reason: collision with root package name */
        private final int f2363b;

        /* renamed from: c  reason: collision with root package name */
        private final int f2364c;

        /* renamed from: d  reason: collision with root package name */
        private final Uri f2365d;

        /* renamed from: e  reason: collision with root package name */
        private final Bundle f2366e;

        g(C0036d dVar) {
            this.f2362a = (ClipData) h.g(dVar.f2356a);
            this.f2363b = h.c(dVar.f2357b, 0, 5, "source");
            this.f2364c = h.f(dVar.f2358c, 1);
            this.f2365d = dVar.f2359d;
            this.f2366e = dVar.f2360e;
        }

        public ClipData a() {
            return this.f2362a;
        }

        public int b() {
            return this.f2364c;
        }

        public ContentInfo c() {
            return null;
        }

        public int d() {
            return this.f2363b;
        }

        public String toString() {
            String str;
            StringBuilder sb = new StringBuilder();
            sb.append("ContentInfoCompat{clip=");
            sb.append(this.f2362a.getDescription());
            sb.append(", source=");
            sb.append(C0127d.e(this.f2363b));
            sb.append(", flags=");
            sb.append(C0127d.a(this.f2364c));
            String str2 = "";
            if (this.f2365d == null) {
                str = str2;
            } else {
                str = ", hasLinkUri(" + this.f2365d.toString().length() + ")";
            }
            sb.append(str);
            if (this.f2366e != null) {
                str2 = ", hasExtras";
            }
            sb.append(str2);
            sb.append("}");
            return sb.toString();
        }
    }

    C0127d(f fVar) {
        this.f2353a = fVar;
    }

    static String a(int i2) {
        return (i2 & 1) != 0 ? "FLAG_CONVERT_TO_PLAIN_TEXT" : String.valueOf(i2);
    }

    static String e(int i2) {
        if (i2 == 0) {
            return "SOURCE_APP";
        }
        if (i2 == 1) {
            return "SOURCE_CLIPBOARD";
        }
        if (i2 == 2) {
            return "SOURCE_INPUT_METHOD";
        }
        if (i2 == 3) {
            return "SOURCE_DRAG_AND_DROP";
        }
        if (i2 != 4) {
            return i2 != 5 ? String.valueOf(i2) : "SOURCE_PROCESS_TEXT";
        }
        return "SOURCE_AUTOFILL";
    }

    public static C0127d g(ContentInfo contentInfo) {
        return new C0127d(new e(contentInfo));
    }

    public ClipData b() {
        return this.f2353a.a();
    }

    public int c() {
        return this.f2353a.b();
    }

    public int d() {
        return this.f2353a.d();
    }

    public ContentInfo f() {
        ContentInfo c2 = this.f2353a.c();
        Objects.requireNonNull(c2);
        return C0125c.a(c2);
    }

    public String toString() {
        return this.f2353a.toString();
    }
}
