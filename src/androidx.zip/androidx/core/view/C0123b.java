package androidx.core.view;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: androidx.core.view.b  reason: case insensitive filesystem */
public abstract class C0123b {

    /* renamed from: a  reason: collision with root package name */
    private final Context f2350a;

    /* renamed from: b  reason: collision with root package name */
    private a f2351b;

    /* renamed from: c  reason: collision with root package name */
    private C0035b f2352c;

    /* renamed from: androidx.core.view.b$a */
    public interface a {
    }

    /* renamed from: androidx.core.view.b$b  reason: collision with other inner class name */
    public interface C0035b {
        void onActionProviderVisibilityChanged(boolean z2);
    }

    public C0123b(Context context) {
        this.f2350a = context;
    }

    public abstract boolean a();

    public abstract boolean b();

    public abstract View c(MenuItem menuItem);

    public abstract boolean d();

    public abstract void e(SubMenu subMenu);

    public abstract boolean f();

    public void g() {
        this.f2352c = null;
        this.f2351b = null;
    }

    public void h(a aVar) {
        this.f2351b = aVar;
    }

    public abstract void i(C0035b bVar);
}
