package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

/* renamed from: androidx.core.view.e0  reason: case insensitive filesystem */
public final class C0130e0 {

    /* renamed from: a  reason: collision with root package name */
    private final WeakReference f2369a;

    /* renamed from: androidx.core.view.e0$a */
    class a extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ C0132f0 f2370a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f2371b;

        a(C0132f0 f0Var, View view) {
            this.f2370a = f0Var;
            this.f2371b = view;
        }

        public void onAnimationCancel(Animator animator) {
            this.f2370a.c(this.f2371b);
        }

        public void onAnimationEnd(Animator animator) {
            this.f2370a.a(this.f2371b);
        }

        public void onAnimationStart(Animator animator) {
            this.f2370a.b(this.f2371b);
        }
    }

    C0130e0(View view) {
        this.f2369a = new WeakReference(view);
    }

    private void i(View view, C0132f0 f0Var) {
        if (f0Var != null) {
            view.animate().setListener(new a(f0Var, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    public C0130e0 b(float f2) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().alpha(f2);
        }
        return this;
    }

    public void c() {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public long d() {
        View view = (View) this.f2369a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0;
    }

    public C0130e0 f(long j2) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
        return this;
    }

    public C0130e0 g(Interpolator interpolator) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().setInterpolator(interpolator);
        }
        return this;
    }

    public C0130e0 h(C0132f0 f0Var) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            i(view, f0Var);
        }
        return this;
    }

    public C0130e0 j(long j2) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().setStartDelay(j2);
        }
        return this;
    }

    public C0130e0 k(C0136h0 h0Var) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().setUpdateListener(h0Var != null ? new C0128d0(h0Var, view) : null);
        }
        return this;
    }

    public void l() {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    public C0130e0 m(float f2) {
        View view = (View) this.f2369a.get();
        if (view != null) {
            view.animate().translationY(f2);
        }
        return this;
    }
}
