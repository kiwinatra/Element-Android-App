package androidx.core.view;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import t.C0284b;
import y.I;
import y.J;

/* renamed from: androidx.core.view.a  reason: case insensitive filesystem */
public class C0121a {

    /* renamed from: c  reason: collision with root package name */
    private static final View.AccessibilityDelegate f2345c = new View.AccessibilityDelegate();

    /* renamed from: a  reason: collision with root package name */
    private final View.AccessibilityDelegate f2346a;

    /* renamed from: b  reason: collision with root package name */
    private final View.AccessibilityDelegate f2347b;

    /* renamed from: androidx.core.view.a$a  reason: collision with other inner class name */
    static final class C0033a extends View.AccessibilityDelegate {

        /* renamed from: a  reason: collision with root package name */
        final C0121a f2348a;

        C0033a(C0121a aVar) {
            this.f2348a = aVar;
        }

        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f2348a.a(view, accessibilityEvent);
        }

        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            J b2 = this.f2348a.b(view);
            if (b2 != null) {
                return (AccessibilityNodeProvider) b2.e();
            }
            return null;
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f2348a.f(view, accessibilityEvent);
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            I O0 = I.O0(accessibilityNodeInfo);
            O0.D0(W.X(view));
            O0.v0(W.S(view));
            O0.A0(W.q(view));
            O0.J0(W.K(view));
            this.f2348a.g(view, O0);
            O0.f(accessibilityNodeInfo.getText(), view);
            List c2 = C0121a.c(view);
            for (int i2 = 0; i2 < c2.size(); i2++) {
                O0.b((I.a) c2.get(i2));
            }
        }

        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f2348a.h(view, accessibilityEvent);
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f2348a.i(viewGroup, view, accessibilityEvent);
        }

        public boolean performAccessibilityAction(View view, int i2, Bundle bundle) {
            return this.f2348a.j(view, i2, bundle);
        }

        public void sendAccessibilityEvent(View view, int i2) {
            this.f2348a.l(view, i2);
        }

        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f2348a.m(view, accessibilityEvent);
        }
    }

    public C0121a() {
        this(f2345c);
    }

    static List c(View view) {
        List list = (List) view.getTag(C0284b.tag_accessibility_actions);
        return list == null ? Collections.emptyList() : list;
    }

    private boolean e(ClickableSpan clickableSpan, View view) {
        if (clickableSpan != null) {
            ClickableSpan[] r2 = I.r(view.createAccessibilityNodeInfo().getText());
            int i2 = 0;
            while (r2 != null && i2 < r2.length) {
                if (clickableSpan.equals(r2[i2])) {
                    return true;
                }
                i2++;
            }
        }
        return false;
    }

    private boolean k(int i2, View view) {
        WeakReference weakReference;
        SparseArray sparseArray = (SparseArray) view.getTag(C0284b.tag_accessibility_clickable_spans);
        if (sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i2)) == null) {
            return false;
        }
        ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
        if (!e(clickableSpan, view)) {
            return false;
        }
        clickableSpan.onClick(view);
        return true;
    }

    public boolean a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f2346a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public J b(View view) {
        AccessibilityNodeProvider accessibilityNodeProvider = this.f2346a.getAccessibilityNodeProvider(view);
        if (accessibilityNodeProvider != null) {
            return new J(accessibilityNodeProvider);
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public View.AccessibilityDelegate d() {
        return this.f2347b;
    }

    public void f(View view, AccessibilityEvent accessibilityEvent) {
        this.f2346a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void g(View view, I i2) {
        this.f2346a.onInitializeAccessibilityNodeInfo(view, i2.N0());
    }

    public void h(View view, AccessibilityEvent accessibilityEvent) {
        this.f2346a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f2346a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean j(View view, int i2, Bundle bundle) {
        List c2 = c(view);
        boolean z2 = false;
        int i3 = 0;
        while (true) {
            if (i3 >= c2.size()) {
                break;
            }
            I.a aVar = (I.a) c2.get(i3);
            if (aVar.b() == i2) {
                z2 = aVar.d(view, bundle);
                break;
            }
            i3++;
        }
        if (!z2) {
            z2 = this.f2346a.performAccessibilityAction(view, i2, bundle);
        }
        return (z2 || i2 != C0284b.accessibility_action_clickable_span || bundle == null) ? z2 : k(bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), view);
    }

    public void l(View view, int i2) {
        this.f2346a.sendAccessibilityEvent(view, i2);
    }

    public void m(View view, AccessibilityEvent accessibilityEvent) {
        this.f2346a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }

    public C0121a(View.AccessibilityDelegate accessibilityDelegate) {
        this.f2346a = accessibilityDelegate;
        this.f2347b = new C0033a(this);
    }
}
