package androidx.core.view;

import android.view.MotionEvent;

class U {

    /* renamed from: a  reason: collision with root package name */
    private final float[] f2310a = new float[20];

    /* renamed from: b  reason: collision with root package name */
    private final long[] f2311b = new long[20];

    /* renamed from: c  reason: collision with root package name */
    private float f2312c = 0.0f;

    /* renamed from: d  reason: collision with root package name */
    private int f2313d = 0;

    /* renamed from: e  reason: collision with root package name */
    private int f2314e = 0;

    U() {
    }

    private void b() {
        this.f2313d = 0;
        this.f2312c = 0.0f;
    }

    private float e() {
        long[] jArr;
        long j2;
        int i2 = this.f2313d;
        if (i2 < 2) {
            return 0.0f;
        }
        int i3 = this.f2314e;
        int i4 = ((i3 + 20) - (i2 - 1)) % 20;
        long j3 = this.f2311b[i3];
        while (true) {
            jArr = this.f2311b;
            j2 = jArr[i4];
            if (j3 - j2 <= 100) {
                break;
            }
            this.f2313d--;
            i4 = (i4 + 1) % 20;
        }
        int i5 = this.f2313d;
        if (i5 < 2) {
            return 0.0f;
        }
        if (i5 == 2) {
            int i6 = (i4 + 1) % 20;
            long j4 = jArr[i6];
            if (j2 == j4) {
                return 0.0f;
            }
            return this.f2310a[i6] / ((float) (j4 - j2));
        }
        int i7 = 0;
        float f2 = 0.0f;
        for (int i8 = 0; i8 < this.f2313d - 1; i8++) {
            int i9 = i8 + i4;
            long[] jArr2 = this.f2311b;
            long j5 = jArr2[i9 % 20];
            int i10 = (i9 + 1) % 20;
            if (jArr2[i10] != j5) {
                i7++;
                float f3 = f(f2);
                float f4 = this.f2310a[i10] / ((float) (this.f2311b[i10] - j5));
                f2 += (f4 - f3) * Math.abs(f4);
                if (i7 == 1) {
                    f2 *= 0.5f;
                }
            }
        }
        return f(f2);
    }

    private static float f(float f2) {
        return (f2 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt((double) (Math.abs(f2) * 2.0f)));
    }

    /* access modifiers changed from: package-private */
    public void a(MotionEvent motionEvent) {
        long eventTime = motionEvent.getEventTime();
        if (this.f2313d != 0 && eventTime - this.f2311b[this.f2314e] > 40) {
            b();
        }
        int i2 = (this.f2314e + 1) % 20;
        this.f2314e = i2;
        int i3 = this.f2313d;
        if (i3 != 20) {
            this.f2313d = i3 + 1;
        }
        this.f2310a[i2] = motionEvent.getAxisValue(26);
        this.f2311b[this.f2314e] = eventTime;
    }

    /* access modifiers changed from: package-private */
    public void c(int i2, float f2) {
        float abs;
        float e2 = e() * ((float) i2);
        this.f2312c = e2;
        if (e2 < (-Math.abs(f2))) {
            abs = -Math.abs(f2);
        } else if (this.f2312c > Math.abs(f2)) {
            abs = Math.abs(f2);
        } else {
            return;
        }
        this.f2312c = abs;
    }

    /* access modifiers changed from: package-private */
    public float d(int i2) {
        if (i2 != 26) {
            return 0.0f;
        }
        return this.f2312c;
    }
}
