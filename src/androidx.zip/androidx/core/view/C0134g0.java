package androidx.core.view;

import android.view.View;

/* renamed from: androidx.core.view.g0  reason: case insensitive filesystem */
public abstract class C0134g0 implements C0132f0 {
    public void b(View view) {
    }

    public void c(View view) {
    }
}
