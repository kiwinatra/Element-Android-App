package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.C0130e0;
import androidx.core.view.C0132f0;
import androidx.core.view.C0134g0;
import java.util.ArrayList;
import java.util.Iterator;

public class h {

    /* renamed from: a  reason: collision with root package name */
    final ArrayList f870a = new ArrayList();

    /* renamed from: b  reason: collision with root package name */
    private long f871b = -1;

    /* renamed from: c  reason: collision with root package name */
    private Interpolator f872c;

    /* renamed from: d  reason: collision with root package name */
    C0132f0 f873d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f874e;

    /* renamed from: f  reason: collision with root package name */
    private final C0134g0 f875f = new a();

    class a extends C0134g0 {

        /* renamed from: a  reason: collision with root package name */
        private boolean f876a = false;

        /* renamed from: b  reason: collision with root package name */
        private int f877b = 0;

        a() {
        }

        public void a(View view) {
            int i2 = this.f877b + 1;
            this.f877b = i2;
            if (i2 == h.this.f870a.size()) {
                C0132f0 f0Var = h.this.f873d;
                if (f0Var != null) {
                    f0Var.a((View) null);
                }
                d();
            }
        }

        public void b(View view) {
            if (!this.f876a) {
                this.f876a = true;
                C0132f0 f0Var = h.this.f873d;
                if (f0Var != null) {
                    f0Var.b((View) null);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d() {
            this.f877b = 0;
            this.f876a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.f874e) {
            Iterator it = this.f870a.iterator();
            while (it.hasNext()) {
                ((C0130e0) it.next()).c();
            }
            this.f874e = false;
        }
    }

    /* access modifiers changed from: package-private */
    public void b() {
        this.f874e = false;
    }

    public h c(C0130e0 e0Var) {
        if (!this.f874e) {
            this.f870a.add(e0Var);
        }
        return this;
    }

    public h d(C0130e0 e0Var, C0130e0 e0Var2) {
        this.f870a.add(e0Var);
        e0Var2.j(e0Var.d());
        this.f870a.add(e0Var2);
        return this;
    }

    public h e(long j2) {
        if (!this.f874e) {
            this.f871b = j2;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.f874e) {
            this.f872c = interpolator;
        }
        return this;
    }

    public h g(C0132f0 f0Var) {
        if (!this.f874e) {
            this.f873d = f0Var;
        }
        return this;
    }

    public void h() {
        if (!this.f874e) {
            Iterator it = this.f870a.iterator();
            while (it.hasNext()) {
                C0130e0 e0Var = (C0130e0) it.next();
                long j2 = this.f871b;
                if (j2 >= 0) {
                    e0Var.f(j2);
                }
                Interpolator interpolator = this.f872c;
                if (interpolator != null) {
                    e0Var.g(interpolator);
                }
                if (this.f873d != null) {
                    e0Var.h(this.f875f);
                }
                e0Var.l();
            }
            this.f874e = true;
        }
    }
}
