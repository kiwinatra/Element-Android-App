package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import e.g;
import java.util.ArrayList;

public class c implements j, AdapterView.OnItemClickListener {

    /* renamed from: a  reason: collision with root package name */
    Context f959a;

    /* renamed from: b  reason: collision with root package name */
    LayoutInflater f960b;

    /* renamed from: c  reason: collision with root package name */
    e f961c;

    /* renamed from: d  reason: collision with root package name */
    ExpandedMenuView f962d;

    /* renamed from: e  reason: collision with root package name */
    int f963e;

    /* renamed from: f  reason: collision with root package name */
    int f964f;

    /* renamed from: g  reason: collision with root package name */
    int f965g;

    /* renamed from: h  reason: collision with root package name */
    private j.a f966h;

    /* renamed from: i  reason: collision with root package name */
    a f967i;

    /* renamed from: j  reason: collision with root package name */
    private int f968j;

    private class a extends BaseAdapter {

        /* renamed from: a  reason: collision with root package name */
        private int f969a = -1;

        public a() {
            a();
        }

        /* access modifiers changed from: package-private */
        public void a() {
            g x2 = c.this.f961c.x();
            if (x2 != null) {
                ArrayList B2 = c.this.f961c.B();
                int size = B2.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (((g) B2.get(i2)) == x2) {
                        this.f969a = i2;
                        return;
                    }
                }
            }
            this.f969a = -1;
        }

        /* renamed from: b */
        public g getItem(int i2) {
            ArrayList B2 = c.this.f961c.B();
            int i3 = i2 + c.this.f963e;
            int i4 = this.f969a;
            if (i4 >= 0 && i3 >= i4) {
                i3++;
            }
            return (g) B2.get(i3);
        }

        public int getCount() {
            int size = c.this.f961c.B().size() - c.this.f963e;
            return this.f969a < 0 ? size : size - 1;
        }

        public long getItemId(int i2) {
            return (long) i2;
        }

        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                c cVar = c.this;
                view = cVar.f960b.inflate(cVar.f965g, viewGroup, false);
            }
            ((k.a) view).e(getItem(i2), 0);
            return view;
        }

        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public c(int i2, int i3) {
        this.f965g = i2;
        this.f964f = i3;
    }

    public void a(e eVar, boolean z2) {
        j.a aVar = this.f966h;
        if (aVar != null) {
            aVar.a(eVar, z2);
        }
    }

    public ListAdapter b() {
        if (this.f967i == null) {
            this.f967i = new a();
        }
        return this.f967i;
    }

    public int c() {
        return this.f968j;
    }

    public boolean d() {
        return false;
    }

    public Parcelable e() {
        if (this.f962d == null) {
            return null;
        }
        Bundle bundle = new Bundle();
        o(bundle);
        return bundle;
    }

    public k f(ViewGroup viewGroup) {
        if (this.f962d == null) {
            this.f962d = (ExpandedMenuView) this.f960b.inflate(g.abc_expanded_menu_layout, viewGroup, false);
            if (this.f967i == null) {
                this.f967i = new a();
            }
            this.f962d.setAdapter(this.f967i);
            this.f962d.setOnItemClickListener(this);
        }
        return this.f962d;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x0029  */
    /* JADX WARNING: Removed duplicated region for block: B:13:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void g(android.content.Context r3, androidx.appcompat.view.menu.e r4) {
        /*
            r2 = this;
            int r0 = r2.f964f
            if (r0 == 0) goto L_0x0014
            android.view.ContextThemeWrapper r0 = new android.view.ContextThemeWrapper
            int r1 = r2.f964f
            r0.<init>(r3, r1)
            r2.f959a = r0
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r0)
        L_0x0011:
            r2.f960b = r3
            goto L_0x0023
        L_0x0014:
            android.content.Context r0 = r2.f959a
            if (r0 == 0) goto L_0x0023
            r2.f959a = r3
            android.view.LayoutInflater r0 = r2.f960b
            if (r0 != 0) goto L_0x0023
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            goto L_0x0011
        L_0x0023:
            r2.f961c = r4
            androidx.appcompat.view.menu.c$a r3 = r2.f967i
            if (r3 == 0) goto L_0x002c
            r3.notifyDataSetChanged()
        L_0x002c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.c.g(android.content.Context, androidx.appcompat.view.menu.e):void");
    }

    public void h(Parcelable parcelable) {
        k((Bundle) parcelable);
    }

    public boolean i(e eVar, g gVar) {
        return false;
    }

    public boolean j(e eVar, g gVar) {
        return false;
    }

    public void k(Bundle bundle) {
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray("android:menu:list");
        if (sparseParcelableArray != null) {
            this.f962d.restoreHierarchyState(sparseParcelableArray);
        }
    }

    public void l(j.a aVar) {
        this.f966h = aVar;
    }

    public boolean m(m mVar) {
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        new f(mVar).d((IBinder) null);
        j.a aVar = this.f966h;
        if (aVar == null) {
            return true;
        }
        aVar.b(mVar);
        return true;
    }

    public void n(boolean z2) {
        a aVar = this.f967i;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    public void o(Bundle bundle) {
        SparseArray sparseArray = new SparseArray();
        ExpandedMenuView expandedMenuView = this.f962d;
        if (expandedMenuView != null) {
            expandedMenuView.saveHierarchyState(sparseArray);
        }
        bundle.putSparseParcelableArray("android:menu:list", sparseArray);
    }

    public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        this.f961c.P(this.f967i.getItem(i2), this, 0);
    }

    public c(Context context, int i2) {
        this(i2, 0);
        this.f959a = context;
        this.f960b = LayoutInflater.from(context);
    }
}
