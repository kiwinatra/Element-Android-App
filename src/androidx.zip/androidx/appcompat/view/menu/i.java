package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.j;
import androidx.core.view.C0156s;

public class i {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1041a;

    /* renamed from: b  reason: collision with root package name */
    private final e f1042b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f1043c;

    /* renamed from: d  reason: collision with root package name */
    private final int f1044d;

    /* renamed from: e  reason: collision with root package name */
    private final int f1045e;

    /* renamed from: f  reason: collision with root package name */
    private View f1046f;

    /* renamed from: g  reason: collision with root package name */
    private int f1047g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1048h;

    /* renamed from: i  reason: collision with root package name */
    private j.a f1049i;

    /* renamed from: j  reason: collision with root package name */
    private h f1050j;

    /* renamed from: k  reason: collision with root package name */
    private PopupWindow.OnDismissListener f1051k;

    /* renamed from: l  reason: collision with root package name */
    private final PopupWindow.OnDismissListener f1052l;

    class a implements PopupWindow.OnDismissListener {
        a() {
        }

        public void onDismiss() {
            i.this.e();
        }
    }

    public i(Context context, e eVar, View view, boolean z2, int i2) {
        this(context, eVar, view, z2, i2, 0);
    }

    /* JADX WARNING: type inference failed for: r0v6, types: [androidx.appcompat.view.menu.h, androidx.appcompat.view.menu.j] */
    /* JADX WARNING: type inference failed for: r8v1, types: [androidx.appcompat.view.menu.l] */
    /* JADX WARNING: type inference failed for: r2v2, types: [androidx.appcompat.view.menu.b] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private androidx.appcompat.view.menu.h a() {
        /*
            r15 = this;
            android.content.Context r0 = r15.f1041a
            java.lang.String r1 = "window"
            java.lang.Object r0 = r0.getSystemService(r1)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            android.view.Display r0 = r0.getDefaultDisplay()
            android.graphics.Point r1 = new android.graphics.Point
            r1.<init>()
            r0.getRealSize(r1)
            int r0 = r1.x
            int r1 = r1.y
            int r0 = java.lang.Math.min(r0, r1)
            android.content.Context r1 = r15.f1041a
            android.content.res.Resources r1 = r1.getResources()
            int r2 = e.d.abc_cascading_menus_min_smallest_width
            int r1 = r1.getDimensionPixelSize(r2)
            if (r0 < r1) goto L_0x003d
            androidx.appcompat.view.menu.b r0 = new androidx.appcompat.view.menu.b
            android.content.Context r3 = r15.f1041a
            android.view.View r4 = r15.f1046f
            int r5 = r15.f1044d
            int r6 = r15.f1045e
            boolean r7 = r15.f1043c
            r2 = r0
            r2.<init>(r3, r4, r5, r6, r7)
            goto L_0x004f
        L_0x003d:
            androidx.appcompat.view.menu.l r0 = new androidx.appcompat.view.menu.l
            android.content.Context r9 = r15.f1041a
            androidx.appcompat.view.menu.e r10 = r15.f1042b
            android.view.View r11 = r15.f1046f
            int r12 = r15.f1044d
            int r13 = r15.f1045e
            boolean r14 = r15.f1043c
            r8 = r0
            r8.<init>(r9, r10, r11, r12, r13, r14)
        L_0x004f:
            androidx.appcompat.view.menu.e r1 = r15.f1042b
            r0.o(r1)
            android.widget.PopupWindow$OnDismissListener r1 = r15.f1052l
            r0.x(r1)
            android.view.View r1 = r15.f1046f
            r0.s(r1)
            androidx.appcompat.view.menu.j$a r1 = r15.f1049i
            r0.l(r1)
            boolean r1 = r15.f1048h
            r0.u(r1)
            int r1 = r15.f1047g
            r0.v(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.i.a():androidx.appcompat.view.menu.h");
    }

    private void l(int i2, int i3, boolean z2, boolean z3) {
        h c2 = c();
        c2.y(z3);
        if (z2) {
            if ((C0156s.b(this.f1047g, this.f1046f.getLayoutDirection()) & 7) == 5) {
                i2 -= this.f1046f.getWidth();
            }
            c2.w(i2);
            c2.z(i3);
            int i4 = (int) ((this.f1041a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            c2.t(new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4));
        }
        c2.f();
    }

    public void b() {
        if (d()) {
            this.f1050j.dismiss();
        }
    }

    public h c() {
        if (this.f1050j == null) {
            this.f1050j = a();
        }
        return this.f1050j;
    }

    public boolean d() {
        h hVar = this.f1050j;
        return hVar != null && hVar.b();
    }

    /* access modifiers changed from: protected */
    public void e() {
        this.f1050j = null;
        PopupWindow.OnDismissListener onDismissListener = this.f1051k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void f(View view) {
        this.f1046f = view;
    }

    public void g(boolean z2) {
        this.f1048h = z2;
        h hVar = this.f1050j;
        if (hVar != null) {
            hVar.u(z2);
        }
    }

    public void h(int i2) {
        this.f1047g = i2;
    }

    public void i(PopupWindow.OnDismissListener onDismissListener) {
        this.f1051k = onDismissListener;
    }

    public void j(j.a aVar) {
        this.f1049i = aVar;
        h hVar = this.f1050j;
        if (hVar != null) {
            hVar.l(aVar);
        }
    }

    public void k() {
        if (!m()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    public boolean m() {
        if (d()) {
            return true;
        }
        if (this.f1046f == null) {
            return false;
        }
        l(0, 0, false, false);
        return true;
    }

    public boolean n(int i2, int i3) {
        if (d()) {
            return true;
        }
        if (this.f1046f == null) {
            return false;
        }
        l(i2, i3, true, true);
        return true;
    }

    public i(Context context, e eVar, View view, boolean z2, int i2, int i3) {
        this.f1047g = 8388611;
        this.f1052l = new a();
        this.f1041a = context;
        this.f1042b = eVar;
        this.f1046f = view;
        this.f1043c = z2;
        this.f1044d = i2;
        this.f1045e = i3;
    }
}
