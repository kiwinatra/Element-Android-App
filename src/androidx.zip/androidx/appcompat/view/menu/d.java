package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.k;
import java.util.ArrayList;

public class d extends BaseAdapter {

    /* renamed from: a  reason: collision with root package name */
    e f971a;

    /* renamed from: b  reason: collision with root package name */
    private int f972b = -1;

    /* renamed from: c  reason: collision with root package name */
    private boolean f973c;

    /* renamed from: d  reason: collision with root package name */
    private final boolean f974d;

    /* renamed from: e  reason: collision with root package name */
    private final LayoutInflater f975e;

    /* renamed from: f  reason: collision with root package name */
    private final int f976f;

    public d(e eVar, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f974d = z2;
        this.f975e = layoutInflater;
        this.f971a = eVar;
        this.f976f = i2;
        a();
    }

    /* access modifiers changed from: package-private */
    public void a() {
        g x2 = this.f971a.x();
        if (x2 != null) {
            ArrayList B2 = this.f971a.B();
            int size = B2.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((g) B2.get(i2)) == x2) {
                    this.f972b = i2;
                    return;
                }
            }
        }
        this.f972b = -1;
    }

    public e b() {
        return this.f971a;
    }

    /* renamed from: c */
    public g getItem(int i2) {
        ArrayList B2 = this.f974d ? this.f971a.B() : this.f971a.G();
        int i3 = this.f972b;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (g) B2.get(i2);
    }

    public void d(boolean z2) {
        this.f973c = z2;
    }

    public int getCount() {
        ArrayList B2 = this.f974d ? this.f971a.B() : this.f971a.G();
        int i2 = this.f972b;
        int size = B2.size();
        return i2 < 0 ? size : size - 1;
    }

    public long getItemId(int i2) {
        return (long) i2;
    }

    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f975e.inflate(this.f976f, viewGroup, false);
        }
        int groupId = getItem(i2).getGroupId();
        int i3 = i2 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f971a.I() && groupId != (i3 >= 0 ? getItem(i3).getGroupId() : groupId));
        k.a aVar = (k.a) view;
        if (this.f973c) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.e(getItem(i2), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
