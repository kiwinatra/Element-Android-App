package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.k;
import androidx.core.view.C0123b;
import e.h;
import f.C0236a;
import u.C0287b;

public final class g implements C0287b {

    /* renamed from: A  reason: collision with root package name */
    private View f1008A;

    /* renamed from: B  reason: collision with root package name */
    private C0123b f1009B;

    /* renamed from: C  reason: collision with root package name */
    private MenuItem.OnActionExpandListener f1010C;

    /* renamed from: D  reason: collision with root package name */
    private boolean f1011D = false;

    /* renamed from: E  reason: collision with root package name */
    private ContextMenu.ContextMenuInfo f1012E;

    /* renamed from: a  reason: collision with root package name */
    private final int f1013a;

    /* renamed from: b  reason: collision with root package name */
    private final int f1014b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1015c;

    /* renamed from: d  reason: collision with root package name */
    private final int f1016d;

    /* renamed from: e  reason: collision with root package name */
    private CharSequence f1017e;

    /* renamed from: f  reason: collision with root package name */
    private CharSequence f1018f;

    /* renamed from: g  reason: collision with root package name */
    private Intent f1019g;

    /* renamed from: h  reason: collision with root package name */
    private char f1020h;

    /* renamed from: i  reason: collision with root package name */
    private int f1021i = 4096;

    /* renamed from: j  reason: collision with root package name */
    private char f1022j;

    /* renamed from: k  reason: collision with root package name */
    private int f1023k = 4096;

    /* renamed from: l  reason: collision with root package name */
    private Drawable f1024l;

    /* renamed from: m  reason: collision with root package name */
    private int f1025m = 0;

    /* renamed from: n  reason: collision with root package name */
    e f1026n;

    /* renamed from: o  reason: collision with root package name */
    private m f1027o;

    /* renamed from: p  reason: collision with root package name */
    private Runnable f1028p;

    /* renamed from: q  reason: collision with root package name */
    private MenuItem.OnMenuItemClickListener f1029q;

    /* renamed from: r  reason: collision with root package name */
    private CharSequence f1030r;

    /* renamed from: s  reason: collision with root package name */
    private CharSequence f1031s;

    /* renamed from: t  reason: collision with root package name */
    private ColorStateList f1032t = null;

    /* renamed from: u  reason: collision with root package name */
    private PorterDuff.Mode f1033u = null;

    /* renamed from: v  reason: collision with root package name */
    private boolean f1034v = false;

    /* renamed from: w  reason: collision with root package name */
    private boolean f1035w = false;

    /* renamed from: x  reason: collision with root package name */
    private boolean f1036x = false;

    /* renamed from: y  reason: collision with root package name */
    private int f1037y = 16;

    /* renamed from: z  reason: collision with root package name */
    private int f1038z;

    class a implements C0123b.C0035b {
        a() {
        }

        public void onActionProviderVisibilityChanged(boolean z2) {
            g gVar = g.this;
            gVar.f1026n.M(gVar);
        }
    }

    g(e eVar, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f1026n = eVar;
        this.f1013a = i3;
        this.f1014b = i2;
        this.f1015c = i4;
        this.f1016d = i5;
        this.f1017e = charSequence;
        this.f1038z = i6;
    }

    private static void d(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    private Drawable e(Drawable drawable) {
        if (drawable != null && this.f1036x && (this.f1034v || this.f1035w)) {
            drawable = androidx.core.graphics.drawable.a.r(drawable).mutate();
            if (this.f1034v) {
                androidx.core.graphics.drawable.a.o(drawable, this.f1032t);
            }
            if (this.f1035w) {
                androidx.core.graphics.drawable.a.p(drawable, this.f1033u);
            }
            this.f1036x = false;
        }
        return drawable;
    }

    /* access modifiers changed from: package-private */
    public boolean A() {
        return this.f1026n.K() && g() != 0;
    }

    public boolean B() {
        return (this.f1038z & 4) == 4;
    }

    public C0287b a(C0123b bVar) {
        C0123b bVar2 = this.f1009B;
        if (bVar2 != null) {
            bVar2.g();
        }
        this.f1008A = null;
        this.f1009B = bVar;
        this.f1026n.N(true);
        C0123b bVar3 = this.f1009B;
        if (bVar3 != null) {
            bVar3.i(new a());
        }
        return this;
    }

    public C0123b b() {
        return this.f1009B;
    }

    public void c() {
        this.f1026n.L(this);
    }

    public boolean collapseActionView() {
        if ((this.f1038z & 8) == 0) {
            return false;
        }
        if (this.f1008A == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1010C;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f1026n.f(this);
        }
        return false;
    }

    public boolean expandActionView() {
        if (!j()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1010C;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f1026n.m(this);
        }
        return false;
    }

    public int f() {
        return this.f1016d;
    }

    /* access modifiers changed from: package-private */
    public char g() {
        return this.f1026n.J() ? this.f1022j : this.f1020h;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    public View getActionView() {
        View view = this.f1008A;
        if (view != null) {
            return view;
        }
        C0123b bVar = this.f1009B;
        if (bVar == null) {
            return null;
        }
        View c2 = bVar.c(this);
        this.f1008A = c2;
        return c2;
    }

    public int getAlphabeticModifiers() {
        return this.f1023k;
    }

    public char getAlphabeticShortcut() {
        return this.f1022j;
    }

    public CharSequence getContentDescription() {
        return this.f1030r;
    }

    public int getGroupId() {
        return this.f1014b;
    }

    public Drawable getIcon() {
        Drawable drawable = this.f1024l;
        if (drawable != null) {
            return e(drawable);
        }
        if (this.f1025m == 0) {
            return null;
        }
        Drawable b2 = C0236a.b(this.f1026n.w(), this.f1025m);
        this.f1025m = 0;
        this.f1024l = b2;
        return e(b2);
    }

    public ColorStateList getIconTintList() {
        return this.f1032t;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f1033u;
    }

    public Intent getIntent() {
        return this.f1019g;
    }

    public int getItemId() {
        return this.f1013a;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f1012E;
    }

    public int getNumericModifiers() {
        return this.f1021i;
    }

    public char getNumericShortcut() {
        return this.f1020h;
    }

    public int getOrder() {
        return this.f1015c;
    }

    public SubMenu getSubMenu() {
        return this.f1027o;
    }

    public CharSequence getTitle() {
        return this.f1017e;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f1018f;
        return charSequence != null ? charSequence : this.f1017e;
    }

    public CharSequence getTooltipText() {
        return this.f1031s;
    }

    /* access modifiers changed from: package-private */
    public String h() {
        int i2;
        char g2 = g();
        if (g2 == 0) {
            return "";
        }
        Resources resources = this.f1026n.w().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f1026n.w()).hasPermanentMenuKey()) {
            sb.append(resources.getString(h.abc_prepend_shortcut_label));
        }
        int i3 = this.f1026n.J() ? this.f1023k : this.f1021i;
        d(sb, i3, 65536, resources.getString(h.abc_menu_meta_shortcut_label));
        d(sb, i3, 4096, resources.getString(h.abc_menu_ctrl_shortcut_label));
        d(sb, i3, 2, resources.getString(h.abc_menu_alt_shortcut_label));
        d(sb, i3, 1, resources.getString(h.abc_menu_shift_shortcut_label));
        d(sb, i3, 4, resources.getString(h.abc_menu_sym_shortcut_label));
        d(sb, i3, 8, resources.getString(h.abc_menu_function_shortcut_label));
        if (g2 == 8) {
            i2 = h.abc_menu_delete_shortcut_label;
        } else if (g2 == 10) {
            i2 = h.abc_menu_enter_shortcut_label;
        } else if (g2 != ' ') {
            sb.append(g2);
            return sb.toString();
        } else {
            i2 = h.abc_menu_space_shortcut_label;
        }
        sb.append(resources.getString(i2));
        return sb.toString();
    }

    public boolean hasSubMenu() {
        return this.f1027o != null;
    }

    /* access modifiers changed from: package-private */
    public CharSequence i(k.a aVar) {
        return (aVar == null || !aVar.d()) ? getTitle() : getTitleCondensed();
    }

    public boolean isActionViewExpanded() {
        return this.f1011D;
    }

    public boolean isCheckable() {
        return (this.f1037y & 1) == 1;
    }

    public boolean isChecked() {
        return (this.f1037y & 2) == 2;
    }

    public boolean isEnabled() {
        return (this.f1037y & 16) != 0;
    }

    public boolean isVisible() {
        C0123b bVar = this.f1009B;
        return (bVar == null || !bVar.f()) ? (this.f1037y & 8) == 0 : (this.f1037y & 8) == 0 && this.f1009B.b();
    }

    public boolean j() {
        C0123b bVar;
        if ((this.f1038z & 8) == 0) {
            return false;
        }
        if (this.f1008A == null && (bVar = this.f1009B) != null) {
            this.f1008A = bVar.c(this);
        }
        return this.f1008A != null;
    }

    public boolean k() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f1029q;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick(this)) {
            return true;
        }
        e eVar = this.f1026n;
        if (eVar.h(eVar, this)) {
            return true;
        }
        Runnable runnable = this.f1028p;
        if (runnable != null) {
            runnable.run();
            return true;
        }
        if (this.f1019g != null) {
            try {
                this.f1026n.w().startActivity(this.f1019g);
                return true;
            } catch (ActivityNotFoundException e2) {
                Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e2);
            }
        }
        C0123b bVar = this.f1009B;
        return bVar != null && bVar.d();
    }

    public boolean l() {
        return (this.f1037y & 32) == 32;
    }

    public boolean m() {
        return (this.f1037y & 4) != 0;
    }

    public boolean n() {
        return (this.f1038z & 1) == 1;
    }

    public boolean o() {
        return (this.f1038z & 2) == 2;
    }

    /* renamed from: p */
    public C0287b setActionView(int i2) {
        Context w2 = this.f1026n.w();
        setActionView(LayoutInflater.from(w2).inflate(i2, new LinearLayout(w2), false));
        return this;
    }

    /* renamed from: q */
    public C0287b setActionView(View view) {
        int i2;
        this.f1008A = view;
        this.f1009B = null;
        if (view != null && view.getId() == -1 && (i2 = this.f1013a) > 0) {
            view.setId(i2);
        }
        this.f1026n.L(this);
        return this;
    }

    public void r(boolean z2) {
        this.f1011D = z2;
        this.f1026n.N(false);
    }

    /* access modifiers changed from: package-private */
    public void s(boolean z2) {
        int i2 = this.f1037y;
        int i3 = (z2 ? 2 : 0) | (i2 & -3);
        this.f1037y = i3;
        if (i2 != i3) {
            this.f1026n.N(false);
        }
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    public MenuItem setAlphabeticShortcut(char c2) {
        if (this.f1022j == c2) {
            return this;
        }
        this.f1022j = Character.toLowerCase(c2);
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setCheckable(boolean z2) {
        int i2 = this.f1037y;
        boolean z3 = z2 | (i2 & true);
        this.f1037y = z3 ? 1 : 0;
        if (i2 != z3) {
            this.f1026n.N(false);
        }
        return this;
    }

    public MenuItem setChecked(boolean z2) {
        if ((this.f1037y & 4) != 0) {
            this.f1026n.Y(this);
        } else {
            s(z2);
        }
        return this;
    }

    public MenuItem setEnabled(boolean z2) {
        this.f1037y = z2 ? this.f1037y | 16 : this.f1037y & -17;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setIcon(int i2) {
        this.f1024l = null;
        this.f1025m = i2;
        this.f1036x = true;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1032t = colorStateList;
        this.f1034v = true;
        this.f1036x = true;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1033u = mode;
        this.f1035w = true;
        this.f1036x = true;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f1019g = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c2) {
        if (this.f1020h == c2) {
            return this;
        }
        this.f1020h = c2;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f1010C = onActionExpandListener;
        return this;
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f1029q = onMenuItemClickListener;
        return this;
    }

    public MenuItem setShortcut(char c2, char c3) {
        this.f1020h = c2;
        this.f1022j = Character.toLowerCase(c3);
        this.f1026n.N(false);
        return this;
    }

    public void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 == 0 || i3 == 1 || i3 == 2) {
            this.f1038z = i2;
            this.f1026n.L(this);
            return;
        }
        throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
    }

    public MenuItem setTitle(int i2) {
        return setTitle((CharSequence) this.f1026n.w().getString(i2));
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f1018f = charSequence;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setVisible(boolean z2) {
        if (y(z2)) {
            this.f1026n.M(this);
        }
        return this;
    }

    public void t(boolean z2) {
        this.f1037y = (z2 ? 4 : 0) | (this.f1037y & -5);
    }

    public String toString() {
        CharSequence charSequence = this.f1017e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public void u(boolean z2) {
        this.f1037y = z2 ? this.f1037y | 32 : this.f1037y & -33;
    }

    /* access modifiers changed from: package-private */
    public void v(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.f1012E = contextMenuInfo;
    }

    /* renamed from: w */
    public C0287b setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    public void x(m mVar) {
        this.f1027o = mVar;
        mVar.setHeaderTitle(getTitle());
    }

    /* access modifiers changed from: package-private */
    public boolean y(boolean z2) {
        int i2 = this.f1037y;
        int i3 = (z2 ? 0 : 8) | (i2 & -9);
        this.f1037y = i3;
        return i2 != i3;
    }

    public boolean z() {
        return this.f1026n.C();
    }

    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f1022j == c2 && this.f1023k == i2) {
            return this;
        }
        this.f1022j = Character.toLowerCase(c2);
        this.f1023k = KeyEvent.normalizeMetaState(i2);
        this.f1026n.N(false);
        return this;
    }

    public C0287b setContentDescription(CharSequence charSequence) {
        this.f1030r = charSequence;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f1025m = 0;
        this.f1024l = drawable;
        this.f1036x = true;
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f1020h == c2 && this.f1021i == i2) {
            return this;
        }
        this.f1020h = c2;
        this.f1021i = KeyEvent.normalizeMetaState(i2);
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f1020h = c2;
        this.f1021i = KeyEvent.normalizeMetaState(i2);
        this.f1022j = Character.toLowerCase(c3);
        this.f1023k = KeyEvent.normalizeMetaState(i3);
        this.f1026n.N(false);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f1017e = charSequence;
        this.f1026n.N(false);
        m mVar = this.f1027o;
        if (mVar != null) {
            mVar.setHeaderTitle(charSequence);
        }
        return this;
    }

    public C0287b setTooltipText(CharSequence charSequence) {
        this.f1031s = charSequence;
        this.f1026n.N(false);
        return this;
    }
}
