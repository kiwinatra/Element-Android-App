package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.V;
import e.d;
import e.g;

final class l extends h implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, j, View.OnKeyListener {

    /* renamed from: v  reason: collision with root package name */
    private static final int f1054v = g.abc_popup_menu_item_layout;

    /* renamed from: b  reason: collision with root package name */
    private final Context f1055b;

    /* renamed from: c  reason: collision with root package name */
    private final e f1056c;

    /* renamed from: d  reason: collision with root package name */
    private final d f1057d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean f1058e;

    /* renamed from: f  reason: collision with root package name */
    private final int f1059f;

    /* renamed from: g  reason: collision with root package name */
    private final int f1060g;

    /* renamed from: h  reason: collision with root package name */
    private final int f1061h;

    /* renamed from: i  reason: collision with root package name */
    final V f1062i;

    /* renamed from: j  reason: collision with root package name */
    final ViewTreeObserver.OnGlobalLayoutListener f1063j = new a();

    /* renamed from: k  reason: collision with root package name */
    private final View.OnAttachStateChangeListener f1064k = new b();

    /* renamed from: l  reason: collision with root package name */
    private PopupWindow.OnDismissListener f1065l;

    /* renamed from: m  reason: collision with root package name */
    private View f1066m;

    /* renamed from: n  reason: collision with root package name */
    View f1067n;

    /* renamed from: o  reason: collision with root package name */
    private j.a f1068o;

    /* renamed from: p  reason: collision with root package name */
    ViewTreeObserver f1069p;

    /* renamed from: q  reason: collision with root package name */
    private boolean f1070q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f1071r;

    /* renamed from: s  reason: collision with root package name */
    private int f1072s;

    /* renamed from: t  reason: collision with root package name */
    private int f1073t = 0;

    /* renamed from: u  reason: collision with root package name */
    private boolean f1074u;

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        public void onGlobalLayout() {
            if (l.this.b() && !l.this.f1062i.B()) {
                View view = l.this.f1067n;
                if (view == null || !view.isShown()) {
                    l.this.dismiss();
                } else {
                    l.this.f1062i.f();
                }
            }
        }
    }

    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = l.this.f1069p;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    l.this.f1069p = view.getViewTreeObserver();
                }
                l lVar = l.this;
                lVar.f1069p.removeGlobalOnLayoutListener(lVar.f1063j);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public l(Context context, e eVar, View view, int i2, int i3, boolean z2) {
        this.f1055b = context;
        this.f1056c = eVar;
        this.f1058e = z2;
        this.f1057d = new d(eVar, LayoutInflater.from(context), z2, f1054v);
        this.f1060g = i2;
        this.f1061h = i3;
        Resources resources = context.getResources();
        this.f1059f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(d.abc_config_prefDialogWidth));
        this.f1066m = view;
        this.f1062i = new V(context, (AttributeSet) null, i2, i3);
        eVar.c(this, context);
    }

    private boolean C() {
        View view;
        if (b()) {
            return true;
        }
        if (this.f1070q || (view = this.f1066m) == null) {
            return false;
        }
        this.f1067n = view;
        this.f1062i.K(this);
        this.f1062i.L(this);
        this.f1062i.J(true);
        View view2 = this.f1067n;
        boolean z2 = this.f1069p == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.f1069p = viewTreeObserver;
        if (z2) {
            viewTreeObserver.addOnGlobalLayoutListener(this.f1063j);
        }
        view2.addOnAttachStateChangeListener(this.f1064k);
        this.f1062i.D(view2);
        this.f1062i.G(this.f1073t);
        if (!this.f1071r) {
            this.f1072s = h.r(this.f1057d, (ViewGroup) null, this.f1055b, this.f1059f);
            this.f1071r = true;
        }
        this.f1062i.F(this.f1072s);
        this.f1062i.I(2);
        this.f1062i.H(q());
        this.f1062i.f();
        ListView k2 = this.f1062i.k();
        k2.setOnKeyListener(this);
        if (this.f1074u && this.f1056c.z() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.f1055b).inflate(g.abc_popup_menu_header_item_layout, k2, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            if (textView != null) {
                textView.setText(this.f1056c.z());
            }
            frameLayout.setEnabled(false);
            k2.addHeaderView(frameLayout, (Object) null, false);
        }
        this.f1062i.o(this.f1057d);
        this.f1062i.f();
        return true;
    }

    public void a(e eVar, boolean z2) {
        if (eVar == this.f1056c) {
            dismiss();
            j.a aVar = this.f1068o;
            if (aVar != null) {
                aVar.a(eVar, z2);
            }
        }
    }

    public boolean b() {
        return !this.f1070q && this.f1062i.b();
    }

    public boolean d() {
        return false;
    }

    public void dismiss() {
        if (b()) {
            this.f1062i.dismiss();
        }
    }

    public Parcelable e() {
        return null;
    }

    public void f() {
        if (!C()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    public void h(Parcelable parcelable) {
    }

    public ListView k() {
        return this.f1062i.k();
    }

    public void l(j.a aVar) {
        this.f1068o = aVar;
    }

    public boolean m(m mVar) {
        if (mVar.hasVisibleItems()) {
            i iVar = new i(this.f1055b, mVar, this.f1067n, this.f1058e, this.f1060g, this.f1061h);
            iVar.j(this.f1068o);
            iVar.g(h.A(mVar));
            iVar.i(this.f1065l);
            this.f1065l = null;
            this.f1056c.e(false);
            int d2 = this.f1062i.d();
            int g2 = this.f1062i.g();
            if ((Gravity.getAbsoluteGravity(this.f1073t, this.f1066m.getLayoutDirection()) & 7) == 5) {
                d2 += this.f1066m.getWidth();
            }
            if (iVar.n(d2, g2)) {
                j.a aVar = this.f1068o;
                if (aVar == null) {
                    return true;
                }
                aVar.b(mVar);
                return true;
            }
        }
        return false;
    }

    public void n(boolean z2) {
        this.f1071r = false;
        d dVar = this.f1057d;
        if (dVar != null) {
            dVar.notifyDataSetChanged();
        }
    }

    public void o(e eVar) {
    }

    public void onDismiss() {
        this.f1070q = true;
        this.f1056c.close();
        ViewTreeObserver viewTreeObserver = this.f1069p;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f1069p = this.f1067n.getViewTreeObserver();
            }
            this.f1069p.removeGlobalOnLayoutListener(this.f1063j);
            this.f1069p = null;
        }
        this.f1067n.removeOnAttachStateChangeListener(this.f1064k);
        PopupWindow.OnDismissListener onDismissListener = this.f1065l;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    public void s(View view) {
        this.f1066m = view;
    }

    public void u(boolean z2) {
        this.f1057d.d(z2);
    }

    public void v(int i2) {
        this.f1073t = i2;
    }

    public void w(int i2) {
        this.f1062i.c(i2);
    }

    public void x(PopupWindow.OnDismissListener onDismissListener) {
        this.f1065l = onDismissListener;
    }

    public void y(boolean z2) {
        this.f1074u = z2;
    }

    public void z(int i2) {
        this.f1062i.n(i2);
    }
}
