package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.widget.e0;
import e.C0233a;
import e.f;
import e.g;
import e.j;

public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a  reason: collision with root package name */
    private g f895a;

    /* renamed from: b  reason: collision with root package name */
    private ImageView f896b;

    /* renamed from: c  reason: collision with root package name */
    private RadioButton f897c;

    /* renamed from: d  reason: collision with root package name */
    private TextView f898d;

    /* renamed from: e  reason: collision with root package name */
    private CheckBox f899e;

    /* renamed from: f  reason: collision with root package name */
    private TextView f900f;

    /* renamed from: g  reason: collision with root package name */
    private ImageView f901g;

    /* renamed from: h  reason: collision with root package name */
    private ImageView f902h;

    /* renamed from: i  reason: collision with root package name */
    private LinearLayout f903i;

    /* renamed from: j  reason: collision with root package name */
    private Drawable f904j;

    /* renamed from: k  reason: collision with root package name */
    private int f905k;

    /* renamed from: l  reason: collision with root package name */
    private Context f906l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f907m;

    /* renamed from: n  reason: collision with root package name */
    private Drawable f908n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f909o;

    /* renamed from: p  reason: collision with root package name */
    private LayoutInflater f910p;

    /* renamed from: q  reason: collision with root package name */
    private boolean f911q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.listMenuViewStyle);
    }

    private void a(View view) {
        b(view, -1);
    }

    private void b(View view, int i2) {
        LinearLayout linearLayout = this.f903i;
        if (linearLayout != null) {
            linearLayout.addView(view, i2);
        } else {
            addView(view, i2);
        }
    }

    private void c() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(g.abc_list_menu_item_checkbox, this, false);
        this.f899e = checkBox;
        a(checkBox);
    }

    private void f() {
        ImageView imageView = (ImageView) getInflater().inflate(g.abc_list_menu_item_icon, this, false);
        this.f896b = imageView;
        b(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(g.abc_list_menu_item_radio, this, false);
        this.f897c = radioButton;
        a(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.f910p == null) {
            this.f910p = LayoutInflater.from(getContext());
        }
        return this.f910p;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f901g;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f902h;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f902h.getLayoutParams();
            rect.top += this.f902h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
        }
    }

    public boolean d() {
        return false;
    }

    public void e(g gVar, int i2) {
        this.f895a = gVar;
        setVisibility(gVar.isVisible() ? 0 : 8);
        setTitle(gVar.i(this));
        setCheckable(gVar.isCheckable());
        h(gVar.A(), gVar.g());
        setIcon(gVar.getIcon());
        setEnabled(gVar.isEnabled());
        setSubMenuArrowVisible(gVar.hasSubMenu());
        setContentDescription(gVar.getContentDescription());
    }

    public g getItemData() {
        return this.f895a;
    }

    public void h(boolean z2, char c2) {
        int i2 = (!z2 || !this.f895a.A()) ? 8 : 0;
        if (i2 == 0) {
            this.f900f.setText(this.f895a.h());
        }
        if (this.f900f.getVisibility() != i2) {
            this.f900f.setVisibility(i2);
        }
    }

    /* access modifiers changed from: protected */
    public void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f904j);
        TextView textView = (TextView) findViewById(f.title);
        this.f898d = textView;
        int i2 = this.f905k;
        if (i2 != -1) {
            textView.setTextAppearance(this.f906l, i2);
        }
        this.f900f = (TextView) findViewById(f.shortcut);
        ImageView imageView = (ImageView) findViewById(f.submenuarrow);
        this.f901g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f908n);
        }
        this.f902h = (ImageView) findViewById(f.group_divider);
        this.f903i = (LinearLayout) findViewById(f.content);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        if (this.f896b != null && this.f907m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f896b.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        View view;
        CompoundButton compoundButton;
        if (z2 || this.f897c != null || this.f899e != null) {
            if (this.f895a.m()) {
                if (this.f897c == null) {
                    g();
                }
                compoundButton = this.f897c;
                view = this.f899e;
            } else {
                if (this.f899e == null) {
                    c();
                }
                compoundButton = this.f899e;
                view = this.f897c;
            }
            if (z2) {
                compoundButton.setChecked(this.f895a.isChecked());
                if (compoundButton.getVisibility() != 0) {
                    compoundButton.setVisibility(0);
                }
                if (view != null && view.getVisibility() != 8) {
                    view.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.f899e;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.f897c;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if (this.f895a.m()) {
            if (this.f897c == null) {
                g();
            }
            compoundButton = this.f897c;
        } else {
            if (this.f899e == null) {
                c();
            }
            compoundButton = this.f899e;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f911q = z2;
        this.f907m = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f902h;
        if (imageView != null) {
            imageView.setVisibility((this.f909o || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z2 = this.f895a.z() || this.f911q;
        if (z2 || this.f907m) {
            ImageView imageView = this.f896b;
            if (imageView != null || drawable != null || this.f907m) {
                if (imageView == null) {
                    f();
                }
                if (drawable != null || this.f907m) {
                    ImageView imageView2 = this.f896b;
                    if (!z2) {
                        drawable = null;
                    }
                    imageView2.setImageDrawable(drawable);
                    if (this.f896b.getVisibility() != 0) {
                        this.f896b.setVisibility(0);
                        return;
                    }
                    return;
                }
                this.f896b.setVisibility(8);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i2;
        TextView textView;
        if (charSequence != null) {
            this.f898d.setText(charSequence);
            if (this.f898d.getVisibility() != 0) {
                textView = this.f898d;
                i2 = 0;
            } else {
                return;
            }
        } else {
            i2 = 8;
            if (this.f898d.getVisibility() != 8) {
                textView = this.f898d;
            } else {
                return;
            }
        }
        textView.setVisibility(i2);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        e0 v2 = e0.v(getContext(), attributeSet, j.b2, i2, 0);
        this.f904j = v2.g(j.d2);
        this.f905k = v2.n(j.c2, -1);
        this.f907m = v2.a(j.e2, false);
        this.f906l = context;
        this.f908n = v2.g(j.f2);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, C0233a.dropDownListViewStyle, 0);
        this.f909o = obtainStyledAttributes.hasValue(0);
        v2.x();
        obtainStyledAttributes.recycle();
    }
}
