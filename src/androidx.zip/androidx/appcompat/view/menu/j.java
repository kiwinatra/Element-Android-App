package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface j {

    public interface a {
        void a(e eVar, boolean z2);

        boolean b(e eVar);
    }

    void a(e eVar, boolean z2);

    int c();

    boolean d();

    Parcelable e();

    void g(Context context, e eVar);

    void h(Parcelable parcelable);

    boolean i(e eVar, g gVar);

    boolean j(e eVar, g gVar);

    void l(a aVar);

    boolean m(m mVar);

    void n(boolean z2);
}
