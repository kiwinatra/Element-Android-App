package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.U;
import androidx.appcompat.widget.V;
import androidx.core.view.C0156s;
import e.g;
import java.util.ArrayList;
import java.util.List;

final class b extends h implements j, View.OnKeyListener, PopupWindow.OnDismissListener {

    /* renamed from: B  reason: collision with root package name */
    private static final int f922B = g.abc_cascading_menu_item_layout;

    /* renamed from: A  reason: collision with root package name */
    boolean f923A;

    /* renamed from: b  reason: collision with root package name */
    private final Context f924b;

    /* renamed from: c  reason: collision with root package name */
    private final int f925c;

    /* renamed from: d  reason: collision with root package name */
    private final int f926d;

    /* renamed from: e  reason: collision with root package name */
    private final int f927e;

    /* renamed from: f  reason: collision with root package name */
    private final boolean f928f;

    /* renamed from: g  reason: collision with root package name */
    final Handler f929g;

    /* renamed from: h  reason: collision with root package name */
    private final List f930h = new ArrayList();

    /* renamed from: i  reason: collision with root package name */
    final List f931i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    final ViewTreeObserver.OnGlobalLayoutListener f932j = new a();

    /* renamed from: k  reason: collision with root package name */
    private final View.OnAttachStateChangeListener f933k = new C0017b();

    /* renamed from: l  reason: collision with root package name */
    private final U f934l = new c();

    /* renamed from: m  reason: collision with root package name */
    private int f935m = 0;

    /* renamed from: n  reason: collision with root package name */
    private int f936n = 0;

    /* renamed from: o  reason: collision with root package name */
    private View f937o;

    /* renamed from: p  reason: collision with root package name */
    View f938p;

    /* renamed from: q  reason: collision with root package name */
    private int f939q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f940r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f941s;

    /* renamed from: t  reason: collision with root package name */
    private int f942t;

    /* renamed from: u  reason: collision with root package name */
    private int f943u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f944v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f945w;

    /* renamed from: x  reason: collision with root package name */
    private j.a f946x;

    /* renamed from: y  reason: collision with root package name */
    ViewTreeObserver f947y;

    /* renamed from: z  reason: collision with root package name */
    private PopupWindow.OnDismissListener f948z;

    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        public void onGlobalLayout() {
            if (b.this.b() && b.this.f931i.size() > 0 && !((d) b.this.f931i.get(0)).f956a.B()) {
                View view = b.this.f938p;
                if (view == null || !view.isShown()) {
                    b.this.dismiss();
                    return;
                }
                for (d dVar : b.this.f931i) {
                    dVar.f956a.f();
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.view.menu.b$b  reason: collision with other inner class name */
    class C0017b implements View.OnAttachStateChangeListener {
        C0017b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = b.this.f947y;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    b.this.f947y = view.getViewTreeObserver();
                }
                b bVar = b.this;
                bVar.f947y.removeGlobalOnLayoutListener(bVar.f932j);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    class c implements U {

        class a implements Runnable {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ d f952a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ MenuItem f953b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ e f954c;

            a(d dVar, MenuItem menuItem, e eVar) {
                this.f952a = dVar;
                this.f953b = menuItem;
                this.f954c = eVar;
            }

            public void run() {
                d dVar = this.f952a;
                if (dVar != null) {
                    b.this.f923A = true;
                    dVar.f957b.e(false);
                    b.this.f923A = false;
                }
                if (this.f953b.isEnabled() && this.f953b.hasSubMenu()) {
                    this.f954c.O(this.f953b, 4);
                }
            }
        }

        c() {
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v11, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v4, resolved type: androidx.appcompat.view.menu.b$d} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void a(androidx.appcompat.view.menu.e r6, android.view.MenuItem r7) {
            /*
                r5 = this;
                androidx.appcompat.view.menu.b r0 = androidx.appcompat.view.menu.b.this
                android.os.Handler r0 = r0.f929g
                r1 = 0
                r0.removeCallbacksAndMessages(r1)
                androidx.appcompat.view.menu.b r0 = androidx.appcompat.view.menu.b.this
                java.util.List r0 = r0.f931i
                int r0 = r0.size()
                r2 = 0
            L_0x0011:
                r3 = -1
                if (r2 >= r0) goto L_0x0026
                androidx.appcompat.view.menu.b r4 = androidx.appcompat.view.menu.b.this
                java.util.List r4 = r4.f931i
                java.lang.Object r4 = r4.get(r2)
                androidx.appcompat.view.menu.b$d r4 = (androidx.appcompat.view.menu.b.d) r4
                androidx.appcompat.view.menu.e r4 = r4.f957b
                if (r6 != r4) goto L_0x0023
                goto L_0x0027
            L_0x0023:
                int r2 = r2 + 1
                goto L_0x0011
            L_0x0026:
                r2 = -1
            L_0x0027:
                if (r2 != r3) goto L_0x002a
                return
            L_0x002a:
                int r2 = r2 + 1
                androidx.appcompat.view.menu.b r0 = androidx.appcompat.view.menu.b.this
                java.util.List r0 = r0.f931i
                int r0 = r0.size()
                if (r2 >= r0) goto L_0x0041
                androidx.appcompat.view.menu.b r0 = androidx.appcompat.view.menu.b.this
                java.util.List r0 = r0.f931i
                java.lang.Object r0 = r0.get(r2)
                r1 = r0
                androidx.appcompat.view.menu.b$d r1 = (androidx.appcompat.view.menu.b.d) r1
            L_0x0041:
                androidx.appcompat.view.menu.b$c$a r0 = new androidx.appcompat.view.menu.b$c$a
                r0.<init>(r1, r7, r6)
                long r1 = android.os.SystemClock.uptimeMillis()
                r3 = 200(0xc8, double:9.9E-322)
                long r1 = r1 + r3
                androidx.appcompat.view.menu.b r7 = androidx.appcompat.view.menu.b.this
                android.os.Handler r7 = r7.f929g
                r7.postAtTime(r0, r6, r1)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.b.c.a(androidx.appcompat.view.menu.e, android.view.MenuItem):void");
        }

        public void h(e eVar, MenuItem menuItem) {
            b.this.f929g.removeCallbacksAndMessages(eVar);
        }
    }

    private static class d {

        /* renamed from: a  reason: collision with root package name */
        public final V f956a;

        /* renamed from: b  reason: collision with root package name */
        public final e f957b;

        /* renamed from: c  reason: collision with root package name */
        public final int f958c;

        public d(V v2, e eVar, int i2) {
            this.f956a = v2;
            this.f957b = eVar;
            this.f958c = i2;
        }

        public ListView a() {
            return this.f956a.k();
        }
    }

    public b(Context context, View view, int i2, int i3, boolean z2) {
        this.f924b = context;
        this.f937o = view;
        this.f926d = i2;
        this.f927e = i3;
        this.f928f = z2;
        this.f944v = false;
        this.f939q = G();
        Resources resources = context.getResources();
        this.f925c = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(e.d.abc_config_prefDialogWidth));
        this.f929g = new Handler();
    }

    private V C() {
        V v2 = new V(this.f924b, (AttributeSet) null, this.f926d, this.f927e);
        v2.U(this.f934l);
        v2.L(this);
        v2.K(this);
        v2.D(this.f937o);
        v2.G(this.f936n);
        v2.J(true);
        v2.I(2);
        return v2;
    }

    private int D(e eVar) {
        int size = this.f931i.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (eVar == ((d) this.f931i.get(i2)).f957b) {
                return i2;
            }
        }
        return -1;
    }

    private MenuItem E(e eVar, e eVar2) {
        int size = eVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = eVar.getItem(i2);
            if (item.hasSubMenu() && eVar2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    private View F(d dVar, e eVar) {
        int i2;
        d dVar2;
        int firstVisiblePosition;
        MenuItem E2 = E(dVar.f957b, eVar);
        if (E2 == null) {
            return null;
        }
        ListView a2 = dVar.a();
        ListAdapter adapter = a2.getAdapter();
        int i3 = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            i2 = headerViewListAdapter.getHeadersCount();
            dVar2 = (d) headerViewListAdapter.getWrappedAdapter();
        } else {
            dVar2 = (d) adapter;
            i2 = 0;
        }
        int count = dVar2.getCount();
        while (true) {
            if (i3 >= count) {
                i3 = -1;
                break;
            } else if (E2 == dVar2.getItem(i3)) {
                break;
            } else {
                i3++;
            }
        }
        if (i3 != -1 && (firstVisiblePosition = (i3 + i2) - a2.getFirstVisiblePosition()) >= 0 && firstVisiblePosition < a2.getChildCount()) {
            return a2.getChildAt(firstVisiblePosition);
        }
        return null;
    }

    private int G() {
        return this.f937o.getLayoutDirection() == 1 ? 0 : 1;
    }

    private int H(int i2) {
        List list = this.f931i;
        ListView a2 = ((d) list.get(list.size() - 1)).a();
        int[] iArr = new int[2];
        a2.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.f938p.getWindowVisibleDisplayFrame(rect);
        return this.f939q == 1 ? (iArr[0] + a2.getWidth()) + i2 > rect.right ? 0 : 1 : iArr[0] - i2 < 0 ? 1 : 0;
    }

    private void I(e eVar) {
        View view;
        d dVar;
        int i2;
        int i3;
        int i4;
        LayoutInflater from = LayoutInflater.from(this.f924b);
        d dVar2 = new d(eVar, from, this.f928f, f922B);
        if (!b() && this.f944v) {
            dVar2.d(true);
        } else if (b()) {
            dVar2.d(h.A(eVar));
        }
        int r2 = h.r(dVar2, (ViewGroup) null, this.f924b, this.f925c);
        V C2 = C();
        C2.o(dVar2);
        C2.F(r2);
        C2.G(this.f936n);
        if (this.f931i.size() > 0) {
            List list = this.f931i;
            dVar = (d) list.get(list.size() - 1);
            view = F(dVar, eVar);
        } else {
            dVar = null;
            view = null;
        }
        if (view != null) {
            C2.V(false);
            C2.S((Object) null);
            int H2 = H(r2);
            boolean z2 = H2 == 1;
            this.f939q = H2;
            if (Build.VERSION.SDK_INT >= 26) {
                C2.D(view);
                i3 = 0;
                i2 = 0;
            } else {
                int[] iArr = new int[2];
                this.f937o.getLocationOnScreen(iArr);
                int[] iArr2 = new int[2];
                view.getLocationOnScreen(iArr2);
                if ((this.f936n & 7) == 5) {
                    iArr[0] = iArr[0] + this.f937o.getWidth();
                    iArr2[0] = iArr2[0] + view.getWidth();
                }
                i2 = iArr2[0] - iArr[0];
                i3 = iArr2[1] - iArr[1];
            }
            if ((this.f936n & 5) != 5) {
                if (z2) {
                    r2 = view.getWidth();
                }
                i4 = i2 - r2;
                C2.c(i4);
                C2.N(true);
                C2.n(i3);
            } else if (!z2) {
                r2 = view.getWidth();
                i4 = i2 - r2;
                C2.c(i4);
                C2.N(true);
                C2.n(i3);
            }
            i4 = i2 + r2;
            C2.c(i4);
            C2.N(true);
            C2.n(i3);
        } else {
            if (this.f940r) {
                C2.c(this.f942t);
            }
            if (this.f941s) {
                C2.n(this.f943u);
            }
            C2.H(q());
        }
        this.f931i.add(new d(C2, eVar, this.f939q));
        C2.f();
        ListView k2 = C2.k();
        k2.setOnKeyListener(this);
        if (dVar == null && this.f945w && eVar.z() != null) {
            FrameLayout frameLayout = (FrameLayout) from.inflate(g.abc_popup_menu_header_item_layout, k2, false);
            frameLayout.setEnabled(false);
            ((TextView) frameLayout.findViewById(16908310)).setText(eVar.z());
            k2.addHeaderView(frameLayout, (Object) null, false);
            C2.f();
        }
    }

    public void a(e eVar, boolean z2) {
        int D2 = D(eVar);
        if (D2 >= 0) {
            int i2 = D2 + 1;
            if (i2 < this.f931i.size()) {
                ((d) this.f931i.get(i2)).f957b.e(false);
            }
            d dVar = (d) this.f931i.remove(D2);
            dVar.f957b.R(this);
            if (this.f923A) {
                dVar.f956a.T((Object) null);
                dVar.f956a.E(0);
            }
            dVar.f956a.dismiss();
            int size = this.f931i.size();
            this.f939q = size > 0 ? ((d) this.f931i.get(size - 1)).f958c : G();
            if (size == 0) {
                dismiss();
                j.a aVar = this.f946x;
                if (aVar != null) {
                    aVar.a(eVar, true);
                }
                ViewTreeObserver viewTreeObserver = this.f947y;
                if (viewTreeObserver != null) {
                    if (viewTreeObserver.isAlive()) {
                        this.f947y.removeGlobalOnLayoutListener(this.f932j);
                    }
                    this.f947y = null;
                }
                this.f938p.removeOnAttachStateChangeListener(this.f933k);
                this.f948z.onDismiss();
            } else if (z2) {
                ((d) this.f931i.get(0)).f957b.e(false);
            }
        }
    }

    public boolean b() {
        return this.f931i.size() > 0 && ((d) this.f931i.get(0)).f956a.b();
    }

    public boolean d() {
        return false;
    }

    public void dismiss() {
        int size = this.f931i.size();
        if (size > 0) {
            d[] dVarArr = (d[]) this.f931i.toArray(new d[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                d dVar = dVarArr[i2];
                if (dVar.f956a.b()) {
                    dVar.f956a.dismiss();
                }
            }
        }
    }

    public Parcelable e() {
        return null;
    }

    public void f() {
        if (!b()) {
            for (e I2 : this.f930h) {
                I(I2);
            }
            this.f930h.clear();
            View view = this.f937o;
            this.f938p = view;
            if (view != null) {
                boolean z2 = this.f947y == null;
                ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
                this.f947y = viewTreeObserver;
                if (z2) {
                    viewTreeObserver.addOnGlobalLayoutListener(this.f932j);
                }
                this.f938p.addOnAttachStateChangeListener(this.f933k);
            }
        }
    }

    public void h(Parcelable parcelable) {
    }

    public ListView k() {
        if (this.f931i.isEmpty()) {
            return null;
        }
        List list = this.f931i;
        return ((d) list.get(list.size() - 1)).a();
    }

    public void l(j.a aVar) {
        this.f946x = aVar;
    }

    public boolean m(m mVar) {
        for (d dVar : this.f931i) {
            if (mVar == dVar.f957b) {
                dVar.a().requestFocus();
                return true;
            }
        }
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        o(mVar);
        j.a aVar = this.f946x;
        if (aVar != null) {
            aVar.b(mVar);
        }
        return true;
    }

    public void n(boolean z2) {
        for (d a2 : this.f931i) {
            h.B(a2.a().getAdapter()).notifyDataSetChanged();
        }
    }

    public void o(e eVar) {
        eVar.c(this, this.f924b);
        if (b()) {
            I(eVar);
        } else {
            this.f930h.add(eVar);
        }
    }

    public void onDismiss() {
        d dVar;
        int size = this.f931i.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                dVar = null;
                break;
            }
            dVar = (d) this.f931i.get(i2);
            if (!dVar.f956a.b()) {
                break;
            }
            i2++;
        }
        if (dVar != null) {
            dVar.f957b.e(false);
        }
    }

    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    /* access modifiers changed from: protected */
    public boolean p() {
        return false;
    }

    public void s(View view) {
        if (this.f937o != view) {
            this.f937o = view;
            this.f936n = C0156s.b(this.f935m, view.getLayoutDirection());
        }
    }

    public void u(boolean z2) {
        this.f944v = z2;
    }

    public void v(int i2) {
        if (this.f935m != i2) {
            this.f935m = i2;
            this.f936n = C0156s.b(i2, this.f937o.getLayoutDirection());
        }
    }

    public void w(int i2) {
        this.f940r = true;
        this.f942t = i2;
    }

    public void x(PopupWindow.OnDismissListener onDismissListener) {
        this.f948z = onDismissListener;
    }

    public void y(boolean z2) {
        this.f945w = z2;
    }

    public void z(int i2) {
        this.f941s = true;
        this.f943u = i2;
    }
}
