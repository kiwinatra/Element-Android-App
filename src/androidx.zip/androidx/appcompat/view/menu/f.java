package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.C0090c;
import androidx.appcompat.view.menu.j;
import e.g;

class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {

    /* renamed from: a  reason: collision with root package name */
    private e f1004a;

    /* renamed from: b  reason: collision with root package name */
    private C0090c f1005b;

    /* renamed from: c  reason: collision with root package name */
    c f1006c;

    /* renamed from: d  reason: collision with root package name */
    private j.a f1007d;

    public f(e eVar) {
        this.f1004a = eVar;
    }

    public void a(e eVar, boolean z2) {
        if (z2 || eVar == this.f1004a) {
            c();
        }
        j.a aVar = this.f1007d;
        if (aVar != null) {
            aVar.a(eVar, z2);
        }
    }

    public boolean b(e eVar) {
        j.a aVar = this.f1007d;
        if (aVar != null) {
            return aVar.b(eVar);
        }
        return false;
    }

    public void c() {
        C0090c cVar = this.f1005b;
        if (cVar != null) {
            cVar.dismiss();
        }
    }

    public void d(IBinder iBinder) {
        e eVar = this.f1004a;
        C0090c.a aVar = new C0090c.a(eVar.w());
        c cVar = new c(aVar.b(), g.abc_list_menu_item_layout);
        this.f1006c = cVar;
        cVar.l(this);
        this.f1004a.b(this.f1006c);
        aVar.c(this.f1006c.b(), this);
        View A2 = eVar.A();
        if (A2 != null) {
            aVar.d(A2);
        } else {
            aVar.e(eVar.y()).h(eVar.z());
        }
        aVar.f(this);
        C0090c a2 = aVar.a();
        this.f1005b = a2;
        a2.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f1005b.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.f1005b.show();
    }

    public void onClick(DialogInterface dialogInterface, int i2) {
        this.f1004a.O((g) this.f1006c.b().getItem(i2), 0);
    }

    public void onDismiss(DialogInterface dialogInterface) {
        this.f1006c.a(this.f1004a, true);
    }

    public boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f1005b.getWindow();
                if (!(window2 == null || (decorView2 = window2.getDecorView()) == null || (keyDispatcherState2 = decorView2.getKeyDispatcherState()) == null)) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f1005b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f1004a.e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f1004a.performShortcut(i2, keyEvent, 0);
    }
}
