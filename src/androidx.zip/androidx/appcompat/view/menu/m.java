package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.e;

public class m extends e implements SubMenu {

    /* renamed from: B  reason: collision with root package name */
    private e f1077B;

    /* renamed from: C  reason: collision with root package name */
    private g f1078C;

    public m(Context context, e eVar, g gVar) {
        super(context);
        this.f1077B = eVar;
        this.f1078C = gVar;
    }

    public e F() {
        return this.f1077B.F();
    }

    public boolean I() {
        return this.f1077B.I();
    }

    public boolean J() {
        return this.f1077B.J();
    }

    public boolean K() {
        return this.f1077B.K();
    }

    public void W(e.a aVar) {
        this.f1077B.W(aVar);
    }

    public boolean f(g gVar) {
        return this.f1077B.f(gVar);
    }

    public MenuItem getItem() {
        return this.f1078C;
    }

    /* access modifiers changed from: package-private */
    public boolean h(e eVar, MenuItem menuItem) {
        return super.h(eVar, menuItem) || this.f1077B.h(eVar, menuItem);
    }

    public Menu j0() {
        return this.f1077B;
    }

    public boolean m(g gVar) {
        return this.f1077B.m(gVar);
    }

    public void setGroupDividerEnabled(boolean z2) {
        this.f1077B.setGroupDividerEnabled(z2);
    }

    public SubMenu setHeaderIcon(int i2) {
        return (SubMenu) super.Z(i2);
    }

    public SubMenu setHeaderTitle(int i2) {
        return (SubMenu) super.c0(i2);
    }

    public SubMenu setHeaderView(View view) {
        return (SubMenu) super.e0(view);
    }

    public SubMenu setIcon(int i2) {
        this.f1078C.setIcon(i2);
        return this;
    }

    public void setQwertyMode(boolean z2) {
        this.f1077B.setQwertyMode(z2);
    }

    public String v() {
        g gVar = this.f1078C;
        int itemId = gVar != null ? gVar.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        return super.v() + ":" + itemId;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        return (SubMenu) super.a0(drawable);
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        return (SubMenu) super.d0(charSequence);
    }

    public SubMenu setIcon(Drawable drawable) {
        this.f1078C.setIcon(drawable);
        return this;
    }
}
