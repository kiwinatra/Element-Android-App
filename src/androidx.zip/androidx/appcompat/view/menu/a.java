package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import java.util.ArrayList;

public abstract class a implements j {

    /* renamed from: a  reason: collision with root package name */
    protected Context f912a;

    /* renamed from: b  reason: collision with root package name */
    protected Context f913b;

    /* renamed from: c  reason: collision with root package name */
    protected e f914c;

    /* renamed from: d  reason: collision with root package name */
    protected LayoutInflater f915d;

    /* renamed from: e  reason: collision with root package name */
    protected LayoutInflater f916e;

    /* renamed from: f  reason: collision with root package name */
    private j.a f917f;

    /* renamed from: g  reason: collision with root package name */
    private int f918g;

    /* renamed from: h  reason: collision with root package name */
    private int f919h;

    /* renamed from: i  reason: collision with root package name */
    protected k f920i;

    /* renamed from: j  reason: collision with root package name */
    private int f921j;

    public a(Context context, int i2, int i3) {
        this.f912a = context;
        this.f915d = LayoutInflater.from(context);
        this.f918g = i2;
        this.f919h = i3;
    }

    public void a(e eVar, boolean z2) {
        j.a aVar = this.f917f;
        if (aVar != null) {
            aVar.a(eVar, z2);
        }
    }

    /* access modifiers changed from: protected */
    public void b(View view, int i2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.f920i).addView(view, i2);
    }

    public int c() {
        return this.f921j;
    }

    public abstract void f(g gVar, k.a aVar);

    public void g(Context context, e eVar) {
        this.f913b = context;
        this.f916e = LayoutInflater.from(context);
        this.f914c = eVar;
    }

    public boolean i(e eVar, g gVar) {
        return false;
    }

    public boolean j(e eVar, g gVar) {
        return false;
    }

    public k.a k(ViewGroup viewGroup) {
        return (k.a) this.f915d.inflate(this.f919h, viewGroup, false);
    }

    public void l(j.a aVar) {
        this.f917f = aVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000e, code lost:
        return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean m(androidx.appcompat.view.menu.m r2) {
        /*
            r1 = this;
            androidx.appcompat.view.menu.j$a r0 = r1.f917f
            if (r0 == 0) goto L_0x000e
            if (r2 == 0) goto L_0x0007
            goto L_0x0009
        L_0x0007:
            androidx.appcompat.view.menu.e r2 = r1.f914c
        L_0x0009:
            boolean r2 = r0.b(r2)
            return r2
        L_0x000e:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.a.m(androidx.appcompat.view.menu.m):boolean");
    }

    public void n(boolean z2) {
        ViewGroup viewGroup = (ViewGroup) this.f920i;
        if (viewGroup != null) {
            e eVar = this.f914c;
            int i2 = 0;
            if (eVar != null) {
                eVar.t();
                ArrayList G2 = this.f914c.G();
                int size = G2.size();
                int i3 = 0;
                for (int i4 = 0; i4 < size; i4++) {
                    g gVar = (g) G2.get(i4);
                    if (t(i3, gVar)) {
                        View childAt = viewGroup.getChildAt(i3);
                        g itemData = childAt instanceof k.a ? ((k.a) childAt).getItemData() : null;
                        View q2 = q(gVar, childAt, viewGroup);
                        if (gVar != itemData) {
                            q2.setPressed(false);
                            q2.jumpDrawablesToCurrentState();
                        }
                        if (q2 != childAt) {
                            b(q2, i3);
                        }
                        i3++;
                    }
                }
                i2 = i3;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (!o(viewGroup, i2)) {
                    i2++;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public boolean o(ViewGroup viewGroup, int i2) {
        viewGroup.removeViewAt(i2);
        return true;
    }

    public j.a p() {
        return this.f917f;
    }

    public View q(g gVar, View view, ViewGroup viewGroup) {
        k.a k2 = view instanceof k.a ? (k.a) view : k(viewGroup);
        f(gVar, k2);
        return (View) k2;
    }

    public k r(ViewGroup viewGroup) {
        if (this.f920i == null) {
            k kVar = (k) this.f915d.inflate(this.f918g, viewGroup, false);
            this.f920i = kVar;
            kVar.b(this.f914c);
            n(true);
        }
        return this.f920i;
    }

    public void s(int i2) {
        this.f921j = i2;
    }

    public abstract boolean t(int i2, g gVar);
}
