package androidx.appcompat.view.menu;

public interface k {

    public interface a {
        boolean d();

        void e(g gVar, int i2);

        g getItemData();
    }

    void b(e eVar);
}
