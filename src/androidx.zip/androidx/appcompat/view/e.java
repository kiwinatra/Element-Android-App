package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.b;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

public class e extends b implements e.a {

    /* renamed from: c  reason: collision with root package name */
    private Context f816c;

    /* renamed from: d  reason: collision with root package name */
    private ActionBarContextView f817d;

    /* renamed from: e  reason: collision with root package name */
    private b.a f818e;

    /* renamed from: f  reason: collision with root package name */
    private WeakReference f819f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f820g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f821h;

    /* renamed from: i  reason: collision with root package name */
    private androidx.appcompat.view.menu.e f822i;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z2) {
        this.f816c = context;
        this.f817d = actionBarContextView;
        this.f818e = aVar;
        androidx.appcompat.view.menu.e X2 = new androidx.appcompat.view.menu.e(actionBarContextView.getContext()).X(1);
        this.f822i = X2;
        X2.W(this);
        this.f821h = z2;
    }

    public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
        return this.f818e.b(this, menuItem);
    }

    public void b(androidx.appcompat.view.menu.e eVar) {
        k();
        this.f817d.l();
    }

    public void c() {
        if (!this.f820g) {
            this.f820g = true;
            this.f818e.d(this);
        }
    }

    public View d() {
        WeakReference weakReference = this.f819f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    public Menu e() {
        return this.f822i;
    }

    public MenuInflater f() {
        return new g(this.f817d.getContext());
    }

    public CharSequence g() {
        return this.f817d.getSubtitle();
    }

    public CharSequence i() {
        return this.f817d.getTitle();
    }

    public void k() {
        this.f818e.a(this, this.f822i);
    }

    public boolean l() {
        return this.f817d.j();
    }

    public void m(View view) {
        this.f817d.setCustomView(view);
        this.f819f = view != null ? new WeakReference(view) : null;
    }

    public void n(int i2) {
        o(this.f816c.getString(i2));
    }

    public void o(CharSequence charSequence) {
        this.f817d.setSubtitle(charSequence);
    }

    public void q(int i2) {
        r(this.f816c.getString(i2));
    }

    public void r(CharSequence charSequence) {
        this.f817d.setTitle(charSequence);
    }

    public void s(boolean z2) {
        super.s(z2);
        this.f817d.setTitleOptional(z2);
    }
}
