package androidx.appcompat.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.N;
import androidx.appcompat.widget.e0;
import androidx.core.view.C0123b;
import androidx.core.view.C0168y;
import e.j;
import i.C0247c;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import u.C0286a;

public class g extends MenuInflater {

    /* renamed from: e  reason: collision with root package name */
    static final Class[] f829e;

    /* renamed from: f  reason: collision with root package name */
    static final Class[] f830f;

    /* renamed from: a  reason: collision with root package name */
    final Object[] f831a;

    /* renamed from: b  reason: collision with root package name */
    final Object[] f832b;

    /* renamed from: c  reason: collision with root package name */
    Context f833c;

    /* renamed from: d  reason: collision with root package name */
    private Object f834d;

    private static class a implements MenuItem.OnMenuItemClickListener {

        /* renamed from: c  reason: collision with root package name */
        private static final Class[] f835c = {MenuItem.class};

        /* renamed from: a  reason: collision with root package name */
        private Object f836a;

        /* renamed from: b  reason: collision with root package name */
        private Method f837b;

        public a(Object obj, String str) {
            this.f836a = obj;
            Class<?> cls = obj.getClass();
            try {
                this.f837b = cls.getMethod(str, f835c);
            } catch (Exception e2) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e2);
                throw inflateException;
            }
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f837b.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f837b.invoke(this.f836a, new Object[]{menuItem})).booleanValue();
                }
                this.f837b.invoke(this.f836a, new Object[]{menuItem});
                return true;
            } catch (Exception e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    private class b {

        /* renamed from: A  reason: collision with root package name */
        C0123b f838A;

        /* renamed from: B  reason: collision with root package name */
        private CharSequence f839B;

        /* renamed from: C  reason: collision with root package name */
        private CharSequence f840C;

        /* renamed from: D  reason: collision with root package name */
        private ColorStateList f841D = null;

        /* renamed from: E  reason: collision with root package name */
        private PorterDuff.Mode f842E = null;

        /* renamed from: a  reason: collision with root package name */
        private Menu f844a;

        /* renamed from: b  reason: collision with root package name */
        private int f845b;

        /* renamed from: c  reason: collision with root package name */
        private int f846c;

        /* renamed from: d  reason: collision with root package name */
        private int f847d;

        /* renamed from: e  reason: collision with root package name */
        private int f848e;

        /* renamed from: f  reason: collision with root package name */
        private boolean f849f;

        /* renamed from: g  reason: collision with root package name */
        private boolean f850g;

        /* renamed from: h  reason: collision with root package name */
        private boolean f851h;

        /* renamed from: i  reason: collision with root package name */
        private int f852i;

        /* renamed from: j  reason: collision with root package name */
        private int f853j;

        /* renamed from: k  reason: collision with root package name */
        private CharSequence f854k;

        /* renamed from: l  reason: collision with root package name */
        private CharSequence f855l;

        /* renamed from: m  reason: collision with root package name */
        private int f856m;

        /* renamed from: n  reason: collision with root package name */
        private char f857n;

        /* renamed from: o  reason: collision with root package name */
        private int f858o;

        /* renamed from: p  reason: collision with root package name */
        private char f859p;

        /* renamed from: q  reason: collision with root package name */
        private int f860q;

        /* renamed from: r  reason: collision with root package name */
        private int f861r;

        /* renamed from: s  reason: collision with root package name */
        private boolean f862s;

        /* renamed from: t  reason: collision with root package name */
        private boolean f863t;

        /* renamed from: u  reason: collision with root package name */
        private boolean f864u;

        /* renamed from: v  reason: collision with root package name */
        private int f865v;

        /* renamed from: w  reason: collision with root package name */
        private int f866w;

        /* renamed from: x  reason: collision with root package name */
        private String f867x;

        /* renamed from: y  reason: collision with root package name */
        private String f868y;

        /* renamed from: z  reason: collision with root package name */
        private String f869z;

        public b(Menu menu) {
            this.f844a = menu;
            h();
        }

        private char c(String str) {
            if (str == null) {
                return 0;
            }
            return str.charAt(0);
        }

        private Object e(String str, Class[] clsArr, Object[] objArr) {
            try {
                Constructor<?> constructor = Class.forName(str, false, g.this.f833c.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return constructor.newInstance(objArr);
            } catch (Exception e2) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
                return null;
            }
        }

        private void i(MenuItem menuItem) {
            boolean z2 = false;
            menuItem.setChecked(this.f862s).setVisible(this.f863t).setEnabled(this.f864u).setCheckable(this.f861r >= 1).setTitleCondensed(this.f855l).setIcon(this.f856m);
            int i2 = this.f865v;
            if (i2 >= 0) {
                menuItem.setShowAsAction(i2);
            }
            if (this.f869z != null) {
                if (!g.this.f833c.isRestricted()) {
                    menuItem.setOnMenuItemClickListener(new a(g.this.b(), this.f869z));
                } else {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
            }
            if (this.f861r >= 2) {
                if (menuItem instanceof androidx.appcompat.view.menu.g) {
                    ((androidx.appcompat.view.menu.g) menuItem).t(true);
                } else if (menuItem instanceof C0247c) {
                    ((C0247c) menuItem).h(true);
                }
            }
            String str = this.f867x;
            if (str != null) {
                menuItem.setActionView((View) e(str, g.f829e, g.this.f831a));
                z2 = true;
            }
            int i3 = this.f866w;
            if (i3 > 0) {
                if (!z2) {
                    menuItem.setActionView(i3);
                } else {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                }
            }
            C0123b bVar = this.f838A;
            if (bVar != null) {
                C0168y.a(menuItem, bVar);
            }
            C0168y.c(menuItem, this.f839B);
            C0168y.g(menuItem, this.f840C);
            C0168y.b(menuItem, this.f857n, this.f858o);
            C0168y.f(menuItem, this.f859p, this.f860q);
            PorterDuff.Mode mode = this.f842E;
            if (mode != null) {
                C0168y.e(menuItem, mode);
            }
            ColorStateList colorStateList = this.f841D;
            if (colorStateList != null) {
                C0168y.d(menuItem, colorStateList);
            }
        }

        public void a() {
            this.f851h = true;
            i(this.f844a.add(this.f845b, this.f852i, this.f853j, this.f854k));
        }

        public SubMenu b() {
            this.f851h = true;
            SubMenu addSubMenu = this.f844a.addSubMenu(this.f845b, this.f852i, this.f853j, this.f854k);
            i(addSubMenu.getItem());
            return addSubMenu;
        }

        public boolean d() {
            return this.f851h;
        }

        public void f(AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = g.this.f833c.obtainStyledAttributes(attributeSet, j.w1);
            this.f845b = obtainStyledAttributes.getResourceId(j.y1, 0);
            this.f846c = obtainStyledAttributes.getInt(j.A1, 0);
            this.f847d = obtainStyledAttributes.getInt(j.B1, 0);
            this.f848e = obtainStyledAttributes.getInt(j.C1, 0);
            this.f849f = obtainStyledAttributes.getBoolean(j.z1, true);
            this.f850g = obtainStyledAttributes.getBoolean(j.x1, true);
            obtainStyledAttributes.recycle();
        }

        public void g(AttributeSet attributeSet) {
            e0 u2 = e0.u(g.this.f833c, attributeSet, j.D1);
            this.f852i = u2.n(j.G1, 0);
            this.f853j = (u2.k(j.J1, this.f846c) & -65536) | (u2.k(j.K1, this.f847d) & 65535);
            this.f854k = u2.p(j.L1);
            this.f855l = u2.p(j.M1);
            this.f856m = u2.n(j.E1, 0);
            this.f857n = c(u2.o(j.N1));
            this.f858o = u2.k(j.U1, 4096);
            this.f859p = c(u2.o(j.O1));
            this.f860q = u2.k(j.Y1, 4096);
            int i2 = j.P1;
            this.f861r = u2.s(i2) ? u2.a(i2, false) : this.f848e;
            this.f862s = u2.a(j.H1, false);
            this.f863t = u2.a(j.I1, this.f849f);
            this.f864u = u2.a(j.F1, this.f850g);
            this.f865v = u2.k(j.Z1, -1);
            this.f869z = u2.o(j.Q1);
            this.f866w = u2.n(j.R1, 0);
            this.f867x = u2.o(j.T1);
            String o2 = u2.o(j.S1);
            this.f868y = o2;
            boolean z2 = o2 != null;
            if (z2 && this.f866w == 0 && this.f867x == null) {
                this.f838A = (C0123b) e(o2, g.f830f, g.this.f832b);
            } else {
                if (z2) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.f838A = null;
            }
            this.f839B = u2.p(j.V1);
            this.f840C = u2.p(j.a2);
            int i3 = j.X1;
            if (u2.s(i3)) {
                this.f842E = N.d(u2.k(i3, -1), this.f842E);
            } else {
                this.f842E = null;
            }
            int i4 = j.W1;
            if (u2.s(i4)) {
                this.f841D = u2.c(i4);
            } else {
                this.f841D = null;
            }
            u2.x();
            this.f851h = false;
        }

        public void h() {
            this.f845b = 0;
            this.f846c = 0;
            this.f847d = 0;
            this.f848e = 0;
            this.f849f = true;
            this.f850g = true;
        }
    }

    static {
        Class[] clsArr = {Context.class};
        f829e = clsArr;
        f830f = clsArr;
    }

    public g(Context context) {
        super(context);
        this.f833c = context;
        Object[] objArr = {context};
        this.f831a = objArr;
        this.f832b = objArr;
    }

    private Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    private void c(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) {
        b bVar = new b(menu);
        int eventType = xmlPullParser.getEventType();
        while (true) {
            if (eventType != 2) {
                eventType = xmlPullParser.next();
                if (eventType == 1) {
                    break;
                }
            } else {
                String name = xmlPullParser.getName();
                if (name.equals("menu")) {
                    eventType = xmlPullParser.next();
                } else {
                    throw new RuntimeException("Expecting menu, got " + name);
                }
            }
        }
        String str = null;
        boolean z2 = false;
        boolean z3 = false;
        while (!z2) {
            if (eventType != 1) {
                if (eventType != 2) {
                    if (eventType == 3) {
                        String name2 = xmlPullParser.getName();
                        if (z3 && name2.equals(str)) {
                            str = null;
                            z3 = false;
                        } else if (name2.equals("group")) {
                            bVar.h();
                        } else if (name2.equals("item")) {
                            if (!bVar.d()) {
                                C0123b bVar2 = bVar.f838A;
                                if (bVar2 == null || !bVar2.a()) {
                                    bVar.a();
                                } else {
                                    bVar.b();
                                }
                            }
                        } else if (name2.equals("menu")) {
                            z2 = true;
                        }
                    }
                } else if (!z3) {
                    String name3 = xmlPullParser.getName();
                    if (name3.equals("group")) {
                        bVar.f(attributeSet);
                    } else if (name3.equals("item")) {
                        bVar.g(attributeSet);
                    } else if (name3.equals("menu")) {
                        c(xmlPullParser, attributeSet, bVar.b());
                    } else {
                        str = name3;
                        z3 = true;
                    }
                }
                eventType = xmlPullParser.next();
            } else {
                throw new RuntimeException("Unexpected end of document");
            }
        }
    }

    /* access modifiers changed from: package-private */
    public Object b() {
        if (this.f834d == null) {
            this.f834d = a(this.f833c);
        }
        return this.f834d;
    }

    public void inflate(int i2, Menu menu) {
        if (!(menu instanceof C0286a)) {
            super.inflate(i2, menu);
            return;
        }
        XmlResourceParser xmlResourceParser = null;
        boolean z2 = false;
        try {
            XmlResourceParser layout = this.f833c.getResources().getLayout(i2);
            AttributeSet asAttributeSet = Xml.asAttributeSet(layout);
            if (menu instanceof e) {
                e eVar = (e) menu;
                if (eVar.H()) {
                    eVar.i0();
                    z2 = true;
                }
            }
            c(layout, asAttributeSet, menu);
            if (z2) {
                ((e) menu).h0();
            }
            if (layout != null) {
                layout.close();
            }
        } catch (XmlPullParserException e2) {
            throw new InflateException("Error inflating menu XML", e2);
        } catch (IOException e3) {
            throw new InflateException("Error inflating menu XML", e3);
        } catch (Throwable th) {
            if (0 != 0) {
                ((e) menu).h0();
            }
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }
}
