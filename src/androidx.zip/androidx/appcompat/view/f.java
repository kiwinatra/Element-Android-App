package androidx.appcompat.view;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.b;
import i.C0247c;
import i.d;
import java.util.ArrayList;
import l.g;
import u.C0286a;
import u.C0287b;

public class f extends ActionMode {

    /* renamed from: a  reason: collision with root package name */
    final Context f823a;

    /* renamed from: b  reason: collision with root package name */
    final b f824b;

    public static class a implements b.a {

        /* renamed from: a  reason: collision with root package name */
        final ActionMode.Callback f825a;

        /* renamed from: b  reason: collision with root package name */
        final Context f826b;

        /* renamed from: c  reason: collision with root package name */
        final ArrayList f827c = new ArrayList();

        /* renamed from: d  reason: collision with root package name */
        final g f828d = new g();

        public a(Context context, ActionMode.Callback callback) {
            this.f826b = context;
            this.f825a = callback;
        }

        private Menu f(Menu menu) {
            Menu menu2 = (Menu) this.f828d.get(menu);
            if (menu2 != null) {
                return menu2;
            }
            d dVar = new d(this.f826b, (C0286a) menu);
            this.f828d.put(menu, dVar);
            return dVar;
        }

        public boolean a(b bVar, Menu menu) {
            return this.f825a.onPrepareActionMode(e(bVar), f(menu));
        }

        public boolean b(b bVar, MenuItem menuItem) {
            return this.f825a.onActionItemClicked(e(bVar), new C0247c(this.f826b, (C0287b) menuItem));
        }

        public boolean c(b bVar, Menu menu) {
            return this.f825a.onCreateActionMode(e(bVar), f(menu));
        }

        public void d(b bVar) {
            this.f825a.onDestroyActionMode(e(bVar));
        }

        public ActionMode e(b bVar) {
            int size = this.f827c.size();
            for (int i2 = 0; i2 < size; i2++) {
                f fVar = (f) this.f827c.get(i2);
                if (fVar != null && fVar.f824b == bVar) {
                    return fVar;
                }
            }
            f fVar2 = new f(this.f826b, bVar);
            this.f827c.add(fVar2);
            return fVar2;
        }
    }

    public f(Context context, b bVar) {
        this.f823a = context;
        this.f824b = bVar;
    }

    public void finish() {
        this.f824b.c();
    }

    public View getCustomView() {
        return this.f824b.d();
    }

    public Menu getMenu() {
        return new d(this.f823a, (C0286a) this.f824b.e());
    }

    public MenuInflater getMenuInflater() {
        return this.f824b.f();
    }

    public CharSequence getSubtitle() {
        return this.f824b.g();
    }

    public Object getTag() {
        return this.f824b.h();
    }

    public CharSequence getTitle() {
        return this.f824b.i();
    }

    public boolean getTitleOptionalHint() {
        return this.f824b.j();
    }

    public void invalidate() {
        this.f824b.k();
    }

    public boolean isTitleOptional() {
        return this.f824b.l();
    }

    public void setCustomView(View view) {
        this.f824b.m(view);
    }

    public void setSubtitle(int i2) {
        this.f824b.n(i2);
    }

    public void setTag(Object obj) {
        this.f824b.p(obj);
    }

    public void setTitle(int i2) {
        this.f824b.q(i2);
    }

    public void setTitleOptionalHint(boolean z2) {
        this.f824b.s(z2);
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f824b.o(charSequence);
    }

    public void setTitle(CharSequence charSequence) {
        this.f824b.r(charSequence);
    }
}
