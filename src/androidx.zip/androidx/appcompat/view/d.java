package androidx.appcompat.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.view.LayoutInflater;
import e.i;

public class d extends ContextWrapper {

    /* renamed from: f  reason: collision with root package name */
    private static Configuration f810f;

    /* renamed from: a  reason: collision with root package name */
    private int f811a;

    /* renamed from: b  reason: collision with root package name */
    private Resources.Theme f812b;

    /* renamed from: c  reason: collision with root package name */
    private LayoutInflater f813c;

    /* renamed from: d  reason: collision with root package name */
    private Configuration f814d;

    /* renamed from: e  reason: collision with root package name */
    private Resources f815e;

    public d(Context context, int i2) {
        super(context);
        this.f811a = i2;
    }

    private Resources b() {
        if (this.f815e == null) {
            Configuration configuration = this.f814d;
            this.f815e = (configuration == null || (Build.VERSION.SDK_INT >= 26 && e(configuration))) ? super.getResources() : createConfigurationContext(this.f814d).getResources();
        }
        return this.f815e;
    }

    private void d() {
        boolean z2 = this.f812b == null;
        if (z2) {
            this.f812b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f812b.setTo(theme);
            }
        }
        f(this.f812b, this.f811a, z2);
    }

    private static boolean e(Configuration configuration) {
        if (configuration == null) {
            return true;
        }
        if (f810f == null) {
            Configuration configuration2 = new Configuration();
            configuration2.fontScale = 0.0f;
            f810f = configuration2;
        }
        return configuration.equals(f810f);
    }

    public void a(Configuration configuration) {
        if (this.f815e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        } else if (this.f814d == null) {
            this.f814d = new Configuration(configuration);
        } else {
            throw new IllegalStateException("Override configuration has already been set");
        }
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public int c() {
        return this.f811a;
    }

    /* access modifiers changed from: protected */
    public void f(Resources.Theme theme, int i2, boolean z2) {
        theme.applyStyle(i2, true);
    }

    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public Resources getResources() {
        return b();
    }

    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f813c == null) {
            this.f813c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f813c;
    }

    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f812b;
        if (theme != null) {
            return theme;
        }
        if (this.f811a == 0) {
            this.f811a = i.Theme_AppCompat_Light;
        }
        d();
        return this.f812b;
    }

    public void setTheme(int i2) {
        if (this.f811a != i2) {
            this.f811a = i2;
            d();
        }
    }

    public d(Context context, Resources.Theme theme) {
        super(context);
        this.f812b = theme;
    }
}
