package androidx.appcompat.view;

public interface c {
    void c();

    void f();
}
