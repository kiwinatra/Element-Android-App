package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.W;
import e.j;

/* renamed from: androidx.appcompat.widget.e  reason: case insensitive filesystem */
class C0100e {

    /* renamed from: a  reason: collision with root package name */
    private final View f1497a;

    /* renamed from: b  reason: collision with root package name */
    private final C0106k f1498b;

    /* renamed from: c  reason: collision with root package name */
    private int f1499c = -1;

    /* renamed from: d  reason: collision with root package name */
    private c0 f1500d;

    /* renamed from: e  reason: collision with root package name */
    private c0 f1501e;

    /* renamed from: f  reason: collision with root package name */
    private c0 f1502f;

    C0100e(View view) {
        this.f1497a = view;
        this.f1498b = C0106k.b();
    }

    private boolean a(Drawable drawable) {
        if (this.f1502f == null) {
            this.f1502f = new c0();
        }
        c0 c0Var = this.f1502f;
        c0Var.a();
        ColorStateList t2 = W.t(this.f1497a);
        if (t2 != null) {
            c0Var.f1491d = true;
            c0Var.f1488a = t2;
        }
        PorterDuff.Mode u2 = W.u(this.f1497a);
        if (u2 != null) {
            c0Var.f1490c = true;
            c0Var.f1489b = u2;
        }
        if (!c0Var.f1491d && !c0Var.f1490c) {
            return false;
        }
        C0106k.i(drawable, c0Var, this.f1497a.getDrawableState());
        return true;
    }

    private boolean k() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f1500d != null : i2 == 21;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        Drawable background = this.f1497a.getBackground();
        if (background == null) {
            return;
        }
        if (!k() || !a(background)) {
            c0 c0Var = this.f1501e;
            if (c0Var != null) {
                C0106k.i(background, c0Var, this.f1497a.getDrawableState());
                return;
            }
            c0 c0Var2 = this.f1500d;
            if (c0Var2 != null) {
                C0106k.i(background, c0Var2, this.f1497a.getDrawableState());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public ColorStateList c() {
        c0 c0Var = this.f1501e;
        if (c0Var != null) {
            return c0Var.f1488a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode d() {
        c0 c0Var = this.f1501e;
        if (c0Var != null) {
            return c0Var.f1489b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public void e(AttributeSet attributeSet, int i2) {
        Context context = this.f1497a.getContext();
        int[] iArr = j.p3;
        e0 v2 = e0.v(context, attributeSet, iArr, i2, 0);
        View view = this.f1497a;
        W.o0(view, view.getContext(), iArr, attributeSet, v2.r(), i2, 0);
        try {
            int i3 = j.q3;
            if (v2.s(i3)) {
                this.f1499c = v2.n(i3, -1);
                ColorStateList f2 = this.f1498b.f(this.f1497a.getContext(), this.f1499c);
                if (f2 != null) {
                    h(f2);
                }
            }
            int i4 = j.r3;
            if (v2.s(i4)) {
                W.v0(this.f1497a, v2.c(i4));
            }
            int i5 = j.s3;
            if (v2.s(i5)) {
                W.w0(this.f1497a, N.d(v2.k(i5, -1), (PorterDuff.Mode) null));
            }
            v2.x();
        } catch (Throwable th) {
            v2.x();
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public void f(Drawable drawable) {
        this.f1499c = -1;
        h((ColorStateList) null);
        b();
    }

    /* access modifiers changed from: package-private */
    public void g(int i2) {
        this.f1499c = i2;
        C0106k kVar = this.f1498b;
        h(kVar != null ? kVar.f(this.f1497a.getContext(), i2) : null);
        b();
    }

    /* access modifiers changed from: package-private */
    public void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1500d == null) {
                this.f1500d = new c0();
            }
            c0 c0Var = this.f1500d;
            c0Var.f1488a = colorStateList;
            c0Var.f1491d = true;
        } else {
            this.f1500d = null;
        }
        b();
    }

    /* access modifiers changed from: package-private */
    public void i(ColorStateList colorStateList) {
        if (this.f1501e == null) {
            this.f1501e = new c0();
        }
        c0 c0Var = this.f1501e;
        c0Var.f1488a = colorStateList;
        c0Var.f1491d = true;
        b();
    }

    /* access modifiers changed from: package-private */
    public void j(PorterDuff.Mode mode) {
        if (this.f1501e == null) {
            this.f1501e = new c0();
        }
        c0 c0Var = this.f1501e;
        c0Var.f1489b = mode;
        c0Var.f1490c = true;
        b();
    }
}
