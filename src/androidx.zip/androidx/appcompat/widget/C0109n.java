package androidx.appcompat.widget;

import H.f;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.TextView;
import e.j;

/* renamed from: androidx.appcompat.widget.n  reason: case insensitive filesystem */
class C0109n {

    /* renamed from: a  reason: collision with root package name */
    private final TextView f1586a;

    /* renamed from: b  reason: collision with root package name */
    private final f f1587b;

    C0109n(TextView textView) {
        this.f1586a = textView;
        this.f1587b = new f(textView, false);
    }

    /* access modifiers changed from: package-private */
    public InputFilter[] a(InputFilter[] inputFilterArr) {
        return this.f1587b.a(inputFilterArr);
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void b(AttributeSet attributeSet, int i2) {
        TypedArray obtainStyledAttributes = this.f1586a.getContext().obtainStyledAttributes(attributeSet, j.f5334g0, i2, 0);
        try {
            int i3 = j.f5362u0;
            boolean z2 = true;
            if (obtainStyledAttributes.hasValue(i3)) {
                z2 = obtainStyledAttributes.getBoolean(i3, true);
            }
            obtainStyledAttributes.recycle();
            d(z2);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public void c(boolean z2) {
        this.f1587b.b(z2);
    }

    /* access modifiers changed from: package-private */
    public void d(boolean z2) {
        this.f1587b.c(z2);
    }
}
