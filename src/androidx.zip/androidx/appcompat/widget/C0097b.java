package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;

/* renamed from: androidx.appcompat.widget.b  reason: case insensitive filesystem */
class C0097b extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    final ActionBarContainer f1453a;

    /* renamed from: androidx.appcompat.widget.b$a */
    private static class a {
        public static void a(Drawable drawable, Outline outline) {
            drawable.getOutline(outline);
        }
    }

    public C0097b(ActionBarContainer actionBarContainer) {
        this.f1453a = actionBarContainer;
    }

    public void draw(Canvas canvas) {
        ActionBarContainer actionBarContainer = this.f1453a;
        if (actionBarContainer.f1115h) {
            Drawable drawable = actionBarContainer.f1114g;
            if (drawable != null) {
                drawable.draw(canvas);
                return;
            }
            return;
        }
        Drawable drawable2 = actionBarContainer.f1112e;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        ActionBarContainer actionBarContainer2 = this.f1453a;
        Drawable drawable3 = actionBarContainer2.f1113f;
        if (drawable3 != null && actionBarContainer2.f1116i) {
            drawable3.draw(canvas);
        }
    }

    public int getOpacity() {
        return 0;
    }

    public void getOutline(Outline outline) {
        Drawable drawable;
        ActionBarContainer actionBarContainer = this.f1453a;
        if (!actionBarContainer.f1115h) {
            drawable = actionBarContainer.f1112e;
            if (drawable == null) {
                return;
            }
        } else if (actionBarContainer.f1114g != null) {
            drawable = actionBarContainer.f1112e;
        } else {
            return;
        }
        a.a(drawable, outline);
    }

    public void setAlpha(int i2) {
    }

    public void setColorFilter(ColorFilter colorFilter) {
    }
}
