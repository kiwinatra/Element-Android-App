package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.C0130e0;
import androidx.core.view.C0134g0;
import androidx.core.view.W;
import e.C0233a;
import e.e;
import e.f;
import e.h;
import f.C0236a;
import i.C0245a;

public class i0 implements M {

    /* renamed from: a  reason: collision with root package name */
    Toolbar f1526a;

    /* renamed from: b  reason: collision with root package name */
    private int f1527b;

    /* renamed from: c  reason: collision with root package name */
    private View f1528c;

    /* renamed from: d  reason: collision with root package name */
    private View f1529d;

    /* renamed from: e  reason: collision with root package name */
    private Drawable f1530e;

    /* renamed from: f  reason: collision with root package name */
    private Drawable f1531f;

    /* renamed from: g  reason: collision with root package name */
    private Drawable f1532g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1533h;

    /* renamed from: i  reason: collision with root package name */
    CharSequence f1534i;

    /* renamed from: j  reason: collision with root package name */
    private CharSequence f1535j;

    /* renamed from: k  reason: collision with root package name */
    private CharSequence f1536k;

    /* renamed from: l  reason: collision with root package name */
    Window.Callback f1537l;

    /* renamed from: m  reason: collision with root package name */
    boolean f1538m;

    /* renamed from: n  reason: collision with root package name */
    private C0098c f1539n;

    /* renamed from: o  reason: collision with root package name */
    private int f1540o;

    /* renamed from: p  reason: collision with root package name */
    private int f1541p;

    /* renamed from: q  reason: collision with root package name */
    private Drawable f1542q;

    class a implements View.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        final C0245a f1543a;

        a() {
            this.f1543a = new C0245a(i0.this.f1526a.getContext(), 0, 16908332, 0, 0, i0.this.f1534i);
        }

        public void onClick(View view) {
            i0 i0Var = i0.this;
            Window.Callback callback = i0Var.f1537l;
            if (callback != null && i0Var.f1538m) {
                callback.onMenuItemSelected(0, this.f1543a);
            }
        }
    }

    class b extends C0134g0 {

        /* renamed from: a  reason: collision with root package name */
        private boolean f1545a = false;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f1546b;

        b(int i2) {
            this.f1546b = i2;
        }

        public void a(View view) {
            if (!this.f1545a) {
                i0.this.f1526a.setVisibility(this.f1546b);
            }
        }

        public void b(View view) {
            i0.this.f1526a.setVisibility(0);
        }

        public void c(View view) {
            this.f1545a = true;
        }
    }

    public i0(Toolbar toolbar, boolean z2) {
        this(toolbar, z2, h.abc_action_bar_up_description, e.abc_ic_ab_back_material);
    }

    private int A() {
        if (this.f1526a.getNavigationIcon() == null) {
            return 11;
        }
        this.f1542q = this.f1526a.getNavigationIcon();
        return 15;
    }

    private void H(CharSequence charSequence) {
        this.f1534i = charSequence;
        if ((this.f1527b & 8) != 0) {
            this.f1526a.setTitle(charSequence);
            if (this.f1533h) {
                W.t0(this.f1526a.getRootView(), charSequence);
            }
        }
    }

    private void I() {
        if ((this.f1527b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.f1536k)) {
            this.f1526a.setNavigationContentDescription(this.f1541p);
        } else {
            this.f1526a.setNavigationContentDescription(this.f1536k);
        }
    }

    private void J() {
        Toolbar toolbar;
        Drawable drawable;
        if ((this.f1527b & 4) != 0) {
            toolbar = this.f1526a;
            drawable = this.f1532g;
            if (drawable == null) {
                drawable = this.f1542q;
            }
        } else {
            toolbar = this.f1526a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void K() {
        Drawable drawable;
        int i2 = this.f1527b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f1531f) == null) {
            drawable = this.f1530e;
        }
        this.f1526a.setLogo(drawable);
    }

    public void B(View view) {
        View view2 = this.f1529d;
        if (!(view2 == null || (this.f1527b & 16) == 0)) {
            this.f1526a.removeView(view2);
        }
        this.f1529d = view;
        if (view != null && (this.f1527b & 16) != 0) {
            this.f1526a.addView(view);
        }
    }

    public void C(int i2) {
        if (i2 != this.f1541p) {
            this.f1541p = i2;
            if (TextUtils.isEmpty(this.f1526a.getNavigationContentDescription())) {
                p(this.f1541p);
            }
        }
    }

    public void D(Drawable drawable) {
        this.f1531f = drawable;
        K();
    }

    public void E(CharSequence charSequence) {
        this.f1536k = charSequence;
        I();
    }

    public void F(CharSequence charSequence) {
        this.f1535j = charSequence;
        if ((this.f1527b & 8) != 0) {
            this.f1526a.setSubtitle(charSequence);
        }
    }

    public void G(CharSequence charSequence) {
        this.f1533h = true;
        H(charSequence);
    }

    public void a(Menu menu, j.a aVar) {
        if (this.f1539n == null) {
            C0098c cVar = new C0098c(this.f1526a.getContext());
            this.f1539n = cVar;
            cVar.s(f.action_menu_presenter);
        }
        this.f1539n.l(aVar);
        this.f1526a.M((androidx.appcompat.view.menu.e) menu, this.f1539n);
    }

    public boolean b() {
        return this.f1526a.C();
    }

    public boolean c() {
        return this.f1526a.D();
    }

    public void collapseActionView() {
        this.f1526a.e();
    }

    public boolean d() {
        return this.f1526a.y();
    }

    public boolean e() {
        return this.f1526a.S();
    }

    public void f() {
        this.f1538m = true;
    }

    public boolean g() {
        return this.f1526a.d();
    }

    public CharSequence getTitle() {
        return this.f1526a.getTitle();
    }

    public void h() {
        this.f1526a.g();
    }

    public void i(j.a aVar, e.a aVar2) {
        this.f1526a.N(aVar, aVar2);
    }

    public int j() {
        return this.f1527b;
    }

    public void k(int i2) {
        this.f1526a.setVisibility(i2);
    }

    public Menu l() {
        return this.f1526a.getMenu();
    }

    public void m(int i2) {
        D(i2 != 0 ? C0236a.b(r(), i2) : null);
    }

    public void n(Z z2) {
        Toolbar toolbar;
        View view = this.f1528c;
        if (view != null && view.getParent() == (toolbar = this.f1526a)) {
            toolbar.removeView(this.f1528c);
        }
        this.f1528c = z2;
    }

    public ViewGroup o() {
        return this.f1526a;
    }

    public void p(int i2) {
        E(i2 == 0 ? null : r().getString(i2));
    }

    public void q(boolean z2) {
    }

    public Context r() {
        return this.f1526a.getContext();
    }

    public int s() {
        return this.f1540o;
    }

    public void setIcon(int i2) {
        setIcon(i2 != 0 ? C0236a.b(r(), i2) : null);
    }

    public void setWindowCallback(Window.Callback callback) {
        this.f1537l = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        if (!this.f1533h) {
            H(charSequence);
        }
    }

    public C0130e0 t(int i2, long j2) {
        return W.e(this.f1526a).b(i2 == 0 ? 1.0f : 0.0f).f(j2).h(new b(i2));
    }

    public void u() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public boolean v() {
        return this.f1526a.x();
    }

    public void w() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    public void x(Drawable drawable) {
        this.f1532g = drawable;
        J();
    }

    public void y(boolean z2) {
        this.f1526a.setCollapsible(z2);
    }

    public void z(int i2) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i3 = this.f1527b ^ i2;
        this.f1527b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    I();
                }
                J();
            }
            if ((i3 & 3) != 0) {
                K();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f1526a.setTitle(this.f1534i);
                    toolbar = this.f1526a;
                    charSequence = this.f1535j;
                } else {
                    charSequence = null;
                    this.f1526a.setTitle((CharSequence) null);
                    toolbar = this.f1526a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i3 & 16) != 0 && (view = this.f1529d) != null) {
                if ((i2 & 16) != 0) {
                    this.f1526a.addView(view);
                } else {
                    this.f1526a.removeView(view);
                }
            }
        }
    }

    public i0(Toolbar toolbar, boolean z2, int i2, int i3) {
        Drawable drawable;
        this.f1540o = 0;
        this.f1541p = 0;
        this.f1526a = toolbar;
        this.f1534i = toolbar.getTitle();
        this.f1535j = toolbar.getSubtitle();
        this.f1533h = this.f1534i != null;
        this.f1532g = toolbar.getNavigationIcon();
        e0 v2 = e0.v(toolbar.getContext(), (AttributeSet) null, e.j.f5321a, C0233a.actionBarStyle, 0);
        this.f1542q = v2.g(e.j.f5343l);
        if (z2) {
            CharSequence p2 = v2.p(e.j.f5355r);
            if (!TextUtils.isEmpty(p2)) {
                G(p2);
            }
            CharSequence p3 = v2.p(e.j.f5351p);
            if (!TextUtils.isEmpty(p3)) {
                F(p3);
            }
            Drawable g2 = v2.g(e.j.f5347n);
            if (g2 != null) {
                D(g2);
            }
            Drawable g3 = v2.g(e.j.f5345m);
            if (g3 != null) {
                setIcon(g3);
            }
            if (this.f1532g == null && (drawable = this.f1542q) != null) {
                x(drawable);
            }
            z(v2.k(e.j.f5335h, 0));
            int n2 = v2.n(e.j.f5333g, 0);
            if (n2 != 0) {
                B(LayoutInflater.from(this.f1526a.getContext()).inflate(n2, this.f1526a, false));
                z(this.f1527b | 16);
            }
            int m2 = v2.m(e.j.f5339j, 0);
            if (m2 > 0) {
                ViewGroup.LayoutParams layoutParams = this.f1526a.getLayoutParams();
                layoutParams.height = m2;
                this.f1526a.setLayoutParams(layoutParams);
            }
            int e2 = v2.e(e.j.f5331f, -1);
            int e3 = v2.e(e.j.f5329e, -1);
            if (e2 >= 0 || e3 >= 0) {
                this.f1526a.L(Math.max(e2, 0), Math.max(e3, 0));
            }
            int n3 = v2.n(e.j.f5357s, 0);
            if (n3 != 0) {
                Toolbar toolbar2 = this.f1526a;
                toolbar2.P(toolbar2.getContext(), n3);
            }
            int n4 = v2.n(e.j.f5353q, 0);
            if (n4 != 0) {
                Toolbar toolbar3 = this.f1526a;
                toolbar3.O(toolbar3.getContext(), n4);
            }
            int n5 = v2.n(e.j.f5349o, 0);
            if (n5 != 0) {
                this.f1526a.setPopupTheme(n5);
            }
        } else {
            this.f1527b = A();
        }
        v2.x();
        C(i2);
        this.f1536k = this.f1526a.getNavigationContentDescription();
        this.f1526a.setNavigationOnClickListener(new a());
    }

    public void setIcon(Drawable drawable) {
        this.f1530e = drawable;
        K();
    }
}
