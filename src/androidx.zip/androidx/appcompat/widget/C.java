package androidx.appcompat.widget;

import android.widget.ThemedSpinnerAdapter;

public abstract /* synthetic */ class C {
    public static /* bridge */ /* synthetic */ ThemedSpinnerAdapter a(Object obj) {
        return (ThemedSpinnerAdapter) obj;
    }
}
