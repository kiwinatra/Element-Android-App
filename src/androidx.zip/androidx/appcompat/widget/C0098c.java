package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.ActionMenuView;
import androidx.core.view.C0123b;
import e.C0233a;
import java.util.ArrayList;

/* renamed from: androidx.appcompat.widget.c  reason: case insensitive filesystem */
class C0098c extends androidx.appcompat.view.menu.a implements C0123b.a {

    /* renamed from: A  reason: collision with root package name */
    C0019c f1458A;

    /* renamed from: B  reason: collision with root package name */
    private b f1459B;

    /* renamed from: C  reason: collision with root package name */
    final f f1460C = new f();

    /* renamed from: D  reason: collision with root package name */
    int f1461D;

    /* renamed from: k  reason: collision with root package name */
    d f1462k;

    /* renamed from: l  reason: collision with root package name */
    private Drawable f1463l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f1464m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f1465n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f1466o;

    /* renamed from: p  reason: collision with root package name */
    private int f1467p;

    /* renamed from: q  reason: collision with root package name */
    private int f1468q;

    /* renamed from: r  reason: collision with root package name */
    private int f1469r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f1470s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f1471t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f1472u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f1473v;

    /* renamed from: w  reason: collision with root package name */
    private int f1474w;

    /* renamed from: x  reason: collision with root package name */
    private final SparseBooleanArray f1475x = new SparseBooleanArray();

    /* renamed from: y  reason: collision with root package name */
    e f1476y;

    /* renamed from: z  reason: collision with root package name */
    a f1477z;

    /* renamed from: androidx.appcompat.widget.c$a */
    private class a extends i {
        public a(Context context, m mVar, View view) {
            super(context, mVar, view, false, C0233a.actionOverflowMenuStyle);
            if (!((androidx.appcompat.view.menu.g) mVar.getItem()).l()) {
                View view2 = C0098c.this.f1462k;
                f(view2 == null ? (View) C0098c.this.f920i : view2);
            }
            j(C0098c.this.f1460C);
        }

        /* access modifiers changed from: protected */
        public void e() {
            C0098c cVar = C0098c.this;
            cVar.f1477z = null;
            cVar.f1461D = 0;
            super.e();
        }
    }

    /* renamed from: androidx.appcompat.widget.c$b */
    private class b extends ActionMenuItemView.b {
        b() {
        }

        public i.e a() {
            a aVar = C0098c.this.f1477z;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }

    /* renamed from: androidx.appcompat.widget.c$c  reason: collision with other inner class name */
    private class C0019c implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        private e f1480a;

        public C0019c(e eVar) {
            this.f1480a = eVar;
        }

        public void run() {
            if (C0098c.this.f914c != null) {
                C0098c.this.f914c.d();
            }
            View view = (View) C0098c.this.f920i;
            if (!(view == null || view.getWindowToken() == null || !this.f1480a.m())) {
                C0098c.this.f1476y = this.f1480a;
            }
            C0098c.this.f1458A = null;
        }
    }

    /* renamed from: androidx.appcompat.widget.c$d */
    private class d extends r implements ActionMenuView.a {

        /* renamed from: androidx.appcompat.widget.c$d$a */
        class a extends Q {

            /* renamed from: j  reason: collision with root package name */
            final /* synthetic */ C0098c f1483j;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(View view, C0098c cVar) {
                super(view);
                this.f1483j = cVar;
            }

            public i.e b() {
                e eVar = C0098c.this.f1476y;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            public boolean c() {
                C0098c.this.N();
                return true;
            }

            public boolean d() {
                C0098c cVar = C0098c.this;
                if (cVar.f1458A != null) {
                    return false;
                }
                cVar.E();
                return true;
            }
        }

        public d(Context context) {
            super(context, (AttributeSet) null, C0233a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            j0.a(this, getContentDescription());
            setOnTouchListener(new a(this, C0098c.this));
        }

        public boolean a() {
            return false;
        }

        public boolean b() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0098c.this.N();
            return true;
        }

        /* access modifiers changed from: protected */
        public boolean setFrame(int i2, int i3, int i4, int i5) {
            boolean frame = super.setFrame(i2, i3, i4, i5);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                androidx.core.graphics.drawable.a.l(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: androidx.appcompat.widget.c$e */
    private class e extends i {
        public e(Context context, androidx.appcompat.view.menu.e eVar, View view, boolean z2) {
            super(context, eVar, view, z2, C0233a.actionOverflowMenuStyle);
            h(8388613);
            j(C0098c.this.f1460C);
        }

        /* access modifiers changed from: protected */
        public void e() {
            if (C0098c.this.f914c != null) {
                C0098c.this.f914c.close();
            }
            C0098c.this.f1476y = null;
            super.e();
        }
    }

    /* renamed from: androidx.appcompat.widget.c$f */
    private class f implements j.a {
        f() {
        }

        public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
            if (eVar instanceof m) {
                eVar.F().e(false);
            }
            j.a p2 = C0098c.this.p();
            if (p2 != null) {
                p2.a(eVar, z2);
            }
        }

        public boolean b(androidx.appcompat.view.menu.e eVar) {
            if (eVar == C0098c.this.f914c) {
                return false;
            }
            C0098c.this.f1461D = ((m) eVar).getItem().getItemId();
            j.a p2 = C0098c.this.p();
            if (p2 != null) {
                return p2.b(eVar);
            }
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.c$g */
    private static class g implements Parcelable {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: a  reason: collision with root package name */
        public int f1487a;

        /* renamed from: androidx.appcompat.widget.c$g$a */
        class a implements Parcelable.Creator {
            a() {
            }

            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel);
            }

            /* renamed from: b */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        g() {
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f1487a);
        }

        g(Parcel parcel) {
            this.f1487a = parcel.readInt();
        }
    }

    public C0098c(Context context) {
        super(context, e.g.abc_action_menu_layout, e.g.abc_action_menu_item_layout);
    }

    private View C(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.f920i;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if ((childAt instanceof k.a) && ((k.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public boolean B() {
        return E() | F();
    }

    public Drawable D() {
        d dVar = this.f1462k;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.f1464m) {
            return this.f1463l;
        }
        return null;
    }

    public boolean E() {
        k kVar;
        C0019c cVar = this.f1458A;
        if (cVar == null || (kVar = this.f920i) == null) {
            e eVar = this.f1476y;
            if (eVar == null) {
                return false;
            }
            eVar.b();
            return true;
        }
        ((View) kVar).removeCallbacks(cVar);
        this.f1458A = null;
        return true;
    }

    public boolean F() {
        a aVar = this.f1477z;
        if (aVar == null) {
            return false;
        }
        aVar.b();
        return true;
    }

    public boolean G() {
        return this.f1458A != null || H();
    }

    public boolean H() {
        e eVar = this.f1476y;
        return eVar != null && eVar.d();
    }

    public void I(Configuration configuration) {
        if (!this.f1470s) {
            this.f1469r = androidx.appcompat.view.a.b(this.f913b).d();
        }
        androidx.appcompat.view.menu.e eVar = this.f914c;
        if (eVar != null) {
            eVar.N(true);
        }
    }

    public void J(boolean z2) {
        this.f1473v = z2;
    }

    public void K(ActionMenuView actionMenuView) {
        this.f920i = actionMenuView;
        actionMenuView.b(this.f914c);
    }

    public void L(Drawable drawable) {
        d dVar = this.f1462k;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        this.f1464m = true;
        this.f1463l = drawable;
    }

    public void M(boolean z2) {
        this.f1465n = z2;
        this.f1466o = true;
    }

    public boolean N() {
        androidx.appcompat.view.menu.e eVar;
        if (!this.f1465n || H() || (eVar = this.f914c) == null || this.f920i == null || this.f1458A != null || eVar.B().isEmpty()) {
            return false;
        }
        C0019c cVar = new C0019c(new e(this.f913b, this.f914c, this.f1462k, true));
        this.f1458A = cVar;
        ((View) this.f920i).post(cVar);
        return true;
    }

    public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
        B();
        super.a(eVar, z2);
    }

    public boolean d() {
        int i2;
        ArrayList arrayList;
        int i3;
        int i4;
        int i5;
        C0098c cVar = this;
        androidx.appcompat.view.menu.e eVar = cVar.f914c;
        View view = null;
        int i6 = 0;
        if (eVar != null) {
            arrayList = eVar.G();
            i2 = arrayList.size();
        } else {
            arrayList = null;
            i2 = 0;
        }
        int i7 = cVar.f1469r;
        int i8 = cVar.f1468q;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) cVar.f920i;
        boolean z2 = false;
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < i2; i11++) {
            androidx.appcompat.view.menu.g gVar = (androidx.appcompat.view.menu.g) arrayList.get(i11);
            if (gVar.o()) {
                i9++;
            } else if (gVar.n()) {
                i10++;
            } else {
                z2 = true;
            }
            if (cVar.f1473v && gVar.isActionViewExpanded()) {
                i7 = 0;
            }
        }
        if (cVar.f1465n && (z2 || i10 + i9 > i7)) {
            i7--;
        }
        int i12 = i7 - i9;
        SparseBooleanArray sparseBooleanArray = cVar.f1475x;
        sparseBooleanArray.clear();
        if (cVar.f1471t) {
            int i13 = cVar.f1474w;
            i3 = i8 / i13;
            i4 = i13 + ((i8 % i13) / i3);
        } else {
            i4 = 0;
            i3 = 0;
        }
        int i14 = 0;
        int i15 = 0;
        while (i14 < i2) {
            androidx.appcompat.view.menu.g gVar2 = (androidx.appcompat.view.menu.g) arrayList.get(i14);
            if (gVar2.o()) {
                View q2 = cVar.q(gVar2, view, viewGroup);
                if (cVar.f1471t) {
                    i3 -= ActionMenuView.L(q2, i4, i3, makeMeasureSpec, i6);
                } else {
                    q2.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = q2.getMeasuredWidth();
                i8 -= measuredWidth;
                if (i15 == 0) {
                    i15 = measuredWidth;
                }
                int groupId = gVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                gVar2.u(true);
                i5 = i2;
            } else if (gVar2.n()) {
                int groupId2 = gVar2.getGroupId();
                boolean z3 = sparseBooleanArray.get(groupId2);
                boolean z4 = (i12 > 0 || z3) && i8 > 0 && (!cVar.f1471t || i3 > 0);
                boolean z5 = z4;
                i5 = i2;
                if (z4) {
                    View q3 = cVar.q(gVar2, (View) null, viewGroup);
                    if (cVar.f1471t) {
                        int L2 = ActionMenuView.L(q3, i4, i3, makeMeasureSpec, 0);
                        i3 -= L2;
                        if (L2 == 0) {
                            z5 = false;
                        }
                    } else {
                        q3.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    boolean z6 = z5;
                    int measuredWidth2 = q3.getMeasuredWidth();
                    i8 -= measuredWidth2;
                    if (i15 == 0) {
                        i15 = measuredWidth2;
                    }
                    z4 = z6 & (!cVar.f1471t ? i8 + i15 > 0 : i8 >= 0);
                }
                if (z4 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z3) {
                    sparseBooleanArray.put(groupId2, false);
                    int i16 = 0;
                    while (i16 < i14) {
                        androidx.appcompat.view.menu.g gVar3 = (androidx.appcompat.view.menu.g) arrayList.get(i16);
                        if (gVar3.getGroupId() == groupId2) {
                            if (gVar3.l()) {
                                i12++;
                            }
                            gVar3.u(false);
                        }
                        i16++;
                    }
                }
                if (z4) {
                    i12--;
                }
                gVar2.u(z4);
            } else {
                i5 = i2;
                gVar2.u(false);
                i14++;
                view = null;
                cVar = this;
                i2 = i5;
                i6 = 0;
            }
            i14++;
            view = null;
            cVar = this;
            i2 = i5;
            i6 = 0;
        }
        return true;
    }

    public Parcelable e() {
        g gVar = new g();
        gVar.f1487a = this.f1461D;
        return gVar;
    }

    public void f(androidx.appcompat.view.menu.g gVar, k.a aVar) {
        aVar.e(gVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.f920i);
        if (this.f1459B == null) {
            this.f1459B = new b();
        }
        actionMenuItemView.setPopupCallback(this.f1459B);
    }

    public void g(Context context, androidx.appcompat.view.menu.e eVar) {
        super.g(context, eVar);
        Resources resources = context.getResources();
        androidx.appcompat.view.a b2 = androidx.appcompat.view.a.b(context);
        if (!this.f1466o) {
            this.f1465n = b2.f();
        }
        if (!this.f1472u) {
            this.f1467p = b2.c();
        }
        if (!this.f1470s) {
            this.f1469r = b2.d();
        }
        int i2 = this.f1467p;
        if (this.f1465n) {
            if (this.f1462k == null) {
                d dVar = new d(this.f912a);
                this.f1462k = dVar;
                if (this.f1464m) {
                    dVar.setImageDrawable(this.f1463l);
                    this.f1463l = null;
                    this.f1464m = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1462k.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i2 -= this.f1462k.getMeasuredWidth();
        } else {
            this.f1462k = null;
        }
        this.f1468q = i2;
        this.f1474w = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    public void h(Parcelable parcelable) {
        int i2;
        MenuItem findItem;
        if ((parcelable instanceof g) && (i2 = ((g) parcelable).f1487a) > 0 && (findItem = this.f914c.findItem(i2)) != null) {
            m((m) findItem.getSubMenu());
        }
    }

    public boolean m(m mVar) {
        boolean z2 = false;
        if (!mVar.hasVisibleItems()) {
            return false;
        }
        m mVar2 = mVar;
        while (mVar2.j0() != this.f914c) {
            mVar2 = (m) mVar2.j0();
        }
        View C2 = C(mVar2.getItem());
        if (C2 == null) {
            return false;
        }
        this.f1461D = mVar.getItem().getItemId();
        int size = mVar.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            MenuItem item = mVar.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z2 = true;
                break;
            }
            i2++;
        }
        a aVar = new a(this.f913b, mVar, C2);
        this.f1477z = aVar;
        aVar.g(z2);
        this.f1477z.k();
        super.m(mVar);
        return true;
    }

    public void n(boolean z2) {
        k kVar;
        super.n(z2);
        ((View) this.f920i).requestLayout();
        androidx.appcompat.view.menu.e eVar = this.f914c;
        boolean z3 = false;
        if (eVar != null) {
            ArrayList u2 = eVar.u();
            int size = u2.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0123b b2 = ((androidx.appcompat.view.menu.g) u2.get(i2)).b();
                if (b2 != null) {
                    b2.h(this);
                }
            }
        }
        androidx.appcompat.view.menu.e eVar2 = this.f914c;
        ArrayList B2 = eVar2 != null ? eVar2.B() : null;
        if (this.f1465n && B2 != null) {
            int size2 = B2.size();
            if (size2 == 1) {
                z3 = !((androidx.appcompat.view.menu.g) B2.get(0)).isActionViewExpanded();
            } else if (size2 > 0) {
                z3 = true;
            }
        }
        d dVar = this.f1462k;
        if (z3) {
            if (dVar == null) {
                this.f1462k = new d(this.f912a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f1462k.getParent();
            if (viewGroup != this.f920i) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f1462k);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f920i;
                actionMenuView.addView(this.f1462k, actionMenuView.F());
            }
        } else if (dVar != null && dVar.getParent() == (kVar = this.f920i)) {
            ((ViewGroup) kVar).removeView(this.f1462k);
        }
        ((ActionMenuView) this.f920i).setOverflowReserved(this.f1465n);
    }

    public boolean o(ViewGroup viewGroup, int i2) {
        if (viewGroup.getChildAt(i2) == this.f1462k) {
            return false;
        }
        return super.o(viewGroup, i2);
    }

    public View q(androidx.appcompat.view.menu.g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.j()) {
            actionView = super.q(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.o(layoutParams));
        }
        return actionView;
    }

    public k r(ViewGroup viewGroup) {
        k kVar = this.f920i;
        k r2 = super.r(viewGroup);
        if (kVar != r2) {
            ((ActionMenuView) r2).setPresenter(this);
        }
        return r2;
    }

    public boolean t(int i2, androidx.appcompat.view.menu.g gVar) {
        return gVar.l();
    }
}
