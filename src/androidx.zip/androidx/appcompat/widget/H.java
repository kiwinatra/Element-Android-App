package androidx.appcompat.widget;

public abstract /* synthetic */ class H {
}
