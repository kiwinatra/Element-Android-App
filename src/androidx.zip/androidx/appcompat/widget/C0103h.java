package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import androidx.core.widget.j;
import androidx.core.widget.n;
import e.C0233a;
import f.C0236a;

/* renamed from: androidx.appcompat.widget.h  reason: case insensitive filesystem */
public class C0103h extends CheckedTextView implements n {

    /* renamed from: a  reason: collision with root package name */
    private final C0104i f1515a;

    /* renamed from: b  reason: collision with root package name */
    private final C0100e f1516b;

    /* renamed from: c  reason: collision with root package name */
    private final E f1517c;

    /* renamed from: d  reason: collision with root package name */
    private C0109n f1518d;

    public C0103h(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.checkedTextViewStyle);
    }

    private C0109n getEmojiTextViewHelper() {
        if (this.f1518d == null) {
            this.f1518d = new C0109n(this);
        }
        return this.f1518d;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        E e2 = this.f1517c;
        if (e2 != null) {
            e2.b();
        }
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            eVar.b();
        }
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            iVar.a();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return j.q(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            return iVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            return iVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1517c.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1517c.k();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return C0110o.a(super.onCreateInputConnection(editorInfo), editorInfo, this);
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCheckMarkDrawable(int i2) {
        setCheckMarkDrawable(C0236a.b(getContext(), i2));
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1517c;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1517c;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(j.r(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1516b;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            iVar.f(colorStateList);
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            iVar.g(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1517c.w(colorStateList);
        this.f1517c.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1517c.x(mode);
        this.f1517c.b();
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        E e2 = this.f1517c;
        if (e2 != null) {
            e2.q(context, i2);
        }
    }

    public C0103h(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        a0.a(this, getContext());
        E e2 = new E(this);
        this.f1517c = e2;
        e2.m(attributeSet, i2);
        e2.b();
        C0100e eVar = new C0100e(this);
        this.f1516b = eVar;
        eVar.e(attributeSet, i2);
        C0104i iVar = new C0104i(this);
        this.f1515a = iVar;
        iVar.d(attributeSet, i2);
        getEmojiTextViewHelper().b(attributeSet, i2);
    }

    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        C0104i iVar = this.f1515a;
        if (iVar != null) {
            iVar.e();
        }
    }
}
