package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;
import androidx.core.widget.n;

public class K extends ToggleButton implements n {

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1249a;

    /* renamed from: b  reason: collision with root package name */
    private final E f1250b;

    /* renamed from: c  reason: collision with root package name */
    private C0109n f1251c;

    public K(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842827);
    }

    private C0109n getEmojiTextViewHelper() {
        if (this.f1251c == null) {
            this.f1251c = new C0109n(this);
        }
        return this.f1251c;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1250b;
        if (e2 != null) {
            e2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1250b.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1250b.k();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1250b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1250b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1249a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1250b.w(colorStateList);
        this.f1250b.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1250b.x(mode);
        this.f1250b.b();
    }

    public K(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        a0.a(this, getContext());
        C0100e eVar = new C0100e(this);
        this.f1249a = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1250b = e2;
        e2.m(attributeSet, i2);
        getEmojiTextViewHelper().b(attributeSet, i2);
    }
}
