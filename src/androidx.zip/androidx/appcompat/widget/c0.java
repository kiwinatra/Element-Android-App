package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public class c0 {

    /* renamed from: a  reason: collision with root package name */
    public ColorStateList f1488a;

    /* renamed from: b  reason: collision with root package name */
    public PorterDuff.Mode f1489b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f1490c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f1491d;

    /* access modifiers changed from: package-private */
    public void a() {
        this.f1488a = null;
        this.f1491d = false;
        this.f1489b = null;
        this.f1490c = false;
    }
}
