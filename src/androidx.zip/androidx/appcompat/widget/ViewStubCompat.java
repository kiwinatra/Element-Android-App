package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import e.j;
import java.lang.ref.WeakReference;

public final class ViewStubCompat extends View {

    /* renamed from: a  reason: collision with root package name */
    private int f1409a;

    /* renamed from: b  reason: collision with root package name */
    private int f1410b;

    /* renamed from: c  reason: collision with root package name */
    private WeakReference f1411c;

    /* renamed from: d  reason: collision with root package name */
    private LayoutInflater f1412d;

    public interface a {
    }

    public ViewStubCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public View a() {
        ViewParent parent = getParent();
        if (!(parent instanceof ViewGroup)) {
            throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
        } else if (this.f1409a != 0) {
            ViewGroup viewGroup = (ViewGroup) parent;
            LayoutInflater layoutInflater = this.f1412d;
            if (layoutInflater == null) {
                layoutInflater = LayoutInflater.from(getContext());
            }
            View inflate = layoutInflater.inflate(this.f1409a, viewGroup, false);
            int i2 = this.f1410b;
            if (i2 != -1) {
                inflate.setId(i2);
            }
            int indexOfChild = viewGroup.indexOfChild(this);
            viewGroup.removeViewInLayout(this);
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams != null) {
                viewGroup.addView(inflate, indexOfChild, layoutParams);
            } else {
                viewGroup.addView(inflate, indexOfChild);
            }
            this.f1411c = new WeakReference(inflate);
            return inflate;
        } else {
            throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
        }
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
    }

    public void draw(Canvas canvas) {
    }

    public int getInflatedId() {
        return this.f1410b;
    }

    public LayoutInflater getLayoutInflater() {
        return this.f1412d;
    }

    public int getLayoutResource() {
        return this.f1409a;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        setMeasuredDimension(0, 0);
    }

    public void setInflatedId(int i2) {
        this.f1410b = i2;
    }

    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.f1412d = layoutInflater;
    }

    public void setLayoutResource(int i2) {
        this.f1409a = i2;
    }

    public void setOnInflateListener(a aVar) {
    }

    public void setVisibility(int i2) {
        WeakReference weakReference = this.f1411c;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            if (view != null) {
                view.setVisibility(i2);
                return;
            }
            throw new IllegalStateException("setVisibility called on un-referenced view");
        }
        super.setVisibility(i2);
        if (i2 == 0 || i2 == 4) {
            a();
        }
    }

    public ViewStubCompat(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1409a = 0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.t3, i2, 0);
        this.f1410b = obtainStyledAttributes.getResourceId(j.w3, -1);
        this.f1409a = obtainStyledAttributes.getResourceId(j.v3, 0);
        setId(obtainStyledAttributes.getResourceId(j.u3, -1));
        obtainStyledAttributes.recycle();
        setVisibility(8);
        setWillNotDraw(true);
    }
}
