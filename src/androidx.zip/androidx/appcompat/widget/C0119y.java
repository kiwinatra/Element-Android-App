package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.SeekBar;
import e.C0233a;

/* renamed from: androidx.appcompat.widget.y  reason: case insensitive filesystem */
public class C0119y extends SeekBar {

    /* renamed from: a  reason: collision with root package name */
    private final C0120z f1625a;

    public C0119y(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.seekBarStyle);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        this.f1625a.h();
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        this.f1625a.i();
    }

    /* access modifiers changed from: protected */
    public synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1625a.g(canvas);
    }

    public C0119y(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        a0.a(this, getContext());
        C0120z zVar = new C0120z(this);
        this.f1625a = zVar;
        zVar.c(attributeSet, i2);
    }
}
