package androidx.appcompat.widget;

public final /* synthetic */ class l0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f1571a;

    public /* synthetic */ l0(m0 m0Var) {
        this.f1571a = m0Var;
    }

    public final void run() {
        this.f1571a.d();
    }
}
