package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class b0 extends ContextWrapper {

    /* renamed from: c  reason: collision with root package name */
    private static final Object f1454c = new Object();

    /* renamed from: d  reason: collision with root package name */
    private static ArrayList f1455d;

    /* renamed from: a  reason: collision with root package name */
    private final Resources f1456a;

    /* renamed from: b  reason: collision with root package name */
    private final Resources.Theme f1457b;

    private b0(Context context) {
        super(context);
        if (o0.c()) {
            o0 o0Var = new o0(this, context.getResources());
            this.f1456a = o0Var;
            Resources.Theme newTheme = o0Var.newTheme();
            this.f1457b = newTheme;
            newTheme.setTo(context.getTheme());
            return;
        }
        this.f1456a = new d0(this, context.getResources());
        this.f1457b = null;
    }

    private static boolean a(Context context) {
        if ((context instanceof b0) || (context.getResources() instanceof d0) || (context.getResources() instanceof o0)) {
            return false;
        }
        return o0.c();
    }

    public static Context b(Context context) {
        if (!a(context)) {
            return context;
        }
        synchronized (f1454c) {
            try {
                ArrayList arrayList = f1455d;
                if (arrayList == null) {
                    f1455d = new ArrayList();
                } else {
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        WeakReference weakReference = (WeakReference) f1455d.get(size);
                        if (weakReference == null || weakReference.get() == null) {
                            f1455d.remove(size);
                        }
                    }
                    for (int size2 = f1455d.size() - 1; size2 >= 0; size2--) {
                        WeakReference weakReference2 = (WeakReference) f1455d.get(size2);
                        b0 b0Var = weakReference2 != null ? (b0) weakReference2.get() : null;
                        if (b0Var != null && b0Var.getBaseContext() == context) {
                            return b0Var;
                        }
                    }
                }
                b0 b0Var2 = new b0(context);
                f1455d.add(new WeakReference(b0Var2));
                return b0Var2;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public AssetManager getAssets() {
        return this.f1456a.getAssets();
    }

    public Resources getResources() {
        return this.f1456a;
    }

    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f1457b;
        return theme == null ? super.getTheme() : theme;
    }

    public void setTheme(int i2) {
        Resources.Theme theme = this.f1457b;
        if (theme == null) {
            super.setTheme(i2);
        } else {
            theme.applyStyle(i2, true);
        }
    }
}
