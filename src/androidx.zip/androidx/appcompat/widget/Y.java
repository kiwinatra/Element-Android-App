package androidx.appcompat.widget;

class Y {

    /* renamed from: a  reason: collision with root package name */
    private int f1424a = 0;

    /* renamed from: b  reason: collision with root package name */
    private int f1425b = 0;

    /* renamed from: c  reason: collision with root package name */
    private int f1426c = Integer.MIN_VALUE;

    /* renamed from: d  reason: collision with root package name */
    private int f1427d = Integer.MIN_VALUE;

    /* renamed from: e  reason: collision with root package name */
    private int f1428e = 0;

    /* renamed from: f  reason: collision with root package name */
    private int f1429f = 0;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1430g = false;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1431h = false;

    Y() {
    }

    public int a() {
        return this.f1430g ? this.f1424a : this.f1425b;
    }

    public int b() {
        return this.f1424a;
    }

    public int c() {
        return this.f1425b;
    }

    public int d() {
        return this.f1430g ? this.f1425b : this.f1424a;
    }

    public void e(int i2, int i3) {
        this.f1431h = false;
        if (i2 != Integer.MIN_VALUE) {
            this.f1428e = i2;
            this.f1424a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f1429f = i3;
            this.f1425b = i3;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001a, code lost:
        if (r2 != Integer.MIN_VALUE) goto L_0x001c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002a, code lost:
        if (r2 != Integer.MIN_VALUE) goto L_0x001c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void f(boolean r2) {
        /*
            r1 = this;
            boolean r0 = r1.f1430g
            if (r2 != r0) goto L_0x0005
            return
        L_0x0005:
            r1.f1430g = r2
            boolean r0 = r1.f1431h
            if (r0 == 0) goto L_0x002d
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == 0) goto L_0x001f
            int r2 = r1.f1427d
            if (r2 == r0) goto L_0x0014
            goto L_0x0016
        L_0x0014:
            int r2 = r1.f1428e
        L_0x0016:
            r1.f1424a = r2
            int r2 = r1.f1426c
            if (r2 == r0) goto L_0x0031
        L_0x001c:
            r1.f1425b = r2
            goto L_0x0034
        L_0x001f:
            int r2 = r1.f1426c
            if (r2 == r0) goto L_0x0024
            goto L_0x0026
        L_0x0024:
            int r2 = r1.f1428e
        L_0x0026:
            r1.f1424a = r2
            int r2 = r1.f1427d
            if (r2 == r0) goto L_0x0031
            goto L_0x001c
        L_0x002d:
            int r2 = r1.f1428e
            r1.f1424a = r2
        L_0x0031:
            int r2 = r1.f1429f
            goto L_0x001c
        L_0x0034:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Y.f(boolean):void");
    }

    public void g(int i2, int i3) {
        this.f1426c = i2;
        this.f1427d = i3;
        this.f1431h = true;
        if (this.f1430g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1424a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f1425b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1424a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f1425b = i3;
        }
    }
}
