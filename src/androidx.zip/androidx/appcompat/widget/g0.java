package androidx.appcompat.widget;

public final /* synthetic */ class g0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1514a;

    public /* synthetic */ g0(Toolbar toolbar) {
        this.f1514a = toolbar;
    }

    public final void run() {
        this.f1514a.A();
    }
}
