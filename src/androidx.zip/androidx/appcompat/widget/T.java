package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import e.C0233a;
import e.j;
import java.lang.reflect.Method;

public class T implements i.e {

    /* renamed from: G  reason: collision with root package name */
    private static Method f1305G;

    /* renamed from: H  reason: collision with root package name */
    private static Method f1306H;

    /* renamed from: I  reason: collision with root package name */
    private static Method f1307I;

    /* renamed from: A  reason: collision with root package name */
    private Runnable f1308A;

    /* renamed from: B  reason: collision with root package name */
    final Handler f1309B;

    /* renamed from: C  reason: collision with root package name */
    private final Rect f1310C;

    /* renamed from: D  reason: collision with root package name */
    private Rect f1311D;

    /* renamed from: E  reason: collision with root package name */
    private boolean f1312E;

    /* renamed from: F  reason: collision with root package name */
    PopupWindow f1313F;

    /* renamed from: a  reason: collision with root package name */
    private Context f1314a;

    /* renamed from: b  reason: collision with root package name */
    private ListAdapter f1315b;

    /* renamed from: c  reason: collision with root package name */
    O f1316c;

    /* renamed from: d  reason: collision with root package name */
    private int f1317d;

    /* renamed from: e  reason: collision with root package name */
    private int f1318e;

    /* renamed from: f  reason: collision with root package name */
    private int f1319f;

    /* renamed from: g  reason: collision with root package name */
    private int f1320g;

    /* renamed from: h  reason: collision with root package name */
    private int f1321h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f1322i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f1323j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f1324k;

    /* renamed from: l  reason: collision with root package name */
    private int f1325l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f1326m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f1327n;

    /* renamed from: o  reason: collision with root package name */
    int f1328o;

    /* renamed from: p  reason: collision with root package name */
    private View f1329p;

    /* renamed from: q  reason: collision with root package name */
    private int f1330q;

    /* renamed from: r  reason: collision with root package name */
    private DataSetObserver f1331r;

    /* renamed from: s  reason: collision with root package name */
    private View f1332s;

    /* renamed from: t  reason: collision with root package name */
    private Drawable f1333t;

    /* renamed from: u  reason: collision with root package name */
    private AdapterView.OnItemClickListener f1334u;

    /* renamed from: v  reason: collision with root package name */
    private AdapterView.OnItemSelectedListener f1335v;

    /* renamed from: w  reason: collision with root package name */
    final i f1336w;

    /* renamed from: x  reason: collision with root package name */
    private final h f1337x;

    /* renamed from: y  reason: collision with root package name */
    private final g f1338y;

    /* renamed from: z  reason: collision with root package name */
    private final e f1339z;

    class a implements Runnable {
        a() {
        }

        public void run() {
            View t2 = T.this.t();
            if (t2 != null && t2.getWindowToken() != null) {
                T.this.f();
            }
        }
    }

    class b implements AdapterView.OnItemSelectedListener {
        b() {
        }

        public void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
            O o2;
            if (i2 != -1 && (o2 = T.this.f1316c) != null) {
                o2.setListSelectionHidden(false);
            }
        }

        public void onNothingSelected(AdapterView adapterView) {
        }
    }

    static class c {
        static int a(PopupWindow popupWindow, View view, int i2, boolean z2) {
            return popupWindow.getMaxAvailableHeight(view, i2, z2);
        }
    }

    static class d {
        static void a(PopupWindow popupWindow, Rect rect) {
            popupWindow.setEpicenterBounds(rect);
        }

        static void b(PopupWindow popupWindow, boolean z2) {
            popupWindow.setIsClippedToScreen(z2);
        }
    }

    private class e implements Runnable {
        e() {
        }

        public void run() {
            T.this.r();
        }
    }

    private class f extends DataSetObserver {
        f() {
        }

        public void onChanged() {
            if (T.this.b()) {
                T.this.f();
            }
        }

        public void onInvalidated() {
            T.this.dismiss();
        }
    }

    private class g implements AbsListView.OnScrollListener {
        g() {
        }

        public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
        }

        public void onScrollStateChanged(AbsListView absListView, int i2) {
            if (i2 == 1 && !T.this.A() && T.this.f1313F.getContentView() != null) {
                T t2 = T.this;
                t2.f1309B.removeCallbacks(t2.f1336w);
                T.this.f1336w.run();
            }
        }
    }

    private class h implements View.OnTouchListener {
        h() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x2 = (int) motionEvent.getX();
            int y2 = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = T.this.f1313F) != null && popupWindow.isShowing() && x2 >= 0 && x2 < T.this.f1313F.getWidth() && y2 >= 0 && y2 < T.this.f1313F.getHeight()) {
                T t2 = T.this;
                t2.f1309B.postDelayed(t2.f1336w, 250);
                return false;
            } else if (action != 1) {
                return false;
            } else {
                T t3 = T.this;
                t3.f1309B.removeCallbacks(t3.f1336w);
                return false;
            }
        }
    }

    private class i implements Runnable {
        i() {
        }

        public void run() {
            O o2 = T.this.f1316c;
            if (o2 != null && o2.isAttachedToWindow() && T.this.f1316c.getCount() > T.this.f1316c.getChildCount()) {
                int childCount = T.this.f1316c.getChildCount();
                T t2 = T.this;
                if (childCount <= t2.f1328o) {
                    t2.f1313F.setInputMethodMode(2);
                    T.this.f();
                }
            }
        }
    }

    static {
        Class<PopupWindow> cls = PopupWindow.class;
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f1305G = cls.getDeclaredMethod("setClipToScreenEnabled", new Class[]{Boolean.TYPE});
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f1307I = cls.getDeclaredMethod("setEpicenterBounds", new Class[]{Rect.class});
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                f1306H = cls.getDeclaredMethod("getMaxAvailableHeight", new Class[]{View.class, Integer.TYPE, Boolean.TYPE});
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public T(Context context) {
        this(context, (AttributeSet) null, C0233a.listPopupWindowStyle);
    }

    private void C() {
        View view = this.f1329p;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.f1329p);
            }
        }
    }

    private void O(boolean z2) {
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f1305G;
            if (method != null) {
                try {
                    method.invoke(this.f1313F, new Object[]{Boolean.valueOf(z2)});
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            d.b(this.f1313F, z2);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v23, resolved type: androidx.appcompat.widget.O} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v24, resolved type: androidx.appcompat.widget.O} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: android.widget.LinearLayout} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v29, resolved type: androidx.appcompat.widget.O} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0152  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private int q() {
        /*
            r12 = this;
            androidx.appcompat.widget.O r0 = r12.f1316c
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = -1
            r3 = 1
            r4 = 0
            if (r0 != 0) goto L_0x00bf
            android.content.Context r0 = r12.f1314a
            androidx.appcompat.widget.T$a r5 = new androidx.appcompat.widget.T$a
            r5.<init>()
            r12.f1308A = r5
            boolean r5 = r12.f1312E
            r5 = r5 ^ r3
            androidx.appcompat.widget.O r5 = r12.s(r0, r5)
            r12.f1316c = r5
            android.graphics.drawable.Drawable r6 = r12.f1333t
            if (r6 == 0) goto L_0x0022
            r5.setSelector(r6)
        L_0x0022:
            androidx.appcompat.widget.O r5 = r12.f1316c
            android.widget.ListAdapter r6 = r12.f1315b
            r5.setAdapter(r6)
            androidx.appcompat.widget.O r5 = r12.f1316c
            android.widget.AdapterView$OnItemClickListener r6 = r12.f1334u
            r5.setOnItemClickListener(r6)
            androidx.appcompat.widget.O r5 = r12.f1316c
            r5.setFocusable(r3)
            androidx.appcompat.widget.O r5 = r12.f1316c
            r5.setFocusableInTouchMode(r3)
            androidx.appcompat.widget.O r5 = r12.f1316c
            androidx.appcompat.widget.T$b r6 = new androidx.appcompat.widget.T$b
            r6.<init>()
            r5.setOnItemSelectedListener(r6)
            androidx.appcompat.widget.O r5 = r12.f1316c
            androidx.appcompat.widget.T$g r6 = r12.f1338y
            r5.setOnScrollListener(r6)
            android.widget.AdapterView$OnItemSelectedListener r5 = r12.f1335v
            if (r5 == 0) goto L_0x0054
            androidx.appcompat.widget.O r6 = r12.f1316c
            r6.setOnItemSelectedListener(r5)
        L_0x0054:
            androidx.appcompat.widget.O r5 = r12.f1316c
            android.view.View r6 = r12.f1329p
            if (r6 == 0) goto L_0x00b8
            android.widget.LinearLayout r7 = new android.widget.LinearLayout
            r7.<init>(r0)
            r7.setOrientation(r3)
            android.widget.LinearLayout$LayoutParams r0 = new android.widget.LinearLayout$LayoutParams
            r8 = 1065353216(0x3f800000, float:1.0)
            r0.<init>(r2, r4, r8)
            int r8 = r12.f1330q
            if (r8 == 0) goto L_0x008f
            if (r8 == r3) goto L_0x0088
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r5 = "Invalid hint position "
            r0.append(r5)
            int r5 = r12.f1330q
            r0.append(r5)
            java.lang.String r0 = r0.toString()
            java.lang.String r5 = "ListPopupWindow"
            android.util.Log.e(r5, r0)
            goto L_0x0095
        L_0x0088:
            r7.addView(r5, r0)
            r7.addView(r6)
            goto L_0x0095
        L_0x008f:
            r7.addView(r6)
            r7.addView(r5, r0)
        L_0x0095:
            int r0 = r12.f1318e
            if (r0 < 0) goto L_0x009c
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x009e
        L_0x009c:
            r0 = 0
            r5 = 0
        L_0x009e:
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r5)
            r6.measure(r0, r4)
            android.view.ViewGroup$LayoutParams r0 = r6.getLayoutParams()
            android.widget.LinearLayout$LayoutParams r0 = (android.widget.LinearLayout.LayoutParams) r0
            int r5 = r6.getMeasuredHeight()
            int r6 = r0.topMargin
            int r5 = r5 + r6
            int r0 = r0.bottomMargin
            int r5 = r5 + r0
            r0 = r5
            r5 = r7
            goto L_0x00b9
        L_0x00b8:
            r0 = 0
        L_0x00b9:
            android.widget.PopupWindow r6 = r12.f1313F
            r6.setContentView(r5)
            goto L_0x00dd
        L_0x00bf:
            android.widget.PopupWindow r0 = r12.f1313F
            android.view.View r0 = r0.getContentView()
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            android.view.View r0 = r12.f1329p
            if (r0 == 0) goto L_0x00dc
            android.view.ViewGroup$LayoutParams r5 = r0.getLayoutParams()
            android.widget.LinearLayout$LayoutParams r5 = (android.widget.LinearLayout.LayoutParams) r5
            int r0 = r0.getMeasuredHeight()
            int r6 = r5.topMargin
            int r0 = r0 + r6
            int r5 = r5.bottomMargin
            int r0 = r0 + r5
            goto L_0x00dd
        L_0x00dc:
            r0 = 0
        L_0x00dd:
            android.widget.PopupWindow r5 = r12.f1313F
            android.graphics.drawable.Drawable r5 = r5.getBackground()
            if (r5 == 0) goto L_0x00f9
            android.graphics.Rect r6 = r12.f1310C
            r5.getPadding(r6)
            android.graphics.Rect r5 = r12.f1310C
            int r6 = r5.top
            int r5 = r5.bottom
            int r5 = r5 + r6
            boolean r7 = r12.f1322i
            if (r7 != 0) goto L_0x00ff
            int r6 = -r6
            r12.f1320g = r6
            goto L_0x00ff
        L_0x00f9:
            android.graphics.Rect r5 = r12.f1310C
            r5.setEmpty()
            r5 = 0
        L_0x00ff:
            android.widget.PopupWindow r6 = r12.f1313F
            int r6 = r6.getInputMethodMode()
            r7 = 2
            if (r6 != r7) goto L_0x0109
            goto L_0x010a
        L_0x0109:
            r3 = 0
        L_0x010a:
            android.view.View r4 = r12.t()
            int r6 = r12.f1320g
            int r3 = r12.u(r4, r6, r3)
            boolean r4 = r12.f1326m
            if (r4 != 0) goto L_0x0163
            int r4 = r12.f1317d
            if (r4 != r2) goto L_0x011d
            goto L_0x0163
        L_0x011d:
            int r4 = r12.f1318e
            r6 = -2
            if (r4 == r6) goto L_0x012c
            r1 = 1073741824(0x40000000, float:2.0)
            if (r4 == r2) goto L_0x012c
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r1)
        L_0x012a:
            r7 = r1
            goto L_0x0145
        L_0x012c:
            android.content.Context r2 = r12.f1314a
            android.content.res.Resources r2 = r2.getResources()
            android.util.DisplayMetrics r2 = r2.getDisplayMetrics()
            int r2 = r2.widthPixels
            android.graphics.Rect r4 = r12.f1310C
            int r6 = r4.left
            int r4 = r4.right
            int r6 = r6 + r4
            int r2 = r2 - r6
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r1)
            goto L_0x012a
        L_0x0145:
            androidx.appcompat.widget.O r6 = r12.f1316c
            int r10 = r3 - r0
            r11 = -1
            r8 = 0
            r9 = -1
            int r1 = r6.d(r7, r8, r9, r10, r11)
            if (r1 <= 0) goto L_0x0161
            androidx.appcompat.widget.O r2 = r12.f1316c
            int r2 = r2.getPaddingTop()
            androidx.appcompat.widget.O r3 = r12.f1316c
            int r3 = r3.getPaddingBottom()
            int r2 = r2 + r3
            int r5 = r5 + r2
            int r0 = r0 + r5
        L_0x0161:
            int r1 = r1 + r0
            return r1
        L_0x0163:
            int r3 = r3 + r5
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.T.q():int");
    }

    private int u(View view, int i2, boolean z2) {
        if (Build.VERSION.SDK_INT > 23) {
            return c.a(this.f1313F, view, i2, z2);
        }
        Method method = f1306H;
        if (method != null) {
            try {
                return ((Integer) method.invoke(this.f1313F, new Object[]{view, Integer.valueOf(i2), Boolean.valueOf(z2)})).intValue();
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
            }
        }
        return this.f1313F.getMaxAvailableHeight(view, i2);
    }

    public boolean A() {
        return this.f1313F.getInputMethodMode() == 2;
    }

    public boolean B() {
        return this.f1312E;
    }

    public void D(View view) {
        this.f1332s = view;
    }

    public void E(int i2) {
        this.f1313F.setAnimationStyle(i2);
    }

    public void F(int i2) {
        Drawable background = this.f1313F.getBackground();
        if (background != null) {
            background.getPadding(this.f1310C);
            Rect rect = this.f1310C;
            this.f1318e = rect.left + rect.right + i2;
            return;
        }
        R(i2);
    }

    public void G(int i2) {
        this.f1325l = i2;
    }

    public void H(Rect rect) {
        this.f1311D = rect != null ? new Rect(rect) : null;
    }

    public void I(int i2) {
        this.f1313F.setInputMethodMode(i2);
    }

    public void J(boolean z2) {
        this.f1312E = z2;
        this.f1313F.setFocusable(z2);
    }

    public void K(PopupWindow.OnDismissListener onDismissListener) {
        this.f1313F.setOnDismissListener(onDismissListener);
    }

    public void L(AdapterView.OnItemClickListener onItemClickListener) {
        this.f1334u = onItemClickListener;
    }

    public void M(AdapterView.OnItemSelectedListener onItemSelectedListener) {
        this.f1335v = onItemSelectedListener;
    }

    public void N(boolean z2) {
        this.f1324k = true;
        this.f1323j = z2;
    }

    public void P(int i2) {
        this.f1330q = i2;
    }

    public void Q(int i2) {
        O o2 = this.f1316c;
        if (b() && o2 != null) {
            o2.setListSelectionHidden(false);
            o2.setSelection(i2);
            if (o2.getChoiceMode() != 0) {
                o2.setItemChecked(i2, true);
            }
        }
    }

    public void R(int i2) {
        this.f1318e = i2;
    }

    public boolean b() {
        return this.f1313F.isShowing();
    }

    public void c(int i2) {
        this.f1319f = i2;
    }

    public int d() {
        return this.f1319f;
    }

    public void dismiss() {
        this.f1313F.dismiss();
        C();
        this.f1313F.setContentView((View) null);
        this.f1316c = null;
        this.f1309B.removeCallbacks(this.f1336w);
    }

    public void f() {
        int q2 = q();
        boolean A2 = A();
        androidx.core.widget.h.b(this.f1313F, this.f1321h);
        boolean z2 = true;
        if (!this.f1313F.isShowing()) {
            int i2 = this.f1318e;
            if (i2 == -1) {
                i2 = -1;
            } else if (i2 == -2) {
                i2 = t().getWidth();
            }
            int i3 = this.f1317d;
            if (i3 == -1) {
                q2 = -1;
            } else if (i3 != -2) {
                q2 = i3;
            }
            this.f1313F.setWidth(i2);
            this.f1313F.setHeight(q2);
            O(true);
            this.f1313F.setOutsideTouchable(!this.f1327n && !this.f1326m);
            this.f1313F.setTouchInterceptor(this.f1337x);
            if (this.f1324k) {
                androidx.core.widget.h.a(this.f1313F, this.f1323j);
            }
            if (Build.VERSION.SDK_INT <= 28) {
                Method method = f1307I;
                if (method != null) {
                    try {
                        method.invoke(this.f1313F, new Object[]{this.f1311D});
                    } catch (Exception e2) {
                        Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                    }
                }
            } else {
                d.a(this.f1313F, this.f1311D);
            }
            androidx.core.widget.h.c(this.f1313F, t(), this.f1319f, this.f1320g, this.f1325l);
            this.f1316c.setSelection(-1);
            if (!this.f1312E || this.f1316c.isInTouchMode()) {
                r();
            }
            if (!this.f1312E) {
                this.f1309B.post(this.f1339z);
            }
        } else if (t().isAttachedToWindow()) {
            int i4 = this.f1318e;
            if (i4 == -1) {
                i4 = -1;
            } else if (i4 == -2) {
                i4 = t().getWidth();
            }
            int i5 = this.f1317d;
            if (i5 == -1) {
                if (!A2) {
                    q2 = -1;
                }
                if (A2) {
                    this.f1313F.setWidth(this.f1318e == -1 ? -1 : 0);
                    this.f1313F.setHeight(0);
                } else {
                    this.f1313F.setWidth(this.f1318e == -1 ? -1 : 0);
                    this.f1313F.setHeight(-1);
                }
            } else if (i5 != -2) {
                q2 = i5;
            }
            PopupWindow popupWindow = this.f1313F;
            if (this.f1327n || this.f1326m) {
                z2 = false;
            }
            popupWindow.setOutsideTouchable(z2);
            this.f1313F.update(t(), this.f1319f, this.f1320g, i4 < 0 ? -1 : i4, q2 < 0 ? -1 : q2);
        }
    }

    public int g() {
        if (!this.f1322i) {
            return 0;
        }
        return this.f1320g;
    }

    public Drawable i() {
        return this.f1313F.getBackground();
    }

    public ListView k() {
        return this.f1316c;
    }

    public void m(Drawable drawable) {
        this.f1313F.setBackgroundDrawable(drawable);
    }

    public void n(int i2) {
        this.f1320g = i2;
        this.f1322i = true;
    }

    public void o(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.f1331r;
        if (dataSetObserver == null) {
            this.f1331r = new f();
        } else {
            ListAdapter listAdapter2 = this.f1315b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f1315b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f1331r);
        }
        O o2 = this.f1316c;
        if (o2 != null) {
            o2.setAdapter(this.f1315b);
        }
    }

    public void r() {
        O o2 = this.f1316c;
        if (o2 != null) {
            o2.setListSelectionHidden(true);
            o2.requestLayout();
        }
    }

    /* access modifiers changed from: package-private */
    public O s(Context context, boolean z2) {
        return new O(context, z2);
    }

    public View t() {
        return this.f1332s;
    }

    public Object v() {
        if (!b()) {
            return null;
        }
        return this.f1316c.getSelectedItem();
    }

    public long w() {
        if (!b()) {
            return Long.MIN_VALUE;
        }
        return this.f1316c.getSelectedItemId();
    }

    public int x() {
        if (!b()) {
            return -1;
        }
        return this.f1316c.getSelectedItemPosition();
    }

    public View y() {
        if (!b()) {
            return null;
        }
        return this.f1316c.getSelectedView();
    }

    public int z() {
        return this.f1318e;
    }

    public T(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public T(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f1317d = -2;
        this.f1318e = -2;
        this.f1321h = 1002;
        this.f1325l = 0;
        this.f1326m = false;
        this.f1327n = false;
        this.f1328o = Integer.MAX_VALUE;
        this.f1330q = 0;
        this.f1336w = new i();
        this.f1337x = new h();
        this.f1338y = new g();
        this.f1339z = new e();
        this.f1310C = new Rect();
        this.f1314a = context;
        this.f1309B = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.t1, i2, i3);
        this.f1319f = obtainStyledAttributes.getDimensionPixelOffset(j.u1, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(j.v1, 0);
        this.f1320g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f1322i = true;
        }
        obtainStyledAttributes.recycle();
        C0114t tVar = new C0114t(context, attributeSet, i2, i3);
        this.f1313F = tVar;
        tVar.setInputMethodMode(1);
    }
}
