package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;
import androidx.core.widget.m;
import androidx.core.widget.n;
import e.C0233a;
import f.C0236a;

/* renamed from: androidx.appcompat.widget.g  reason: case insensitive filesystem */
public class C0102g extends CheckBox implements m, n {

    /* renamed from: a  reason: collision with root package name */
    private final C0105j f1510a;

    /* renamed from: b  reason: collision with root package name */
    private final C0100e f1511b;

    /* renamed from: c  reason: collision with root package name */
    private final E f1512c;

    /* renamed from: d  reason: collision with root package name */
    private C0109n f1513d;

    public C0102g(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.f5288o);
    }

    private C0109n getEmojiTextViewHelper() {
        if (this.f1513d == null) {
            this.f1513d = new C0109n(this);
        }
        return this.f1513d;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1512c;
        if (e2 != null) {
            e2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        C0105j jVar = this.f1510a;
        if (jVar != null) {
            return jVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0105j jVar = this.f1510a;
        if (jVar != null) {
            return jVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1512c.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1512c.k();
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setButtonDrawable(int i2) {
        setButtonDrawable(C0236a.b(getContext(), i2));
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1512c;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1512c;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1511b;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0105j jVar = this.f1510a;
        if (jVar != null) {
            jVar.f(colorStateList);
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0105j jVar = this.f1510a;
        if (jVar != null) {
            jVar.g(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1512c.w(colorStateList);
        this.f1512c.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1512c.x(mode);
        this.f1512c.b();
    }

    public C0102g(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        a0.a(this, getContext());
        C0105j jVar = new C0105j(this);
        this.f1510a = jVar;
        jVar.d(attributeSet, i2);
        C0100e eVar = new C0100e(this);
        this.f1511b = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1512c = e2;
        e2.m(attributeSet, i2);
        getEmojiTextViewHelper().b(attributeSet, i2);
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0105j jVar = this.f1510a;
        if (jVar != null) {
            jVar.e();
        }
    }
}
