package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.view.C0130e0;
import e.C0233a;
import g.C0239c;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class O extends ListView {

    /* renamed from: a  reason: collision with root package name */
    private final Rect f1255a = new Rect();

    /* renamed from: b  reason: collision with root package name */
    private int f1256b = 0;

    /* renamed from: c  reason: collision with root package name */
    private int f1257c = 0;

    /* renamed from: d  reason: collision with root package name */
    private int f1258d = 0;

    /* renamed from: e  reason: collision with root package name */
    private int f1259e = 0;

    /* renamed from: f  reason: collision with root package name */
    private int f1260f;

    /* renamed from: g  reason: collision with root package name */
    private d f1261g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1262h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f1263i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f1264j;

    /* renamed from: k  reason: collision with root package name */
    private C0130e0 f1265k;

    /* renamed from: l  reason: collision with root package name */
    private androidx.core.widget.f f1266l;

    /* renamed from: m  reason: collision with root package name */
    f f1267m;

    static class a {
        static void a(View view, float f2, float f3) {
            view.drawableHotspotChanged(f2, f3);
        }
    }

    static class b {

        /* renamed from: a  reason: collision with root package name */
        private static Method f1268a;

        /* renamed from: b  reason: collision with root package name */
        private static Method f1269b;

        /* renamed from: c  reason: collision with root package name */
        private static Method f1270c;

        /* renamed from: d  reason: collision with root package name */
        private static boolean f1271d = true;

        static {
            Class<AdapterView> cls = AdapterView.class;
            Class<AbsListView> cls2 = AbsListView.class;
            try {
                Class cls3 = Integer.TYPE;
                Class cls4 = Float.TYPE;
                Method declaredMethod = cls2.getDeclaredMethod("positionSelector", new Class[]{cls3, View.class, Boolean.TYPE, cls4, cls4});
                f1268a = declaredMethod;
                declaredMethod.setAccessible(true);
                Method declaredMethod2 = cls.getDeclaredMethod("setSelectedPositionInt", new Class[]{cls3});
                f1269b = declaredMethod2;
                declaredMethod2.setAccessible(true);
                Method declaredMethod3 = cls.getDeclaredMethod("setNextSelectedPositionInt", new Class[]{cls3});
                f1270c = declaredMethod3;
                declaredMethod3.setAccessible(true);
            } catch (NoSuchMethodException e2) {
                e2.printStackTrace();
            }
        }

        static boolean a() {
            return f1271d;
        }

        static void b(O o2, int i2, View view) {
            try {
                f1268a.invoke(o2, new Object[]{Integer.valueOf(i2), view, Boolean.FALSE, -1, -1});
                f1269b.invoke(o2, new Object[]{Integer.valueOf(i2)});
                f1270c.invoke(o2, new Object[]{Integer.valueOf(i2)});
            } catch (IllegalAccessException | InvocationTargetException e2) {
                e2.printStackTrace();
            }
        }
    }

    static class c {
        static boolean a(AbsListView absListView) {
            return absListView.isSelectedChildViewEnabled();
        }

        static void b(AbsListView absListView, boolean z2) {
            absListView.setSelectedChildViewEnabled(z2);
        }
    }

    private static class d extends C0239c {

        /* renamed from: b  reason: collision with root package name */
        private boolean f1272b = true;

        d(Drawable drawable) {
            super(drawable);
        }

        /* access modifiers changed from: package-private */
        public void b(boolean z2) {
            this.f1272b = z2;
        }

        public void draw(Canvas canvas) {
            if (this.f1272b) {
                super.draw(canvas);
            }
        }

        public void setHotspot(float f2, float f3) {
            if (this.f1272b) {
                super.setHotspot(f2, f3);
            }
        }

        public void setHotspotBounds(int i2, int i3, int i4, int i5) {
            if (this.f1272b) {
                super.setHotspotBounds(i2, i3, i4, i5);
            }
        }

        public boolean setState(int[] iArr) {
            if (this.f1272b) {
                return super.setState(iArr);
            }
            return false;
        }

        public boolean setVisible(boolean z2, boolean z3) {
            if (this.f1272b) {
                return super.setVisible(z2, z3);
            }
            return false;
        }
    }

    static class e {

        /* renamed from: a  reason: collision with root package name */
        private static final Field f1273a;

        static {
            Field field = null;
            try {
                field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
                field.setAccessible(true);
            } catch (NoSuchFieldException e2) {
                e2.printStackTrace();
            }
            f1273a = field;
        }

        static boolean a(AbsListView absListView) {
            Field field = f1273a;
            if (field == null) {
                return false;
            }
            try {
                return field.getBoolean(absListView);
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
                return false;
            }
        }

        static void b(AbsListView absListView, boolean z2) {
            Field field = f1273a;
            if (field != null) {
                try {
                    field.set(absListView, Boolean.valueOf(z2));
                } catch (IllegalAccessException e2) {
                    e2.printStackTrace();
                }
            }
        }
    }

    private class f implements Runnable {
        f() {
        }

        public void a() {
            O o2 = O.this;
            o2.f1267m = null;
            o2.removeCallbacks(this);
        }

        public void b() {
            O.this.post(this);
        }

        public void run() {
            O o2 = O.this;
            o2.f1267m = null;
            o2.drawableStateChanged();
        }
    }

    O(Context context, boolean z2) {
        super(context, (AttributeSet) null, C0233a.dropDownListViewStyle);
        this.f1263i = z2;
        setCacheColorHint(0);
    }

    private void a() {
        this.f1264j = false;
        setPressed(false);
        drawableStateChanged();
        View childAt = getChildAt(this.f1260f - getFirstVisiblePosition());
        if (childAt != null) {
            childAt.setPressed(false);
        }
        C0130e0 e0Var = this.f1265k;
        if (e0Var != null) {
            e0Var.c();
            this.f1265k = null;
        }
    }

    private void b(View view, int i2) {
        performItemClick(view, i2, getItemIdAtPosition(i2));
    }

    private void c(Canvas canvas) {
        Drawable selector;
        if (!this.f1255a.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(this.f1255a);
            selector.draw(canvas);
        }
    }

    private void f(int i2, View view) {
        Rect rect = this.f1255a;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        rect.left -= this.f1256b;
        rect.top -= this.f1257c;
        rect.right += this.f1258d;
        rect.bottom += this.f1259e;
        boolean k2 = k();
        if (view.isEnabled() != k2) {
            l(!k2);
            if (i2 != -1) {
                refreshDrawableState();
            }
        }
    }

    private void g(int i2, View view) {
        Drawable selector = getSelector();
        boolean z2 = true;
        boolean z3 = (selector == null || i2 == -1) ? false : true;
        if (z3) {
            selector.setVisible(false, false);
        }
        f(i2, view);
        if (z3) {
            Rect rect = this.f1255a;
            float exactCenterX = rect.exactCenterX();
            float exactCenterY = rect.exactCenterY();
            if (getVisibility() != 0) {
                z2 = false;
            }
            selector.setVisible(z2, false);
            androidx.core.graphics.drawable.a.k(selector, exactCenterX, exactCenterY);
        }
    }

    private void h(int i2, View view, float f2, float f3) {
        g(i2, view);
        Drawable selector = getSelector();
        if (selector != null && i2 != -1) {
            androidx.core.graphics.drawable.a.k(selector, f2, f3);
        }
    }

    private void i(View view, int i2, float f2, float f3) {
        View childAt;
        this.f1264j = true;
        a.a(this, f2, f3);
        if (!isPressed()) {
            setPressed(true);
        }
        layoutChildren();
        int i3 = this.f1260f;
        if (!(i3 == -1 || (childAt = getChildAt(i3 - getFirstVisiblePosition())) == null || childAt == view || !childAt.isPressed())) {
            childAt.setPressed(false);
        }
        this.f1260f = i2;
        a.a(view, f2 - ((float) view.getLeft()), f3 - ((float) view.getTop()));
        if (!view.isPressed()) {
            view.setPressed(true);
        }
        h(i2, view, f2, f3);
        j(false);
        refreshDrawableState();
    }

    private void j(boolean z2) {
        d dVar = this.f1261g;
        if (dVar != null) {
            dVar.b(z2);
        }
    }

    private boolean k() {
        return Build.VERSION.SDK_INT >= 33 ? c.a(this) : e.a(this);
    }

    private void l(boolean z2) {
        if (Build.VERSION.SDK_INT >= 33) {
            c.b(this, z2);
        } else {
            e.b(this, z2);
        }
    }

    private boolean m() {
        return this.f1264j;
    }

    private void n() {
        Drawable selector = getSelector();
        if (selector != null && m() && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    public int d(int i2, int i3, int i4, int i5, int i6) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        int i7 = listPaddingTop + listPaddingBottom;
        if (adapter == null) {
            return i7;
        }
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        View view = null;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        while (i8 < count) {
            int itemViewType = adapter.getItemViewType(i8);
            if (itemViewType != i9) {
                view = null;
                i9 = itemViewType;
            }
            view = adapter.getView(i8, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i11 = layoutParams.height;
            view.measure(i2, i11 > 0 ? View.MeasureSpec.makeMeasureSpec(i11, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i8 > 0) {
                i7 += dividerHeight;
            }
            i7 += view.getMeasuredHeight();
            if (i7 >= i5) {
                return (i6 < 0 || i8 <= i6 || i10 <= 0 || i7 == i5) ? i5 : i10;
            }
            if (i6 >= 0 && i8 >= i6) {
                i10 = i7;
            }
            i8++;
        }
        return i7;
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        c(canvas);
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        if (this.f1267m == null) {
            super.drawableStateChanged();
            j(true);
            n();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x000c, code lost:
        if (r0 != 3) goto L_0x000e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x001e  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x004f  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0065  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean e(android.view.MotionEvent r8, int r9) {
        /*
            r7 = this;
            int r0 = r8.getActionMasked()
            r1 = 1
            r2 = 0
            if (r0 == r1) goto L_0x0016
            r3 = 2
            if (r0 == r3) goto L_0x0014
            r9 = 3
            if (r0 == r9) goto L_0x0011
        L_0x000e:
            r9 = 0
            r3 = 1
            goto L_0x0046
        L_0x0011:
            r9 = 0
            r3 = 0
            goto L_0x0046
        L_0x0014:
            r3 = 1
            goto L_0x0017
        L_0x0016:
            r3 = 0
        L_0x0017:
            int r9 = r8.findPointerIndex(r9)
            if (r9 >= 0) goto L_0x001e
            goto L_0x0011
        L_0x001e:
            float r4 = r8.getX(r9)
            int r4 = (int) r4
            float r9 = r8.getY(r9)
            int r9 = (int) r9
            int r5 = r7.pointToPosition(r4, r9)
            r6 = -1
            if (r5 != r6) goto L_0x0031
            r9 = 1
            goto L_0x0046
        L_0x0031:
            int r3 = r7.getFirstVisiblePosition()
            int r3 = r5 - r3
            android.view.View r3 = r7.getChildAt(r3)
            float r4 = (float) r4
            float r9 = (float) r9
            r7.i(r3, r5, r4, r9)
            if (r0 != r1) goto L_0x000e
            r7.b(r3, r5)
            goto L_0x000e
        L_0x0046:
            if (r3 == 0) goto L_0x004a
            if (r9 == 0) goto L_0x004d
        L_0x004a:
            r7.a()
        L_0x004d:
            if (r3 == 0) goto L_0x0065
            androidx.core.widget.f r9 = r7.f1266l
            if (r9 != 0) goto L_0x005a
            androidx.core.widget.f r9 = new androidx.core.widget.f
            r9.<init>(r7)
            r7.f1266l = r9
        L_0x005a:
            androidx.core.widget.f r9 = r7.f1266l
            r9.m(r1)
            androidx.core.widget.f r9 = r7.f1266l
            r9.onTouch(r7, r8)
            goto L_0x006c
        L_0x0065:
            androidx.core.widget.f r8 = r7.f1266l
            if (r8 == 0) goto L_0x006c
            r8.m(r2)
        L_0x006c:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.O.e(android.view.MotionEvent, int):boolean");
    }

    public boolean hasFocus() {
        return this.f1263i || super.hasFocus();
    }

    public boolean hasWindowFocus() {
        return this.f1263i || super.hasWindowFocus();
    }

    public boolean isFocused() {
        return this.f1263i || super.isFocused();
    }

    public boolean isInTouchMode() {
        return (this.f1263i && this.f1262h) || super.isInTouchMode();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        this.f1267m = null;
        super.onDetachedFromWindow();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f1267m == null) {
            f fVar = new f();
            this.f1267m = fVar;
            fVar.b();
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    requestFocus();
                    if (i2 < 30 || !b.a()) {
                        setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                    } else {
                        b.b(this, pointToPosition, childAt);
                    }
                }
                n();
            }
        } else {
            setSelection(-1);
        }
        return onHoverEvent;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f1260f = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        f fVar = this.f1267m;
        if (fVar != null) {
            fVar.a();
        }
        return super.onTouchEvent(motionEvent);
    }

    /* access modifiers changed from: package-private */
    public void setListSelectionHidden(boolean z2) {
        this.f1262h = z2;
    }

    public void setSelector(Drawable drawable) {
        d dVar = drawable != null ? new d(drawable) : null;
        this.f1261g = dVar;
        super.setSelector(dVar);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f1256b = rect.left;
        this.f1257c = rect.top;
        this.f1258d = rect.right;
        this.f1259e = rect.bottom;
    }
}
