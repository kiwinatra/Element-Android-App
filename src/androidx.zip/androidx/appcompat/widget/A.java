package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.C0090c;
import e.C0233a;
import f.C0236a;

public class A extends Spinner {

    /* renamed from: i  reason: collision with root package name */
    private static final int[] f1079i = {16843505};

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1080a;

    /* renamed from: b  reason: collision with root package name */
    private final Context f1081b;

    /* renamed from: c  reason: collision with root package name */
    private Q f1082c;

    /* renamed from: d  reason: collision with root package name */
    private SpinnerAdapter f1083d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean f1084e;

    /* renamed from: f  reason: collision with root package name */
    private h f1085f;

    /* renamed from: g  reason: collision with root package name */
    int f1086g;

    /* renamed from: h  reason: collision with root package name */
    final Rect f1087h;

    class a extends Q {

        /* renamed from: j  reason: collision with root package name */
        final /* synthetic */ f f1088j;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(View view, f fVar) {
            super(view);
            this.f1088j = fVar;
        }

        public i.e b() {
            return this.f1088j;
        }

        public boolean c() {
            if (A.this.getInternalPopup().b()) {
                return true;
            }
            A.this.b();
            return true;
        }
    }

    class b implements ViewTreeObserver.OnGlobalLayoutListener {
        b() {
        }

        public void onGlobalLayout() {
            if (!A.this.getInternalPopup().b()) {
                A.this.b();
            }
            ViewTreeObserver viewTreeObserver = A.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    private static final class c {
        static void a(ThemedSpinnerAdapter themedSpinnerAdapter, Resources.Theme theme) {
            if (!x.c.a(themedSpinnerAdapter.getDropDownViewTheme(), theme)) {
                themedSpinnerAdapter.setDropDownViewTheme(theme);
            }
        }
    }

    class d implements h, DialogInterface.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        C0090c f1091a;

        /* renamed from: b  reason: collision with root package name */
        private ListAdapter f1092b;

        /* renamed from: c  reason: collision with root package name */
        private CharSequence f1093c;

        d() {
        }

        public boolean b() {
            C0090c cVar = this.f1091a;
            if (cVar != null) {
                return cVar.isShowing();
            }
            return false;
        }

        public void c(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        public int d() {
            return 0;
        }

        public void dismiss() {
            C0090c cVar = this.f1091a;
            if (cVar != null) {
                cVar.dismiss();
                this.f1091a = null;
            }
        }

        public void e(int i2, int i3) {
            if (this.f1092b != null) {
                C0090c.a aVar = new C0090c.a(A.this.getPopupContext());
                CharSequence charSequence = this.f1093c;
                if (charSequence != null) {
                    aVar.h(charSequence);
                }
                C0090c a2 = aVar.g(this.f1092b, A.this.getSelectedItemPosition(), this).a();
                this.f1091a = a2;
                ListView l2 = a2.l();
                l2.setTextDirection(i2);
                l2.setTextAlignment(i3);
                this.f1091a.show();
            }
        }

        public int g() {
            return 0;
        }

        public Drawable i() {
            return null;
        }

        public CharSequence j() {
            return this.f1093c;
        }

        public void l(CharSequence charSequence) {
            this.f1093c = charSequence;
        }

        public void m(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        public void n(int i2) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        public void o(ListAdapter listAdapter) {
            this.f1092b = listAdapter;
        }

        public void onClick(DialogInterface dialogInterface, int i2) {
            A.this.setSelection(i2);
            if (A.this.getOnItemClickListener() != null) {
                A.this.performItemClick((View) null, i2, this.f1092b.getItemId(i2));
            }
            dismiss();
        }

        public void p(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }
    }

    private static class e implements ListAdapter, SpinnerAdapter {

        /* renamed from: a  reason: collision with root package name */
        private SpinnerAdapter f1095a;

        /* renamed from: b  reason: collision with root package name */
        private ListAdapter f1096b;

        public e(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f1095a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f1096b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null && Build.VERSION.SDK_INT >= 23 && B.a(spinnerAdapter)) {
                c.a(C.a(spinnerAdapter), theme);
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f1096b;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i2, view, viewGroup);
        }

        public Object getItem(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i2);
        }

        public long getItemId(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter == null) {
                return -1;
            }
            return spinnerAdapter.getItemId(i2);
        }

        public int getItemViewType(int i2) {
            return 0;
        }

        public View getView(int i2, View view, ViewGroup viewGroup) {
            return getDropDownView(i2, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public boolean isEnabled(int i2) {
            ListAdapter listAdapter = this.f1096b;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i2);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1095a;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    class f extends T implements h {

        /* renamed from: J  reason: collision with root package name */
        private CharSequence f1097J;

        /* renamed from: K  reason: collision with root package name */
        ListAdapter f1098K;

        /* renamed from: L  reason: collision with root package name */
        private final Rect f1099L = new Rect();

        /* renamed from: M  reason: collision with root package name */
        private int f1100M;

        class a implements AdapterView.OnItemClickListener {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ A f1102a;

            a(A a2) {
                this.f1102a = a2;
            }

            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                A.this.setSelection(i2);
                if (A.this.getOnItemClickListener() != null) {
                    f fVar = f.this;
                    A.this.performItemClick(view, i2, fVar.f1098K.getItemId(i2));
                }
                f.this.dismiss();
            }
        }

        class b implements ViewTreeObserver.OnGlobalLayoutListener {
            b() {
            }

            public void onGlobalLayout() {
                f fVar = f.this;
                if (!fVar.V(A.this)) {
                    f.this.dismiss();
                    return;
                }
                f.this.T();
                f.super.f();
            }
        }

        class c implements PopupWindow.OnDismissListener {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f1105a;

            c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f1105a = onGlobalLayoutListener;
            }

            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = A.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f1105a);
                }
            }
        }

        public f(Context context, AttributeSet attributeSet, int i2) {
            super(context, attributeSet, i2);
            D(A.this);
            J(true);
            P(0);
            L(new a(A.this));
        }

        /* access modifiers changed from: package-private */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x008d  */
        /* JADX WARNING: Removed duplicated region for block: B:21:0x009a  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void T() {
            /*
                r8 = this;
                android.graphics.drawable.Drawable r0 = r8.i()
                if (r0 == 0) goto L_0x0024
                androidx.appcompat.widget.A r1 = androidx.appcompat.widget.A.this
                android.graphics.Rect r1 = r1.f1087h
                r0.getPadding(r1)
                androidx.appcompat.widget.A r0 = androidx.appcompat.widget.A.this
                boolean r0 = androidx.appcompat.widget.p0.b(r0)
                if (r0 == 0) goto L_0x001c
                androidx.appcompat.widget.A r0 = androidx.appcompat.widget.A.this
                android.graphics.Rect r0 = r0.f1087h
                int r0 = r0.right
                goto L_0x002e
            L_0x001c:
                androidx.appcompat.widget.A r0 = androidx.appcompat.widget.A.this
                android.graphics.Rect r0 = r0.f1087h
                int r0 = r0.left
                int r0 = -r0
                goto L_0x002e
            L_0x0024:
                androidx.appcompat.widget.A r0 = androidx.appcompat.widget.A.this
                android.graphics.Rect r0 = r0.f1087h
                r1 = 0
                r0.right = r1
                r0.left = r1
                r0 = 0
            L_0x002e:
                androidx.appcompat.widget.A r1 = androidx.appcompat.widget.A.this
                int r1 = r1.getPaddingLeft()
                androidx.appcompat.widget.A r2 = androidx.appcompat.widget.A.this
                int r2 = r2.getPaddingRight()
                androidx.appcompat.widget.A r3 = androidx.appcompat.widget.A.this
                int r3 = r3.getWidth()
                androidx.appcompat.widget.A r4 = androidx.appcompat.widget.A.this
                int r5 = r4.f1086g
                r6 = -2
                if (r5 != r6) goto L_0x007b
                android.widget.ListAdapter r5 = r8.f1098K
                android.widget.SpinnerAdapter r5 = (android.widget.SpinnerAdapter) r5
                android.graphics.drawable.Drawable r6 = r8.i()
                int r4 = r4.a(r5, r6)
                androidx.appcompat.widget.A r5 = androidx.appcompat.widget.A.this
                android.content.Context r5 = r5.getContext()
                android.content.res.Resources r5 = r5.getResources()
                android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
                int r5 = r5.widthPixels
                androidx.appcompat.widget.A r6 = androidx.appcompat.widget.A.this
                android.graphics.Rect r6 = r6.f1087h
                int r7 = r6.left
                int r5 = r5 - r7
                int r6 = r6.right
                int r5 = r5 - r6
                if (r4 <= r5) goto L_0x0070
                r4 = r5
            L_0x0070:
                int r5 = r3 - r1
                int r5 = r5 - r2
                int r4 = java.lang.Math.max(r4, r5)
            L_0x0077:
                r8.F(r4)
                goto L_0x0085
            L_0x007b:
                r4 = -1
                if (r5 != r4) goto L_0x0082
                int r4 = r3 - r1
                int r4 = r4 - r2
                goto L_0x0077
            L_0x0082:
                r8.F(r5)
            L_0x0085:
                androidx.appcompat.widget.A r4 = androidx.appcompat.widget.A.this
                boolean r4 = androidx.appcompat.widget.p0.b(r4)
                if (r4 == 0) goto L_0x009a
                int r3 = r3 - r2
                int r1 = r8.z()
                int r3 = r3 - r1
                int r1 = r8.U()
                int r3 = r3 - r1
                int r0 = r0 + r3
                goto L_0x00a0
            L_0x009a:
                int r2 = r8.U()
                int r1 = r1 + r2
                int r0 = r0 + r1
            L_0x00a0:
                r8.c(r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.A.f.T():void");
        }

        public int U() {
            return this.f1100M;
        }

        /* access modifiers changed from: package-private */
        public boolean V(View view) {
            return view.isAttachedToWindow() && view.getGlobalVisibleRect(this.f1099L);
        }

        public void e(int i2, int i3) {
            ViewTreeObserver viewTreeObserver;
            boolean b2 = b();
            T();
            I(2);
            super.f();
            ListView k2 = k();
            k2.setChoiceMode(1);
            k2.setTextDirection(i2);
            k2.setTextAlignment(i3);
            Q(A.this.getSelectedItemPosition());
            if (!b2 && (viewTreeObserver = A.this.getViewTreeObserver()) != null) {
                b bVar = new b();
                viewTreeObserver.addOnGlobalLayoutListener(bVar);
                K(new c(bVar));
            }
        }

        public CharSequence j() {
            return this.f1097J;
        }

        public void l(CharSequence charSequence) {
            this.f1097J = charSequence;
        }

        public void o(ListAdapter listAdapter) {
            super.o(listAdapter);
            this.f1098K = listAdapter;
        }

        public void p(int i2) {
            this.f1100M = i2;
        }
    }

    static class g extends View.BaseSavedState {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: a  reason: collision with root package name */
        boolean f1107a;

        class a implements Parcelable.Creator {
            a() {
            }

            /* renamed from: a */
            public g createFromParcel(Parcel parcel) {
                return new g(parcel);
            }

            /* renamed from: b */
            public g[] newArray(int i2) {
                return new g[i2];
            }
        }

        g(Parcel parcel) {
            super(parcel);
            this.f1107a = parcel.readByte() != 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeByte(this.f1107a ? (byte) 1 : 0);
        }

        g(Parcelable parcelable) {
            super(parcelable);
        }
    }

    interface h {
        boolean b();

        void c(int i2);

        int d();

        void dismiss();

        void e(int i2, int i3);

        int g();

        Drawable i();

        CharSequence j();

        void l(CharSequence charSequence);

        void m(Drawable drawable);

        void n(int i2);

        void o(ListAdapter listAdapter);

        void p(int i2);
    }

    public A(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.spinnerStyle);
    }

    /* access modifiers changed from: package-private */
    public int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i2 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i3 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i2) {
                view = null;
                i2 = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i3 = Math.max(i3, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i3;
        }
        drawable.getPadding(this.f1087h);
        Rect rect = this.f1087h;
        return i3 + rect.left + rect.right;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        this.f1085f.e(getTextDirection(), getTextAlignment());
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            eVar.b();
        }
    }

    public int getDropDownHorizontalOffset() {
        h hVar = this.f1085f;
        return hVar != null ? hVar.d() : super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        h hVar = this.f1085f;
        return hVar != null ? hVar.g() : super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        return this.f1085f != null ? this.f1086g : super.getDropDownWidth();
    }

    /* access modifiers changed from: package-private */
    public final h getInternalPopup() {
        return this.f1085f;
    }

    public Drawable getPopupBackground() {
        h hVar = this.f1085f;
        return hVar != null ? hVar.i() : super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.f1081b;
    }

    public CharSequence getPrompt() {
        h hVar = this.f1085f;
        return hVar != null ? hVar.j() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h hVar = this.f1085f;
        if (hVar != null && hVar.b()) {
            this.f1085f.dismiss();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f1085f != null && View.MeasureSpec.getMode(i2) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i2)), getMeasuredHeight());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.getSuperState());
        if (gVar.f1107a && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new b());
        }
    }

    public Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        h hVar = this.f1085f;
        gVar.f1107a = hVar != null && hVar.b();
        return gVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        Q q2 = this.f1082c;
        if (q2 == null || !q2.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public boolean performClick() {
        h hVar = this.f1085f;
        if (hVar == null) {
            return super.performClick();
        }
        if (hVar.b()) {
            return true;
        }
        b();
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setDropDownHorizontalOffset(int i2) {
        h hVar = this.f1085f;
        if (hVar != null) {
            hVar.p(i2);
            this.f1085f.c(i2);
            return;
        }
        super.setDropDownHorizontalOffset(i2);
    }

    public void setDropDownVerticalOffset(int i2) {
        h hVar = this.f1085f;
        if (hVar != null) {
            hVar.n(i2);
        } else {
            super.setDropDownVerticalOffset(i2);
        }
    }

    public void setDropDownWidth(int i2) {
        if (this.f1085f != null) {
            this.f1086g = i2;
        } else {
            super.setDropDownWidth(i2);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        h hVar = this.f1085f;
        if (hVar != null) {
            hVar.m(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i2) {
        setPopupBackgroundDrawable(C0236a.b(getPopupContext(), i2));
    }

    public void setPrompt(CharSequence charSequence) {
        h hVar = this.f1085f;
        if (hVar != null) {
            hVar.l(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1080a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public A(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, -1);
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f1084e) {
            this.f1083d = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f1085f != null) {
            Context context = this.f1081b;
            if (context == null) {
                context = getContext();
            }
            this.f1085f.o(new e(spinnerAdapter, context.getTheme()));
        }
    }

    public A(Context context, AttributeSet attributeSet, int i2, int i3) {
        this(context, attributeSet, i2, i3, (Resources.Theme) null);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0062, code lost:
        if (r11 != null) goto L_0x0053;
     */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x003d A[SYNTHETIC, Splitter:B:10:0x003d] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0067  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x006e  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00a8  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00d9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public A(android.content.Context r7, android.util.AttributeSet r8, int r9, int r10, android.content.res.Resources.Theme r11) {
        /*
            r6 = this;
            r6.<init>(r7, r8, r9)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r6.f1087h = r0
            android.content.Context r0 = r6.getContext()
            androidx.appcompat.widget.a0.a(r6, r0)
            int[] r0 = e.j.o2
            r1 = 0
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.e0.v(r7, r8, r0, r9, r1)
            androidx.appcompat.widget.e r2 = new androidx.appcompat.widget.e
            r2.<init>(r6)
            r6.f1080a = r2
            if (r11 == 0) goto L_0x0029
            androidx.appcompat.view.d r2 = new androidx.appcompat.view.d
            r2.<init>((android.content.Context) r7, (android.content.res.Resources.Theme) r11)
        L_0x0026:
            r6.f1081b = r2
            goto L_0x0039
        L_0x0029:
            int r11 = e.j.t2
            int r11 = r0.n(r11, r1)
            if (r11 == 0) goto L_0x0037
            androidx.appcompat.view.d r2 = new androidx.appcompat.view.d
            r2.<init>((android.content.Context) r7, (int) r11)
            goto L_0x0026
        L_0x0037:
            r6.f1081b = r7
        L_0x0039:
            r11 = -1
            r2 = 0
            if (r10 != r11) goto L_0x006b
            int[] r11 = f1079i     // Catch:{ Exception -> 0x0059, all -> 0x0057 }
            android.content.res.TypedArray r11 = r7.obtainStyledAttributes(r8, r11, r9, r1)     // Catch:{ Exception -> 0x0059, all -> 0x0057 }
            boolean r3 = r11.hasValue(r1)     // Catch:{ Exception -> 0x0051 }
            if (r3 == 0) goto L_0x0053
            int r10 = r11.getInt(r1, r1)     // Catch:{ Exception -> 0x0051 }
            goto L_0x0053
        L_0x004e:
            r7 = move-exception
            r2 = r11
            goto L_0x0065
        L_0x0051:
            r3 = move-exception
            goto L_0x005b
        L_0x0053:
            r11.recycle()
            goto L_0x006b
        L_0x0057:
            r7 = move-exception
            goto L_0x0065
        L_0x0059:
            r3 = move-exception
            r11 = r2
        L_0x005b:
            java.lang.String r4 = "AppCompatSpinner"
            java.lang.String r5 = "Could not read android:spinnerMode"
            android.util.Log.i(r4, r5, r3)     // Catch:{ all -> 0x004e }
            if (r11 == 0) goto L_0x006b
            goto L_0x0053
        L_0x0065:
            if (r2 == 0) goto L_0x006a
            r2.recycle()
        L_0x006a:
            throw r7
        L_0x006b:
            r11 = 1
            if (r10 == 0) goto L_0x00a8
            if (r10 == r11) goto L_0x0071
            goto L_0x00b8
        L_0x0071:
            androidx.appcompat.widget.A$f r10 = new androidx.appcompat.widget.A$f
            android.content.Context r3 = r6.f1081b
            r10.<init>(r3, r8, r9)
            android.content.Context r3 = r6.f1081b
            int[] r4 = e.j.o2
            androidx.appcompat.widget.e0 r1 = androidx.appcompat.widget.e0.v(r3, r8, r4, r9, r1)
            int r3 = e.j.s2
            r4 = -2
            int r3 = r1.m(r3, r4)
            r6.f1086g = r3
            int r3 = e.j.q2
            android.graphics.drawable.Drawable r3 = r1.g(r3)
            r10.m(r3)
            int r3 = e.j.r2
            java.lang.String r3 = r0.o(r3)
            r10.l(r3)
            r1.x()
            r6.f1085f = r10
            androidx.appcompat.widget.A$a r1 = new androidx.appcompat.widget.A$a
            r1.<init>(r6, r10)
            r6.f1082c = r1
            goto L_0x00b8
        L_0x00a8:
            androidx.appcompat.widget.A$d r10 = new androidx.appcompat.widget.A$d
            r10.<init>()
            r6.f1085f = r10
            int r1 = e.j.r2
            java.lang.String r1 = r0.o(r1)
            r10.l(r1)
        L_0x00b8:
            int r10 = e.j.p2
            java.lang.CharSequence[] r10 = r0.q(r10)
            if (r10 == 0) goto L_0x00d0
            android.widget.ArrayAdapter r1 = new android.widget.ArrayAdapter
            r3 = 17367048(0x1090008, float:2.5162948E-38)
            r1.<init>(r7, r3, r10)
            int r7 = e.g.support_simple_spinner_dropdown_item
            r1.setDropDownViewResource(r7)
            r6.setAdapter((android.widget.SpinnerAdapter) r1)
        L_0x00d0:
            r0.x()
            r6.f1084e = r11
            android.widget.SpinnerAdapter r7 = r6.f1083d
            if (r7 == 0) goto L_0x00de
            r6.setAdapter((android.widget.SpinnerAdapter) r7)
            r6.f1083d = r2
        L_0x00de:
            androidx.appcompat.widget.e r7 = r6.f1080a
            r7.e(r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.A.<init>(android.content.Context, android.util.AttributeSet, int, int, android.content.res.Resources$Theme):void");
    }
}
