package androidx.appcompat.widget;

public final /* synthetic */ class f0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Toolbar f1509a;

    public /* synthetic */ f0(Toolbar toolbar) {
        this.f1509a = toolbar;
    }

    public final void run() {
        this.f1509a.e();
    }
}
