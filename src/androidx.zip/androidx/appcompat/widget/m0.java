package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.C0122a0;
import androidx.core.view.W;

class m0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: k  reason: collision with root package name */
    private static m0 f1574k;

    /* renamed from: l  reason: collision with root package name */
    private static m0 f1575l;

    /* renamed from: a  reason: collision with root package name */
    private final View f1576a;

    /* renamed from: b  reason: collision with root package name */
    private final CharSequence f1577b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1578c;

    /* renamed from: d  reason: collision with root package name */
    private final Runnable f1579d = new k0(this);

    /* renamed from: e  reason: collision with root package name */
    private final Runnable f1580e = new l0(this);

    /* renamed from: f  reason: collision with root package name */
    private int f1581f;

    /* renamed from: g  reason: collision with root package name */
    private int f1582g;

    /* renamed from: h  reason: collision with root package name */
    private n0 f1583h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f1584i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f1585j;

    private m0(View view, CharSequence charSequence) {
        this.f1576a = view;
        this.f1577b = charSequence;
        this.f1578c = C0122a0.g(ViewConfiguration.get(view.getContext()));
        c();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    private void b() {
        this.f1576a.removeCallbacks(this.f1579d);
    }

    private void c() {
        this.f1585j = true;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void e() {
        i(false);
    }

    private void f() {
        this.f1576a.postDelayed(this.f1579d, (long) ViewConfiguration.getLongPressTimeout());
    }

    private static void g(m0 m0Var) {
        m0 m0Var2 = f1574k;
        if (m0Var2 != null) {
            m0Var2.b();
        }
        f1574k = m0Var;
        if (m0Var != null) {
            m0Var.f();
        }
    }

    public static void h(View view, CharSequence charSequence) {
        m0 m0Var = f1574k;
        if (m0Var != null && m0Var.f1576a == view) {
            g((m0) null);
        }
        if (TextUtils.isEmpty(charSequence)) {
            m0 m0Var2 = f1575l;
            if (m0Var2 != null && m0Var2.f1576a == view) {
                m0Var2.d();
            }
            view.setOnLongClickListener((View.OnLongClickListener) null);
            view.setLongClickable(false);
            view.setOnHoverListener((View.OnHoverListener) null);
            return;
        }
        new m0(view, charSequence);
    }

    private boolean j(MotionEvent motionEvent) {
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        if (!this.f1585j && Math.abs(x2 - this.f1581f) <= this.f1578c && Math.abs(y2 - this.f1582g) <= this.f1578c) {
            return false;
        }
        this.f1581f = x2;
        this.f1582g = y2;
        this.f1585j = false;
        return true;
    }

    /* access modifiers changed from: package-private */
    public void d() {
        if (f1575l == this) {
            f1575l = null;
            n0 n0Var = this.f1583h;
            if (n0Var != null) {
                n0Var.c();
                this.f1583h = null;
                c();
                this.f1576a.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1574k == this) {
            g((m0) null);
        }
        this.f1576a.removeCallbacks(this.f1580e);
    }

    /* access modifiers changed from: package-private */
    public void i(boolean z2) {
        long j2;
        long longPressTimeout;
        long j3;
        if (this.f1576a.isAttachedToWindow()) {
            g((m0) null);
            m0 m0Var = f1575l;
            if (m0Var != null) {
                m0Var.d();
            }
            f1575l = this;
            this.f1584i = z2;
            n0 n0Var = new n0(this.f1576a.getContext());
            this.f1583h = n0Var;
            n0Var.e(this.f1576a, this.f1581f, this.f1582g, this.f1584i, this.f1577b);
            this.f1576a.addOnAttachStateChangeListener(this);
            if (this.f1584i) {
                j2 = 2500;
            } else {
                if ((W.N(this.f1576a) & 1) == 1) {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 3000;
                } else {
                    longPressTimeout = (long) ViewConfiguration.getLongPressTimeout();
                    j3 = 15000;
                }
                j2 = j3 - longPressTimeout;
            }
            this.f1576a.removeCallbacks(this.f1580e);
            this.f1576a.postDelayed(this.f1580e, j2);
        }
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.f1583h != null && this.f1584i) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f1576a.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                c();
                d();
            }
        } else if (this.f1576a.isEnabled() && this.f1583h == null && j(motionEvent)) {
            g(this);
        }
        return false;
    }

    public boolean onLongClick(View view) {
        this.f1581f = view.getWidth() / 2;
        this.f1582g = view.getHeight() / 2;
        i(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        d();
    }
}
