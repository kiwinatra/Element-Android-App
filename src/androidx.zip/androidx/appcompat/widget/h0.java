package androidx.appcompat.widget;

import android.window.OnBackInvokedCallback;

public final /* synthetic */ class h0 implements OnBackInvokedCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Runnable f1519a;

    public /* synthetic */ h0(Runnable runnable) {
        this.f1519a = runnable;
    }

    public final void onBackInvoked() {
        this.f1519a.run();
    }
}
