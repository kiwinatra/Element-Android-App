package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.e;

public interface U {
    void a(e eVar, MenuItem menuItem);

    void h(e eVar, MenuItem menuItem);
}
