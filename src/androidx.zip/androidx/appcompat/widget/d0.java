package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

class d0 extends X {

    /* renamed from: b  reason: collision with root package name */
    private final WeakReference f1496b;

    public d0(Context context, Resources resources) {
        super(resources);
        this.f1496b = new WeakReference(context);
    }

    public Drawable getDrawable(int i2) {
        Drawable a2 = a(i2);
        Context context = (Context) this.f1496b.get();
        if (!(a2 == null || context == null)) {
            W.h().x(context, i2, a2);
        }
        return a2;
    }
}
