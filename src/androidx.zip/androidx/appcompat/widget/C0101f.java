package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import androidx.core.widget.j;
import androidx.core.widget.n;
import e.C0233a;

/* renamed from: androidx.appcompat.widget.f  reason: case insensitive filesystem */
public class C0101f extends Button implements n {

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1506a;

    /* renamed from: b  reason: collision with root package name */
    private final E f1507b;

    /* renamed from: c  reason: collision with root package name */
    private C0109n f1508c;

    public C0101f(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.buttonStyle);
    }

    private C0109n getEmojiTextViewHelper() {
        if (this.f1508c == null) {
            this.f1508c = new C0109n(this);
        }
        return this.f1508c;
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (p0.f1602c) {
            return super.getAutoSizeMaxTextSize();
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            return e2.e();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (p0.f1602c) {
            return super.getAutoSizeMinTextSize();
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            return e2.f();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (p0.f1602c) {
            return super.getAutoSizeStepGranularity();
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            return e2.g();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (p0.f1602c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        E e2 = this.f1507b;
        return e2 != null ? e2.h() : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (p0.f1602c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            return e2.i();
        }
        return 0;
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return j.q(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1507b.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1507b.k();
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.o(z2, i2, i3, i4, i5);
        }
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        E e2 = this.f1507b;
        if (e2 != null && !p0.f1602c && e2.l()) {
            this.f1507b.c();
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (p0.f1602c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.t(i2, i3, i4, i5);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (p0.f1602c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.u(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (p0.f1602c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.v(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(j.r(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.s(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1506a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1507b.w(colorStateList);
        this.f1507b.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1507b.x(mode);
        this.f1507b.b();
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.q(context, i2);
        }
    }

    public void setTextSize(int i2, float f2) {
        if (p0.f1602c) {
            super.setTextSize(i2, f2);
            return;
        }
        E e2 = this.f1507b;
        if (e2 != null) {
            e2.A(i2, f2);
        }
    }

    public C0101f(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        a0.a(this, getContext());
        C0100e eVar = new C0100e(this);
        this.f1506a = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1507b = e2;
        e2.m(attributeSet, i2);
        e2.b();
        getEmojiTextViewHelper().b(attributeSet, i2);
    }
}
