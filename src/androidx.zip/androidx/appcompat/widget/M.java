package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.C0130e0;

public interface M {
    void a(Menu menu, j.a aVar);

    boolean b();

    boolean c();

    void collapseActionView();

    boolean d();

    boolean e();

    void f();

    boolean g();

    CharSequence getTitle();

    void h();

    void i(j.a aVar, e.a aVar2);

    int j();

    void k(int i2);

    Menu l();

    void m(int i2);

    void n(Z z2);

    ViewGroup o();

    void p(int i2);

    void q(boolean z2);

    Context r();

    int s();

    void setIcon(int i2);

    void setIcon(Drawable drawable);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    C0130e0 t(int i2, long j2);

    void u();

    boolean v();

    void w();

    void x(Drawable drawable);

    void y(boolean z2);

    void z(int i2);
}
