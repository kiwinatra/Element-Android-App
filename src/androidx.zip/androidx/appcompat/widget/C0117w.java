package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;
import e.C0233a;

/* renamed from: androidx.appcompat.widget.w  reason: case insensitive filesystem */
public class C0117w extends RatingBar {

    /* renamed from: a  reason: collision with root package name */
    private final C0115u f1624a;

    public C0117w(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.ratingBarStyle);
    }

    /* access modifiers changed from: protected */
    public synchronized void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        Bitmap b2 = this.f1624a.b();
        if (b2 != null) {
            setMeasuredDimension(View.resolveSizeAndState(b2.getWidth() * getNumStars(), i2, 0), getMeasuredHeight());
        }
    }

    public C0117w(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        a0.a(this, getContext());
        C0115u uVar = new C0115u(this);
        this.f1624a = uVar;
        uVar.c(attributeSet, i2);
    }
}
