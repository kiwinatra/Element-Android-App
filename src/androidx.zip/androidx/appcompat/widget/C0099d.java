package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import androidx.core.widget.j;
import androidx.core.widget.n;
import e.C0233a;
import f.C0236a;

/* renamed from: androidx.appcompat.widget.d  reason: case insensitive filesystem */
public class C0099d extends AutoCompleteTextView implements n {

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f1492d = {16843126};

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1493a;

    /* renamed from: b  reason: collision with root package name */
    private final E f1494b;

    /* renamed from: c  reason: collision with root package name */
    private final C0108m f1495c;

    public C0099d(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.f5287m);
    }

    /* access modifiers changed from: package-private */
    public void a(C0108m mVar) {
        KeyListener keyListener = getKeyListener();
        if (mVar.b(keyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a2 = mVar.a(keyListener);
            if (a2 != keyListener) {
                super.setKeyListener(a2);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1494b;
        if (e2 != null) {
            e2.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return j.q(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1494b.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1494b.k();
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        return this.f1495c.d(C0110o.a(super.onCreateInputConnection(editorInfo), editorInfo, this), editorInfo);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1494b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1494b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(j.r(this, callback));
    }

    public void setDropDownBackgroundResource(int i2) {
        setDropDownBackgroundDrawable(C0236a.b(getContext(), i2));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1495c.e(z2);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1495c.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1493a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1494b.w(colorStateList);
        this.f1494b.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1494b.x(mode);
        this.f1494b.b();
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        E e2 = this.f1494b;
        if (e2 != null) {
            e2.q(context, i2);
        }
    }

    public C0099d(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        a0.a(this, getContext());
        e0 v2 = e0.v(getContext(), attributeSet, f1492d, i2, 0);
        if (v2.s(0)) {
            setDropDownBackgroundDrawable(v2.g(0));
        }
        v2.x();
        C0100e eVar = new C0100e(this);
        this.f1493a = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1494b = e2;
        e2.m(attributeSet, i2);
        e2.b();
        C0108m mVar = new C0108m(this);
        this.f1495c = mVar;
        mVar.c(attributeSet, i2);
        a(mVar);
    }
}
