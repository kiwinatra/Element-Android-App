package androidx.appcompat.widget;

import H.a;
import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import e.j;

/* renamed from: androidx.appcompat.widget.m  reason: case insensitive filesystem */
class C0108m {

    /* renamed from: a  reason: collision with root package name */
    private final EditText f1572a;

    /* renamed from: b  reason: collision with root package name */
    private final a f1573b;

    C0108m(EditText editText) {
        this.f1572a = editText;
        this.f1573b = new a(editText, false);
    }

    /* access modifiers changed from: package-private */
    public KeyListener a(KeyListener keyListener) {
        return b(keyListener) ? this.f1573b.a(keyListener) : keyListener;
    }

    /* access modifiers changed from: package-private */
    public boolean b(KeyListener keyListener) {
        return !(keyListener instanceof NumberKeyListener);
    }

    /* JADX INFO: finally extract failed */
    /* access modifiers changed from: package-private */
    public void c(AttributeSet attributeSet, int i2) {
        TypedArray obtainStyledAttributes = this.f1572a.getContext().obtainStyledAttributes(attributeSet, j.f5334g0, i2, 0);
        try {
            int i3 = j.f5362u0;
            boolean z2 = true;
            if (obtainStyledAttributes.hasValue(i3)) {
                z2 = obtainStyledAttributes.getBoolean(i3, true);
            }
            obtainStyledAttributes.recycle();
            e(z2);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public InputConnection d(InputConnection inputConnection, EditorInfo editorInfo) {
        return this.f1573b.b(inputConnection, editorInfo);
    }

    /* access modifiers changed from: package-private */
    public void e(boolean z2) {
        this.f1573b.c(z2);
    }
}
