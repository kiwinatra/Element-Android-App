package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.C0130e0;
import androidx.core.view.C0132f0;
import androidx.core.view.W;
import e.C0233a;
import e.j;

/* renamed from: androidx.appcompat.widget.a  reason: case insensitive filesystem */
abstract class C0096a extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    protected final C0018a f1432a = new C0018a();

    /* renamed from: b  reason: collision with root package name */
    protected final Context f1433b;

    /* renamed from: c  reason: collision with root package name */
    protected ActionMenuView f1434c;

    /* renamed from: d  reason: collision with root package name */
    protected C0098c f1435d;

    /* renamed from: e  reason: collision with root package name */
    protected int f1436e;

    /* renamed from: f  reason: collision with root package name */
    protected C0130e0 f1437f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1438g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1439h;

    /* renamed from: androidx.appcompat.widget.a$a  reason: collision with other inner class name */
    protected class C0018a implements C0132f0 {

        /* renamed from: a  reason: collision with root package name */
        private boolean f1440a = false;

        /* renamed from: b  reason: collision with root package name */
        int f1441b;

        protected C0018a() {
        }

        public void a(View view) {
            if (!this.f1440a) {
                C0096a aVar = C0096a.this;
                aVar.f1437f = null;
                C0096a.super.setVisibility(this.f1441b);
            }
        }

        public void b(View view) {
            C0096a.super.setVisibility(0);
            this.f1440a = false;
        }

        public void c(View view) {
            this.f1440a = true;
        }

        public C0018a d(C0130e0 e0Var, int i2) {
            C0096a.this.f1437f = e0Var;
            this.f1441b = i2;
            return this;
        }
    }

    C0096a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(C0233a.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f1433b = context;
        } else {
            this.f1433b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    protected static int d(int i2, int i3, boolean z2) {
        return z2 ? i2 - i3 : i2 + i3;
    }

    /* access modifiers changed from: protected */
    public int c(View view, int i2, int i3, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, (i2 - view.getMeasuredWidth()) - i4);
    }

    /* access modifiers changed from: protected */
    public int e(View view, int i2, int i3, int i4, boolean z2) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = i3 + ((i4 - measuredHeight) / 2);
        if (z2) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        return z2 ? -measuredWidth : measuredWidth;
    }

    public C0130e0 f(int i2, long j2) {
        C0130e0 b2;
        C0130e0 e0Var = this.f1437f;
        if (e0Var != null) {
            e0Var.c();
        }
        if (i2 == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            b2 = W.e(this).b(1.0f);
        } else {
            b2 = W.e(this).b(0.0f);
        }
        b2.f(j2);
        b2.h(this.f1432a.d(b2, i2));
        return b2;
    }

    public int getAnimatedVisibility() {
        return this.f1437f != null ? this.f1432a.f1441b : getVisibility();
    }

    public int getContentHeight() {
        return this.f1436e;
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes((AttributeSet) null, j.f5321a, C0233a.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(j.f5339j, 0));
        obtainStyledAttributes.recycle();
        C0098c cVar = this.f1435d;
        if (cVar != null) {
            cVar.I(configuration);
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1439h = false;
        }
        if (!this.f1439h) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1439h = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1439h = false;
        }
        return true;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1438g = false;
        }
        if (!this.f1438g) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1438g = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1438g = false;
        }
        return true;
    }

    public abstract void setContentHeight(int i2);

    public void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            C0130e0 e0Var = this.f1437f;
            if (e0Var != null) {
                e0Var.c();
            }
            super.setVisibility(i2);
        }
    }
}
