package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.core.view.W;
import androidx.core.widget.e;
import e.j;
import f.C0236a;

/* renamed from: androidx.appcompat.widget.q  reason: case insensitive filesystem */
public class C0112q {

    /* renamed from: a  reason: collision with root package name */
    private final ImageView f1603a;

    /* renamed from: b  reason: collision with root package name */
    private c0 f1604b;

    /* renamed from: c  reason: collision with root package name */
    private c0 f1605c;

    /* renamed from: d  reason: collision with root package name */
    private c0 f1606d;

    /* renamed from: e  reason: collision with root package name */
    private int f1607e = 0;

    public C0112q(ImageView imageView) {
        this.f1603a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.f1606d == null) {
            this.f1606d = new c0();
        }
        c0 c0Var = this.f1606d;
        c0Var.a();
        ColorStateList a2 = e.a(this.f1603a);
        if (a2 != null) {
            c0Var.f1491d = true;
            c0Var.f1488a = a2;
        }
        PorterDuff.Mode b2 = e.b(this.f1603a);
        if (b2 != null) {
            c0Var.f1490c = true;
            c0Var.f1489b = b2;
        }
        if (!c0Var.f1491d && !c0Var.f1490c) {
            return false;
        }
        C0106k.i(drawable, c0Var, this.f1603a.getDrawableState());
        return true;
    }

    private boolean l() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f1604b != null : i2 == 21;
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (this.f1603a.getDrawable() != null) {
            this.f1603a.getDrawable().setLevel(this.f1607e);
        }
    }

    /* access modifiers changed from: package-private */
    public void c() {
        Drawable drawable = this.f1603a.getDrawable();
        if (drawable != null) {
            N.b(drawable);
        }
        if (drawable == null) {
            return;
        }
        if (!l() || !a(drawable)) {
            c0 c0Var = this.f1605c;
            if (c0Var != null) {
                C0106k.i(drawable, c0Var, this.f1603a.getDrawableState());
                return;
            }
            c0 c0Var2 = this.f1604b;
            if (c0Var2 != null) {
                C0106k.i(drawable, c0Var2, this.f1603a.getDrawableState());
            }
        }
    }

    /* access modifiers changed from: package-private */
    public ColorStateList d() {
        c0 c0Var = this.f1605c;
        if (c0Var != null) {
            return c0Var.f1488a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode e() {
        c0 c0Var = this.f1605c;
        if (c0Var != null) {
            return c0Var.f1489b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public boolean f() {
        return !(this.f1603a.getBackground() instanceof RippleDrawable);
    }

    public void g(AttributeSet attributeSet, int i2) {
        int n2;
        Context context = this.f1603a.getContext();
        int[] iArr = j.f5310P;
        e0 v2 = e0.v(context, attributeSet, iArr, i2, 0);
        ImageView imageView = this.f1603a;
        W.o0(imageView, imageView.getContext(), iArr, attributeSet, v2.r(), i2, 0);
        try {
            Drawable drawable = this.f1603a.getDrawable();
            if (!(drawable != null || (n2 = v2.n(j.f5311Q, -1)) == -1 || (drawable = C0236a.b(this.f1603a.getContext(), n2)) == null)) {
                this.f1603a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                N.b(drawable);
            }
            int i3 = j.f5312R;
            if (v2.s(i3)) {
                e.c(this.f1603a, v2.c(i3));
            }
            int i4 = j.f5313S;
            if (v2.s(i4)) {
                e.d(this.f1603a, N.d(v2.k(i4, -1), (PorterDuff.Mode) null));
            }
            v2.x();
        } catch (Throwable th) {
            v2.x();
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public void h(Drawable drawable) {
        this.f1607e = drawable.getLevel();
    }

    public void i(int i2) {
        if (i2 != 0) {
            Drawable b2 = C0236a.b(this.f1603a.getContext(), i2);
            if (b2 != null) {
                N.b(b2);
            }
            this.f1603a.setImageDrawable(b2);
        } else {
            this.f1603a.setImageDrawable((Drawable) null);
        }
        c();
    }

    /* access modifiers changed from: package-private */
    public void j(ColorStateList colorStateList) {
        if (this.f1605c == null) {
            this.f1605c = new c0();
        }
        c0 c0Var = this.f1605c;
        c0Var.f1488a = colorStateList;
        c0Var.f1491d = true;
        c();
    }

    /* access modifiers changed from: package-private */
    public void k(PorterDuff.Mode mode) {
        if (this.f1605c == null) {
            this.f1605c = new c0();
        }
        c0 c0Var = this.f1605c;
        c0Var.f1489b = mode;
        c0Var.f1490c = true;
        c();
    }
}
