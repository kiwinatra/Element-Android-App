package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import x.h;

final class D {

    /* renamed from: a  reason: collision with root package name */
    private TextView f1201a;

    /* renamed from: b  reason: collision with root package name */
    private TextClassifier f1202b;

    private static final class a {
        static TextClassifier a(TextView textView) {
            TextClassificationManager textClassificationManager = (TextClassificationManager) textView.getContext().getSystemService(TextClassificationManager.class);
            return textClassificationManager != null ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
        }
    }

    D(TextView textView) {
        this.f1201a = (TextView) h.g(textView);
    }

    public TextClassifier a() {
        TextClassifier textClassifier = this.f1202b;
        return textClassifier == null ? a.a(this.f1201a) : textClassifier;
    }

    public void b(TextClassifier textClassifier) {
        this.f1202b = textClassifier;
    }
}
