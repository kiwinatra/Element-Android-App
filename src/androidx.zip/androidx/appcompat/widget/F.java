package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.graphics.i;
import androidx.core.text.n;
import androidx.core.widget.j;
import androidx.core.widget.n;
import f.C0236a;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class F extends TextView implements n {

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1224a;

    /* renamed from: b  reason: collision with root package name */
    private final E f1225b;

    /* renamed from: c  reason: collision with root package name */
    private final D f1226c;

    /* renamed from: d  reason: collision with root package name */
    private C0109n f1227d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f1228e;

    /* renamed from: f  reason: collision with root package name */
    private a f1229f;

    /* renamed from: g  reason: collision with root package name */
    private Future f1230g;

    private interface a {
        void a(int[] iArr, int i2);

        void b(TextClassifier textClassifier);

        int c();

        int[] d();

        void e(int i2);

        void f(int i2);

        TextClassifier g();

        int h();

        int i();

        void j(int i2);

        void k(int i2, int i3, int i4, int i5);

        void l(int i2, float f2);

        int m();
    }

    class b implements a {
        b() {
        }

        public void a(int[] iArr, int i2) {
            F.super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
        }

        public void b(TextClassifier textClassifier) {
            F.super.setTextClassifier(textClassifier);
        }

        public int c() {
            return F.super.getAutoSizeMinTextSize();
        }

        public int[] d() {
            return F.super.getAutoSizeTextAvailableSizes();
        }

        public void e(int i2) {
        }

        public void f(int i2) {
        }

        public TextClassifier g() {
            return F.super.getTextClassifier();
        }

        public int h() {
            return F.super.getAutoSizeStepGranularity();
        }

        public int i() {
            return F.super.getAutoSizeMaxTextSize();
        }

        public void j(int i2) {
            F.super.setAutoSizeTextTypeWithDefaults(i2);
        }

        public void k(int i2, int i3, int i4, int i5) {
            F.super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
        }

        public void l(int i2, float f2) {
        }

        public int m() {
            return F.super.getAutoSizeTextType();
        }
    }

    class c extends b {
        c() {
            super();
        }

        public void e(int i2) {
            F.super.setLastBaselineToBottomHeight(i2);
        }

        public void f(int i2) {
            F.super.setFirstBaselineToTopHeight(i2);
        }
    }

    class d extends c {
        d() {
            super();
        }

        public void l(int i2, float f2) {
            F.super.setLineHeight(i2, f2);
        }
    }

    public F(Context context) {
        this(context, (AttributeSet) null);
    }

    private C0109n getEmojiTextViewHelper() {
        if (this.f1227d == null) {
            this.f1227d = new C0109n(this);
        }
        return this.f1227d;
    }

    private void r() {
        Future future = this.f1230g;
        if (future != null) {
            try {
                this.f1230g = null;
                android.support.v4.media.session.b.a(future.get());
                j.n(this, (androidx.core.text.n) null);
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (p0.f1602c) {
            return getSuperCaller().i();
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            return e2.e();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (p0.f1602c) {
            return getSuperCaller().c();
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            return e2.f();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (p0.f1602c) {
            return getSuperCaller().h();
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            return e2.g();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (p0.f1602c) {
            return getSuperCaller().d();
        }
        E e2 = this.f1225b;
        return e2 != null ? e2.h() : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (p0.f1602c) {
            return getSuperCaller().m() == 1 ? 1 : 0;
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            return e2.i();
        }
        return 0;
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return j.q(super.getCustomSelectionActionModeCallback());
    }

    public int getFirstBaselineToTopHeight() {
        return j.b(this);
    }

    public int getLastBaselineToBottomHeight() {
        return j.c(this);
    }

    /* access modifiers changed from: package-private */
    public a getSuperCaller() {
        a bVar;
        if (this.f1229f == null) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 34) {
                bVar = new d();
            } else if (i2 >= 28) {
                bVar = new c();
            } else if (i2 >= 26) {
                bVar = new b();
            }
            this.f1229f = bVar;
        }
        return this.f1229f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1225b.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1225b.k();
    }

    public CharSequence getText() {
        r();
        return super.getText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f1226c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            androidx.appcompat.widget.D r0 = r2.f1226c
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.a()
            return r0
        L_0x0010:
            androidx.appcompat.widget.F$a r0 = r2.getSuperCaller()
            android.view.textclassifier.TextClassifier r0 = r0.g()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.F.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public n.a getTextMetricsParamsCompat() {
        return j.f(this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f1225b.r(this, onCreateInputConnection, editorInfo);
        return C0110o.a(onCreateInputConnection, editorInfo, this);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33 && onCheckIsTextEditor()) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.o(z2, i2, i3, i4, i5);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        r();
        super.onMeasure(i2, i3);
    }

    /* access modifiers changed from: protected */
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        E e2 = this.f1225b;
        if (e2 != null && !p0.f1602c && e2.l()) {
            this.f1225b.c();
        }
    }

    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().c(z2);
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (p0.f1602c) {
            getSuperCaller().k(i2, i3, i4, i5);
            return;
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.t(i2, i3, i4, i5);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (p0.f1602c) {
            getSuperCaller().a(iArr, i2);
            return;
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.u(iArr, i2);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (p0.f1602c) {
            getSuperCaller().j(i2);
            return;
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.v(i2);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b2 = i2 != 0 ? C0236a.b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C0236a.b(context, i3) : null;
        Drawable b4 = i4 != 0 ? C0236a.b(context, i4) : null;
        if (i5 != 0) {
            drawable = C0236a.b(context, i5);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(b2, b3, b4, drawable);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b2 = i2 != 0 ? C0236a.b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C0236a.b(context, i3) : null;
        Drawable b4 = i4 != 0 ? C0236a.b(context, i4) : null;
        if (i5 != 0) {
            drawable = C0236a.b(context, i5);
        }
        setCompoundDrawablesWithIntrinsicBounds(b2, b3, b4, drawable);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(j.r(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().d(z2);
    }

    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setFirstBaselineToTopHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().f(i2);
        } else {
            j.j(this, i2);
        }
    }

    public void setLastBaselineToBottomHeight(int i2) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().e(i2);
        } else {
            j.k(this, i2);
        }
    }

    public void setLineHeight(int i2) {
        j.l(this, i2);
    }

    public void setPrecomputedText(androidx.core.text.n nVar) {
        j.n(this, nVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1224a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1225b.w(colorStateList);
        this.f1225b.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1225b.x(mode);
        this.f1225b.b();
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.q(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        D d2;
        if (Build.VERSION.SDK_INT >= 28 || (d2 = this.f1226c) == null) {
            getSuperCaller().b(textClassifier);
        } else {
            d2.b(textClassifier);
        }
    }

    public void setTextFuture(Future<androidx.core.text.n> future) {
        this.f1230g = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(n.a aVar) {
        j.p(this, aVar);
    }

    public void setTextSize(int i2, float f2) {
        if (p0.f1602c) {
            super.setTextSize(i2, f2);
            return;
        }
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.A(i2, f2);
        }
    }

    public void setTypeface(Typeface typeface, int i2) {
        if (!this.f1228e) {
            Typeface a2 = (typeface == null || i2 <= 0) ? null : i.a(getContext(), typeface, i2);
            this.f1228e = true;
            if (a2 != null) {
                typeface = a2;
            }
            try {
                super.setTypeface(typeface, i2);
            } finally {
                this.f1228e = false;
            }
        }
    }

    public F(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1225b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setLineHeight(int i2, float f2) {
        if (Build.VERSION.SDK_INT >= 34) {
            getSuperCaller().l(i2, f2);
        } else {
            j.m(this, i2, f2);
        }
    }

    public F(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        this.f1228e = false;
        this.f1229f = null;
        a0.a(this, getContext());
        C0100e eVar = new C0100e(this);
        this.f1224a = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1225b = e2;
        e2.m(attributeSet, i2);
        e2.b();
        this.f1226c = new D(this);
        getEmojiTextViewHelper().b(attributeSet, i2);
    }
}
