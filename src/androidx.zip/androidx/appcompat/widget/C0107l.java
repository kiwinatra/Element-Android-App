package androidx.appcompat.widget;

import B.c;
import B.e;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import androidx.core.view.C0127d;
import androidx.core.view.H;
import androidx.core.view.W;
import androidx.core.widget.j;
import androidx.core.widget.l;
import androidx.core.widget.n;
import e.C0233a;

/* renamed from: androidx.appcompat.widget.l  reason: case insensitive filesystem */
public class C0107l extends EditText implements H, n {

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1564a;

    /* renamed from: b  reason: collision with root package name */
    private final E f1565b;

    /* renamed from: c  reason: collision with root package name */
    private final D f1566c;

    /* renamed from: d  reason: collision with root package name */
    private final l f1567d;

    /* renamed from: e  reason: collision with root package name */
    private final C0108m f1568e;

    /* renamed from: f  reason: collision with root package name */
    private a f1569f;

    /* renamed from: androidx.appcompat.widget.l$a */
    class a {
        a() {
        }

        public TextClassifier a() {
            return C0107l.super.getTextClassifier();
        }

        public void b(TextClassifier textClassifier) {
            C0107l.super.setTextClassifier(textClassifier);
        }
    }

    public C0107l(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.f5284A);
    }

    private a getSuperCaller() {
        if (this.f1569f == null) {
            this.f1569f = new a();
        }
        return this.f1569f;
    }

    public C0127d a(C0127d dVar) {
        return this.f1567d.a(this, dVar);
    }

    /* access modifiers changed from: package-private */
    public void d(C0108m mVar) {
        KeyListener keyListener = getKeyListener();
        if (mVar.b(keyListener)) {
            boolean isFocusable = super.isFocusable();
            boolean isClickable = super.isClickable();
            boolean isLongClickable = super.isLongClickable();
            int inputType = super.getInputType();
            KeyListener a2 = mVar.a(keyListener);
            if (a2 != keyListener) {
                super.setKeyListener(a2);
                super.setRawInputType(inputType);
                super.setFocusable(isFocusable);
                super.setClickable(isClickable);
                super.setLongClickable(isLongClickable);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            eVar.b();
        }
        E e2 = this.f1565b;
        if (e2 != null) {
            e2.b();
        }
    }

    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return j.q(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1565b.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1565b.k();
    }

    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f1566c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            androidx.appcompat.widget.D r0 = r2.f1566c
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.a()
            return r0
        L_0x0010:
            androidx.appcompat.widget.l$a r0 = r2.getSuperCaller()
            android.view.textclassifier.TextClassifier r0 = r0.a()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.C0107l.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        String[] F2;
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f1565b.r(this, onCreateInputConnection, editorInfo);
        InputConnection a2 = C0110o.a(onCreateInputConnection, editorInfo, this);
        if (!(a2 == null || Build.VERSION.SDK_INT > 30 || (F2 = W.F(this)) == null)) {
            c.d(editorInfo, F2);
            a2 = e.c(this, a2, editorInfo);
        }
        return this.f1568e.d(a2, editorInfo);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 && i2 < 33) {
            ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
        }
    }

    public boolean onDragEvent(DragEvent dragEvent) {
        if (C0118x.a(this, dragEvent)) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    public boolean onTextContextMenuItem(int i2) {
        if (C0118x.b(this, i2)) {
            return true;
        }
        return super.onTextContextMenuItem(i2);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1565b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        E e2 = this.f1565b;
        if (e2 != null) {
            e2.p();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(j.r(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1568e.e(z2);
    }

    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1568e.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1564a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1565b.w(colorStateList);
        this.f1565b.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1565b.x(mode);
        this.f1565b.b();
    }

    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        E e2 = this.f1565b;
        if (e2 != null) {
            e2.q(context, i2);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        D d2;
        if (Build.VERSION.SDK_INT >= 28 || (d2 = this.f1566c) == null) {
            getSuperCaller().b(textClassifier);
        } else {
            d2.b(textClassifier);
        }
    }

    public C0107l(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        a0.a(this, getContext());
        C0100e eVar = new C0100e(this);
        this.f1564a = eVar;
        eVar.e(attributeSet, i2);
        E e2 = new E(this);
        this.f1565b = e2;
        e2.m(attributeSet, i2);
        e2.b();
        this.f1566c = new D(this);
        this.f1567d = new l();
        C0108m mVar = new C0108m(this);
        this.f1568e = mVar;
        mVar.c(attributeSet, i2);
        d(mVar);
    }
}
