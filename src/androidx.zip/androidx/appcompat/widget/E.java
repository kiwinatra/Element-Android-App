package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.LocaleList;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.core.content.res.h;
import e.j;
import java.lang.ref.WeakReference;
import java.util.Locale;

class E {

    /* renamed from: a  reason: collision with root package name */
    private final TextView f1203a;

    /* renamed from: b  reason: collision with root package name */
    private c0 f1204b;

    /* renamed from: c  reason: collision with root package name */
    private c0 f1205c;

    /* renamed from: d  reason: collision with root package name */
    private c0 f1206d;

    /* renamed from: e  reason: collision with root package name */
    private c0 f1207e;

    /* renamed from: f  reason: collision with root package name */
    private c0 f1208f;

    /* renamed from: g  reason: collision with root package name */
    private c0 f1209g;

    /* renamed from: h  reason: collision with root package name */
    private c0 f1210h;

    /* renamed from: i  reason: collision with root package name */
    private final G f1211i;

    /* renamed from: j  reason: collision with root package name */
    private int f1212j = 0;

    /* renamed from: k  reason: collision with root package name */
    private int f1213k = -1;

    /* renamed from: l  reason: collision with root package name */
    private Typeface f1214l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f1215m;

    class a extends h.e {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f1216a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f1217b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ WeakReference f1218c;

        a(int i2, int i3, WeakReference weakReference) {
            this.f1216a = i2;
            this.f1217b = i3;
            this.f1218c = weakReference;
        }

        public void h(int i2) {
        }

        public void i(Typeface typeface) {
            int i2;
            if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1216a) != -1) {
                typeface = f.a(typeface, i2, (this.f1217b & 2) != 0);
            }
            E.this.n(this.f1218c, typeface);
        }
    }

    class b implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ TextView f1220a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Typeface f1221b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ int f1222c;

        b(TextView textView, Typeface typeface, int i2) {
            this.f1220a = textView;
            this.f1221b = typeface;
            this.f1222c = i2;
        }

        public void run() {
            this.f1220a.setTypeface(this.f1221b, this.f1222c);
        }
    }

    static class c {
        static Locale a(String str) {
            return Locale.forLanguageTag(str);
        }
    }

    static class d {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }

        static void b(TextView textView, LocaleList localeList) {
            textView.setTextLocales(localeList);
        }
    }

    static class e {
        static int a(TextView textView) {
            return textView.getAutoSizeStepGranularity();
        }

        static void b(TextView textView, int i2, int i3, int i4, int i5) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
        }

        static void c(TextView textView, int[] iArr, int i2) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
        }

        static boolean d(TextView textView, String str) {
            return textView.setFontVariationSettings(str);
        }
    }

    static class f {
        static Typeface a(Typeface typeface, int i2, boolean z2) {
            return Typeface.create(typeface, i2, z2);
        }
    }

    E(TextView textView) {
        this.f1203a = textView;
        this.f1211i = new G(textView);
    }

    private void B(int i2, float f2) {
        this.f1211i.t(i2, f2);
    }

    private void C(Context context, e0 e0Var) {
        String o2;
        Typeface create;
        Typeface typeface;
        this.f1212j = e0Var.k(j.y2, this.f1212j);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 28) {
            int k2 = e0Var.k(j.D2, -1);
            this.f1213k = k2;
            if (k2 != -1) {
                this.f1212j &= 2;
            }
        }
        int i3 = j.C2;
        boolean z2 = true;
        if (e0Var.s(i3) || e0Var.s(j.E2)) {
            this.f1214l = null;
            int i4 = j.E2;
            if (e0Var.s(i4)) {
                i3 = i4;
            }
            int i5 = this.f1213k;
            int i6 = this.f1212j;
            if (!context.isRestricted()) {
                try {
                    Typeface j2 = e0Var.j(i3, this.f1212j, new a(i5, i6, new WeakReference(this.f1203a)));
                    if (j2 != null) {
                        if (i2 >= 28 && this.f1213k != -1) {
                            j2 = f.a(Typeface.create(j2, 0), this.f1213k, (this.f1212j & 2) != 0);
                        }
                        this.f1214l = j2;
                    }
                    this.f1215m = this.f1214l == null;
                } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
                }
            }
            if (this.f1214l == null && (o2 = e0Var.o(i3)) != null) {
                if (Build.VERSION.SDK_INT < 28 || this.f1213k == -1) {
                    create = Typeface.create(o2, this.f1212j);
                } else {
                    Typeface create2 = Typeface.create(o2, 0);
                    int i7 = this.f1213k;
                    if ((this.f1212j & 2) == 0) {
                        z2 = false;
                    }
                    create = f.a(create2, i7, z2);
                }
                this.f1214l = create;
                return;
            }
            return;
        }
        int i8 = j.x2;
        if (e0Var.s(i8)) {
            this.f1215m = false;
            int k3 = e0Var.k(i8, 1);
            if (k3 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (k3 == 2) {
                typeface = Typeface.SERIF;
            } else if (k3 == 3) {
                typeface = Typeface.MONOSPACE;
            } else {
                return;
            }
            this.f1214l = typeface;
        }
    }

    private void a(Drawable drawable, c0 c0Var) {
        if (drawable != null && c0Var != null) {
            C0106k.i(drawable, c0Var, this.f1203a.getDrawableState());
        }
    }

    private static c0 d(Context context, C0106k kVar, int i2) {
        ColorStateList f2 = kVar.f(context, i2);
        if (f2 == null) {
            return null;
        }
        c0 c0Var = new c0();
        c0Var.f1491d = true;
        c0Var.f1488a = f2;
        return c0Var;
    }

    private void y(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] compoundDrawablesRelative = this.f1203a.getCompoundDrawablesRelative();
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            TextView textView = this.f1203a;
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
        } else if (drawable != null || drawable2 != null || drawable3 != null || drawable4 != null) {
            Drawable[] compoundDrawablesRelative2 = this.f1203a.getCompoundDrawablesRelative();
            Drawable drawable7 = compoundDrawablesRelative2[0];
            if (drawable7 == null && compoundDrawablesRelative2[2] == null) {
                Drawable[] compoundDrawables = this.f1203a.getCompoundDrawables();
                TextView textView2 = this.f1203a;
                if (drawable == null) {
                    drawable = compoundDrawables[0];
                }
                if (drawable2 == null) {
                    drawable2 = compoundDrawables[1];
                }
                if (drawable3 == null) {
                    drawable3 = compoundDrawables[2];
                }
                if (drawable4 == null) {
                    drawable4 = compoundDrawables[3];
                }
                textView2.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
                return;
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative2[1];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative2[3];
            }
            this.f1203a.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, compoundDrawablesRelative2[2], drawable4);
        }
    }

    private void z() {
        c0 c0Var = this.f1210h;
        this.f1204b = c0Var;
        this.f1205c = c0Var;
        this.f1206d = c0Var;
        this.f1207e = c0Var;
        this.f1208f = c0Var;
        this.f1209g = c0Var;
    }

    /* access modifiers changed from: package-private */
    public void A(int i2, float f2) {
        if (!p0.f1602c && !l()) {
            B(i2, f2);
        }
    }

    /* access modifiers changed from: package-private */
    public void b() {
        if (!(this.f1204b == null && this.f1205c == null && this.f1206d == null && this.f1207e == null)) {
            Drawable[] compoundDrawables = this.f1203a.getCompoundDrawables();
            a(compoundDrawables[0], this.f1204b);
            a(compoundDrawables[1], this.f1205c);
            a(compoundDrawables[2], this.f1206d);
            a(compoundDrawables[3], this.f1207e);
        }
        if (this.f1208f != null || this.f1209g != null) {
            Drawable[] compoundDrawablesRelative = this.f1203a.getCompoundDrawablesRelative();
            a(compoundDrawablesRelative[0], this.f1208f);
            a(compoundDrawablesRelative[2], this.f1209g);
        }
    }

    /* access modifiers changed from: package-private */
    public void c() {
        this.f1211i.a();
    }

    /* access modifiers changed from: package-private */
    public int e() {
        return this.f1211i.f();
    }

    /* access modifiers changed from: package-private */
    public int f() {
        return this.f1211i.g();
    }

    /* access modifiers changed from: package-private */
    public int g() {
        return this.f1211i.h();
    }

    /* access modifiers changed from: package-private */
    public int[] h() {
        return this.f1211i.i();
    }

    /* access modifiers changed from: package-private */
    public int i() {
        return this.f1211i.j();
    }

    /* access modifiers changed from: package-private */
    public ColorStateList j() {
        c0 c0Var = this.f1210h;
        if (c0Var != null) {
            return c0Var.f1488a;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public PorterDuff.Mode k() {
        c0 c0Var = this.f1210h;
        if (c0Var != null) {
            return c0Var.f1489b;
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public boolean l() {
        return this.f1211i.n();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x01db  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x01e2  */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x021e  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0259  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x025f  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0268  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x026e  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x0277  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0286  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x028c  */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x0295  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x02a4  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x02aa  */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x02be  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x02cf  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02df  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x02f4  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x0316  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x031f  */
    /* JADX WARNING: Removed duplicated region for block: B:163:0x0326  */
    /* JADX WARNING: Removed duplicated region for block: B:166:0x032f  */
    /* JADX WARNING: Removed duplicated region for block: B:171:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00f7  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0102  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0107  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x010a  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x016e  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0176  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x0186  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x01a9  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x01b0  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x01b7  */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x01c7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m(android.util.AttributeSet r23, int r24) {
        /*
            r22 = this;
            r7 = r22
            r8 = r23
            r9 = r24
            android.widget.TextView r0 = r7.f1203a
            android.content.Context r10 = r0.getContext()
            androidx.appcompat.widget.k r11 = androidx.appcompat.widget.C0106k.b()
            int[] r2 = e.j.f5319Y
            r12 = 0
            androidx.appcompat.widget.e0 r13 = androidx.appcompat.widget.e0.v(r10, r8, r2, r9, r12)
            android.widget.TextView r0 = r7.f1203a
            android.content.Context r1 = r0.getContext()
            android.content.res.TypedArray r4 = r13.r()
            r6 = 0
            r3 = r23
            r5 = r24
            androidx.core.view.W.o0(r0, r1, r2, r3, r4, r5, r6)
            int r0 = e.j.f5320Z
            r14 = -1
            int r0 = r13.n(r0, r14)
            int r1 = e.j.f5326c0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x0042
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1204b = r1
        L_0x0042:
            int r1 = e.j.f5322a0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x0054
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1205c = r1
        L_0x0054:
            int r1 = e.j.f5328d0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x0066
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1206d = r1
        L_0x0066:
            int r1 = e.j.f5324b0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x0078
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1207e = r1
        L_0x0078:
            int r1 = e.j.f5330e0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x008a
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1208f = r1
        L_0x008a:
            int r1 = e.j.f5332f0
            boolean r2 = r13.s(r1)
            if (r2 == 0) goto L_0x009c
            int r1 = r13.n(r1, r12)
            androidx.appcompat.widget.c0 r1 = d(r10, r11, r1)
            r7.f1209g = r1
        L_0x009c:
            r13.x()
            android.widget.TextView r1 = r7.f1203a
            android.text.method.TransformationMethod r1 = r1.getTransformationMethod()
            boolean r1 = r1 instanceof android.text.method.PasswordTransformationMethod
            r2 = 26
            r3 = 23
            if (r0 == r14) goto L_0x011c
            int[] r5 = e.j.v2
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.e0.t(r10, r0, r5)
            if (r1 != 0) goto L_0x00c3
            int r5 = e.j.G2
            boolean r6 = r0.s(r5)
            if (r6 == 0) goto L_0x00c3
            boolean r5 = r0.a(r5, r12)
            r6 = 1
            goto L_0x00c5
        L_0x00c3:
            r5 = 0
            r6 = 0
        L_0x00c5:
            r7.C(r10, r0)
            int r15 = android.os.Build.VERSION.SDK_INT
            if (r15 >= r3) goto L_0x00f7
            int r4 = e.j.z2
            boolean r17 = r0.s(r4)
            if (r17 == 0) goto L_0x00d9
            android.content.res.ColorStateList r4 = r0.c(r4)
            goto L_0x00da
        L_0x00d9:
            r4 = 0
        L_0x00da:
            int r13 = e.j.A2
            boolean r18 = r0.s(r13)
            if (r18 == 0) goto L_0x00e7
            android.content.res.ColorStateList r13 = r0.c(r13)
            goto L_0x00e8
        L_0x00e7:
            r13 = 0
        L_0x00e8:
            int r14 = e.j.B2
            boolean r19 = r0.s(r14)
            if (r19 == 0) goto L_0x00f5
            android.content.res.ColorStateList r14 = r0.c(r14)
            goto L_0x00fa
        L_0x00f5:
            r14 = 0
            goto L_0x00fa
        L_0x00f7:
            r4 = 0
            r13 = 0
            goto L_0x00f5
        L_0x00fa:
            int r3 = e.j.H2
            boolean r20 = r0.s(r3)
            if (r20 == 0) goto L_0x0107
            java.lang.String r3 = r0.o(r3)
            goto L_0x0108
        L_0x0107:
            r3 = 0
        L_0x0108:
            if (r15 < r2) goto L_0x0117
            int r15 = e.j.F2
            boolean r20 = r0.s(r15)
            if (r20 == 0) goto L_0x0117
            java.lang.String r15 = r0.o(r15)
            goto L_0x0118
        L_0x0117:
            r15 = 0
        L_0x0118:
            r0.x()
            goto L_0x0123
        L_0x011c:
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r13 = 0
            r14 = 0
            r15 = 0
        L_0x0123:
            int[] r0 = e.j.v2
            androidx.appcompat.widget.e0 r0 = androidx.appcompat.widget.e0.v(r10, r8, r0, r9, r12)
            if (r1 != 0) goto L_0x013a
            int r2 = e.j.G2
            boolean r21 = r0.s(r2)
            if (r21 == 0) goto L_0x013a
            boolean r5 = r0.a(r2, r12)
            r16 = 1
            goto L_0x013c
        L_0x013a:
            r16 = r6
        L_0x013c:
            int r2 = android.os.Build.VERSION.SDK_INT
            r6 = 23
            if (r2 >= r6) goto L_0x0166
            int r6 = e.j.z2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x014e
            android.content.res.ColorStateList r4 = r0.c(r6)
        L_0x014e:
            int r6 = e.j.A2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x015a
            android.content.res.ColorStateList r13 = r0.c(r6)
        L_0x015a:
            int r6 = e.j.B2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x0166
            android.content.res.ColorStateList r14 = r0.c(r6)
        L_0x0166:
            int r6 = e.j.H2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x0172
            java.lang.String r3 = r0.o(r6)
        L_0x0172:
            r6 = 26
            if (r2 < r6) goto L_0x0182
            int r6 = e.j.F2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x0182
            java.lang.String r15 = r0.o(r6)
        L_0x0182:
            r6 = 28
            if (r2 < r6) goto L_0x019f
            int r6 = e.j.w2
            boolean r19 = r0.s(r6)
            if (r19 == 0) goto L_0x019f
            r12 = -1
            int r6 = r0.f(r6, r12)
            if (r6 != 0) goto L_0x019f
            android.widget.TextView r6 = r7.f1203a
            r12 = 0
            r20 = r11
            r11 = 0
            r6.setTextSize(r11, r12)
            goto L_0x01a1
        L_0x019f:
            r20 = r11
        L_0x01a1:
            r7.C(r10, r0)
            r0.x()
            if (r4 == 0) goto L_0x01ae
            android.widget.TextView r0 = r7.f1203a
            r0.setTextColor(r4)
        L_0x01ae:
            if (r13 == 0) goto L_0x01b5
            android.widget.TextView r0 = r7.f1203a
            r0.setHintTextColor(r13)
        L_0x01b5:
            if (r14 == 0) goto L_0x01bc
            android.widget.TextView r0 = r7.f1203a
            r0.setLinkTextColor(r14)
        L_0x01bc:
            if (r1 != 0) goto L_0x01c3
            if (r16 == 0) goto L_0x01c3
            r7.s(r5)
        L_0x01c3:
            android.graphics.Typeface r0 = r7.f1214l
            if (r0 == 0) goto L_0x01d9
            int r1 = r7.f1213k
            r4 = -1
            if (r1 != r4) goto L_0x01d4
            android.widget.TextView r1 = r7.f1203a
            int r4 = r7.f1212j
            r1.setTypeface(r0, r4)
            goto L_0x01d9
        L_0x01d4:
            android.widget.TextView r1 = r7.f1203a
            r1.setTypeface(r0)
        L_0x01d9:
            if (r15 == 0) goto L_0x01e0
            android.widget.TextView r0 = r7.f1203a
            androidx.appcompat.widget.E.e.d(r0, r15)
        L_0x01e0:
            if (r3 == 0) goto L_0x0202
            r0 = 24
            if (r2 < r0) goto L_0x01f0
            android.widget.TextView r0 = r7.f1203a
            android.os.LocaleList r1 = androidx.appcompat.widget.E.d.a(r3)
            androidx.appcompat.widget.E.d.b(r0, r1)
            goto L_0x0202
        L_0x01f0:
            java.lang.String r0 = ","
            java.lang.String[] r0 = r3.split(r0)
            r1 = 0
            r0 = r0[r1]
            android.widget.TextView r1 = r7.f1203a
            java.util.Locale r0 = androidx.appcompat.widget.E.c.a(r0)
            r1.setTextLocale(r0)
        L_0x0202:
            androidx.appcompat.widget.G r0 = r7.f1211i
            r0.o(r8, r9)
            boolean r0 = androidx.appcompat.widget.p0.f1602c
            r9 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r0 == 0) goto L_0x0248
            androidx.appcompat.widget.G r0 = r7.f1211i
            int r0 = r0.j()
            if (r0 == 0) goto L_0x0248
            androidx.appcompat.widget.G r0 = r7.f1211i
            int[] r0 = r0.i()
            int r1 = r0.length
            if (r1 <= 0) goto L_0x0248
            android.widget.TextView r1 = r7.f1203a
            int r1 = androidx.appcompat.widget.E.e.a(r1)
            float r1 = (float) r1
            int r1 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r1 == 0) goto L_0x0242
            android.widget.TextView r0 = r7.f1203a
            androidx.appcompat.widget.G r1 = r7.f1211i
            int r1 = r1.g()
            androidx.appcompat.widget.G r2 = r7.f1211i
            int r2 = r2.f()
            androidx.appcompat.widget.G r3 = r7.f1211i
            int r3 = r3.h()
            r4 = 0
            androidx.appcompat.widget.E.e.b(r0, r1, r2, r3, r4)
            goto L_0x0248
        L_0x0242:
            r4 = 0
            android.widget.TextView r1 = r7.f1203a
            androidx.appcompat.widget.E.e.c(r1, r0, r4)
        L_0x0248:
            int[] r0 = e.j.f5334g0
            androidx.appcompat.widget.e0 r8 = androidx.appcompat.widget.e0.u(r10, r8, r0)
            int r0 = e.j.f5350o0
            r1 = -1
            int r0 = r8.n(r0, r1)
            r2 = r20
            if (r0 == r1) goto L_0x025f
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r3 = r0
            goto L_0x0260
        L_0x025f:
            r3 = 0
        L_0x0260:
            int r0 = e.j.f5360t0
            int r0 = r8.n(r0, r1)
            if (r0 == r1) goto L_0x026e
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r4 = r0
            goto L_0x026f
        L_0x026e:
            r4 = 0
        L_0x026f:
            int r0 = e.j.f5352p0
            int r0 = r8.n(r0, r1)
            if (r0 == r1) goto L_0x027d
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r5 = r0
            goto L_0x027e
        L_0x027d:
            r5 = 0
        L_0x027e:
            int r0 = e.j.f5346m0
            int r0 = r8.n(r0, r1)
            if (r0 == r1) goto L_0x028c
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r6 = r0
            goto L_0x028d
        L_0x028c:
            r6 = 0
        L_0x028d:
            int r0 = e.j.f5354q0
            int r0 = r8.n(r0, r1)
            if (r0 == r1) goto L_0x029b
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r11 = r0
            goto L_0x029c
        L_0x029b:
            r11 = 0
        L_0x029c:
            int r0 = e.j.f5348n0
            int r0 = r8.n(r0, r1)
            if (r0 == r1) goto L_0x02aa
            android.graphics.drawable.Drawable r0 = r2.c(r10, r0)
            r10 = r0
            goto L_0x02ab
        L_0x02aa:
            r10 = 0
        L_0x02ab:
            r0 = r22
            r1 = r3
            r2 = r4
            r3 = r5
            r4 = r6
            r5 = r11
            r6 = r10
            r0.y(r1, r2, r3, r4, r5, r6)
            int r0 = e.j.f5356r0
            boolean r1 = r8.s(r0)
            if (r1 == 0) goto L_0x02c7
            android.content.res.ColorStateList r0 = r8.c(r0)
            android.widget.TextView r1 = r7.f1203a
            androidx.core.widget.j.g(r1, r0)
        L_0x02c7:
            int r0 = e.j.f5358s0
            boolean r1 = r8.s(r0)
            if (r1 == 0) goto L_0x02df
            r1 = -1
            int r0 = r8.k(r0, r1)
            r2 = 0
            android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.N.d(r0, r2)
            android.widget.TextView r2 = r7.f1203a
            androidx.core.widget.j.h(r2, r0)
            goto L_0x02e0
        L_0x02df:
            r1 = -1
        L_0x02e0:
            int r0 = e.j.f5364v0
            int r0 = r8.f(r0, r1)
            int r2 = e.j.f5366w0
            int r2 = r8.f(r2, r1)
            int r1 = e.j.f5368x0
            boolean r3 = r8.s(r1)
            if (r3 == 0) goto L_0x0316
            android.util.TypedValue r3 = r8.w(r1)
            if (r3 == 0) goto L_0x030e
            int r4 = r3.type
            r5 = 5
            if (r4 != r5) goto L_0x030e
            int r1 = r3.data
            int r12 = x.j.a(r1)
            int r1 = r3.data
            float r1 = android.util.TypedValue.complexToFloat(r1)
            r3 = r12
            r12 = -1
            goto L_0x031a
        L_0x030e:
            r12 = -1
            int r1 = r8.f(r1, r12)
            float r1 = (float) r1
        L_0x0314:
            r3 = -1
            goto L_0x031a
        L_0x0316:
            r12 = -1
            r1 = -1082130432(0xffffffffbf800000, float:-1.0)
            goto L_0x0314
        L_0x031a:
            r8.x()
            if (r0 == r12) goto L_0x0324
            android.widget.TextView r4 = r7.f1203a
            androidx.core.widget.j.j(r4, r0)
        L_0x0324:
            if (r2 == r12) goto L_0x032b
            android.widget.TextView r0 = r7.f1203a
            androidx.core.widget.j.k(r0, r2)
        L_0x032b:
            int r0 = (r1 > r9 ? 1 : (r1 == r9 ? 0 : -1))
            if (r0 == 0) goto L_0x033b
            android.widget.TextView r0 = r7.f1203a
            if (r3 != r12) goto L_0x0338
            int r1 = (int) r1
            androidx.core.widget.j.l(r0, r1)
            goto L_0x033b
        L_0x0338:
            androidx.core.widget.j.m(r0, r3, r1)
        L_0x033b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.E.m(android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: package-private */
    public void n(WeakReference weakReference, Typeface typeface) {
        if (this.f1215m) {
            this.f1214l = typeface;
            TextView textView = (TextView) weakReference.get();
            if (textView == null) {
                return;
            }
            if (textView.isAttachedToWindow()) {
                textView.post(new b(textView, typeface, this.f1212j));
            } else {
                textView.setTypeface(typeface, this.f1212j);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void o(boolean z2, int i2, int i3, int i4, int i5) {
        if (!p0.f1602c) {
            c();
        }
    }

    /* access modifiers changed from: package-private */
    public void p() {
        b();
    }

    /* access modifiers changed from: package-private */
    public void q(Context context, int i2) {
        String o2;
        ColorStateList c2;
        ColorStateList c3;
        ColorStateList c4;
        e0 t2 = e0.t(context, i2, j.v2);
        int i3 = j.G2;
        if (t2.s(i3)) {
            s(t2.a(i3, false));
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 < 23) {
            int i5 = j.z2;
            if (t2.s(i5) && (c4 = t2.c(i5)) != null) {
                this.f1203a.setTextColor(c4);
            }
            int i6 = j.B2;
            if (t2.s(i6) && (c3 = t2.c(i6)) != null) {
                this.f1203a.setLinkTextColor(c3);
            }
            int i7 = j.A2;
            if (t2.s(i7) && (c2 = t2.c(i7)) != null) {
                this.f1203a.setHintTextColor(c2);
            }
        }
        int i8 = j.w2;
        if (t2.s(i8) && t2.f(i8, -1) == 0) {
            this.f1203a.setTextSize(0, 0.0f);
        }
        C(context, t2);
        if (i4 >= 26) {
            int i9 = j.F2;
            if (t2.s(i9) && (o2 = t2.o(i9)) != null) {
                e.d(this.f1203a, o2);
            }
        }
        t2.x();
        Typeface typeface = this.f1214l;
        if (typeface != null) {
            this.f1203a.setTypeface(typeface, this.f1212j);
        }
    }

    /* access modifiers changed from: package-private */
    public void r(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
        if (Build.VERSION.SDK_INT < 30 && inputConnection != null) {
            B.c.f(editorInfo, textView.getText());
        }
    }

    /* access modifiers changed from: package-private */
    public void s(boolean z2) {
        this.f1203a.setAllCaps(z2);
    }

    /* access modifiers changed from: package-private */
    public void t(int i2, int i3, int i4, int i5) {
        this.f1211i.p(i2, i3, i4, i5);
    }

    /* access modifiers changed from: package-private */
    public void u(int[] iArr, int i2) {
        this.f1211i.q(iArr, i2);
    }

    /* access modifiers changed from: package-private */
    public void v(int i2) {
        this.f1211i.r(i2);
    }

    /* access modifiers changed from: package-private */
    public void w(ColorStateList colorStateList) {
        if (this.f1210h == null) {
            this.f1210h = new c0();
        }
        c0 c0Var = this.f1210h;
        c0Var.f1488a = colorStateList;
        c0Var.f1491d = colorStateList != null;
        z();
    }

    /* access modifiers changed from: package-private */
    public void x(PorterDuff.Mode mode) {
        if (this.f1210h == null) {
            this.f1210h = new c0();
        }
        c0 c0Var = this.f1210h;
        c0Var.f1489b = mode;
        c0Var.f1490c = mode != null;
        z();
    }
}
