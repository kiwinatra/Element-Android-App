package androidx.appcompat.widget;

public final /* synthetic */ class k0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m0 f1563a;

    public /* synthetic */ k0(m0 m0Var) {
        this.f1563a = m0Var;
    }

    public final void run() {
        this.f1563a.e();
    }
}
