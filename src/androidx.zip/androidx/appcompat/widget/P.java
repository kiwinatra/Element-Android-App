package androidx.appcompat.widget;

import android.graphics.Rect;

public interface P {
    void a(Rect rect);
}
