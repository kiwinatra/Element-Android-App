package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.app.C0088a;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.ActionMenuView;
import androidx.core.view.C0156s;
import androidx.core.view.C0164w;
import androidx.core.view.C0166x;
import androidx.core.view.C0170z;
import androidx.core.view.W;
import e.C0233a;
import f.C0236a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class Toolbar extends ViewGroup implements C0164w {

    /* renamed from: A  reason: collision with root package name */
    private ColorStateList f1347A;

    /* renamed from: B  reason: collision with root package name */
    private boolean f1348B;

    /* renamed from: C  reason: collision with root package name */
    private boolean f1349C;

    /* renamed from: D  reason: collision with root package name */
    private final ArrayList f1350D;

    /* renamed from: E  reason: collision with root package name */
    private final ArrayList f1351E;

    /* renamed from: F  reason: collision with root package name */
    private final int[] f1352F;

    /* renamed from: G  reason: collision with root package name */
    final C0166x f1353G;

    /* renamed from: H  reason: collision with root package name */
    private ArrayList f1354H;

    /* renamed from: I  reason: collision with root package name */
    h f1355I;

    /* renamed from: J  reason: collision with root package name */
    private final ActionMenuView.e f1356J;

    /* renamed from: K  reason: collision with root package name */
    private i0 f1357K;

    /* renamed from: L  reason: collision with root package name */
    private C0098c f1358L;

    /* renamed from: M  reason: collision with root package name */
    private f f1359M;

    /* renamed from: N  reason: collision with root package name */
    private j.a f1360N;

    /* renamed from: O  reason: collision with root package name */
    e.a f1361O;

    /* renamed from: P  reason: collision with root package name */
    private boolean f1362P;

    /* renamed from: Q  reason: collision with root package name */
    private OnBackInvokedCallback f1363Q;

    /* renamed from: R  reason: collision with root package name */
    private OnBackInvokedDispatcher f1364R;

    /* renamed from: S  reason: collision with root package name */
    private boolean f1365S;

    /* renamed from: T  reason: collision with root package name */
    private final Runnable f1366T;

    /* renamed from: a  reason: collision with root package name */
    ActionMenuView f1367a;

    /* renamed from: b  reason: collision with root package name */
    private TextView f1368b;

    /* renamed from: c  reason: collision with root package name */
    private TextView f1369c;

    /* renamed from: d  reason: collision with root package name */
    private ImageButton f1370d;

    /* renamed from: e  reason: collision with root package name */
    private ImageView f1371e;

    /* renamed from: f  reason: collision with root package name */
    private Drawable f1372f;

    /* renamed from: g  reason: collision with root package name */
    private CharSequence f1373g;

    /* renamed from: h  reason: collision with root package name */
    ImageButton f1374h;

    /* renamed from: i  reason: collision with root package name */
    View f1375i;

    /* renamed from: j  reason: collision with root package name */
    private Context f1376j;

    /* renamed from: k  reason: collision with root package name */
    private int f1377k;

    /* renamed from: l  reason: collision with root package name */
    private int f1378l;

    /* renamed from: m  reason: collision with root package name */
    private int f1379m;

    /* renamed from: n  reason: collision with root package name */
    int f1380n;

    /* renamed from: o  reason: collision with root package name */
    private int f1381o;

    /* renamed from: p  reason: collision with root package name */
    private int f1382p;

    /* renamed from: q  reason: collision with root package name */
    private int f1383q;

    /* renamed from: r  reason: collision with root package name */
    private int f1384r;

    /* renamed from: s  reason: collision with root package name */
    private int f1385s;

    /* renamed from: t  reason: collision with root package name */
    private Y f1386t;

    /* renamed from: u  reason: collision with root package name */
    private int f1387u;

    /* renamed from: v  reason: collision with root package name */
    private int f1388v;

    /* renamed from: w  reason: collision with root package name */
    private int f1389w;

    /* renamed from: x  reason: collision with root package name */
    private CharSequence f1390x;

    /* renamed from: y  reason: collision with root package name */
    private CharSequence f1391y;

    /* renamed from: z  reason: collision with root package name */
    private ColorStateList f1392z;

    class a implements ActionMenuView.e {
        a() {
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            if (Toolbar.this.f1353G.d(menuItem)) {
                return true;
            }
            h hVar = Toolbar.this.f1355I;
            if (hVar != null) {
                return hVar.onMenuItemClick(menuItem);
            }
            return false;
        }
    }

    class b implements Runnable {
        b() {
        }

        public void run() {
            Toolbar.this.S();
        }
    }

    class c implements e.a {
        c() {
        }

        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            e.a aVar = Toolbar.this.f1361O;
            return aVar != null && aVar.a(eVar, menuItem);
        }

        public void b(androidx.appcompat.view.menu.e eVar) {
            if (!Toolbar.this.f1367a.J()) {
                Toolbar.this.f1353G.e(eVar);
            }
            e.a aVar = Toolbar.this.f1361O;
            if (aVar != null) {
                aVar.b(eVar);
            }
        }
    }

    class d implements View.OnClickListener {
        d() {
        }

        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    static class e {
        static OnBackInvokedDispatcher a(View view) {
            return view.findOnBackInvokedDispatcher();
        }

        static OnBackInvokedCallback b(Runnable runnable) {
            Objects.requireNonNull(runnable);
            return new h0(runnable);
        }

        static void c(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback) obj2);
        }

        static void d(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    private class f implements j {

        /* renamed from: a  reason: collision with root package name */
        androidx.appcompat.view.menu.e f1397a;

        /* renamed from: b  reason: collision with root package name */
        androidx.appcompat.view.menu.g f1398b;

        f() {
        }

        public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
        }

        public int c() {
            return 0;
        }

        public boolean d() {
            return false;
        }

        public Parcelable e() {
            return null;
        }

        public void g(Context context, androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.g gVar;
            androidx.appcompat.view.menu.e eVar2 = this.f1397a;
            if (!(eVar2 == null || (gVar = this.f1398b) == null)) {
                eVar2.f(gVar);
            }
            this.f1397a = eVar;
        }

        public void h(Parcelable parcelable) {
        }

        public boolean i(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            View view = Toolbar.this.f1375i;
            if (view instanceof androidx.appcompat.view.c) {
                ((androidx.appcompat.view.c) view).f();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f1375i);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f1374h);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f1375i = null;
            toolbar3.a();
            this.f1398b = null;
            Toolbar.this.requestLayout();
            gVar.r(false);
            Toolbar.this.T();
            return true;
        }

        public boolean j(androidx.appcompat.view.menu.e eVar, androidx.appcompat.view.menu.g gVar) {
            Toolbar.this.i();
            ViewParent parent = Toolbar.this.f1374h.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f1374h);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f1374h);
            }
            Toolbar.this.f1375i = gVar.getActionView();
            this.f1398b = gVar;
            ViewParent parent2 = Toolbar.this.f1375i.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f1375i);
                }
                g o2 = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                o2.f652a = (toolbar4.f1380n & 112) | 8388611;
                o2.f1400b = 2;
                toolbar4.f1375i.setLayoutParams(o2);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f1375i);
            }
            Toolbar.this.K();
            Toolbar.this.requestLayout();
            gVar.r(true);
            View view = Toolbar.this.f1375i;
            if (view instanceof androidx.appcompat.view.c) {
                ((androidx.appcompat.view.c) view).c();
            }
            Toolbar.this.T();
            return true;
        }

        public boolean m(m mVar) {
            return false;
        }

        public void n(boolean z2) {
            if (this.f1398b != null) {
                androidx.appcompat.view.menu.e eVar = this.f1397a;
                if (eVar != null) {
                    int size = eVar.size();
                    int i2 = 0;
                    while (i2 < size) {
                        if (this.f1397a.getItem(i2) != this.f1398b) {
                            i2++;
                        } else {
                            return;
                        }
                    }
                }
                i(this.f1397a, this.f1398b);
            }
        }
    }

    public static class g extends C0088a.C0014a {

        /* renamed from: b  reason: collision with root package name */
        int f1400b = 0;

        public g(int i2, int i3) {
            super(i2, i3);
            this.f652a = 8388627;
        }

        /* access modifiers changed from: package-private */
        public void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }

        public g(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public g(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public g(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super((ViewGroup.LayoutParams) marginLayoutParams);
            a(marginLayoutParams);
        }

        public g(C0088a.C0014a aVar) {
            super(aVar);
        }

        public g(g gVar) {
            super((C0088a.C0014a) gVar);
            this.f1400b = gVar.f1400b;
        }
    }

    public interface h {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public static class i extends C.a {
        public static final Parcelable.Creator<i> CREATOR = new a();

        /* renamed from: c  reason: collision with root package name */
        int f1401c;

        /* renamed from: d  reason: collision with root package name */
        boolean f1402d;

        class a implements Parcelable.ClassLoaderCreator {
            a() {
            }

            /* renamed from: a */
            public i createFromParcel(Parcel parcel) {
                return new i(parcel, (ClassLoader) null);
            }

            /* renamed from: b */
            public i createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new i(parcel, classLoader);
            }

            /* renamed from: c */
            public i[] newArray(int i2) {
                return new i[i2];
            }
        }

        public i(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1401c = parcel.readInt();
            this.f1402d = parcel.readInt() != 0;
        }

        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f1401c);
            parcel.writeInt(this.f1402d ? 1 : 0);
        }

        public i(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0233a.f5286L);
    }

    private boolean B(View view) {
        return view.getParent() == this || this.f1351E.contains(view);
    }

    private int E(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = gVar.leftMargin - iArr[0];
        int max = i2 + Math.max(0, i4);
        iArr[0] = Math.max(0, -i4);
        int s2 = s(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, s2, max + measuredWidth, view.getMeasuredHeight() + s2);
        return max + measuredWidth + gVar.rightMargin;
    }

    private int F(View view, int i2, int[] iArr, int i3) {
        g gVar = (g) view.getLayoutParams();
        int i4 = gVar.rightMargin - iArr[1];
        int max = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int s2 = s(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, s2, max, view.getMeasuredHeight() + s2);
        return max - (measuredWidth + gVar.leftMargin);
    }

    private int G(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + max + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    private void H(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    private void I() {
        Menu menu = getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        this.f1353G.b(menu, getMenuInflater());
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f1354H = currentMenuItems2;
    }

    private void J() {
        removeCallbacks(this.f1366T);
        post(this.f1366T);
    }

    private boolean Q() {
        if (!this.f1362P) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (R(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    private boolean R(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    private void b(List list, int i2) {
        boolean z2 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int b2 = C0156s.b(i2, getLayoutDirection());
        list.clear();
        if (z2) {
            for (int i3 = childCount - 1; i3 >= 0; i3--) {
                View childAt = getChildAt(i3);
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.f1400b == 0 && R(childAt) && r(gVar.f652a) == b2) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt2 = getChildAt(i4);
            g gVar2 = (g) childAt2.getLayoutParams();
            if (gVar2.f1400b == 0 && R(childAt2) && r(gVar2.f652a) == b2) {
                list.add(childAt2);
            }
        }
    }

    private void c(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        g o2 = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (g) layoutParams;
        o2.f1400b = 1;
        if (!z2 || this.f1375i == null) {
            addView(view, o2);
            return;
        }
        view.setLayoutParams(o2);
        this.f1351E.add(view);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new androidx.appcompat.view.g(getContext());
    }

    private void j() {
        if (this.f1386t == null) {
            this.f1386t = new Y();
        }
    }

    private void k() {
        if (this.f1371e == null) {
            this.f1371e = new r(getContext());
        }
    }

    private void l() {
        m();
        if (this.f1367a.N() == null) {
            androidx.appcompat.view.menu.e eVar = (androidx.appcompat.view.menu.e) this.f1367a.getMenu();
            if (this.f1359M == null) {
                this.f1359M = new f();
            }
            this.f1367a.setExpandedActionViewsExclusive(true);
            eVar.c(this.f1359M, this.f1376j);
            T();
        }
    }

    private void m() {
        if (this.f1367a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f1367a = actionMenuView;
            actionMenuView.setPopupTheme(this.f1377k);
            this.f1367a.setOnMenuItemClickListener(this.f1356J);
            this.f1367a.O(this.f1360N, new c());
            g o2 = generateDefaultLayoutParams();
            o2.f652a = (this.f1380n & 112) | 8388613;
            this.f1367a.setLayoutParams(o2);
            c(this.f1367a, false);
        }
    }

    private void n() {
        if (this.f1370d == null) {
            this.f1370d = new C0111p(getContext(), (AttributeSet) null, C0233a.toolbarNavigationButtonStyle);
            g o2 = generateDefaultLayoutParams();
            o2.f652a = (this.f1380n & 112) | 8388611;
            this.f1370d.setLayoutParams(o2);
        }
    }

    private int r(int i2) {
        int layoutDirection = getLayoutDirection();
        int b2 = C0156s.b(i2, layoutDirection) & 7;
        if (b2 == 1 || b2 == 3 || b2 == 5) {
            return b2;
        }
        return layoutDirection == 1 ? 5 : 3;
    }

    private int s(View view, int i2) {
        g gVar = (g) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int t2 = t(gVar.f652a);
        if (t2 == 48) {
            return getPaddingTop() - i3;
        }
        if (t2 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - gVar.bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = gVar.topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = gVar.bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    private int t(int i2) {
        int i3 = i2 & 112;
        return (i3 == 16 || i3 == 48 || i3 == 80) ? i3 : this.f1389w & 112;
    }

    private int u(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    private int v(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    private int w(List list, int[] iArr) {
        int i2 = iArr[0];
        int i3 = iArr[1];
        int size = list.size();
        int i4 = 0;
        int i5 = 0;
        while (i4 < size) {
            View view = (View) list.get(i4);
            g gVar = (g) view.getLayoutParams();
            int i6 = gVar.leftMargin - i2;
            int i7 = gVar.rightMargin - i3;
            int max = Math.max(0, i6);
            int max2 = Math.max(0, i7);
            int max3 = Math.max(0, -i6);
            int max4 = Math.max(0, -i7);
            i5 += max + view.getMeasuredWidth() + max2;
            i4++;
            i3 = max4;
            i2 = max3;
        }
        return i5;
    }

    public void A() {
        Iterator it = this.f1354H.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(((MenuItem) it.next()).getItemId());
        }
        I();
    }

    public boolean C() {
        ActionMenuView actionMenuView = this.f1367a;
        return actionMenuView != null && actionMenuView.I();
    }

    public boolean D() {
        ActionMenuView actionMenuView = this.f1367a;
        return actionMenuView != null && actionMenuView.J();
    }

    /* access modifiers changed from: package-private */
    public void K() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (!(((g) childAt.getLayoutParams()).f1400b == 2 || childAt == this.f1367a)) {
                removeViewAt(childCount);
                this.f1351E.add(childAt);
            }
        }
    }

    public void L(int i2, int i3) {
        j();
        this.f1386t.g(i2, i3);
    }

    public void M(androidx.appcompat.view.menu.e eVar, C0098c cVar) {
        if (eVar != null || this.f1367a != null) {
            m();
            androidx.appcompat.view.menu.e N2 = this.f1367a.N();
            if (N2 != eVar) {
                if (N2 != null) {
                    N2.R(this.f1358L);
                    N2.R(this.f1359M);
                }
                if (this.f1359M == null) {
                    this.f1359M = new f();
                }
                cVar.J(true);
                if (eVar != null) {
                    eVar.c(cVar, this.f1376j);
                    eVar.c(this.f1359M, this.f1376j);
                } else {
                    cVar.g(this.f1376j, (androidx.appcompat.view.menu.e) null);
                    this.f1359M.g(this.f1376j, (androidx.appcompat.view.menu.e) null);
                    cVar.n(true);
                    this.f1359M.n(true);
                }
                this.f1367a.setPopupTheme(this.f1377k);
                this.f1367a.setPresenter(cVar);
                this.f1358L = cVar;
                T();
            }
        }
    }

    public void N(j.a aVar, e.a aVar2) {
        this.f1360N = aVar;
        this.f1361O = aVar2;
        ActionMenuView actionMenuView = this.f1367a;
        if (actionMenuView != null) {
            actionMenuView.O(aVar, aVar2);
        }
    }

    public void O(Context context, int i2) {
        this.f1379m = i2;
        TextView textView = this.f1369c;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public void P(Context context, int i2) {
        this.f1378l = i2;
        TextView textView = this.f1368b;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public boolean S() {
        ActionMenuView actionMenuView = this.f1367a;
        return actionMenuView != null && actionMenuView.P();
    }

    /* access modifiers changed from: package-private */
    public void T() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher a2 = e.a(this);
            boolean z2 = x() && a2 != null && isAttachedToWindow() && this.f1365S;
            if (z2 && this.f1364R == null) {
                if (this.f1363Q == null) {
                    this.f1363Q = e.b(new f0(this));
                }
                e.c(a2, this.f1363Q);
            } else if (!z2 && (onBackInvokedDispatcher = this.f1364R) != null) {
                e.d(onBackInvokedDispatcher, this.f1363Q);
                a2 = null;
            } else {
                return;
            }
            this.f1364R = a2;
        }
    }

    /* access modifiers changed from: package-private */
    public void a() {
        for (int size = this.f1351E.size() - 1; size >= 0; size--) {
            addView((View) this.f1351E.get(size));
        }
        this.f1351E.clear();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof g);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f1367a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean d() {
        /*
            r1 = this;
            int r0 = r1.getVisibility()
            if (r0 != 0) goto L_0x0012
            androidx.appcompat.widget.ActionMenuView r0 = r1.f1367a
            if (r0 == 0) goto L_0x0012
            boolean r0 = r0.K()
            if (r0 == 0) goto L_0x0012
            r0 = 1
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.d():boolean");
    }

    public void e() {
        f fVar = this.f1359M;
        androidx.appcompat.view.menu.g gVar = fVar == null ? null : fVar.f1398b;
        if (gVar != null) {
            gVar.collapseActionView();
        }
    }

    public void f(C0170z zVar) {
        this.f1353G.f(zVar);
    }

    public void g() {
        ActionMenuView actionMenuView = this.f1367a;
        if (actionMenuView != null) {
            actionMenuView.B();
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.f1374h;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.f1374h;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        Y y2 = this.f1386t;
        if (y2 != null) {
            return y2.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f1388v;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        Y y2 = this.f1386t;
        if (y2 != null) {
            return y2.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        Y y2 = this.f1386t;
        if (y2 != null) {
            return y2.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        Y y2 = this.f1386t;
        if (y2 != null) {
            return y2.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f1387u;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r0.N();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getCurrentContentInsetEnd() {
        /*
            r3 = this;
            androidx.appcompat.widget.ActionMenuView r0 = r3.f1367a
            if (r0 == 0) goto L_0x0020
            androidx.appcompat.view.menu.e r0 = r0.N()
            if (r0 == 0) goto L_0x0020
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0020
            int r0 = r3.getContentInsetEnd()
            int r1 = r3.f1388v
            r2 = 0
            int r1 = java.lang.Math.max(r1, r2)
            int r0 = java.lang.Math.max(r0, r1)
            goto L_0x0024
        L_0x0020:
            int r0 = r3.getContentInsetEnd()
        L_0x0024:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.getCurrentContentInsetEnd():int");
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1387u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f1371e;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f1371e;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        l();
        return this.f1367a.getMenu();
    }

    /* access modifiers changed from: package-private */
    public View getNavButtonView() {
        return this.f1370d;
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f1370d;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f1370d;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public C0098c getOuterActionMenuPresenter() {
        return this.f1358L;
    }

    public Drawable getOverflowIcon() {
        l();
        return this.f1367a.getOverflowIcon();
    }

    /* access modifiers changed from: package-private */
    public Context getPopupContext() {
        return this.f1376j;
    }

    public int getPopupTheme() {
        return this.f1377k;
    }

    public CharSequence getSubtitle() {
        return this.f1391y;
    }

    /* access modifiers changed from: package-private */
    public final TextView getSubtitleTextView() {
        return this.f1369c;
    }

    public CharSequence getTitle() {
        return this.f1390x;
    }

    public int getTitleMarginBottom() {
        return this.f1385s;
    }

    public int getTitleMarginEnd() {
        return this.f1383q;
    }

    public int getTitleMarginStart() {
        return this.f1382p;
    }

    public int getTitleMarginTop() {
        return this.f1384r;
    }

    /* access modifiers changed from: package-private */
    public final TextView getTitleTextView() {
        return this.f1368b;
    }

    public M getWrapper() {
        if (this.f1357K == null) {
            this.f1357K = new i0(this, true);
        }
        return this.f1357K;
    }

    public void h(C0170z zVar) {
        this.f1353G.a(zVar);
    }

    /* access modifiers changed from: package-private */
    public void i() {
        if (this.f1374h == null) {
            C0111p pVar = new C0111p(getContext(), (AttributeSet) null, C0233a.toolbarNavigationButtonStyle);
            this.f1374h = pVar;
            pVar.setImageDrawable(this.f1372f);
            this.f1374h.setContentDescription(this.f1373g);
            g o2 = generateDefaultLayoutParams();
            o2.f652a = (this.f1380n & 112) | 8388611;
            o2.f1400b = 2;
            this.f1374h.setLayoutParams(o2);
            this.f1374h.setOnClickListener(new d());
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: o */
    public g generateDefaultLayoutParams() {
        return new g(-2, -2);
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        T();
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f1366T);
        T();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1349C = false;
        }
        if (!this.f1349C) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f1349C = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f1349C = false;
        }
        return true;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0297 A[LOOP:0: B:108:0x0295->B:109:0x0297, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x02b9 A[LOOP:1: B:111:0x02b7->B:112:0x02b9, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x02e3  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02f2 A[LOOP:2: B:119:0x02f0->B:120:0x02f2, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005e  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00ae  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00de  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00f5  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0112  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0122  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0125  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0129  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x015d  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x019b  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x01ac  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x021d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            r19 = this;
            r0 = r19
            int r1 = r19.getLayoutDirection()
            r2 = 0
            r3 = 1
            if (r1 != r3) goto L_0x000c
            r1 = 1
            goto L_0x000d
        L_0x000c:
            r1 = 0
        L_0x000d:
            int r4 = r19.getWidth()
            int r5 = r19.getHeight()
            int r6 = r19.getPaddingLeft()
            int r7 = r19.getPaddingRight()
            int r8 = r19.getPaddingTop()
            int r9 = r19.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f1352F
            r11[r3] = r2
            r11[r2] = r2
            int r12 = androidx.core.view.W.D(r19)
            if (r12 < 0) goto L_0x003a
            int r13 = r24 - r22
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003b
        L_0x003a:
            r12 = 0
        L_0x003b:
            android.widget.ImageButton r13 = r0.f1370d
            boolean r13 = r0.R(r13)
            if (r13 == 0) goto L_0x0054
            android.widget.ImageButton r13 = r0.f1370d
            if (r1 == 0) goto L_0x004e
            int r13 = r0.F(r13, r10, r11, r12)
            r14 = r13
            r13 = r6
            goto L_0x0056
        L_0x004e:
            int r13 = r0.E(r13, r6, r11, r12)
        L_0x0052:
            r14 = r10
            goto L_0x0056
        L_0x0054:
            r13 = r6
            goto L_0x0052
        L_0x0056:
            android.widget.ImageButton r15 = r0.f1374h
            boolean r15 = r0.R(r15)
            if (r15 == 0) goto L_0x006b
            android.widget.ImageButton r15 = r0.f1374h
            if (r1 == 0) goto L_0x0067
            int r14 = r0.F(r15, r14, r11, r12)
            goto L_0x006b
        L_0x0067:
            int r13 = r0.E(r15, r13, r11, r12)
        L_0x006b:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1367a
            boolean r15 = r0.R(r15)
            if (r15 == 0) goto L_0x0080
            androidx.appcompat.widget.ActionMenuView r15 = r0.f1367a
            if (r1 == 0) goto L_0x007c
            int r13 = r0.E(r15, r13, r11, r12)
            goto L_0x0080
        L_0x007c:
            int r14 = r0.F(r15, r14, r11, r12)
        L_0x0080:
            int r15 = r19.getCurrentContentInsetLeft()
            int r16 = r19.getCurrentContentInsetRight()
            int r3 = r15 - r13
            int r3 = java.lang.Math.max(r2, r3)
            r11[r2] = r3
            int r3 = r10 - r14
            int r3 = r16 - r3
            int r3 = java.lang.Math.max(r2, r3)
            r17 = 1
            r11[r17] = r3
            int r3 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.f1375i
            boolean r13 = r0.R(r13)
            if (r13 == 0) goto L_0x00bb
            android.view.View r13 = r0.f1375i
            if (r1 == 0) goto L_0x00b7
            int r10 = r0.F(r13, r10, r11, r12)
            goto L_0x00bb
        L_0x00b7:
            int r3 = r0.E(r13, r3, r11, r12)
        L_0x00bb:
            android.widget.ImageView r13 = r0.f1371e
            boolean r13 = r0.R(r13)
            if (r13 == 0) goto L_0x00d0
            android.widget.ImageView r13 = r0.f1371e
            if (r1 == 0) goto L_0x00cc
            int r10 = r0.F(r13, r10, r11, r12)
            goto L_0x00d0
        L_0x00cc:
            int r3 = r0.E(r13, r3, r11, r12)
        L_0x00d0:
            android.widget.TextView r13 = r0.f1368b
            boolean r13 = r0.R(r13)
            android.widget.TextView r14 = r0.f1369c
            boolean r14 = r0.R(r14)
            if (r13 == 0) goto L_0x00f5
            android.widget.TextView r15 = r0.f1368b
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r15 = (androidx.appcompat.widget.Toolbar.g) r15
            int r2 = r15.topMargin
            r23 = r7
            android.widget.TextView r7 = r0.f1368b
            int r7 = r7.getMeasuredHeight()
            int r2 = r2 + r7
            int r7 = r15.bottomMargin
            int r2 = r2 + r7
            goto L_0x00f8
        L_0x00f5:
            r23 = r7
            r2 = 0
        L_0x00f8:
            if (r14 == 0) goto L_0x0112
            android.widget.TextView r7 = r0.f1369c
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r7 = (androidx.appcompat.widget.Toolbar.g) r7
            int r15 = r7.topMargin
            r16 = r4
            android.widget.TextView r4 = r0.f1369c
            int r4 = r4.getMeasuredHeight()
            int r15 = r15 + r4
            int r4 = r7.bottomMargin
            int r15 = r15 + r4
            int r2 = r2 + r15
            goto L_0x0114
        L_0x0112:
            r16 = r4
        L_0x0114:
            if (r13 != 0) goto L_0x0120
            if (r14 == 0) goto L_0x0119
            goto L_0x0120
        L_0x0119:
            r18 = r6
            r22 = r12
        L_0x011d:
            r2 = 0
            goto L_0x0287
        L_0x0120:
            if (r13 == 0) goto L_0x0125
            android.widget.TextView r4 = r0.f1368b
            goto L_0x0127
        L_0x0125:
            android.widget.TextView r4 = r0.f1369c
        L_0x0127:
            if (r14 == 0) goto L_0x012c
            android.widget.TextView r7 = r0.f1369c
            goto L_0x012e
        L_0x012c:
            android.widget.TextView r7 = r0.f1368b
        L_0x012e:
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r4 = (androidx.appcompat.widget.Toolbar.g) r4
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r7 = (androidx.appcompat.widget.Toolbar.g) r7
            if (r13 == 0) goto L_0x0144
            android.widget.TextView r15 = r0.f1368b
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x014e
        L_0x0144:
            if (r14 == 0) goto L_0x0151
            android.widget.TextView r15 = r0.f1369c
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x0151
        L_0x014e:
            r17 = 1
            goto L_0x0153
        L_0x0151:
            r17 = 0
        L_0x0153:
            int r15 = r0.f1389w
            r15 = r15 & 112(0x70, float:1.57E-43)
            r18 = r6
            r6 = 48
            if (r15 == r6) goto L_0x019b
            r6 = 80
            if (r15 == r6) goto L_0x018d
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r2
            int r6 = r6 / 2
            int r15 = r4.topMargin
            r22 = r12
            int r12 = r0.f1384r
            r24 = r3
            int r3 = r15 + r12
            if (r6 >= r3) goto L_0x0176
            int r6 = r15 + r12
            goto L_0x018b
        L_0x0176:
            int r5 = r5 - r9
            int r5 = r5 - r2
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r4.bottomMargin
            int r3 = r0.f1385s
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x018b
            int r2 = r7.bottomMargin
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x018b:
            int r8 = r8 + r6
            goto L_0x01aa
        L_0x018d:
            r24 = r3
            r22 = r12
            int r5 = r5 - r9
            int r3 = r7.bottomMargin
            int r5 = r5 - r3
            int r3 = r0.f1385s
            int r5 = r5 - r3
            int r8 = r5 - r2
            goto L_0x01aa
        L_0x019b:
            r24 = r3
            r22 = r12
            int r2 = r19.getPaddingTop()
            int r3 = r4.topMargin
            int r2 = r2 + r3
            int r3 = r0.f1384r
            int r8 = r2 + r3
        L_0x01aa:
            if (r1 == 0) goto L_0x021d
            if (r17 == 0) goto L_0x01b2
            int r1 = r0.f1382p
        L_0x01b0:
            r2 = 1
            goto L_0x01b4
        L_0x01b2:
            r1 = 0
            goto L_0x01b0
        L_0x01b4:
            r3 = r11[r2]
            int r1 = r1 - r3
            r3 = 0
            int r4 = java.lang.Math.max(r3, r1)
            int r10 = r10 - r4
            int r1 = -r1
            int r1 = java.lang.Math.max(r3, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x01ea
            android.widget.TextView r1 = r0.f1368b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r1 = (androidx.appcompat.widget.Toolbar.g) r1
            android.widget.TextView r2 = r0.f1368b
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            android.widget.TextView r3 = r0.f1368b
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f1368b
            r4.layout(r2, r8, r10, r3)
            int r4 = r0.f1383q
            int r2 = r2 - r4
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01eb
        L_0x01ea:
            r2 = r10
        L_0x01eb:
            if (r14 == 0) goto L_0x0211
            android.widget.TextView r1 = r0.f1369c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r1 = (androidx.appcompat.widget.Toolbar.g) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f1369c
            int r1 = r1.getMeasuredWidth()
            int r1 = r10 - r1
            android.widget.TextView r3 = r0.f1369c
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f1369c
            r4.layout(r1, r8, r10, r3)
            int r1 = r0.f1383q
            int r1 = r10 - r1
            goto L_0x0212
        L_0x0211:
            r1 = r10
        L_0x0212:
            if (r17 == 0) goto L_0x0219
            int r1 = java.lang.Math.min(r2, r1)
            r10 = r1
        L_0x0219:
            r3 = r24
            goto L_0x011d
        L_0x021d:
            if (r17 == 0) goto L_0x0224
            int r2 = r0.f1382p
            r1 = r2
        L_0x0222:
            r2 = 0
            goto L_0x0226
        L_0x0224:
            r1 = 0
            goto L_0x0222
        L_0x0226:
            r3 = r11[r2]
            int r1 = r1 - r3
            int r3 = java.lang.Math.max(r2, r1)
            int r3 = r24 + r3
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x025b
            android.widget.TextView r1 = r0.f1368b
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r1 = (androidx.appcompat.widget.Toolbar.g) r1
            android.widget.TextView r4 = r0.f1368b
            int r4 = r4.getMeasuredWidth()
            int r4 = r4 + r3
            android.widget.TextView r5 = r0.f1368b
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f1368b
            r6.layout(r3, r8, r4, r5)
            int r6 = r0.f1383q
            int r4 = r4 + r6
            int r1 = r1.bottomMargin
            int r8 = r5 + r1
            goto L_0x025c
        L_0x025b:
            r4 = r3
        L_0x025c:
            if (r14 == 0) goto L_0x0280
            android.widget.TextView r1 = r0.f1369c
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$g r1 = (androidx.appcompat.widget.Toolbar.g) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f1369c
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r3
            android.widget.TextView r5 = r0.f1369c
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r8
            android.widget.TextView r6 = r0.f1369c
            r6.layout(r3, r8, r1, r5)
            int r5 = r0.f1383q
            int r1 = r1 + r5
            goto L_0x0281
        L_0x0280:
            r1 = r3
        L_0x0281:
            if (r17 == 0) goto L_0x0287
            int r3 = java.lang.Math.max(r4, r1)
        L_0x0287:
            java.util.ArrayList r1 = r0.f1350D
            r4 = 3
            r0.b(r1, r4)
            java.util.ArrayList r1 = r0.f1350D
            int r1 = r1.size()
            r4 = r3
            r3 = 0
        L_0x0295:
            if (r3 >= r1) goto L_0x02a8
            java.util.ArrayList r5 = r0.f1350D
            java.lang.Object r5 = r5.get(r3)
            android.view.View r5 = (android.view.View) r5
            r12 = r22
            int r4 = r0.E(r5, r4, r11, r12)
            int r3 = r3 + 1
            goto L_0x0295
        L_0x02a8:
            r12 = r22
            java.util.ArrayList r1 = r0.f1350D
            r3 = 5
            r0.b(r1, r3)
            java.util.ArrayList r1 = r0.f1350D
            int r1 = r1.size()
            r3 = 0
        L_0x02b7:
            if (r3 >= r1) goto L_0x02c8
            java.util.ArrayList r5 = r0.f1350D
            java.lang.Object r5 = r5.get(r3)
            android.view.View r5 = (android.view.View) r5
            int r10 = r0.F(r5, r10, r11, r12)
            int r3 = r3 + 1
            goto L_0x02b7
        L_0x02c8:
            java.util.ArrayList r1 = r0.f1350D
            r3 = 1
            r0.b(r1, r3)
            java.util.ArrayList r1 = r0.f1350D
            int r1 = r0.w(r1, r11)
            int r3 = r16 - r18
            int r3 = r3 - r23
            int r3 = r3 / 2
            int r6 = r18 + r3
            int r3 = r1 / 2
            int r6 = r6 - r3
            int r1 = r1 + r6
            if (r6 >= r4) goto L_0x02e3
            goto L_0x02ea
        L_0x02e3:
            if (r1 <= r10) goto L_0x02e9
            int r1 = r1 - r10
            int r4 = r6 - r1
            goto L_0x02ea
        L_0x02e9:
            r4 = r6
        L_0x02ea:
            java.util.ArrayList r1 = r0.f1350D
            int r1 = r1.size()
        L_0x02f0:
            if (r2 >= r1) goto L_0x0301
            java.util.ArrayList r3 = r0.f1350D
            java.lang.Object r3 = r3.get(r2)
            android.view.View r3 = (android.view.View) r3
            int r4 = r0.E(r3, r4, r11, r12)
            int r2 = r2 + 1
            goto L_0x02f0
        L_0x0301:
            java.util.ArrayList r1 = r0.f1350D
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int[] iArr = this.f1352F;
        char b2 = p0.b(this);
        int i11 = 0;
        char c2 = b2 ^ 1;
        if (R(this.f1370d)) {
            H(this.f1370d, i2, 0, i3, 0, this.f1381o);
            i6 = this.f1370d.getMeasuredWidth() + u(this.f1370d);
            i5 = Math.max(0, this.f1370d.getMeasuredHeight() + v(this.f1370d));
            i4 = View.combineMeasuredStates(0, this.f1370d.getMeasuredState());
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
        }
        if (R(this.f1374h)) {
            H(this.f1374h, i2, 0, i3, 0, this.f1381o);
            i6 = this.f1374h.getMeasuredWidth() + u(this.f1374h);
            i5 = Math.max(i5, this.f1374h.getMeasuredHeight() + v(this.f1374h));
            i4 = View.combineMeasuredStates(i4, this.f1374h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i6);
        iArr[b2] = Math.max(0, currentContentInsetStart - i6);
        if (R(this.f1367a)) {
            H(this.f1367a, i2, max, i3, 0, this.f1381o);
            i7 = this.f1367a.getMeasuredWidth() + u(this.f1367a);
            i5 = Math.max(i5, this.f1367a.getMeasuredHeight() + v(this.f1367a));
            i4 = View.combineMeasuredStates(i4, this.f1367a.getMeasuredState());
        } else {
            i7 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = max + Math.max(currentContentInsetEnd, i7);
        iArr[c2] = Math.max(0, currentContentInsetEnd - i7);
        if (R(this.f1375i)) {
            max2 += G(this.f1375i, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, this.f1375i.getMeasuredHeight() + v(this.f1375i));
            i4 = View.combineMeasuredStates(i4, this.f1375i.getMeasuredState());
        }
        if (R(this.f1371e)) {
            max2 += G(this.f1371e, i2, max2, i3, 0, iArr);
            i5 = Math.max(i5, this.f1371e.getMeasuredHeight() + v(this.f1371e));
            i4 = View.combineMeasuredStates(i4, this.f1371e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (((g) childAt.getLayoutParams()).f1400b == 0 && R(childAt)) {
                max2 += G(childAt, i2, max2, i3, 0, iArr);
                i5 = Math.max(i5, childAt.getMeasuredHeight() + v(childAt));
                i4 = View.combineMeasuredStates(i4, childAt.getMeasuredState());
            }
        }
        int i13 = this.f1384r + this.f1385s;
        int i14 = this.f1382p + this.f1383q;
        if (R(this.f1368b)) {
            G(this.f1368b, i2, max2 + i14, i3, i13, iArr);
            int measuredWidth = this.f1368b.getMeasuredWidth() + u(this.f1368b);
            i8 = this.f1368b.getMeasuredHeight() + v(this.f1368b);
            i10 = View.combineMeasuredStates(i4, this.f1368b.getMeasuredState());
            i9 = measuredWidth;
        } else {
            i10 = i4;
            i9 = 0;
            i8 = 0;
        }
        if (R(this.f1369c)) {
            int i15 = i8 + i13;
            i9 = Math.max(i9, G(this.f1369c, i2, max2 + i14, i3, i15, iArr));
            i8 += this.f1369c.getMeasuredHeight() + v(this.f1369c);
            i10 = View.combineMeasuredStates(i10, this.f1369c.getMeasuredState());
        } else {
            int i16 = i10;
        }
        int max3 = Math.max(i5, i8);
        int paddingLeft = max2 + i9 + getPaddingLeft() + getPaddingRight();
        int paddingTop = max3 + getPaddingTop() + getPaddingBottom();
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingLeft, getSuggestedMinimumWidth()), i2, -16777216 & i10);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingTop, getSuggestedMinimumHeight()), i3, i10 << 16);
        if (!Q()) {
            i11 = resolveSizeAndState2;
        }
        setMeasuredDimension(resolveSizeAndState, i11);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof i)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        i iVar = (i) parcelable;
        super.onRestoreInstanceState(iVar.c());
        ActionMenuView actionMenuView = this.f1367a;
        androidx.appcompat.view.menu.e N2 = actionMenuView != null ? actionMenuView.N() : null;
        int i2 = iVar.f1401c;
        if (!(i2 == 0 || this.f1359M == null || N2 == null || (findItem = N2.findItem(i2)) == null)) {
            findItem.expandActionView();
        }
        if (iVar.f1402d) {
            J();
        }
    }

    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        j();
        Y y2 = this.f1386t;
        boolean z2 = true;
        if (i2 != 1) {
            z2 = false;
        }
        y2.f(z2);
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.g gVar;
        i iVar = new i(super.onSaveInstanceState());
        f fVar = this.f1359M;
        if (!(fVar == null || (gVar = fVar.f1398b) == null)) {
            iVar.f1401c = gVar.getItemId();
        }
        iVar.f1402d = D();
        return iVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1348B = false;
        }
        if (!this.f1348B) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f1348B = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f1348B = false;
        }
        return true;
    }

    /* renamed from: p */
    public g generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: q */
    public g generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof g) {
            return new g((g) layoutParams);
        }
        if (layoutParams instanceof C0088a.C0014a) {
            return new g((C0088a.C0014a) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new g((ViewGroup.MarginLayoutParams) layoutParams) : new g(layoutParams);
    }

    public void setBackInvokedCallbackEnabled(boolean z2) {
        if (this.f1365S != z2) {
            this.f1365S = z2;
            T();
        }
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(C0236a.b(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f1362P = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f1388v) {
            this.f1388v = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f1387u) {
            this.f1387u = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(C0236a.b(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(C0236a.b(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        n();
        this.f1370d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(h hVar) {
        this.f1355I = hVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        l();
        this.f1367a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f1377k != i2) {
            this.f1377k = i2;
            if (i2 == 0) {
                this.f1376j = getContext();
            } else {
                this.f1376j = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f1385s = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f1383q = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f1382p = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f1384r = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public boolean x() {
        f fVar = this.f1359M;
        return (fVar == null || fVar.f1398b == null) ? false : true;
    }

    public boolean y() {
        ActionMenuView actionMenuView = this.f1367a;
        return actionMenuView != null && actionMenuView.H();
    }

    public void z(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1389w = 8388627;
        this.f1350D = new ArrayList();
        this.f1351E = new ArrayList();
        this.f1352F = new int[2];
        this.f1353G = new C0166x(new g0(this));
        this.f1354H = new ArrayList();
        this.f1356J = new a();
        this.f1366T = new b();
        Context context2 = getContext();
        int[] iArr = e.j.I2;
        e0 v2 = e0.v(context2, attributeSet, iArr, i2, 0);
        W.o0(this, context, iArr, attributeSet, v2.r(), i2, 0);
        this.f1378l = v2.n(e.j.k3, 0);
        this.f1379m = v2.n(e.j.b3, 0);
        this.f1389w = v2.l(e.j.J2, this.f1389w);
        this.f1380n = v2.l(e.j.K2, 48);
        int e2 = v2.e(e.j.e3, 0);
        int i3 = e.j.j3;
        e2 = v2.s(i3) ? v2.e(i3, e2) : e2;
        this.f1385s = e2;
        this.f1384r = e2;
        this.f1383q = e2;
        this.f1382p = e2;
        int e3 = v2.e(e.j.h3, -1);
        if (e3 >= 0) {
            this.f1382p = e3;
        }
        int e4 = v2.e(e.j.g3, -1);
        if (e4 >= 0) {
            this.f1383q = e4;
        }
        int e5 = v2.e(e.j.i3, -1);
        if (e5 >= 0) {
            this.f1384r = e5;
        }
        int e6 = v2.e(e.j.f3, -1);
        if (e6 >= 0) {
            this.f1385s = e6;
        }
        this.f1381o = v2.f(e.j.V2, -1);
        int e7 = v2.e(e.j.R2, Integer.MIN_VALUE);
        int e8 = v2.e(e.j.N2, Integer.MIN_VALUE);
        int f2 = v2.f(e.j.P2, 0);
        int f3 = v2.f(e.j.Q2, 0);
        j();
        this.f1386t.e(f2, f3);
        if (!(e7 == Integer.MIN_VALUE && e8 == Integer.MIN_VALUE)) {
            this.f1386t.g(e7, e8);
        }
        this.f1387u = v2.e(e.j.S2, Integer.MIN_VALUE);
        this.f1388v = v2.e(e.j.O2, Integer.MIN_VALUE);
        this.f1372f = v2.g(e.j.M2);
        this.f1373g = v2.p(e.j.L2);
        CharSequence p2 = v2.p(e.j.d3);
        if (!TextUtils.isEmpty(p2)) {
            setTitle(p2);
        }
        CharSequence p3 = v2.p(e.j.a3);
        if (!TextUtils.isEmpty(p3)) {
            setSubtitle(p3);
        }
        this.f1376j = getContext();
        setPopupTheme(v2.n(e.j.Z2, 0));
        Drawable g2 = v2.g(e.j.Y2);
        if (g2 != null) {
            setNavigationIcon(g2);
        }
        CharSequence p4 = v2.p(e.j.X2);
        if (!TextUtils.isEmpty(p4)) {
            setNavigationContentDescription(p4);
        }
        Drawable g3 = v2.g(e.j.T2);
        if (g3 != null) {
            setLogo(g3);
        }
        CharSequence p5 = v2.p(e.j.U2);
        if (!TextUtils.isEmpty(p5)) {
            setLogoDescription(p5);
        }
        int i4 = e.j.l3;
        if (v2.s(i4)) {
            setTitleTextColor(v2.c(i4));
        }
        int i5 = e.j.c3;
        if (v2.s(i5)) {
            setSubtitleTextColor(v2.c(i5));
        }
        int i6 = e.j.W2;
        if (v2.s(i6)) {
            z(v2.n(i6, 0));
        }
        v2.x();
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageButton imageButton = this.f1374h;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            i();
            this.f1374h.setImageDrawable(drawable);
            return;
        }
        ImageButton imageButton = this.f1374h;
        if (imageButton != null) {
            imageButton.setImageDrawable(this.f1372f);
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            k();
            if (!B(this.f1371e)) {
                c(this.f1371e, true);
            }
        } else {
            ImageView imageView = this.f1371e;
            if (imageView != null && B(imageView)) {
                removeView(this.f1371e);
                this.f1351E.remove(this.f1371e);
            }
        }
        ImageView imageView2 = this.f1371e;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            k();
        }
        ImageView imageView = this.f1371e;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            n();
        }
        ImageButton imageButton = this.f1370d;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            j0.a(this.f1370d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            n();
            if (!B(this.f1370d)) {
                c(this.f1370d, true);
            }
        } else {
            ImageButton imageButton = this.f1370d;
            if (imageButton != null && B(imageButton)) {
                removeView(this.f1370d);
                this.f1351E.remove(this.f1370d);
            }
        }
        ImageButton imageButton2 = this.f1370d;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1369c == null) {
                Context context = getContext();
                F f2 = new F(context);
                this.f1369c = f2;
                f2.setSingleLine();
                this.f1369c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f1379m;
                if (i2 != 0) {
                    this.f1369c.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f1347A;
                if (colorStateList != null) {
                    this.f1369c.setTextColor(colorStateList);
                }
            }
            if (!B(this.f1369c)) {
                c(this.f1369c, true);
            }
        } else {
            TextView textView = this.f1369c;
            if (textView != null && B(textView)) {
                removeView(this.f1369c);
                this.f1351E.remove(this.f1369c);
            }
        }
        TextView textView2 = this.f1369c;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1391y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f1347A = colorStateList;
        TextView textView = this.f1369c;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f1368b == null) {
                Context context = getContext();
                F f2 = new F(context);
                this.f1368b = f2;
                f2.setSingleLine();
                this.f1368b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f1378l;
                if (i2 != 0) {
                    this.f1368b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f1392z;
                if (colorStateList != null) {
                    this.f1368b.setTextColor(colorStateList);
                }
            }
            if (!B(this.f1368b)) {
                c(this.f1368b, true);
            }
        } else {
            TextView textView = this.f1368b;
            if (textView != null && B(textView)) {
                removeView(this.f1368b);
                this.f1351E.remove(this.f1368b);
            }
        }
        TextView textView2 = this.f1368b;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f1390x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f1392z = colorStateList;
        TextView textView = this.f1368b;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }
}
