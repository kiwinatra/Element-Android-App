package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

public class r extends ImageView {

    /* renamed from: a  reason: collision with root package name */
    private final C0100e f1608a;

    /* renamed from: b  reason: collision with root package name */
    private final C0112q f1609b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1610c;

    public r(Context context) {
        this(context, (AttributeSet) null);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            eVar.b();
        }
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.c();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            return eVar.d();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            return qVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            return qVar.e();
        }
        return null;
    }

    public boolean hasOverlappingRendering() {
        return this.f1609b.f() && super.hasOverlappingRendering();
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            eVar.f(drawable);
        }
    }

    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            eVar.g(i2);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.c();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        C0112q qVar = this.f1609b;
        if (!(qVar == null || drawable == null || this.f1610c)) {
            qVar.h(drawable);
        }
        super.setImageDrawable(drawable);
        C0112q qVar2 = this.f1609b;
        if (qVar2 != null) {
            qVar2.c();
            if (!this.f1610c) {
                this.f1609b.b();
            }
        }
    }

    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f1610c = true;
    }

    public void setImageResource(int i2) {
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.i(i2);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.c();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            eVar.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0100e eVar = this.f1608a;
        if (eVar != null) {
            eVar.j(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0112q qVar = this.f1609b;
        if (qVar != null) {
            qVar.k(mode);
        }
    }

    public r(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public r(Context context, AttributeSet attributeSet, int i2) {
        super(b0.b(context), attributeSet, i2);
        this.f1610c = false;
        a0.a(this, getContext());
        C0100e eVar = new C0100e(this);
        this.f1608a = eVar;
        eVar.e(attributeSet, i2);
        C0112q qVar = new C0112q(this);
        this.f1609b = qVar;
        qVar.g(attributeSet, i2);
    }
}
