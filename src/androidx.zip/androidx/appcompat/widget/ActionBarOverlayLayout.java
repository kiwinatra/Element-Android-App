package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.j;
import androidx.core.view.C;
import androidx.core.view.C0165w0;
import androidx.core.view.D;
import androidx.core.view.E;
import androidx.core.view.W;
import e.C0233a;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements L, C, D {

    /* renamed from: G  reason: collision with root package name */
    static final int[] f1132G = {C0233a.actionBarSize, 16842841};

    /* renamed from: H  reason: collision with root package name */
    private static final C0165w0 f1133H = new C0165w0.b().d(androidx.core.graphics.f.b(0, 1, 0, 1)).a();

    /* renamed from: I  reason: collision with root package name */
    private static final Rect f1134I = new Rect();

    /* renamed from: A  reason: collision with root package name */
    ViewPropertyAnimator f1135A;

    /* renamed from: B  reason: collision with root package name */
    final AnimatorListenerAdapter f1136B;

    /* renamed from: C  reason: collision with root package name */
    private final Runnable f1137C;

    /* renamed from: D  reason: collision with root package name */
    private final Runnable f1138D;

    /* renamed from: E  reason: collision with root package name */
    private final E f1139E;

    /* renamed from: F  reason: collision with root package name */
    private final f f1140F;

    /* renamed from: a  reason: collision with root package name */
    private int f1141a;

    /* renamed from: b  reason: collision with root package name */
    private int f1142b = 0;

    /* renamed from: c  reason: collision with root package name */
    private ContentFrameLayout f1143c;

    /* renamed from: d  reason: collision with root package name */
    ActionBarContainer f1144d;

    /* renamed from: e  reason: collision with root package name */
    private M f1145e;

    /* renamed from: f  reason: collision with root package name */
    private Drawable f1146f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1147g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1148h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f1149i;

    /* renamed from: j  reason: collision with root package name */
    boolean f1150j;

    /* renamed from: k  reason: collision with root package name */
    private int f1151k;

    /* renamed from: l  reason: collision with root package name */
    private int f1152l;

    /* renamed from: m  reason: collision with root package name */
    private final Rect f1153m = new Rect();

    /* renamed from: n  reason: collision with root package name */
    private final Rect f1154n = new Rect();

    /* renamed from: o  reason: collision with root package name */
    private final Rect f1155o = new Rect();

    /* renamed from: p  reason: collision with root package name */
    private final Rect f1156p = new Rect();

    /* renamed from: q  reason: collision with root package name */
    private final Rect f1157q = new Rect();

    /* renamed from: r  reason: collision with root package name */
    private final Rect f1158r = new Rect();

    /* renamed from: s  reason: collision with root package name */
    private final Rect f1159s = new Rect();

    /* renamed from: t  reason: collision with root package name */
    private final Rect f1160t = new Rect();

    /* renamed from: u  reason: collision with root package name */
    private C0165w0 f1161u;

    /* renamed from: v  reason: collision with root package name */
    private C0165w0 f1162v;

    /* renamed from: w  reason: collision with root package name */
    private C0165w0 f1163w;

    /* renamed from: x  reason: collision with root package name */
    private C0165w0 f1164x;

    /* renamed from: y  reason: collision with root package name */
    private d f1165y;

    /* renamed from: z  reason: collision with root package name */
    private OverScroller f1166z;

    class a extends AnimatorListenerAdapter {
        a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1135A = null;
            actionBarOverlayLayout.f1150j = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1135A = null;
            actionBarOverlayLayout.f1150j = false;
        }
    }

    class b implements Runnable {
        b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1135A = actionBarOverlayLayout.f1144d.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f1136B);
        }
    }

    class c implements Runnable {
        c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.v();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1135A = actionBarOverlayLayout.f1144d.animate().translationY((float) (-ActionBarOverlayLayout.this.f1144d.getHeight())).setListener(ActionBarOverlayLayout.this.f1136B);
        }
    }

    public interface d {
        void a(boolean z2);

        void b();

        void c();

        void d(int i2);

        void e();

        void f();
    }

    public static class e extends ViewGroup.MarginLayoutParams {
        public e(int i2, int i3) {
            super(i2, i3);
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    private static final class f extends View {
        f(Context context) {
            super(context);
            setWillNotDraw(true);
        }

        public int getWindowSystemUiVisibility() {
            return 0;
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0165w0 w0Var = C0165w0.f2421b;
        this.f1161u = w0Var;
        this.f1162v = w0Var;
        this.f1163w = w0Var;
        this.f1164x = w0Var;
        this.f1136B = new a();
        this.f1137C = new b();
        this.f1138D = new c();
        w(context);
        this.f1139E = new E(this);
        f fVar = new f(context);
        this.f1140F = fVar;
        addView(fVar);
    }

    private void B() {
        v();
        this.f1137C.run();
    }

    private boolean C(float f2) {
        this.f1166z.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.f1166z.getFinalY() > this.f1144d.getHeight();
    }

    private void p() {
        v();
        this.f1138D.run();
    }

    private boolean q(View view, Rect rect, boolean z2, boolean z3, boolean z4, boolean z5) {
        boolean z6;
        int i2;
        int i3;
        int i4;
        int i5;
        e eVar = (e) view.getLayoutParams();
        if (!z2 || eVar.leftMargin == (i5 = rect.left)) {
            z6 = false;
        } else {
            eVar.leftMargin = i5;
            z6 = true;
        }
        if (z3 && eVar.topMargin != (i4 = rect.top)) {
            eVar.topMargin = i4;
            z6 = true;
        }
        if (z5 && eVar.rightMargin != (i3 = rect.right)) {
            eVar.rightMargin = i3;
            z6 = true;
        }
        if (!z4 || eVar.bottomMargin == (i2 = rect.bottom)) {
            return z6;
        }
        eVar.bottomMargin = i2;
        return true;
    }

    private boolean r() {
        W.h(this.f1140F, f1133H, this.f1156p);
        return !this.f1156p.equals(f1134I);
    }

    private M u(View view) {
        if (view instanceof M) {
            return (M) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void w(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f1132G);
        boolean z2 = false;
        this.f1141a = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f1146f = drawable;
        if (drawable == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        obtainStyledAttributes.recycle();
        this.f1166z = new OverScroller(context);
    }

    private void y() {
        v();
        postDelayed(this.f1138D, 600);
    }

    private void z() {
        v();
        postDelayed(this.f1137C, 600);
    }

    /* access modifiers changed from: package-private */
    public void A() {
        if (this.f1143c == null) {
            this.f1143c = (ContentFrameLayout) findViewById(e.f.action_bar_activity_content);
            this.f1144d = (ActionBarContainer) findViewById(e.f.action_bar_container);
            this.f1145e = u(findViewById(e.f.action_bar));
        }
    }

    public void a(Menu menu, j.a aVar) {
        A();
        this.f1145e.a(menu, aVar);
    }

    public boolean b() {
        A();
        return this.f1145e.b();
    }

    public boolean c() {
        A();
        return this.f1145e.c();
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    public boolean d() {
        A();
        return this.f1145e.d();
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f1146f != null) {
            int bottom = this.f1144d.getVisibility() == 0 ? (int) (((float) this.f1144d.getBottom()) + this.f1144d.getTranslationY() + 0.5f) : 0;
            this.f1146f.setBounds(0, bottom, getWidth(), this.f1146f.getIntrinsicHeight() + bottom);
            this.f1146f.draw(canvas);
        }
    }

    public boolean e() {
        A();
        return this.f1145e.e();
    }

    public void f() {
        A();
        this.f1145e.f();
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    public boolean g() {
        A();
        return this.f1145e.g();
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1144d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        return this.f1139E.a();
    }

    public CharSequence getTitle() {
        A();
        return this.f1145e.getTitle();
    }

    public void h(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    public void i(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    public void k(int i2) {
        A();
        if (i2 == 2) {
            this.f1145e.u();
        } else if (i2 == 5) {
            this.f1145e.w();
        } else if (i2 == 109) {
            setOverlayMode(true);
        }
    }

    public void l() {
        A();
        this.f1145e.h();
    }

    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        n(view, i2, i3, i4, i5, i6);
    }

    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    public boolean o(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        A();
        C0165w0 x2 = C0165w0.x(windowInsets, this);
        boolean q2 = q(this.f1144d, new Rect(x2.j(), x2.l(), x2.k(), x2.i()), true, true, false, true);
        W.h(this, x2, this.f1153m);
        Rect rect = this.f1153m;
        C0165w0 n2 = x2.n(rect.left, rect.top, rect.right, rect.bottom);
        this.f1161u = n2;
        boolean z2 = true;
        if (!this.f1162v.equals(n2)) {
            this.f1162v = this.f1161u;
            q2 = true;
        }
        if (!this.f1154n.equals(this.f1153m)) {
            this.f1154n.set(this.f1153m);
        } else {
            z2 = q2;
        }
        if (z2) {
            requestLayout();
        }
        return x2.a().c().b().v();
    }

    /* access modifiers changed from: protected */
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        w(getContext());
        W.n0(this);
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        v();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = eVar.leftMargin + paddingLeft;
                int i8 = eVar.topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i2, int i3) {
        int i4;
        C0165w0 a2;
        A();
        measureChildWithMargins(this.f1144d, i2, 0, i3, 0);
        e eVar = (e) this.f1144d.getLayoutParams();
        int max = Math.max(0, this.f1144d.getMeasuredWidth() + eVar.leftMargin + eVar.rightMargin);
        int max2 = Math.max(0, this.f1144d.getMeasuredHeight() + eVar.topMargin + eVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f1144d.getMeasuredState());
        boolean z2 = (W.N(this) & 256) != 0;
        if (z2) {
            i4 = this.f1141a;
            if (this.f1148h && this.f1144d.getTabContainer() != null) {
                i4 += this.f1141a;
            }
        } else {
            i4 = this.f1144d.getVisibility() != 8 ? this.f1144d.getMeasuredHeight() : 0;
        }
        this.f1155o.set(this.f1153m);
        this.f1163w = this.f1161u;
        if (this.f1147g || z2 || !r()) {
            a2 = new C0165w0.b(this.f1163w).d(androidx.core.graphics.f.b(this.f1163w.j(), this.f1163w.l() + i4, this.f1163w.k(), this.f1163w.i())).a();
        } else {
            Rect rect = this.f1155o;
            rect.top += i4;
            rect.bottom = rect.bottom;
            a2 = this.f1163w.n(0, i4, 0, 0);
        }
        this.f1163w = a2;
        q(this.f1143c, this.f1155o, true, true, true, true);
        if (!this.f1164x.equals(this.f1163w)) {
            C0165w0 w0Var = this.f1163w;
            this.f1164x = w0Var;
            W.i(this.f1143c, w0Var);
        }
        measureChildWithMargins(this.f1143c, i2, 0, i3, 0);
        e eVar2 = (e) this.f1143c.getLayoutParams();
        int max3 = Math.max(max, this.f1143c.getMeasuredWidth() + eVar2.leftMargin + eVar2.rightMargin);
        int max4 = Math.max(max2, this.f1143c.getMeasuredHeight() + eVar2.topMargin + eVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f1143c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(max4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.f1149i || !z2) {
            return false;
        }
        if (C(f3)) {
            p();
        } else {
            B();
        }
        this.f1150j = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f1151k + i3;
        this.f1151k = i6;
        setActionBarHideOffset(i6);
    }

    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1139E.b(view, view2, i2);
        this.f1151k = getActionBarHideOffset();
        v();
        d dVar = this.f1165y;
        if (dVar != null) {
            dVar.c();
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f1144d.getVisibility() != 0) {
            return false;
        }
        return this.f1149i;
    }

    public void onStopNestedScroll(View view) {
        if (this.f1149i && !this.f1150j) {
            if (this.f1151k <= this.f1144d.getHeight()) {
                z();
            } else {
                y();
            }
        }
        d dVar = this.f1165y;
        if (dVar != null) {
            dVar.f();
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        A();
        int i3 = this.f1152l ^ i2;
        this.f1152l = i2;
        boolean z2 = false;
        boolean z3 = (i2 & 4) == 0;
        if ((i2 & 256) != 0) {
            z2 = true;
        }
        d dVar = this.f1165y;
        if (dVar != null) {
            dVar.a(!z2);
            if (z3 || !z2) {
                this.f1165y.b();
            } else {
                this.f1165y.e();
            }
        }
        if ((i3 & 256) != 0 && this.f1165y != null) {
            W.n0(this);
        }
    }

    /* access modifiers changed from: protected */
    public void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.f1142b = i2;
        d dVar = this.f1165y;
        if (dVar != null) {
            dVar.d(i2);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    public void setActionBarHideOffset(int i2) {
        v();
        this.f1144d.setTranslationY((float) (-Math.max(0, Math.min(i2, this.f1144d.getHeight()))));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.f1165y = dVar;
        if (getWindowToken() != null) {
            this.f1165y.d(this.f1142b);
            int i2 = this.f1152l;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                W.n0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f1148h = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f1149i) {
            this.f1149i = z2;
            if (!z2) {
                v();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i2) {
        A();
        this.f1145e.setIcon(i2);
    }

    public void setLogo(int i2) {
        A();
        this.f1145e.m(i2);
    }

    public void setOverlayMode(boolean z2) {
        this.f1147g = z2;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    public void setWindowCallback(Window.Callback callback) {
        A();
        this.f1145e.setWindowCallback(callback);
    }

    public void setWindowTitle(CharSequence charSequence) {
        A();
        this.f1145e.setWindowTitle(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* renamed from: t */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    /* access modifiers changed from: package-private */
    public void v() {
        removeCallbacks(this.f1137C);
        removeCallbacks(this.f1138D);
        ViewPropertyAnimator viewPropertyAnimator = this.f1135A;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean x() {
        return this.f1147g;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        A();
        this.f1145e.setIcon(drawable);
    }
}
