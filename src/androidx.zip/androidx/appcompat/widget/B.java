package androidx.appcompat.widget;

import android.widget.ThemedSpinnerAdapter;

public abstract /* synthetic */ class B {
    public static /* bridge */ /* synthetic */ boolean a(Object obj) {
        return obj instanceof ThemedSpinnerAdapter;
    }
}
