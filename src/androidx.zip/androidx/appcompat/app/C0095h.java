package androidx.appcompat.app;

import androidx.appcompat.app.C0094g;

/* renamed from: androidx.appcompat.app.h  reason: case insensitive filesystem */
public final /* synthetic */ class C0095h implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0094g.c f689a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Runnable f690b;

    public /* synthetic */ C0095h(C0094g.c cVar, Runnable runnable) {
        this.f689a = cVar;
        this.f690b = runnable;
    }

    public final void run() {
        this.f689a.d(this.f690b);
    }
}
