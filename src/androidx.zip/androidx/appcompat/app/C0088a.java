package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.ViewGroup;
import androidx.appcompat.view.b;
import e.j;

/* renamed from: androidx.appcompat.app.a  reason: case insensitive filesystem */
public abstract class C0088a {

    /* renamed from: androidx.appcompat.app.a$a  reason: collision with other inner class name */
    public static class C0014a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        public int f652a = 8388627;

        public C0014a(int i2, int i3) {
            super(i2, i3);
        }

        public C0014a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.f5359t);
            this.f652a = obtainStyledAttributes.getInt(j.f5361u, 0);
            obtainStyledAttributes.recycle();
        }

        public C0014a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0014a(C0014a aVar) {
            super(aVar);
            this.f652a = aVar.f652a;
        }
    }

    public boolean g() {
        return false;
    }

    public abstract boolean h();

    public abstract void i(boolean z2);

    public abstract int j();

    public abstract Context k();

    public boolean l() {
        return false;
    }

    public void m(Configuration configuration) {
    }

    /* access modifiers changed from: package-private */
    public void n() {
    }

    public abstract boolean o(int i2, KeyEvent keyEvent);

    public boolean p(KeyEvent keyEvent) {
        return false;
    }

    public boolean q() {
        return false;
    }

    public abstract void r(boolean z2);

    public abstract void s(boolean z2);

    public abstract void t(int i2);

    public abstract void u(Drawable drawable);

    public abstract void v(boolean z2);

    public abstract void w(boolean z2);

    public abstract void x(CharSequence charSequence);

    public b y(b.a aVar) {
        return null;
    }
}
