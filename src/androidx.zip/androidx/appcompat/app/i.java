package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.app.C0089b;
import androidx.appcompat.view.b;
import androidx.appcompat.view.f;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.C0106k;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.L;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.e0;
import androidx.appcompat.widget.o0;
import androidx.appcompat.widget.p0;
import androidx.core.content.res.h;
import androidx.core.view.C0130e0;
import androidx.core.view.C0132f0;
import androidx.core.view.C0134g0;
import androidx.core.view.C0158t;
import androidx.core.view.C0160u;
import androidx.core.view.C0165w0;
import androidx.core.view.F;
import androidx.core.view.W;
import androidx.lifecycle.C0190g;
import e.C0233a;
import e.C0235c;
import f.C0236a;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;

class i extends C0094g implements e.a, LayoutInflater.Factory2 {

    /* renamed from: j0  reason: collision with root package name */
    private static final l.g f691j0 = new l.g();

    /* renamed from: k0  reason: collision with root package name */
    private static final boolean f692k0 = false;

    /* renamed from: l0  reason: collision with root package name */
    private static final int[] f693l0 = {16842836};

    /* renamed from: m0  reason: collision with root package name */
    private static final boolean f694m0 = (!"robolectric".equals(Build.FINGERPRINT));

    /* renamed from: A  reason: collision with root package name */
    private boolean f695A;

    /* renamed from: B  reason: collision with root package name */
    ViewGroup f696B;

    /* renamed from: C  reason: collision with root package name */
    private TextView f697C;

    /* renamed from: D  reason: collision with root package name */
    private View f698D;

    /* renamed from: E  reason: collision with root package name */
    private boolean f699E;

    /* renamed from: F  reason: collision with root package name */
    private boolean f700F;

    /* renamed from: G  reason: collision with root package name */
    boolean f701G;

    /* renamed from: H  reason: collision with root package name */
    boolean f702H;

    /* renamed from: I  reason: collision with root package name */
    boolean f703I;

    /* renamed from: J  reason: collision with root package name */
    boolean f704J;

    /* renamed from: K  reason: collision with root package name */
    boolean f705K;

    /* renamed from: L  reason: collision with root package name */
    private boolean f706L;

    /* renamed from: M  reason: collision with root package name */
    private s[] f707M;

    /* renamed from: N  reason: collision with root package name */
    private s f708N;

    /* renamed from: O  reason: collision with root package name */
    private boolean f709O;

    /* renamed from: P  reason: collision with root package name */
    private boolean f710P;

    /* renamed from: Q  reason: collision with root package name */
    private boolean f711Q;

    /* renamed from: R  reason: collision with root package name */
    boolean f712R;

    /* renamed from: S  reason: collision with root package name */
    private Configuration f713S;

    /* renamed from: T  reason: collision with root package name */
    private int f714T;

    /* renamed from: U  reason: collision with root package name */
    private int f715U;

    /* renamed from: V  reason: collision with root package name */
    private int f716V;

    /* renamed from: W  reason: collision with root package name */
    private boolean f717W;

    /* renamed from: X  reason: collision with root package name */
    private p f718X;

    /* renamed from: Y  reason: collision with root package name */
    private p f719Y;

    /* renamed from: Z  reason: collision with root package name */
    boolean f720Z;

    /* renamed from: a0  reason: collision with root package name */
    int f721a0;

    /* renamed from: b0  reason: collision with root package name */
    private final Runnable f722b0;

    /* renamed from: c0  reason: collision with root package name */
    private boolean f723c0;

    /* renamed from: d0  reason: collision with root package name */
    private Rect f724d0;

    /* renamed from: e0  reason: collision with root package name */
    private Rect f725e0;

    /* renamed from: f0  reason: collision with root package name */
    private z f726f0;

    /* renamed from: g0  reason: collision with root package name */
    private B f727g0;

    /* renamed from: h0  reason: collision with root package name */
    private OnBackInvokedDispatcher f728h0;

    /* renamed from: i0  reason: collision with root package name */
    private OnBackInvokedCallback f729i0;

    /* renamed from: j  reason: collision with root package name */
    final Object f730j;

    /* renamed from: k  reason: collision with root package name */
    final Context f731k;

    /* renamed from: l  reason: collision with root package name */
    Window f732l;

    /* renamed from: m  reason: collision with root package name */
    private n f733m;

    /* renamed from: n  reason: collision with root package name */
    final C0092e f734n;

    /* renamed from: o  reason: collision with root package name */
    C0088a f735o;

    /* renamed from: p  reason: collision with root package name */
    MenuInflater f736p;

    /* renamed from: q  reason: collision with root package name */
    private CharSequence f737q;

    /* renamed from: r  reason: collision with root package name */
    private L f738r;

    /* renamed from: s  reason: collision with root package name */
    private h f739s;

    /* renamed from: t  reason: collision with root package name */
    private t f740t;

    /* renamed from: u  reason: collision with root package name */
    androidx.appcompat.view.b f741u;

    /* renamed from: v  reason: collision with root package name */
    ActionBarContextView f742v;

    /* renamed from: w  reason: collision with root package name */
    PopupWindow f743w;

    /* renamed from: x  reason: collision with root package name */
    Runnable f744x;

    /* renamed from: y  reason: collision with root package name */
    C0130e0 f745y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f746z;

    class a implements Runnable {
        a() {
        }

        public void run() {
            i iVar = i.this;
            if ((iVar.f721a0 & 1) != 0) {
                iVar.i0(0);
            }
            i iVar2 = i.this;
            if ((iVar2.f721a0 & 4096) != 0) {
                iVar2.i0(108);
            }
            i iVar3 = i.this;
            iVar3.f720Z = false;
            iVar3.f721a0 = 0;
        }
    }

    class b implements F {
        b() {
        }

        public C0165w0 a(View view, C0165w0 w0Var) {
            int l2 = w0Var.l();
            int f1 = i.this.f1(w0Var, (Rect) null);
            if (l2 != f1) {
                w0Var = w0Var.q(w0Var.j(), f1, w0Var.k(), w0Var.i());
            }
            return W.c0(view, w0Var);
        }
    }

    class c implements ContentFrameLayout.a {
        c() {
        }

        public void a() {
        }

        public void onDetachedFromWindow() {
            i.this.g0();
        }
    }

    class d implements Runnable {

        class a extends C0134g0 {
            a() {
            }

            public void a(View view) {
                i.this.f742v.setAlpha(1.0f);
                i.this.f745y.h((C0132f0) null);
                i.this.f745y = null;
            }

            public void b(View view) {
                i.this.f742v.setVisibility(0);
            }
        }

        d() {
        }

        public void run() {
            i iVar = i.this;
            iVar.f743w.showAtLocation(iVar.f742v, 55, 0, 0);
            i.this.j0();
            if (i.this.U0()) {
                i.this.f742v.setAlpha(0.0f);
                i iVar2 = i.this;
                iVar2.f745y = W.e(iVar2.f742v).b(1.0f);
                i.this.f745y.h(new a());
                return;
            }
            i.this.f742v.setAlpha(1.0f);
            i.this.f742v.setVisibility(0);
        }
    }

    class e extends C0134g0 {
        e() {
        }

        public void a(View view) {
            i.this.f742v.setAlpha(1.0f);
            i.this.f745y.h((C0132f0) null);
            i.this.f745y = null;
        }

        public void b(View view) {
            i.this.f742v.setVisibility(0);
            if (i.this.f742v.getParent() instanceof View) {
                W.n0((View) i.this.f742v.getParent());
            }
        }
    }

    private class f implements C0089b.C0015b {
        f() {
        }

        public void a(Drawable drawable, int i2) {
            C0088a s2 = i.this.s();
            if (s2 != null) {
                s2.u(drawable);
                s2.t(i2);
            }
        }

        public Context b() {
            return i.this.o0();
        }

        public boolean c() {
            C0088a s2 = i.this.s();
            return (s2 == null || (s2.j() & 4) == 0) ? false : true;
        }

        public Drawable d() {
            e0 u2 = e0.u(b(), (AttributeSet) null, new int[]{C0233a.homeAsUpIndicator});
            Drawable g2 = u2.g(0);
            u2.x();
            return g2;
        }
    }

    interface g {
        boolean a(int i2);

        View onCreatePanelView(int i2);
    }

    private final class h implements j.a {
        h() {
        }

        public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
            i.this.Z(eVar);
        }

        public boolean b(androidx.appcompat.view.menu.e eVar) {
            Window.Callback v02 = i.this.v0();
            if (v02 == null) {
                return true;
            }
            v02.onMenuOpened(108, eVar);
            return true;
        }
    }

    /* renamed from: androidx.appcompat.app.i$i  reason: collision with other inner class name */
    class C0016i implements b.a {

        /* renamed from: a  reason: collision with root package name */
        private b.a f755a;

        /* renamed from: androidx.appcompat.app.i$i$a */
        class a extends C0134g0 {
            a() {
            }

            public void a(View view) {
                i.this.f742v.setVisibility(8);
                i iVar = i.this;
                PopupWindow popupWindow = iVar.f743w;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (iVar.f742v.getParent() instanceof View) {
                    W.n0((View) i.this.f742v.getParent());
                }
                i.this.f742v.k();
                i.this.f745y.h((C0132f0) null);
                i iVar2 = i.this;
                iVar2.f745y = null;
                W.n0(iVar2.f696B);
            }
        }

        public C0016i(b.a aVar) {
            this.f755a = aVar;
        }

        public boolean a(androidx.appcompat.view.b bVar, Menu menu) {
            W.n0(i.this.f696B);
            return this.f755a.a(bVar, menu);
        }

        public boolean b(androidx.appcompat.view.b bVar, MenuItem menuItem) {
            return this.f755a.b(bVar, menuItem);
        }

        public boolean c(androidx.appcompat.view.b bVar, Menu menu) {
            return this.f755a.c(bVar, menu);
        }

        public void d(androidx.appcompat.view.b bVar) {
            this.f755a.d(bVar);
            i iVar = i.this;
            if (iVar.f743w != null) {
                iVar.f732l.getDecorView().removeCallbacks(i.this.f744x);
            }
            i iVar2 = i.this;
            if (iVar2.f742v != null) {
                iVar2.j0();
                i iVar3 = i.this;
                iVar3.f745y = W.e(iVar3.f742v).b(0.0f);
                i.this.f745y.h(new a());
            }
            i iVar4 = i.this;
            C0092e eVar = iVar4.f734n;
            if (eVar != null) {
                eVar.u(iVar4.f741u);
            }
            i iVar5 = i.this;
            iVar5.f741u = null;
            W.n0(iVar5.f696B);
            i.this.d1();
        }
    }

    static class j {
        static boolean a(PowerManager powerManager) {
            return powerManager.isPowerSaveMode();
        }

        static String b(Locale locale) {
            return locale.toLanguageTag();
        }
    }

    static class k {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            LocaleList a2 = configuration.getLocales();
            LocaleList a3 = configuration2.getLocales();
            if (!a2.equals(a3)) {
                configuration3.setLocales(a3);
                configuration3.locale = configuration2.locale;
            }
        }

        static androidx.core.os.b b(Configuration configuration) {
            return androidx.core.os.b.c(configuration.getLocales().toLanguageTags());
        }

        public static void c(androidx.core.os.b bVar) {
            LocaleList.setDefault(LocaleList.forLanguageTags(bVar.h()));
        }

        static void d(Configuration configuration, androidx.core.os.b bVar) {
            configuration.setLocales(LocaleList.forLanguageTags(bVar.h()));
        }
    }

    static class l {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            if ((configuration.colorMode & 3) != (configuration2.colorMode & 3)) {
                configuration3.colorMode = configuration3.colorMode | (configuration2.colorMode & 3);
            }
            if ((configuration.colorMode & 12) != (configuration2.colorMode & 12)) {
                configuration3.colorMode = configuration3.colorMode | (configuration2.colorMode & 12);
            }
        }
    }

    static class m {
        static OnBackInvokedDispatcher a(Activity activity) {
            return activity.getOnBackInvokedDispatcher();
        }

        static OnBackInvokedCallback b(Object obj, i iVar) {
            Objects.requireNonNull(iVar);
            w wVar = new w(iVar);
            s.a(obj).registerOnBackInvokedCallback(1000000, wVar);
            return wVar;
        }

        static void c(Object obj, Object obj2) {
            s.a(obj).unregisterOnBackInvokedCallback(r.a(obj2));
        }
    }

    class n extends androidx.appcompat.view.i {

        /* renamed from: b  reason: collision with root package name */
        private g f758b;

        /* renamed from: c  reason: collision with root package name */
        private boolean f759c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f760d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f761e;

        n(Window.Callback callback) {
            super(callback);
        }

        /* JADX INFO: finally extract failed */
        public boolean b(Window.Callback callback, KeyEvent keyEvent) {
            try {
                this.f760d = true;
                boolean dispatchKeyEvent = callback.dispatchKeyEvent(keyEvent);
                this.f760d = false;
                return dispatchKeyEvent;
            } catch (Throwable th) {
                this.f760d = false;
                throw th;
            }
        }

        /* JADX INFO: finally extract failed */
        public void c(Window.Callback callback) {
            try {
                this.f759c = true;
                callback.onContentChanged();
                this.f759c = false;
            } catch (Throwable th) {
                this.f759c = false;
                throw th;
            }
        }

        /* JADX INFO: finally extract failed */
        public void d(Window.Callback callback, int i2, Menu menu) {
            try {
                this.f761e = true;
                callback.onPanelClosed(i2, menu);
                this.f761e = false;
            } catch (Throwable th) {
                this.f761e = false;
                throw th;
            }
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return this.f760d ? a().dispatchKeyEvent(keyEvent) : i.this.h0(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || i.this.G0(keyEvent.getKeyCode(), keyEvent);
        }

        /* access modifiers changed from: package-private */
        public void e(g gVar) {
            this.f758b = gVar;
        }

        /* access modifiers changed from: package-private */
        public final ActionMode f(ActionMode.Callback callback) {
            f.a aVar = new f.a(i.this.f731k, callback);
            androidx.appcompat.view.b X0 = i.this.X0(aVar);
            if (X0 != null) {
                return aVar.e(X0);
            }
            return null;
        }

        public void onContentChanged() {
            if (this.f759c) {
                a().onContentChanged();
            }
        }

        public boolean onCreatePanelMenu(int i2, Menu menu) {
            if (i2 != 0 || (menu instanceof androidx.appcompat.view.menu.e)) {
                return super.onCreatePanelMenu(i2, menu);
            }
            return false;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
            r0 = r0.onCreatePanelView(r2);
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public android.view.View onCreatePanelView(int r2) {
            /*
                r1 = this;
                androidx.appcompat.app.i$g r0 = r1.f758b
                if (r0 == 0) goto L_0x000b
                android.view.View r0 = r0.onCreatePanelView(r2)
                if (r0 == 0) goto L_0x000b
                return r0
            L_0x000b:
                android.view.View r2 = super.onCreatePanelView(r2)
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.n.onCreatePanelView(int):android.view.View");
        }

        public boolean onMenuOpened(int i2, Menu menu) {
            super.onMenuOpened(i2, menu);
            i.this.J0(i2);
            return true;
        }

        public void onPanelClosed(int i2, Menu menu) {
            if (this.f761e) {
                a().onPanelClosed(i2, menu);
                return;
            }
            super.onPanelClosed(i2, menu);
            i.this.K0(i2);
        }

        public boolean onPreparePanel(int i2, View view, Menu menu) {
            androidx.appcompat.view.menu.e eVar = menu instanceof androidx.appcompat.view.menu.e ? (androidx.appcompat.view.menu.e) menu : null;
            if (i2 == 0 && eVar == null) {
                return false;
            }
            boolean z2 = true;
            if (eVar != null) {
                eVar.f0(true);
            }
            g gVar = this.f758b;
            if (gVar == null || !gVar.a(i2)) {
                z2 = false;
            }
            if (!z2) {
                z2 = super.onPreparePanel(i2, view, menu);
            }
            if (eVar != null) {
                eVar.f0(false);
            }
            return z2;
        }

        public void onProvideKeyboardShortcuts(List list, Menu menu, int i2) {
            androidx.appcompat.view.menu.e eVar;
            s t02 = i.this.t0(0, true);
            if (t02 == null || (eVar = t02.f780j) == null) {
                super.onProvideKeyboardShortcuts(list, menu, i2);
            } else {
                super.onProvideKeyboardShortcuts(list, eVar, i2);
            }
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            return i.this.B0() ? f(callback) : super.onWindowStartingActionMode(callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i2) {
            return (!i.this.B0() || i2 != 0) ? super.onWindowStartingActionMode(callback, i2) : f(callback);
        }
    }

    private class o extends p {

        /* renamed from: c  reason: collision with root package name */
        private final PowerManager f763c;

        o(Context context) {
            super();
            this.f763c = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        /* access modifiers changed from: package-private */
        public IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        public int c() {
            return j.a(this.f763c) ? 2 : 1;
        }

        public void d() {
            i.this.T();
        }
    }

    abstract class p {

        /* renamed from: a  reason: collision with root package name */
        private BroadcastReceiver f765a;

        class a extends BroadcastReceiver {
            a() {
            }

            public void onReceive(Context context, Intent intent) {
                p.this.d();
            }
        }

        p() {
        }

        /* access modifiers changed from: package-private */
        public void a() {
            BroadcastReceiver broadcastReceiver = this.f765a;
            if (broadcastReceiver != null) {
                try {
                    i.this.f731k.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f765a = null;
            }
        }

        /* access modifiers changed from: package-private */
        public abstract IntentFilter b();

        /* access modifiers changed from: package-private */
        public abstract int c();

        /* access modifiers changed from: package-private */
        public abstract void d();

        /* access modifiers changed from: package-private */
        public void e() {
            a();
            IntentFilter b2 = b();
            if (b2 != null && b2.countActions() != 0) {
                if (this.f765a == null) {
                    this.f765a = new a();
                }
                i.this.f731k.registerReceiver(this.f765a, b2);
            }
        }
    }

    private class q extends p {

        /* renamed from: c  reason: collision with root package name */
        private final G f768c;

        q(G g2) {
            super();
            this.f768c = g2;
        }

        /* access modifiers changed from: package-private */
        public IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        public int c() {
            return this.f768c.d() ? 2 : 1;
        }

        public void d() {
            i.this.T();
        }
    }

    private class r extends ContentFrameLayout {
        public r(Context context) {
            super(context);
        }

        private boolean b(int i2, int i3) {
            return i2 < -5 || i3 < -5 || i2 > getWidth() + 5 || i3 > getHeight() + 5;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return i.this.h0(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !b((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            i.this.b0(0);
            return true;
        }

        public void setBackgroundResource(int i2) {
            setBackgroundDrawable(C0236a.b(getContext(), i2));
        }
    }

    protected static final class s {

        /* renamed from: a  reason: collision with root package name */
        int f771a;

        /* renamed from: b  reason: collision with root package name */
        int f772b;

        /* renamed from: c  reason: collision with root package name */
        int f773c;

        /* renamed from: d  reason: collision with root package name */
        int f774d;

        /* renamed from: e  reason: collision with root package name */
        int f775e;

        /* renamed from: f  reason: collision with root package name */
        int f776f;

        /* renamed from: g  reason: collision with root package name */
        ViewGroup f777g;

        /* renamed from: h  reason: collision with root package name */
        View f778h;

        /* renamed from: i  reason: collision with root package name */
        View f779i;

        /* renamed from: j  reason: collision with root package name */
        androidx.appcompat.view.menu.e f780j;

        /* renamed from: k  reason: collision with root package name */
        androidx.appcompat.view.menu.c f781k;

        /* renamed from: l  reason: collision with root package name */
        Context f782l;

        /* renamed from: m  reason: collision with root package name */
        boolean f783m;

        /* renamed from: n  reason: collision with root package name */
        boolean f784n;

        /* renamed from: o  reason: collision with root package name */
        boolean f785o;

        /* renamed from: p  reason: collision with root package name */
        public boolean f786p;

        /* renamed from: q  reason: collision with root package name */
        boolean f787q = false;

        /* renamed from: r  reason: collision with root package name */
        boolean f788r;

        /* renamed from: s  reason: collision with root package name */
        Bundle f789s;

        s(int i2) {
            this.f771a = i2;
        }

        /* access modifiers changed from: package-private */
        public androidx.appcompat.view.menu.k a(j.a aVar) {
            if (this.f780j == null) {
                return null;
            }
            if (this.f781k == null) {
                androidx.appcompat.view.menu.c cVar = new androidx.appcompat.view.menu.c(this.f782l, e.g.abc_list_menu_item_layout);
                this.f781k = cVar;
                cVar.l(aVar);
                this.f780j.b(this.f781k);
            }
            return this.f781k.f(this.f777g);
        }

        public boolean b() {
            if (this.f778h == null) {
                return false;
            }
            return this.f779i != null || this.f781k.b().getCount() > 0;
        }

        /* access modifiers changed from: package-private */
        public void c(androidx.appcompat.view.menu.e eVar) {
            androidx.appcompat.view.menu.c cVar;
            androidx.appcompat.view.menu.e eVar2 = this.f780j;
            if (eVar != eVar2) {
                if (eVar2 != null) {
                    eVar2.R(this.f781k);
                }
                this.f780j = eVar;
                if (eVar != null && (cVar = this.f781k) != null) {
                    eVar.b(cVar);
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void d(Context context) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(C0233a.actionBarPopupTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                newTheme.applyStyle(i2, true);
            }
            newTheme.resolveAttribute(C0233a.panelMenuListTheme, typedValue, true);
            int i3 = typedValue.resourceId;
            if (i3 == 0) {
                i3 = e.i.Theme_AppCompat_CompactMenu;
            }
            newTheme.applyStyle(i3, true);
            androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, 0);
            dVar.getTheme().setTo(newTheme);
            this.f782l = dVar;
            TypedArray obtainStyledAttributes = dVar.obtainStyledAttributes(e.j.f5370y0);
            this.f772b = obtainStyledAttributes.getResourceId(e.j.f5295B0, 0);
            this.f776f = obtainStyledAttributes.getResourceId(e.j.f5293A0, 0);
            obtainStyledAttributes.recycle();
        }
    }

    private final class t implements j.a {
        t() {
        }

        public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
            androidx.appcompat.view.menu.e F2 = eVar.F();
            boolean z3 = F2 != eVar;
            i iVar = i.this;
            if (z3) {
                eVar = F2;
            }
            s m02 = iVar.m0(eVar);
            if (m02 == null) {
                return;
            }
            if (z3) {
                i.this.Y(m02.f771a, m02, F2);
                i.this.c0(m02, true);
                return;
            }
            i.this.c0(m02, z2);
        }

        public boolean b(androidx.appcompat.view.menu.e eVar) {
            Window.Callback v02;
            if (eVar != eVar.F()) {
                return true;
            }
            i iVar = i.this;
            if (!iVar.f701G || (v02 = iVar.v0()) == null || i.this.f712R) {
                return true;
            }
            v02.onMenuOpened(108, eVar);
            return true;
        }
    }

    i(Activity activity, C0092e eVar) {
        this(activity, (Window) null, eVar, activity);
    }

    private void A0(int i2) {
        this.f721a0 = (1 << i2) | this.f721a0;
        if (!this.f720Z) {
            W.i0(this.f732l.getDecorView(), this.f722b0);
            this.f720Z = true;
        }
    }

    private boolean F0(int i2, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() != 0) {
            return false;
        }
        s t02 = t0(i2, true);
        if (!t02.f785o) {
            return P0(t02, keyEvent);
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x006a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean I0(int r5, android.view.KeyEvent r6) {
        /*
            r4 = this;
            androidx.appcompat.view.b r0 = r4.f741u
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            r0 = 1
            androidx.appcompat.app.i$s r2 = r4.t0(r5, r0)
            if (r5 != 0) goto L_0x0043
            androidx.appcompat.widget.L r5 = r4.f738r
            if (r5 == 0) goto L_0x0043
            boolean r5 = r5.g()
            if (r5 == 0) goto L_0x0043
            android.content.Context r5 = r4.f731k
            android.view.ViewConfiguration r5 = android.view.ViewConfiguration.get(r5)
            boolean r5 = r5.hasPermanentMenuKey()
            if (r5 != 0) goto L_0x0043
            androidx.appcompat.widget.L r5 = r4.f738r
            boolean r5 = r5.c()
            if (r5 != 0) goto L_0x003c
            boolean r5 = r4.f712R
            if (r5 != 0) goto L_0x0062
            boolean r5 = r4.P0(r2, r6)
            if (r5 == 0) goto L_0x0062
            androidx.appcompat.widget.L r5 = r4.f738r
            boolean r0 = r5.e()
            goto L_0x0068
        L_0x003c:
            androidx.appcompat.widget.L r5 = r4.f738r
            boolean r0 = r5.d()
            goto L_0x0068
        L_0x0043:
            boolean r5 = r2.f785o
            if (r5 != 0) goto L_0x0064
            boolean r3 = r2.f784n
            if (r3 == 0) goto L_0x004c
            goto L_0x0064
        L_0x004c:
            boolean r5 = r2.f783m
            if (r5 == 0) goto L_0x0062
            boolean r5 = r2.f788r
            if (r5 == 0) goto L_0x005b
            r2.f783m = r1
            boolean r5 = r4.P0(r2, r6)
            goto L_0x005c
        L_0x005b:
            r5 = 1
        L_0x005c:
            if (r5 == 0) goto L_0x0062
            r4.M0(r2, r6)
            goto L_0x0068
        L_0x0062:
            r0 = 0
            goto L_0x0068
        L_0x0064:
            r4.c0(r2, r0)
            r0 = r5
        L_0x0068:
            if (r0 == 0) goto L_0x0085
            android.content.Context r5 = r4.f731k
            android.content.Context r5 = r5.getApplicationContext()
            java.lang.String r6 = "audio"
            java.lang.Object r5 = r5.getSystemService(r6)
            android.media.AudioManager r5 = (android.media.AudioManager) r5
            if (r5 == 0) goto L_0x007e
            r5.playSoundEffect(r1)
            goto L_0x0085
        L_0x007e:
            java.lang.String r5 = "AppCompatDelegate"
            java.lang.String r6 = "Couldn't get audio manager"
            android.util.Log.w(r5, r6)
        L_0x0085:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.I0(int, android.view.KeyEvent):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x00ed  */
    /* JADX WARNING: Removed duplicated region for block: B:63:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void M0(androidx.appcompat.app.i.s r12, android.view.KeyEvent r13) {
        /*
            r11 = this;
            boolean r0 = r12.f785o
            if (r0 != 0) goto L_0x00f3
            boolean r0 = r11.f712R
            if (r0 == 0) goto L_0x000a
            goto L_0x00f3
        L_0x000a:
            int r0 = r12.f771a
            if (r0 != 0) goto L_0x0020
            android.content.Context r0 = r11.f731k
            android.content.res.Resources r0 = r0.getResources()
            android.content.res.Configuration r0 = r0.getConfiguration()
            int r0 = r0.screenLayout
            r0 = r0 & 15
            r1 = 4
            if (r0 != r1) goto L_0x0020
            return
        L_0x0020:
            android.view.Window$Callback r0 = r11.v0()
            r1 = 1
            if (r0 == 0) goto L_0x0035
            int r2 = r12.f771a
            androidx.appcompat.view.menu.e r3 = r12.f780j
            boolean r0 = r0.onMenuOpened(r2, r3)
            if (r0 != 0) goto L_0x0035
            r11.c0(r12, r1)
            return
        L_0x0035:
            android.content.Context r0 = r11.f731k
            java.lang.String r2 = "window"
            java.lang.Object r0 = r0.getSystemService(r2)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            if (r0 != 0) goto L_0x0042
            return
        L_0x0042:
            boolean r13 = r11.P0(r12, r13)
            if (r13 != 0) goto L_0x0049
            return
        L_0x0049:
            android.view.ViewGroup r13 = r12.f777g
            r2 = -2
            if (r13 == 0) goto L_0x0064
            boolean r3 = r12.f787q
            if (r3 == 0) goto L_0x0053
            goto L_0x0064
        L_0x0053:
            android.view.View r13 = r12.f779i
            if (r13 == 0) goto L_0x00c6
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            if (r13 == 0) goto L_0x00c6
            int r13 = r13.width
            r3 = -1
            if (r13 != r3) goto L_0x00c6
            r4 = -1
            goto L_0x00c7
        L_0x0064:
            if (r13 != 0) goto L_0x0071
            boolean r13 = r11.y0(r12)
            if (r13 == 0) goto L_0x0070
            android.view.ViewGroup r13 = r12.f777g
            if (r13 != 0) goto L_0x0080
        L_0x0070:
            return
        L_0x0071:
            boolean r3 = r12.f787q
            if (r3 == 0) goto L_0x0080
            int r13 = r13.getChildCount()
            if (r13 <= 0) goto L_0x0080
            android.view.ViewGroup r13 = r12.f777g
            r13.removeAllViews()
        L_0x0080:
            boolean r13 = r11.x0(r12)
            if (r13 == 0) goto L_0x00f1
            boolean r13 = r12.b()
            if (r13 != 0) goto L_0x008d
            goto L_0x00f1
        L_0x008d:
            android.view.View r13 = r12.f778h
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            if (r13 != 0) goto L_0x009a
            android.view.ViewGroup$LayoutParams r13 = new android.view.ViewGroup$LayoutParams
            r13.<init>(r2, r2)
        L_0x009a:
            int r3 = r12.f772b
            android.view.ViewGroup r4 = r12.f777g
            r4.setBackgroundResource(r3)
            android.view.View r3 = r12.f778h
            android.view.ViewParent r3 = r3.getParent()
            boolean r4 = r3 instanceof android.view.ViewGroup
            if (r4 == 0) goto L_0x00b2
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            android.view.View r4 = r12.f778h
            r3.removeView(r4)
        L_0x00b2:
            android.view.ViewGroup r3 = r12.f777g
            android.view.View r4 = r12.f778h
            r3.addView(r4, r13)
            android.view.View r13 = r12.f778h
            boolean r13 = r13.hasFocus()
            if (r13 != 0) goto L_0x00c6
            android.view.View r13 = r12.f778h
            r13.requestFocus()
        L_0x00c6:
            r4 = -2
        L_0x00c7:
            r13 = 0
            r12.f784n = r13
            android.view.WindowManager$LayoutParams r13 = new android.view.WindowManager$LayoutParams
            int r6 = r12.f774d
            int r7 = r12.f775e
            r9 = 8519680(0x820000, float:1.1938615E-38)
            r10 = -3
            r5 = -2
            r8 = 1002(0x3ea, float:1.404E-42)
            r3 = r13
            r3.<init>(r4, r5, r6, r7, r8, r9, r10)
            int r2 = r12.f773c
            r13.gravity = r2
            int r2 = r12.f776f
            r13.windowAnimations = r2
            android.view.ViewGroup r2 = r12.f777g
            r0.addView(r2, r13)
            r12.f785o = r1
            int r12 = r12.f771a
            if (r12 != 0) goto L_0x00f0
            r11.d1()
        L_0x00f0:
            return
        L_0x00f1:
            r12.f787q = r1
        L_0x00f3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.M0(androidx.appcompat.app.i$s, android.view.KeyEvent):void");
    }

    private boolean O0(s sVar, int i2, KeyEvent keyEvent, int i3) {
        androidx.appcompat.view.menu.e eVar;
        boolean z2 = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((sVar.f783m || P0(sVar, keyEvent)) && (eVar = sVar.f780j) != null) {
            z2 = eVar.performShortcut(i2, keyEvent, i3);
        }
        if (z2 && (i3 & 1) == 0 && this.f738r == null) {
            c0(sVar, true);
        }
        return z2;
    }

    private boolean P0(s sVar, KeyEvent keyEvent) {
        L l2;
        L l3;
        L l4;
        if (this.f712R) {
            return false;
        }
        if (sVar.f783m) {
            return true;
        }
        s sVar2 = this.f708N;
        if (!(sVar2 == null || sVar2 == sVar)) {
            c0(sVar2, false);
        }
        Window.Callback v02 = v0();
        if (v02 != null) {
            sVar.f779i = v02.onCreatePanelView(sVar.f771a);
        }
        int i2 = sVar.f771a;
        boolean z2 = i2 == 0 || i2 == 108;
        if (z2 && (l4 = this.f738r) != null) {
            l4.f();
        }
        if (sVar.f779i == null && (!z2 || !(N0() instanceof E))) {
            androidx.appcompat.view.menu.e eVar = sVar.f780j;
            if (eVar == null || sVar.f788r) {
                if (eVar == null && (!z0(sVar) || sVar.f780j == null)) {
                    return false;
                }
                if (z2 && this.f738r != null) {
                    if (this.f739s == null) {
                        this.f739s = new h();
                    }
                    this.f738r.a(sVar.f780j, this.f739s);
                }
                sVar.f780j.i0();
                if (!v02.onCreatePanelMenu(sVar.f771a, sVar.f780j)) {
                    sVar.c((androidx.appcompat.view.menu.e) null);
                    if (z2 && (l3 = this.f738r) != null) {
                        l3.a((Menu) null, this.f739s);
                    }
                    return false;
                }
                sVar.f788r = false;
            }
            sVar.f780j.i0();
            Bundle bundle = sVar.f789s;
            if (bundle != null) {
                sVar.f780j.S(bundle);
                sVar.f789s = null;
            }
            if (!v02.onPreparePanel(0, sVar.f779i, sVar.f780j)) {
                if (z2 && (l2 = this.f738r) != null) {
                    l2.a((Menu) null, this.f739s);
                }
                sVar.f780j.h0();
                return false;
            }
            boolean z3 = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            sVar.f786p = z3;
            sVar.f780j.setQwertyMode(z3);
            sVar.f780j.h0();
        }
        sVar.f783m = true;
        sVar.f784n = false;
        this.f708N = sVar;
        return true;
    }

    private void Q0(boolean z2) {
        L l2 = this.f738r;
        if (l2 == null || !l2.g() || (ViewConfiguration.get(this.f731k).hasPermanentMenuKey() && !this.f738r.b())) {
            s t02 = t0(0, true);
            t02.f787q = true;
            c0(t02, false);
            M0(t02, (KeyEvent) null);
            return;
        }
        Window.Callback v02 = v0();
        if (this.f738r.c() && z2) {
            this.f738r.d();
            if (!this.f712R) {
                v02.onPanelClosed(108, t0(0, true).f780j);
            }
        } else if (v02 != null && !this.f712R) {
            if (this.f720Z && (this.f721a0 & 1) != 0) {
                this.f732l.getDecorView().removeCallbacks(this.f722b0);
                this.f722b0.run();
            }
            s t03 = t0(0, true);
            androidx.appcompat.view.menu.e eVar = t03.f780j;
            if (eVar != null && !t03.f788r && v02.onPreparePanel(0, t03.f779i, eVar)) {
                v02.onMenuOpened(108, t03.f780j);
                this.f738r.e();
            }
        }
    }

    private boolean R(boolean z2) {
        return S(z2, true);
    }

    private int R0(int i2) {
        if (i2 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        } else if (i2 != 9) {
            return i2;
        } else {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            return 109;
        }
    }

    private boolean S(boolean z2, boolean z3) {
        if (this.f712R) {
            return false;
        }
        int X2 = X();
        int C02 = C0(this.f731k, X2);
        androidx.core.os.b W2 = Build.VERSION.SDK_INT < 33 ? W(this.f731k) : null;
        if (!z3 && W2 != null) {
            W2 = s0(this.f731k.getResources().getConfiguration());
        }
        boolean c1 = c1(C02, W2, z2);
        if (X2 == 0) {
            r0(this.f731k).e();
        } else {
            p pVar = this.f718X;
            if (pVar != null) {
                pVar.a();
            }
        }
        if (X2 == 3) {
            q0(this.f731k).e();
        } else {
            p pVar2 = this.f719Y;
            if (pVar2 != null) {
                pVar2.a();
            }
        }
        return c1;
    }

    private void U() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.f696B.findViewById(16908290);
        View decorView = this.f732l.getDecorView();
        contentFrameLayout.a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray obtainStyledAttributes = this.f731k.obtainStyledAttributes(e.j.f5370y0);
        obtainStyledAttributes.getValue(e.j.K0, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(e.j.L0, contentFrameLayout.getMinWidthMinor());
        int i2 = e.j.I0;
        if (obtainStyledAttributes.hasValue(i2)) {
            obtainStyledAttributes.getValue(i2, contentFrameLayout.getFixedWidthMajor());
        }
        int i3 = e.j.J0;
        if (obtainStyledAttributes.hasValue(i3)) {
            obtainStyledAttributes.getValue(i3, contentFrameLayout.getFixedWidthMinor());
        }
        int i4 = e.j.G0;
        if (obtainStyledAttributes.hasValue(i4)) {
            obtainStyledAttributes.getValue(i4, contentFrameLayout.getFixedHeightMajor());
        }
        int i5 = e.j.H0;
        if (obtainStyledAttributes.hasValue(i5)) {
            obtainStyledAttributes.getValue(i5, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    private void V(Window window) {
        if (this.f732l == null) {
            Window.Callback callback = window.getCallback();
            if (!(callback instanceof n)) {
                n nVar = new n(callback);
                this.f733m = nVar;
                window.setCallback(nVar);
                e0 u2 = e0.u(this.f731k, (AttributeSet) null, f693l0);
                Drawable h2 = u2.h(0);
                if (h2 != null) {
                    window.setBackgroundDrawable(h2);
                }
                u2.x();
                this.f732l = window;
                if (Build.VERSION.SDK_INT >= 33 && this.f728h0 == null) {
                    L((OnBackInvokedDispatcher) null);
                    return;
                }
                return;
            }
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    private boolean V0(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.f732l.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || ((View) viewParent).isAttachedToWindow()) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    private int X() {
        int i2 = this.f714T;
        return i2 != -100 ? i2 : C0094g.m();
    }

    private void Z0() {
        if (this.f695A) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private void a0() {
        p pVar = this.f718X;
        if (pVar != null) {
            pVar.a();
        }
        p pVar2 = this.f719Y;
        if (pVar2 != null) {
            pVar2.a();
        }
    }

    private C0091d a1() {
        Context context = this.f731k;
        while (context != null) {
            if (!(context instanceof C0091d)) {
                if (!(context instanceof ContextWrapper)) {
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            } else {
                return (C0091d) context;
            }
        }
        return null;
    }

    private void b1(Configuration configuration) {
        Activity activity = (Activity) this.f730j;
        if (activity instanceof androidx.lifecycle.l) {
            if (!((androidx.lifecycle.l) activity).v().b().b(C0190g.b.CREATED)) {
                return;
            }
        } else if (!this.f711Q || this.f712R) {
            return;
        }
        activity.onConfigurationChanged(configuration);
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x00b9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean c1(int r10, androidx.core.os.b r11, boolean r12) {
        /*
            r9 = this;
            android.content.Context r1 = r9.f731k
            r4 = 0
            r5 = 0
            r0 = r9
            r2 = r10
            r3 = r11
            android.content.res.Configuration r0 = r0.d0(r1, r2, r3, r4, r5)
            android.content.Context r1 = r9.f731k
            int r1 = r9.p0(r1)
            android.content.res.Configuration r2 = r9.f713S
            if (r2 != 0) goto L_0x001f
            android.content.Context r2 = r9.f731k
            android.content.res.Resources r2 = r2.getResources()
            android.content.res.Configuration r2 = r2.getConfiguration()
        L_0x001f:
            int r3 = r2.uiMode
            r3 = r3 & 48
            int r4 = r0.uiMode
            r4 = r4 & 48
            androidx.core.os.b r2 = r9.s0(r2)
            r5 = 0
            if (r11 != 0) goto L_0x0030
            r6 = r5
            goto L_0x0034
        L_0x0030:
            androidx.core.os.b r6 = r9.s0(r0)
        L_0x0034:
            r7 = 0
            if (r3 == r4) goto L_0x003a
            r3 = 512(0x200, float:7.175E-43)
            goto L_0x003b
        L_0x003a:
            r3 = 0
        L_0x003b:
            if (r6 == 0) goto L_0x0045
            boolean r2 = r2.equals(r6)
            if (r2 != 0) goto L_0x0045
            r3 = r3 | 8196(0x2004, float:1.1485E-41)
        L_0x0045:
            int r2 = ~r1
            r2 = r2 & r3
            r8 = 1
            if (r2 == 0) goto L_0x008c
            if (r12 == 0) goto L_0x008c
            boolean r12 = r9.f710P
            if (r12 == 0) goto L_0x008c
            boolean r12 = f694m0
            if (r12 != 0) goto L_0x0058
            boolean r12 = r9.f711Q
            if (r12 == 0) goto L_0x008c
        L_0x0058:
            java.lang.Object r12 = r9.f730j
            boolean r2 = r12 instanceof android.app.Activity
            if (r2 == 0) goto L_0x008c
            android.app.Activity r12 = (android.app.Activity) r12
            boolean r12 = r12.isChild()
            if (r12 != 0) goto L_0x008c
            int r12 = android.os.Build.VERSION.SDK_INT
            r2 = 31
            if (r12 < r2) goto L_0x0083
            r12 = r3 & 8192(0x2000, float:1.14794E-41)
            if (r12 == 0) goto L_0x0083
            java.lang.Object r12 = r9.f730j
            android.app.Activity r12 = (android.app.Activity) r12
            android.view.Window r12 = r12.getWindow()
            android.view.View r12 = r12.getDecorView()
            int r0 = r0.getLayoutDirection()
            r12.setLayoutDirection(r0)
        L_0x0083:
            java.lang.Object r12 = r9.f730j
            android.app.Activity r12 = (android.app.Activity) r12
            androidx.core.app.b.j(r12)
            r12 = 1
            goto L_0x008d
        L_0x008c:
            r12 = 0
        L_0x008d:
            if (r12 != 0) goto L_0x009a
            if (r3 == 0) goto L_0x009a
            r12 = r3 & r1
            if (r12 != r3) goto L_0x0096
            r7 = 1
        L_0x0096:
            r9.e1(r4, r6, r7, r5)
            goto L_0x009b
        L_0x009a:
            r8 = r12
        L_0x009b:
            if (r8 == 0) goto L_0x00b7
            java.lang.Object r12 = r9.f730j
            boolean r0 = r12 instanceof androidx.appcompat.app.C0091d
            if (r0 == 0) goto L_0x00b7
            r0 = r3 & 512(0x200, float:7.175E-43)
            if (r0 == 0) goto L_0x00ac
            androidx.appcompat.app.d r12 = (androidx.appcompat.app.C0091d) r12
            r12.j0(r10)
        L_0x00ac:
            r10 = r3 & 4
            if (r10 == 0) goto L_0x00b7
            java.lang.Object r10 = r9.f730j
            androidx.appcompat.app.d r10 = (androidx.appcompat.app.C0091d) r10
            r10.i0(r11)
        L_0x00b7:
            if (r6 == 0) goto L_0x00ca
            android.content.Context r10 = r9.f731k
            android.content.res.Resources r10 = r10.getResources()
            android.content.res.Configuration r10 = r10.getConfiguration()
            androidx.core.os.b r10 = r9.s0(r10)
            r9.T0(r10)
        L_0x00ca:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.c1(int, androidx.core.os.b, boolean):boolean");
    }

    private Configuration d0(Context context, int i2, androidx.core.os.b bVar, Configuration configuration, boolean z2) {
        int i3 = i2 != 1 ? i2 != 2 ? z2 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i3 | (configuration2.uiMode & -49);
        if (bVar != null) {
            S0(configuration2, bVar);
        }
        return configuration2;
    }

    private ViewGroup e0() {
        ViewGroup viewGroup;
        TypedArray obtainStyledAttributes = this.f731k.obtainStyledAttributes(e.j.f5370y0);
        int i2 = e.j.D0;
        if (obtainStyledAttributes.hasValue(i2)) {
            if (obtainStyledAttributes.getBoolean(e.j.M0, false)) {
                H(1);
            } else if (obtainStyledAttributes.getBoolean(i2, false)) {
                H(108);
            }
            if (obtainStyledAttributes.getBoolean(e.j.E0, false)) {
                H(109);
            }
            if (obtainStyledAttributes.getBoolean(e.j.F0, false)) {
                H(10);
            }
            this.f704J = obtainStyledAttributes.getBoolean(e.j.f5372z0, false);
            obtainStyledAttributes.recycle();
            l0();
            this.f732l.getDecorView();
            LayoutInflater from = LayoutInflater.from(this.f731k);
            if (this.f705K) {
                viewGroup = (ViewGroup) from.inflate(this.f703I ? e.g.abc_screen_simple_overlay_action_mode : e.g.abc_screen_simple, (ViewGroup) null);
            } else if (this.f704J) {
                viewGroup = (ViewGroup) from.inflate(e.g.abc_dialog_title_material, (ViewGroup) null);
                this.f702H = false;
                this.f701G = false;
            } else if (this.f701G) {
                TypedValue typedValue = new TypedValue();
                this.f731k.getTheme().resolveAttribute(C0233a.actionBarTheme, typedValue, true);
                viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new androidx.appcompat.view.d(this.f731k, typedValue.resourceId) : this.f731k).inflate(e.g.abc_screen_toolbar, (ViewGroup) null);
                L l2 = (L) viewGroup.findViewById(e.f.decor_content_parent);
                this.f738r = l2;
                l2.setWindowCallback(v0());
                if (this.f702H) {
                    this.f738r.k(109);
                }
                if (this.f699E) {
                    this.f738r.k(2);
                }
                if (this.f700F) {
                    this.f738r.k(5);
                }
            } else {
                viewGroup = null;
            }
            if (viewGroup != null) {
                W.C0(viewGroup, new b());
                if (this.f738r == null) {
                    this.f697C = (TextView) viewGroup.findViewById(e.f.title);
                }
                p0.c(viewGroup);
                ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(e.f.action_bar_activity_content);
                ViewGroup viewGroup2 = (ViewGroup) this.f732l.findViewById(16908290);
                if (viewGroup2 != null) {
                    while (viewGroup2.getChildCount() > 0) {
                        View childAt = viewGroup2.getChildAt(0);
                        viewGroup2.removeViewAt(0);
                        contentFrameLayout.addView(childAt);
                    }
                    viewGroup2.setId(-1);
                    contentFrameLayout.setId(16908290);
                    if (viewGroup2 instanceof FrameLayout) {
                        ((FrameLayout) viewGroup2).setForeground((Drawable) null);
                    }
                }
                this.f732l.setContentView(viewGroup);
                contentFrameLayout.setAttachListener(new c());
                return viewGroup;
            }
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.f701G + ", windowActionBarOverlay: " + this.f702H + ", android:windowIsFloating: " + this.f704J + ", windowActionModeOverlay: " + this.f703I + ", windowNoTitle: " + this.f705K + " }");
        }
        obtainStyledAttributes.recycle();
        throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    }

    private void e1(int i2, androidx.core.os.b bVar, boolean z2, Configuration configuration) {
        Resources resources = this.f731k.getResources();
        Configuration configuration2 = new Configuration(resources.getConfiguration());
        if (configuration != null) {
            configuration2.updateFrom(configuration);
        }
        configuration2.uiMode = i2 | (resources.getConfiguration().uiMode & -49);
        if (bVar != null) {
            S0(configuration2, bVar);
        }
        resources.updateConfiguration(configuration2, (DisplayMetrics) null);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 < 26) {
            D.a(resources);
        }
        int i4 = this.f715U;
        if (i4 != 0) {
            this.f731k.setTheme(i4);
            if (i3 >= 23) {
                this.f731k.getTheme().applyStyle(this.f715U, true);
            }
        }
        if (z2 && (this.f730j instanceof Activity)) {
            b1(configuration2);
        }
    }

    private void g1(View view) {
        Context context;
        int i2;
        if ((W.N(view) & 8192) != 0) {
            context = this.f731k;
            i2 = C0235c.abc_decor_view_status_guard_light;
        } else {
            context = this.f731k;
            i2 = C0235c.abc_decor_view_status_guard;
        }
        view.setBackgroundColor(androidx.core.content.a.a(context, i2));
    }

    private void k0() {
        if (!this.f695A) {
            this.f696B = e0();
            CharSequence u02 = u0();
            if (!TextUtils.isEmpty(u02)) {
                L l2 = this.f738r;
                if (l2 != null) {
                    l2.setWindowTitle(u02);
                } else if (N0() != null) {
                    N0().x(u02);
                } else {
                    TextView textView = this.f697C;
                    if (textView != null) {
                        textView.setText(u02);
                    }
                }
            }
            U();
            L0(this.f696B);
            this.f695A = true;
            s t02 = t0(0, false);
            if (this.f712R) {
                return;
            }
            if (t02 == null || t02.f780j == null) {
                A0(108);
            }
        }
    }

    private void l0() {
        if (this.f732l == null) {
            Object obj = this.f730j;
            if (obj instanceof Activity) {
                V(((Activity) obj).getWindow());
            }
        }
        if (this.f732l == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    private static Configuration n0(Configuration configuration, Configuration configuration2) {
        Configuration configuration3 = new Configuration();
        configuration3.fontScale = 0.0f;
        if (!(configuration2 == null || configuration.diff(configuration2) == 0)) {
            float f2 = configuration.fontScale;
            float f3 = configuration2.fontScale;
            if (f2 != f3) {
                configuration3.fontScale = f3;
            }
            int i2 = configuration.mcc;
            int i3 = configuration2.mcc;
            if (i2 != i3) {
                configuration3.mcc = i3;
            }
            int i4 = configuration.mnc;
            int i5 = configuration2.mnc;
            if (i4 != i5) {
                configuration3.mnc = i5;
            }
            int i6 = Build.VERSION.SDK_INT;
            if (i6 >= 24) {
                k.a(configuration, configuration2, configuration3);
            } else if (!x.c.a(configuration.locale, configuration2.locale)) {
                configuration3.locale = configuration2.locale;
            }
            int i7 = configuration.touchscreen;
            int i8 = configuration2.touchscreen;
            if (i7 != i8) {
                configuration3.touchscreen = i8;
            }
            int i9 = configuration.keyboard;
            int i10 = configuration2.keyboard;
            if (i9 != i10) {
                configuration3.keyboard = i10;
            }
            int i11 = configuration.keyboardHidden;
            int i12 = configuration2.keyboardHidden;
            if (i11 != i12) {
                configuration3.keyboardHidden = i12;
            }
            int i13 = configuration.navigation;
            int i14 = configuration2.navigation;
            if (i13 != i14) {
                configuration3.navigation = i14;
            }
            int i15 = configuration.navigationHidden;
            int i16 = configuration2.navigationHidden;
            if (i15 != i16) {
                configuration3.navigationHidden = i16;
            }
            int i17 = configuration.orientation;
            int i18 = configuration2.orientation;
            if (i17 != i18) {
                configuration3.orientation = i18;
            }
            int i19 = configuration.screenLayout & 15;
            int i20 = configuration2.screenLayout;
            if (i19 != (i20 & 15)) {
                configuration3.screenLayout |= i20 & 15;
            }
            int i21 = configuration.screenLayout & 192;
            int i22 = configuration2.screenLayout;
            if (i21 != (i22 & 192)) {
                configuration3.screenLayout |= i22 & 192;
            }
            int i23 = configuration.screenLayout & 48;
            int i24 = configuration2.screenLayout;
            if (i23 != (i24 & 48)) {
                configuration3.screenLayout |= i24 & 48;
            }
            int i25 = configuration.screenLayout & 768;
            int i26 = configuration2.screenLayout;
            if (i25 != (i26 & 768)) {
                configuration3.screenLayout |= i26 & 768;
            }
            if (i6 >= 26) {
                l.a(configuration, configuration2, configuration3);
            }
            int i27 = configuration.uiMode & 15;
            int i28 = configuration2.uiMode;
            if (i27 != (i28 & 15)) {
                configuration3.uiMode |= i28 & 15;
            }
            int i29 = configuration.uiMode & 48;
            int i30 = configuration2.uiMode;
            if (i29 != (i30 & 48)) {
                configuration3.uiMode |= i30 & 48;
            }
            int i31 = configuration.screenWidthDp;
            int i32 = configuration2.screenWidthDp;
            if (i31 != i32) {
                configuration3.screenWidthDp = i32;
            }
            int i33 = configuration.screenHeightDp;
            int i34 = configuration2.screenHeightDp;
            if (i33 != i34) {
                configuration3.screenHeightDp = i34;
            }
            int i35 = configuration.smallestScreenWidthDp;
            int i36 = configuration2.smallestScreenWidthDp;
            if (i35 != i36) {
                configuration3.smallestScreenWidthDp = i36;
            }
            int i37 = configuration.densityDpi;
            int i38 = configuration2.densityDpi;
            if (i37 != i38) {
                configuration3.densityDpi = i38;
            }
        }
        return configuration3;
    }

    private int p0(Context context) {
        if (!this.f717W && (this.f730j instanceof Activity)) {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return 0;
            }
            try {
                int i2 = Build.VERSION.SDK_INT;
                ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, this.f730j.getClass()), i2 >= 29 ? 269221888 : i2 >= 24 ? 786432 : 0);
                if (activityInfo != null) {
                    this.f716V = activityInfo.configChanges;
                }
            } catch (PackageManager.NameNotFoundException e2) {
                Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e2);
                this.f716V = 0;
            }
        }
        this.f717W = true;
        return this.f716V;
    }

    private p q0(Context context) {
        if (this.f719Y == null) {
            this.f719Y = new o(context);
        }
        return this.f719Y;
    }

    private p r0(Context context) {
        if (this.f718X == null) {
            this.f718X = new q(G.a(context));
        }
        return this.f718X;
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void w0() {
        /*
            r3 = this;
            r3.k0()
            boolean r0 = r3.f701G
            if (r0 == 0) goto L_0x0037
            androidx.appcompat.app.a r0 = r3.f735o
            if (r0 == 0) goto L_0x000c
            goto L_0x0037
        L_0x000c:
            java.lang.Object r0 = r3.f730j
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x0020
            androidx.appcompat.app.H r0 = new androidx.appcompat.app.H
            java.lang.Object r1 = r3.f730j
            android.app.Activity r1 = (android.app.Activity) r1
            boolean r2 = r3.f702H
            r0.<init>(r1, r2)
        L_0x001d:
            r3.f735o = r0
            goto L_0x002e
        L_0x0020:
            boolean r0 = r0 instanceof android.app.Dialog
            if (r0 == 0) goto L_0x002e
            androidx.appcompat.app.H r0 = new androidx.appcompat.app.H
            java.lang.Object r1 = r3.f730j
            android.app.Dialog r1 = (android.app.Dialog) r1
            r0.<init>(r1)
            goto L_0x001d
        L_0x002e:
            androidx.appcompat.app.a r0 = r3.f735o
            if (r0 == 0) goto L_0x0037
            boolean r1 = r3.f723c0
            r0.r(r1)
        L_0x0037:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.w0():void");
    }

    private boolean x0(s sVar) {
        View view = sVar.f779i;
        if (view != null) {
            sVar.f778h = view;
            return true;
        } else if (sVar.f780j == null) {
            return false;
        } else {
            if (this.f740t == null) {
                this.f740t = new t();
            }
            View view2 = (View) sVar.a(this.f740t);
            sVar.f778h = view2;
            return view2 != null;
        }
    }

    private boolean y0(s sVar) {
        sVar.d(o0());
        sVar.f777g = new r(sVar.f782l);
        sVar.f773c = 81;
        return true;
    }

    private boolean z0(s sVar) {
        Resources.Theme theme;
        Context context = this.f731k;
        int i2 = sVar.f771a;
        if ((i2 == 0 || i2 == 108) && this.f738r != null) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme2 = context.getTheme();
            theme2.resolveAttribute(C0233a.actionBarTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                theme = context.getResources().newTheme();
                theme.setTo(theme2);
                theme.applyStyle(typedValue.resourceId, true);
                theme.resolveAttribute(C0233a.actionBarWidgetTheme, typedValue, true);
            } else {
                theme2.resolveAttribute(C0233a.actionBarWidgetTheme, typedValue, true);
                theme = null;
            }
            if (typedValue.resourceId != 0) {
                if (theme == null) {
                    theme = context.getResources().newTheme();
                    theme.setTo(theme2);
                }
                theme.applyStyle(typedValue.resourceId, true);
            }
            if (theme != null) {
                androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, 0);
                dVar.getTheme().setTo(theme);
                context = dVar;
            }
        }
        androidx.appcompat.view.menu.e eVar = new androidx.appcompat.view.menu.e(context);
        eVar.W(this);
        sVar.c(eVar);
        return true;
    }

    public void A(Bundle bundle) {
        k0();
    }

    public void B() {
        C0088a s2 = s();
        if (s2 != null) {
            s2.w(true);
        }
    }

    public boolean B0() {
        return this.f746z;
    }

    public void C(Bundle bundle) {
    }

    /* access modifiers changed from: package-private */
    public int C0(Context context, int i2) {
        p r02;
        if (i2 == -100) {
            return -1;
        }
        if (i2 != -1) {
            if (i2 != 0) {
                if (!(i2 == 1 || i2 == 2)) {
                    if (i2 == 3) {
                        r02 = q0(context);
                    } else {
                        throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                    }
                }
            } else if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) {
                return -1;
            } else {
                r02 = r0(context);
            }
            return r02.c();
        }
        return i2;
    }

    public void D() {
        S(true, false);
    }

    /* access modifiers changed from: package-private */
    public boolean D0() {
        boolean z2 = this.f709O;
        this.f709O = false;
        s t02 = t0(0, false);
        if (t02 == null || !t02.f785o) {
            androidx.appcompat.view.b bVar = this.f741u;
            if (bVar != null) {
                bVar.c();
                return true;
            }
            C0088a s2 = s();
            return s2 != null && s2.h();
        }
        if (!z2) {
            c0(t02, true);
        }
        return true;
    }

    public void E() {
        C0088a s2 = s();
        if (s2 != null) {
            s2.w(false);
        }
    }

    /* access modifiers changed from: package-private */
    public boolean E0(int i2, KeyEvent keyEvent) {
        boolean z2 = true;
        if (i2 == 4) {
            if ((keyEvent.getFlags() & 128) == 0) {
                z2 = false;
            }
            this.f709O = z2;
        } else if (i2 == 82) {
            F0(0, keyEvent);
            return true;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public boolean G0(int i2, KeyEvent keyEvent) {
        C0088a s2 = s();
        if (s2 != null && s2.o(i2, keyEvent)) {
            return true;
        }
        s sVar = this.f708N;
        if (sVar == null || !O0(sVar, keyEvent.getKeyCode(), keyEvent, 1)) {
            if (this.f708N == null) {
                s t02 = t0(0, true);
                P0(t02, keyEvent);
                boolean O0 = O0(t02, keyEvent.getKeyCode(), keyEvent, 1);
                t02.f783m = false;
                if (O0) {
                    return true;
                }
            }
            return false;
        }
        s sVar2 = this.f708N;
        if (sVar2 != null) {
            sVar2.f784n = true;
        }
        return true;
    }

    public boolean H(int i2) {
        int R0 = R0(i2);
        if (this.f705K && R0 == 108) {
            return false;
        }
        if (this.f701G && R0 == 1) {
            this.f701G = false;
        }
        if (R0 == 1) {
            Z0();
            this.f705K = true;
            return true;
        } else if (R0 == 2) {
            Z0();
            this.f699E = true;
            return true;
        } else if (R0 == 5) {
            Z0();
            this.f700F = true;
            return true;
        } else if (R0 == 10) {
            Z0();
            this.f703I = true;
            return true;
        } else if (R0 == 108) {
            Z0();
            this.f701G = true;
            return true;
        } else if (R0 != 109) {
            return this.f732l.requestFeature(R0);
        } else {
            Z0();
            this.f702H = true;
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean H0(int i2, KeyEvent keyEvent) {
        if (i2 != 4) {
            if (i2 == 82) {
                I0(0, keyEvent);
                return true;
            }
        } else if (D0()) {
            return true;
        }
        return false;
    }

    public void I(int i2) {
        k0();
        ViewGroup viewGroup = (ViewGroup) this.f696B.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f731k).inflate(i2, viewGroup);
        this.f733m.c(this.f732l.getCallback());
    }

    public void J(View view) {
        k0();
        ViewGroup viewGroup = (ViewGroup) this.f696B.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f733m.c(this.f732l.getCallback());
    }

    /* access modifiers changed from: package-private */
    public void J0(int i2) {
        C0088a s2;
        if (i2 == 108 && (s2 = s()) != null) {
            s2.i(true);
        }
    }

    public void K(View view, ViewGroup.LayoutParams layoutParams) {
        k0();
        ViewGroup viewGroup = (ViewGroup) this.f696B.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f733m.c(this.f732l.getCallback());
    }

    /* access modifiers changed from: package-private */
    public void K0(int i2) {
        if (i2 == 108) {
            C0088a s2 = s();
            if (s2 != null) {
                s2.i(false);
            }
        } else if (i2 == 0) {
            s t02 = t0(i2, true);
            if (t02.f785o) {
                c0(t02, false);
            }
        }
    }

    public void L(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        OnBackInvokedCallback onBackInvokedCallback;
        super.L(onBackInvokedDispatcher);
        OnBackInvokedDispatcher onBackInvokedDispatcher2 = this.f728h0;
        if (!(onBackInvokedDispatcher2 == null || (onBackInvokedCallback = this.f729i0) == null)) {
            m.c(onBackInvokedDispatcher2, onBackInvokedCallback);
            this.f729i0 = null;
        }
        if (onBackInvokedDispatcher == null) {
            Object obj = this.f730j;
            if ((obj instanceof Activity) && ((Activity) obj).getWindow() != null) {
                onBackInvokedDispatcher = m.a((Activity) this.f730j);
            }
        }
        this.f728h0 = onBackInvokedDispatcher;
        d1();
    }

    /* access modifiers changed from: package-private */
    public void L0(ViewGroup viewGroup) {
    }

    public void M(Toolbar toolbar) {
        if (this.f730j instanceof Activity) {
            C0088a s2 = s();
            if (!(s2 instanceof H)) {
                this.f736p = null;
                if (s2 != null) {
                    s2.n();
                }
                this.f735o = null;
                if (toolbar != null) {
                    E e2 = new E(toolbar, u0(), this.f733m);
                    this.f735o = e2;
                    this.f733m.e(e2.f590c);
                    toolbar.setBackInvokedCallbackEnabled(true);
                } else {
                    this.f733m.e((g) null);
                }
                u();
                return;
            }
            throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
        }
    }

    public void N(int i2) {
        this.f715U = i2;
    }

    /* access modifiers changed from: package-private */
    public final C0088a N0() {
        return this.f735o;
    }

    public final void O(CharSequence charSequence) {
        this.f737q = charSequence;
        L l2 = this.f738r;
        if (l2 != null) {
            l2.setWindowTitle(charSequence);
        } else if (N0() != null) {
            N0().x(charSequence);
        } else {
            TextView textView = this.f697C;
            if (textView != null) {
                textView.setText(charSequence);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void S0(Configuration configuration, androidx.core.os.b bVar) {
        if (Build.VERSION.SDK_INT >= 24) {
            k.d(configuration, bVar);
            return;
        }
        configuration.setLocale(bVar.d(0));
        configuration.setLayoutDirection(bVar.d(0));
    }

    public boolean T() {
        return R(true);
    }

    /* access modifiers changed from: package-private */
    public void T0(androidx.core.os.b bVar) {
        if (Build.VERSION.SDK_INT >= 24) {
            k.c(bVar);
        } else {
            Locale.setDefault(bVar.d(0));
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r1.f696B;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean U0() {
        /*
            r1 = this;
            boolean r0 = r1.f695A
            if (r0 == 0) goto L_0x0010
            android.view.ViewGroup r0 = r1.f696B
            if (r0 == 0) goto L_0x0010
            boolean r0 = r0.isLaidOut()
            if (r0 == 0) goto L_0x0010
            r0 = 1
            goto L_0x0011
        L_0x0010:
            r0 = 0
        L_0x0011:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.U0():boolean");
    }

    /* access modifiers changed from: package-private */
    public androidx.core.os.b W(Context context) {
        androidx.core.os.b r2;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33 || (r2 = C0094g.r()) == null) {
            return null;
        }
        androidx.core.os.b s02 = s0(context.getApplicationContext().getResources().getConfiguration());
        androidx.core.os.b b2 = i2 >= 24 ? C.b(r2, s02) : r2.f() ? androidx.core.os.b.e() : androidx.core.os.b.c(j.b(r2.d(0)));
        return b2.f() ? s02 : b2;
    }

    /* access modifiers changed from: package-private */
    public boolean W0() {
        if (this.f728h0 == null) {
            return false;
        }
        s t02 = t0(0, false);
        return (t02 != null && t02.f785o) || this.f741u != null;
    }

    public androidx.appcompat.view.b X0(b.a aVar) {
        C0092e eVar;
        if (aVar != null) {
            androidx.appcompat.view.b bVar = this.f741u;
            if (bVar != null) {
                bVar.c();
            }
            C0016i iVar = new C0016i(aVar);
            C0088a s2 = s();
            if (s2 != null) {
                androidx.appcompat.view.b y2 = s2.y(iVar);
                this.f741u = y2;
                if (!(y2 == null || (eVar = this.f734n) == null)) {
                    eVar.q(y2);
                }
            }
            if (this.f741u == null) {
                this.f741u = Y0(iVar);
            }
            d1();
            return this.f741u;
        }
        throw new IllegalArgumentException("ActionMode callback can not be null.");
    }

    /* access modifiers changed from: package-private */
    public void Y(int i2, s sVar, Menu menu) {
        if (menu == null) {
            if (sVar == null && i2 >= 0) {
                s[] sVarArr = this.f707M;
                if (i2 < sVarArr.length) {
                    sVar = sVarArr[i2];
                }
            }
            if (sVar != null) {
                menu = sVar.f780j;
            }
        }
        if ((sVar == null || sVar.f785o) && !this.f712R) {
            this.f733m.d(this.f732l.getCallback(), i2, menu);
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0026  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x002a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public androidx.appcompat.view.b Y0(androidx.appcompat.view.b.a r8) {
        /*
            r7 = this;
            r7.j0()
            androidx.appcompat.view.b r0 = r7.f741u
            if (r0 == 0) goto L_0x000a
            r0.c()
        L_0x000a:
            boolean r0 = r8 instanceof androidx.appcompat.app.i.C0016i
            if (r0 != 0) goto L_0x0014
            androidx.appcompat.app.i$i r0 = new androidx.appcompat.app.i$i
            r0.<init>(r8)
            r8 = r0
        L_0x0014:
            androidx.appcompat.app.e r0 = r7.f734n
            r1 = 0
            if (r0 == 0) goto L_0x0023
            boolean r2 = r7.f712R
            if (r2 != 0) goto L_0x0023
            androidx.appcompat.view.b r0 = r0.w(r8)     // Catch:{ AbstractMethodError -> 0x0022 }
            goto L_0x0024
        L_0x0022:
        L_0x0023:
            r0 = r1
        L_0x0024:
            if (r0 == 0) goto L_0x002a
            r7.f741u = r0
            goto L_0x015c
        L_0x002a:
            androidx.appcompat.widget.ActionBarContextView r0 = r7.f742v
            r2 = 0
            r3 = 1
            if (r0 != 0) goto L_0x00d5
            boolean r0 = r7.f704J
            if (r0 == 0) goto L_0x00b6
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            android.content.Context r4 = r7.f731k
            android.content.res.Resources$Theme r4 = r4.getTheme()
            int r5 = e.C0233a.actionBarTheme
            r4.resolveAttribute(r5, r0, r3)
            int r5 = r0.resourceId
            if (r5 == 0) goto L_0x0069
            android.content.Context r5 = r7.f731k
            android.content.res.Resources r5 = r5.getResources()
            android.content.res.Resources$Theme r5 = r5.newTheme()
            r5.setTo(r4)
            int r4 = r0.resourceId
            r5.applyStyle(r4, r3)
            androidx.appcompat.view.d r4 = new androidx.appcompat.view.d
            android.content.Context r6 = r7.f731k
            r4.<init>((android.content.Context) r6, (int) r2)
            android.content.res.Resources$Theme r6 = r4.getTheme()
            r6.setTo(r5)
            goto L_0x006b
        L_0x0069:
            android.content.Context r4 = r7.f731k
        L_0x006b:
            androidx.appcompat.widget.ActionBarContextView r5 = new androidx.appcompat.widget.ActionBarContextView
            r5.<init>(r4)
            r7.f742v = r5
            android.widget.PopupWindow r5 = new android.widget.PopupWindow
            int r6 = e.C0233a.actionModePopupWindowStyle
            r5.<init>(r4, r1, r6)
            r7.f743w = r5
            r6 = 2
            androidx.core.widget.h.b(r5, r6)
            android.widget.PopupWindow r5 = r7.f743w
            androidx.appcompat.widget.ActionBarContextView r6 = r7.f742v
            r5.setContentView(r6)
            android.widget.PopupWindow r5 = r7.f743w
            r6 = -1
            r5.setWidth(r6)
            android.content.res.Resources$Theme r5 = r4.getTheme()
            int r6 = e.C0233a.actionBarSize
            r5.resolveAttribute(r6, r0, r3)
            int r0 = r0.data
            android.content.res.Resources r4 = r4.getResources()
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()
            int r0 = android.util.TypedValue.complexToDimensionPixelSize(r0, r4)
            androidx.appcompat.widget.ActionBarContextView r4 = r7.f742v
            r4.setContentHeight(r0)
            android.widget.PopupWindow r0 = r7.f743w
            r4 = -2
            r0.setHeight(r4)
            androidx.appcompat.app.i$d r0 = new androidx.appcompat.app.i$d
            r0.<init>()
            r7.f744x = r0
            goto L_0x00d5
        L_0x00b6:
            android.view.ViewGroup r0 = r7.f696B
            int r4 = e.f.action_mode_bar_stub
            android.view.View r0 = r0.findViewById(r4)
            androidx.appcompat.widget.ViewStubCompat r0 = (androidx.appcompat.widget.ViewStubCompat) r0
            if (r0 == 0) goto L_0x00d5
            android.content.Context r4 = r7.o0()
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r0.setLayoutInflater(r4)
            android.view.View r0 = r0.a()
            androidx.appcompat.widget.ActionBarContextView r0 = (androidx.appcompat.widget.ActionBarContextView) r0
            r7.f742v = r0
        L_0x00d5:
            androidx.appcompat.widget.ActionBarContextView r0 = r7.f742v
            if (r0 == 0) goto L_0x015c
            r7.j0()
            androidx.appcompat.widget.ActionBarContextView r0 = r7.f742v
            r0.k()
            androidx.appcompat.view.e r0 = new androidx.appcompat.view.e
            androidx.appcompat.widget.ActionBarContextView r4 = r7.f742v
            android.content.Context r4 = r4.getContext()
            androidx.appcompat.widget.ActionBarContextView r5 = r7.f742v
            android.widget.PopupWindow r6 = r7.f743w
            if (r6 != 0) goto L_0x00f0
            goto L_0x00f1
        L_0x00f0:
            r3 = 0
        L_0x00f1:
            r0.<init>(r4, r5, r8, r3)
            android.view.Menu r3 = r0.e()
            boolean r8 = r8.c(r0, r3)
            if (r8 == 0) goto L_0x015a
            r0.k()
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            r8.h(r0)
            r7.f741u = r0
            boolean r8 = r7.U0()
            r0 = 1065353216(0x3f800000, float:1.0)
            if (r8 == 0) goto L_0x012b
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            r1 = 0
            r8.setAlpha(r1)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            androidx.core.view.e0 r8 = androidx.core.view.W.e(r8)
            androidx.core.view.e0 r8 = r8.b(r0)
            r7.f745y = r8
            androidx.appcompat.app.i$e r0 = new androidx.appcompat.app.i$e
            r0.<init>()
            r8.h(r0)
            goto L_0x014a
        L_0x012b:
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            r8.setAlpha(r0)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            r8.setVisibility(r2)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            android.view.ViewParent r8 = r8.getParent()
            boolean r8 = r8 instanceof android.view.View
            if (r8 == 0) goto L_0x014a
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f742v
            android.view.ViewParent r8 = r8.getParent()
            android.view.View r8 = (android.view.View) r8
            androidx.core.view.W.n0(r8)
        L_0x014a:
            android.widget.PopupWindow r8 = r7.f743w
            if (r8 == 0) goto L_0x015c
            android.view.Window r8 = r7.f732l
            android.view.View r8 = r8.getDecorView()
            java.lang.Runnable r0 = r7.f744x
            r8.post(r0)
            goto L_0x015c
        L_0x015a:
            r7.f741u = r1
        L_0x015c:
            androidx.appcompat.view.b r8 = r7.f741u
            if (r8 == 0) goto L_0x0167
            androidx.appcompat.app.e r0 = r7.f734n
            if (r0 == 0) goto L_0x0167
            r0.q(r8)
        L_0x0167:
            r7.d1()
            androidx.appcompat.view.b r8 = r7.f741u
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.Y0(androidx.appcompat.view.b$a):androidx.appcompat.view.b");
    }

    /* access modifiers changed from: package-private */
    public void Z(androidx.appcompat.view.menu.e eVar) {
        if (!this.f706L) {
            this.f706L = true;
            this.f738r.l();
            Window.Callback v02 = v0();
            if (v02 != null && !this.f712R) {
                v02.onPanelClosed(108, eVar);
            }
            this.f706L = false;
        }
    }

    public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
        s m02;
        Window.Callback v02 = v0();
        if (v02 == null || this.f712R || (m02 = m0(eVar.F())) == null) {
            return false;
        }
        return v02.onMenuItemSelected(m02.f771a, menuItem);
    }

    public void b(androidx.appcompat.view.menu.e eVar) {
        Q0(true);
    }

    /* access modifiers changed from: package-private */
    public void b0(int i2) {
        c0(t0(i2, true), true);
    }

    /* access modifiers changed from: package-private */
    public void c0(s sVar, boolean z2) {
        ViewGroup viewGroup;
        L l2;
        if (!z2 || sVar.f771a != 0 || (l2 = this.f738r) == null || !l2.c()) {
            WindowManager windowManager = (WindowManager) this.f731k.getSystemService("window");
            if (!(windowManager == null || !sVar.f785o || (viewGroup = sVar.f777g) == null)) {
                windowManager.removeView(viewGroup);
                if (z2) {
                    Y(sVar.f771a, sVar, (Menu) null);
                }
            }
            sVar.f783m = false;
            sVar.f784n = false;
            sVar.f785o = false;
            sVar.f778h = null;
            sVar.f787q = true;
            if (this.f708N == sVar) {
                this.f708N = null;
            }
            if (sVar.f771a == 0) {
                d1();
                return;
            }
            return;
        }
        Z(sVar.f780j);
    }

    /* access modifiers changed from: package-private */
    public void d1() {
        OnBackInvokedCallback onBackInvokedCallback;
        OnBackInvokedCallback onBackInvokedCallback2;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean W0 = W0();
            if (W0 && this.f729i0 == null) {
                onBackInvokedCallback2 = m.b(this.f728h0, this);
            } else if (!W0 && (onBackInvokedCallback = this.f729i0) != null) {
                m.c(this.f728h0, onBackInvokedCallback);
                onBackInvokedCallback2 = null;
            } else {
                return;
            }
            this.f729i0 = onBackInvokedCallback2;
        }
    }

    public void e(View view, ViewGroup.LayoutParams layoutParams) {
        k0();
        ((ViewGroup) this.f696B.findViewById(16908290)).addView(view, layoutParams);
        this.f733m.c(this.f732l.getCallback());
    }

    public View f0(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z2;
        z zVar;
        if (this.f726f0 == null) {
            TypedArray obtainStyledAttributes = this.f731k.obtainStyledAttributes(e.j.f5370y0);
            String string = obtainStyledAttributes.getString(e.j.f5297C0);
            obtainStyledAttributes.recycle();
            if (string == null) {
                zVar = new z();
            } else {
                try {
                    this.f726f0 = (z) this.f731k.getClassLoader().loadClass(string).getDeclaredConstructor((Class[]) null).newInstance((Object[]) null);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    zVar = new z();
                }
            }
            this.f726f0 = zVar;
        }
        boolean z3 = f692k0;
        boolean z4 = false;
        if (z3) {
            if (this.f727g0 == null) {
                this.f727g0 = new B();
            }
            if (this.f727g0.a(attributeSet)) {
                z2 = true;
            } else {
                if (!(attributeSet instanceof XmlPullParser)) {
                    z4 = V0((ViewParent) view);
                } else if (((XmlPullParser) attributeSet).getDepth() > 1) {
                    z4 = true;
                }
                z2 = z4;
            }
        } else {
            z2 = false;
        }
        return this.f726f0.r(view, str, context, attributeSet, z2, z3, true, o0.c());
    }

    /* access modifiers changed from: package-private */
    public final int f1(C0165w0 w0Var, Rect rect) {
        boolean z2;
        boolean z3;
        ViewGroup.MarginLayoutParams marginLayoutParams;
        int i2;
        int i3 = 0;
        int l2 = w0Var != null ? w0Var.l() : rect != null ? rect.top : 0;
        ActionBarContextView actionBarContextView = this.f742v;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z2 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) this.f742v.getLayoutParams();
            boolean z4 = true;
            if (this.f742v.isShown()) {
                if (this.f724d0 == null) {
                    this.f724d0 = new Rect();
                    this.f725e0 = new Rect();
                }
                Rect rect2 = this.f724d0;
                Rect rect3 = this.f725e0;
                if (w0Var == null) {
                    rect2.set(rect);
                } else {
                    rect2.set(w0Var.j(), w0Var.l(), w0Var.k(), w0Var.i());
                }
                p0.a(this.f696B, rect2, rect3);
                int i4 = rect2.top;
                int i5 = rect2.left;
                int i6 = rect2.right;
                C0165w0 J2 = W.J(this.f696B);
                int j2 = J2 == null ? 0 : J2.j();
                int k2 = J2 == null ? 0 : J2.k();
                if (marginLayoutParams2.topMargin == i4 && marginLayoutParams2.leftMargin == i5 && marginLayoutParams2.rightMargin == i6) {
                    z3 = false;
                } else {
                    marginLayoutParams2.topMargin = i4;
                    marginLayoutParams2.leftMargin = i5;
                    marginLayoutParams2.rightMargin = i6;
                    z3 = true;
                }
                if (i4 <= 0 || this.f698D != null) {
                    View view = this.f698D;
                    if (!(view == null || ((marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams()).height == (i2 = marginLayoutParams2.topMargin) && marginLayoutParams.leftMargin == j2 && marginLayoutParams.rightMargin == k2))) {
                        marginLayoutParams.height = i2;
                        marginLayoutParams.leftMargin = j2;
                        marginLayoutParams.rightMargin = k2;
                        this.f698D.setLayoutParams(marginLayoutParams);
                    }
                } else {
                    View view2 = new View(this.f731k);
                    this.f698D = view2;
                    view2.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams2.topMargin, 51);
                    layoutParams.leftMargin = j2;
                    layoutParams.rightMargin = k2;
                    this.f696B.addView(this.f698D, -1, layoutParams);
                }
                View view3 = this.f698D;
                if (view3 == null) {
                    z4 = false;
                }
                if (z4 && view3.getVisibility() != 0) {
                    g1(this.f698D);
                }
                if (!this.f703I && z4) {
                    l2 = 0;
                }
                z2 = z4;
                z4 = z3;
            } else if (marginLayoutParams2.topMargin != 0) {
                marginLayoutParams2.topMargin = 0;
                z2 = false;
            } else {
                z2 = false;
                z4 = false;
            }
            if (z4) {
                this.f742v.setLayoutParams(marginLayoutParams2);
            }
        }
        View view4 = this.f698D;
        if (view4 != null) {
            if (!z2) {
                i3 = 8;
            }
            view4.setVisibility(i3);
        }
        return l2;
    }

    public Context g(Context context) {
        this.f710P = true;
        int C02 = C0(context, X());
        if (C0094g.v(context)) {
            C0094g.Q(context);
        }
        androidx.core.os.b W2 = W(context);
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(d0(context, C02, W2, (Configuration) null, false));
                return context;
            } catch (IllegalStateException unused) {
            }
        }
        if (context instanceof androidx.appcompat.view.d) {
            try {
                ((androidx.appcompat.view.d) context).a(d0(context, C02, W2, (Configuration) null, false));
                return context;
            } catch (IllegalStateException unused2) {
            }
        }
        if (!f694m0) {
            return super.g(context);
        }
        Configuration configuration = new Configuration();
        configuration.uiMode = -1;
        configuration.fontScale = 0.0f;
        Configuration configuration2 = context.createConfigurationContext(configuration).getResources().getConfiguration();
        Configuration configuration3 = context.getResources().getConfiguration();
        configuration2.uiMode = configuration3.uiMode;
        Configuration d02 = d0(context, C02, W2, !configuration2.equals(configuration3) ? n0(configuration2, configuration3) : null, true);
        androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, e.i.Theme_AppCompat_Empty);
        dVar.a(d02);
        try {
            if (context.getTheme() != null) {
                h.f.a(dVar.getTheme());
            }
        } catch (NullPointerException unused3) {
        }
        return super.g(dVar);
    }

    /* access modifiers changed from: package-private */
    public void g0() {
        androidx.appcompat.view.menu.e eVar;
        L l2 = this.f738r;
        if (l2 != null) {
            l2.l();
        }
        if (this.f743w != null) {
            this.f732l.getDecorView().removeCallbacks(this.f744x);
            if (this.f743w.isShowing()) {
                try {
                    this.f743w.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.f743w = null;
        }
        j0();
        s t02 = t0(0, false);
        if (t02 != null && (eVar = t02.f780j) != null) {
            eVar.close();
        }
    }

    /* access modifiers changed from: package-private */
    public boolean h0(KeyEvent keyEvent) {
        View decorView;
        Object obj = this.f730j;
        if (((obj instanceof C0158t.a) || (obj instanceof y)) && (decorView = this.f732l.getDecorView()) != null && C0158t.d(decorView, keyEvent)) {
            return true;
        }
        if (keyEvent.getKeyCode() == 82 && this.f733m.b(this.f732l.getCallback(), keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        return keyEvent.getAction() == 0 ? E0(keyCode, keyEvent) : H0(keyCode, keyEvent);
    }

    /* access modifiers changed from: package-private */
    public void i0(int i2) {
        s t02;
        s t03 = t0(i2, true);
        if (t03.f780j != null) {
            Bundle bundle = new Bundle();
            t03.f780j.U(bundle);
            if (bundle.size() > 0) {
                t03.f789s = bundle;
            }
            t03.f780j.i0();
            t03.f780j.clear();
        }
        t03.f788r = true;
        t03.f787q = true;
        if ((i2 == 108 || i2 == 0) && this.f738r != null && (t02 = t0(0, false)) != null) {
            t02.f783m = false;
            P0(t02, (KeyEvent) null);
        }
    }

    public View j(int i2) {
        k0();
        return this.f732l.findViewById(i2);
    }

    /* access modifiers changed from: package-private */
    public void j0() {
        C0130e0 e0Var = this.f745y;
        if (e0Var != null) {
            e0Var.c();
        }
    }

    public Context l() {
        return this.f731k;
    }

    /* access modifiers changed from: package-private */
    public s m0(Menu menu) {
        s[] sVarArr = this.f707M;
        int length = sVarArr != null ? sVarArr.length : 0;
        for (int i2 = 0; i2 < length; i2++) {
            s sVar = sVarArr[i2];
            if (sVar != null && sVar.f780j == menu) {
                return sVar;
            }
        }
        return null;
    }

    public final C0089b.C0015b n() {
        return new f();
    }

    public int o() {
        return this.f714T;
    }

    /* access modifiers changed from: package-private */
    public final Context o0() {
        C0088a s2 = s();
        Context k2 = s2 != null ? s2.k() : null;
        return k2 == null ? this.f731k : k2;
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return f0(view, str, context, attributeSet);
    }

    public MenuInflater q() {
        if (this.f736p == null) {
            w0();
            C0088a aVar = this.f735o;
            this.f736p = new androidx.appcompat.view.g(aVar != null ? aVar.k() : this.f731k);
        }
        return this.f736p;
    }

    public C0088a s() {
        w0();
        return this.f735o;
    }

    /* access modifiers changed from: package-private */
    public androidx.core.os.b s0(Configuration configuration) {
        return Build.VERSION.SDK_INT >= 24 ? k.b(configuration) : androidx.core.os.b.c(j.b(configuration.locale));
    }

    public void t() {
        LayoutInflater from = LayoutInflater.from(this.f731k);
        if (from.getFactory() == null) {
            C0160u.a(from, this);
        } else if (!(from.getFactory2() instanceof i)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    /* access modifiers changed from: protected */
    public s t0(int i2, boolean z2) {
        s[] sVarArr = this.f707M;
        if (sVarArr == null || sVarArr.length <= i2) {
            s[] sVarArr2 = new s[(i2 + 1)];
            if (sVarArr != null) {
                System.arraycopy(sVarArr, 0, sVarArr2, 0, sVarArr.length);
            }
            this.f707M = sVarArr2;
            sVarArr = sVarArr2;
        }
        s sVar = sVarArr[i2];
        if (sVar != null) {
            return sVar;
        }
        s sVar2 = new s(i2);
        sVarArr[i2] = sVar2;
        return sVar2;
    }

    public void u() {
        if (N0() != null && !s().l()) {
            A0(0);
        }
    }

    /* access modifiers changed from: package-private */
    public final CharSequence u0() {
        Object obj = this.f730j;
        return obj instanceof Activity ? ((Activity) obj).getTitle() : this.f737q;
    }

    /* access modifiers changed from: package-private */
    public final Window.Callback v0() {
        return this.f732l.getCallback();
    }

    public void x(Configuration configuration) {
        C0088a s2;
        if (this.f701G && this.f695A && (s2 = s()) != null) {
            s2.m(configuration);
        }
        C0106k.b().g(this.f731k);
        this.f713S = new Configuration(this.f731k.getResources().getConfiguration());
        S(false, false);
    }

    public void y(Bundle bundle) {
        String str;
        this.f710P = true;
        R(false);
        l0();
        Object obj = this.f730j;
        if (obj instanceof Activity) {
            try {
                str = androidx.core.app.h.c((Activity) obj);
            } catch (IllegalArgumentException unused) {
                str = null;
            }
            if (str != null) {
                C0088a N0 = N0();
                if (N0 == null) {
                    this.f723c0 = true;
                } else {
                    N0.r(true);
                }
            }
            C0094g.d(this);
        }
        this.f713S = new Configuration(this.f731k.getResources().getConfiguration());
        this.f711Q = true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0058  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void z() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f730j
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L_0x0009
            androidx.appcompat.app.C0094g.F(r3)
        L_0x0009:
            boolean r0 = r3.f720Z
            if (r0 == 0) goto L_0x0018
            android.view.Window r0 = r3.f732l
            android.view.View r0 = r0.getDecorView()
            java.lang.Runnable r1 = r3.f722b0
            r0.removeCallbacks(r1)
        L_0x0018:
            r0 = 1
            r3.f712R = r0
            int r0 = r3.f714T
            r1 = -100
            if (r0 == r1) goto L_0x0045
            java.lang.Object r0 = r3.f730j
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x0045
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L_0x0045
            l.g r0 = f691j0
            java.lang.Object r1 = r3.f730j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.f714T
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L_0x0054
        L_0x0045:
            l.g r0 = f691j0
            java.lang.Object r1 = r3.f730j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L_0x0054:
            androidx.appcompat.app.a r0 = r3.f735o
            if (r0 == 0) goto L_0x005b
            r0.n()
        L_0x005b:
            r3.a0()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.i.z():void");
    }

    i(Dialog dialog, C0092e eVar) {
        this(dialog.getContext(), dialog.getWindow(), eVar, dialog);
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    private i(Context context, Window window, C0092e eVar, Object obj) {
        C0091d a1;
        this.f745y = null;
        this.f746z = true;
        this.f714T = -100;
        this.f722b0 = new a();
        this.f731k = context;
        this.f734n = eVar;
        this.f730j = obj;
        if (this.f714T == -100 && (obj instanceof Dialog) && (a1 = a1()) != null) {
            this.f714T = a1.d0().o();
        }
        if (this.f714T == -100) {
            l.g gVar = f691j0;
            Integer num = (Integer) gVar.get(obj.getClass().getName());
            if (num != null) {
                this.f714T = num.intValue();
                gVar.remove(obj.getClass().getName());
            }
        }
        if (window != null) {
            V(window);
        }
        C0106k.h();
    }
}
