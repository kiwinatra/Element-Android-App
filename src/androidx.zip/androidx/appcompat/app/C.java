package androidx.appcompat.app;

import androidx.core.os.b;
import java.util.LinkedHashSet;
import java.util.Locale;

abstract class C {
    private static b a(b bVar, b bVar2) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        int i2 = 0;
        while (i2 < bVar.g() + bVar2.g()) {
            Locale d2 = i2 < bVar.g() ? bVar.d(i2) : bVar2.d(i2 - bVar.g());
            if (d2 != null) {
                linkedHashSet.add(d2);
            }
            i2++;
        }
        return b.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]));
    }

    static b b(b bVar, b bVar2) {
        return (bVar == null || bVar.f()) ? b.e() : a(bVar, bVar2);
    }
}
