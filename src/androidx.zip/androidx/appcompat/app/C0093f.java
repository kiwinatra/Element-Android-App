package androidx.appcompat.app;

import android.content.Context;

/* renamed from: androidx.appcompat.app.f  reason: case insensitive filesystem */
public final /* synthetic */ class C0093f implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Context f675a;

    public /* synthetic */ C0093f(Context context) {
        this.f675a = context;
    }

    public final void run() {
        C0094g.w(this.f675a);
    }
}
