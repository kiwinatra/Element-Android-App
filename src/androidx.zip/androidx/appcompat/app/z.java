package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.view.d;
import androidx.appcompat.widget.A;
import androidx.appcompat.widget.C0099d;
import androidx.appcompat.widget.C0101f;
import androidx.appcompat.widget.C0102g;
import androidx.appcompat.widget.C0103h;
import androidx.appcompat.widget.C0107l;
import androidx.appcompat.widget.C0111p;
import androidx.appcompat.widget.C0113s;
import androidx.appcompat.widget.C0116v;
import androidx.appcompat.widget.C0117w;
import androidx.appcompat.widget.C0119y;
import androidx.appcompat.widget.F;
import androidx.appcompat.widget.K;
import androidx.appcompat.widget.b0;
import androidx.appcompat.widget.r;
import androidx.core.view.W;
import e.j;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import l.g;

public class z {

    /* renamed from: b  reason: collision with root package name */
    private static final Class[] f795b = {Context.class, AttributeSet.class};

    /* renamed from: c  reason: collision with root package name */
    private static final int[] f796c = {16843375};

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f797d = {16844160};

    /* renamed from: e  reason: collision with root package name */
    private static final int[] f798e = {16844156};

    /* renamed from: f  reason: collision with root package name */
    private static final int[] f799f = {16844148};

    /* renamed from: g  reason: collision with root package name */
    private static final String[] f800g = {"android.widget.", "android.view.", "android.webkit."};

    /* renamed from: h  reason: collision with root package name */
    private static final g f801h = new g();

    /* renamed from: a  reason: collision with root package name */
    private final Object[] f802a = new Object[2];

    private static class a implements View.OnClickListener {

        /* renamed from: a  reason: collision with root package name */
        private final View f803a;

        /* renamed from: b  reason: collision with root package name */
        private final String f804b;

        /* renamed from: c  reason: collision with root package name */
        private Method f805c;

        /* renamed from: d  reason: collision with root package name */
        private Context f806d;

        public a(View view, String str) {
            this.f803a = view;
            this.f804b = str;
        }

        private void a(Context context) {
            String str;
            Method method;
            while (context != null) {
                try {
                    if (!context.isRestricted() && (method = context.getClass().getMethod(this.f804b, new Class[]{View.class})) != null) {
                        this.f805c = method;
                        this.f806d = context;
                        return;
                    }
                } catch (NoSuchMethodException unused) {
                }
                context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
            }
            int id = this.f803a.getId();
            if (id == -1) {
                str = "";
            } else {
                str = " with id '" + this.f803a.getContext().getResources().getResourceEntryName(id) + "'";
            }
            throw new IllegalStateException("Could not find method " + this.f804b + "(View) in a parent or ancestor Context for android:onClick attribute defined on view " + this.f803a.getClass() + str);
        }

        public void onClick(View view) {
            if (this.f805c == null) {
                a(this.f803a.getContext());
            }
            try {
                this.f805c.invoke(this.f806d, new Object[]{view});
            } catch (IllegalAccessException e2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
            } catch (InvocationTargetException e3) {
                throw new IllegalStateException("Could not execute method for android:onClick", e3);
            }
        }
    }

    private void a(Context context, View view, AttributeSet attributeSet) {
        if (Build.VERSION.SDK_INT <= 28) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f797d);
            if (obtainStyledAttributes.hasValue(0)) {
                W.r0(view, obtainStyledAttributes.getBoolean(0, false));
            }
            obtainStyledAttributes.recycle();
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, f798e);
            if (obtainStyledAttributes2.hasValue(0)) {
                W.t0(view, obtainStyledAttributes2.getString(0));
            }
            obtainStyledAttributes2.recycle();
            TypedArray obtainStyledAttributes3 = context.obtainStyledAttributes(attributeSet, f799f);
            if (obtainStyledAttributes3.hasValue(0)) {
                W.E0(view, obtainStyledAttributes3.getBoolean(0, false));
            }
            obtainStyledAttributes3.recycle();
        }
    }

    private void b(View view, AttributeSet attributeSet) {
        Context context = view.getContext();
        if ((context instanceof ContextWrapper) && view.hasOnClickListeners()) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f796c);
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                view.setOnClickListener(new a(view, string));
            }
            obtainStyledAttributes.recycle();
        }
    }

    private View s(Context context, String str, String str2) {
        String str3;
        g gVar = f801h;
        Constructor<? extends U> constructor = (Constructor) gVar.get(str);
        if (constructor == null) {
            if (str2 != null) {
                try {
                    str3 = str2 + str;
                } catch (Exception unused) {
                    return null;
                }
            } else {
                str3 = str;
            }
            constructor = Class.forName(str3, false, context.getClassLoader()).asSubclass(View.class).getConstructor(f795b);
            gVar.put(str, constructor);
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.f802a);
    }

    private View t(Context context, String str, AttributeSet attributeSet) {
        if (str.equals("view")) {
            str = attributeSet.getAttributeValue((String) null, "class");
        }
        try {
            Object[] objArr = this.f802a;
            objArr[0] = context;
            objArr[1] = attributeSet;
            if (-1 == str.indexOf(46)) {
                int i2 = 0;
                while (true) {
                    String[] strArr = f800g;
                    if (i2 < strArr.length) {
                        View s2 = s(context, str, strArr[i2]);
                        if (s2 != null) {
                            return s2;
                        }
                        i2++;
                    } else {
                        Object[] objArr2 = this.f802a;
                        objArr2[0] = null;
                        objArr2[1] = null;
                        return null;
                    }
                }
            } else {
                View s3 = s(context, str, (String) null);
                Object[] objArr3 = this.f802a;
                objArr3[0] = null;
                objArr3[1] = null;
                return s3;
            }
        } catch (Exception unused) {
            return null;
        } finally {
            Object[] objArr4 = this.f802a;
            objArr4[0] = null;
            objArr4[1] = null;
        }
    }

    private static Context u(Context context, AttributeSet attributeSet, boolean z2, boolean z3) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.m3, 0, 0);
        int resourceId = z2 ? obtainStyledAttributes.getResourceId(j.n3, 0) : 0;
        if (z3 && resourceId == 0 && (resourceId = obtainStyledAttributes.getResourceId(j.o3, 0)) != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        obtainStyledAttributes.recycle();
        if (resourceId != 0) {
            return (!(context instanceof d) || ((d) context).c() != resourceId) ? new d(context, resourceId) : context;
        }
        return context;
    }

    private void v(View view, String str) {
        if (view == null) {
            throw new IllegalStateException(getClass().getName() + " asked to inflate view for <" + str + ">, but returned null");
        }
    }

    /* access modifiers changed from: protected */
    public C0099d c(Context context, AttributeSet attributeSet) {
        return new C0099d(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0101f d(Context context, AttributeSet attributeSet) {
        return new C0101f(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0102g e(Context context, AttributeSet attributeSet) {
        return new C0102g(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0103h f(Context context, AttributeSet attributeSet) {
        return new C0103h(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0107l g(Context context, AttributeSet attributeSet) {
        return new C0107l(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0111p h(Context context, AttributeSet attributeSet) {
        return new C0111p(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public r i(Context context, AttributeSet attributeSet) {
        return new r(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0113s j(Context context, AttributeSet attributeSet) {
        return new C0113s(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0116v k(Context context, AttributeSet attributeSet) {
        return new C0116v(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0117w l(Context context, AttributeSet attributeSet) {
        return new C0117w(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public C0119y m(Context context, AttributeSet attributeSet) {
        return new C0119y(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public A n(Context context, AttributeSet attributeSet) {
        return new A(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public F o(Context context, AttributeSet attributeSet) {
        return new F(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public K p(Context context, AttributeSet attributeSet) {
        return new K(context, attributeSet);
    }

    /* access modifiers changed from: protected */
    public View q(Context context, String str, AttributeSet attributeSet) {
        return null;
    }

    public final View r(View view, String str, Context context, AttributeSet attributeSet, boolean z2, boolean z3, boolean z4, boolean z5) {
        View view2;
        Context context2 = (!z2 || view == null) ? context : view.getContext();
        if (z3 || z4) {
            context2 = u(context2, attributeSet, z3, z4);
        }
        if (z5) {
            context2 = b0.b(context2);
        }
        str.hashCode();
        char c2 = 65535;
        switch (str.hashCode()) {
            case -1946472170:
                if (str.equals("RatingBar")) {
                    c2 = 0;
                    break;
                }
                break;
            case -1455429095:
                if (str.equals("CheckedTextView")) {
                    c2 = 1;
                    break;
                }
                break;
            case -1346021293:
                if (str.equals("MultiAutoCompleteTextView")) {
                    c2 = 2;
                    break;
                }
                break;
            case -938935918:
                if (str.equals("TextView")) {
                    c2 = 3;
                    break;
                }
                break;
            case -937446323:
                if (str.equals("ImageButton")) {
                    c2 = 4;
                    break;
                }
                break;
            case -658531749:
                if (str.equals("SeekBar")) {
                    c2 = 5;
                    break;
                }
                break;
            case -339785223:
                if (str.equals("Spinner")) {
                    c2 = 6;
                    break;
                }
                break;
            case 776382189:
                if (str.equals("RadioButton")) {
                    c2 = 7;
                    break;
                }
                break;
            case 799298502:
                if (str.equals("ToggleButton")) {
                    c2 = 8;
                    break;
                }
                break;
            case 1125864064:
                if (str.equals("ImageView")) {
                    c2 = 9;
                    break;
                }
                break;
            case 1413872058:
                if (str.equals("AutoCompleteTextView")) {
                    c2 = 10;
                    break;
                }
                break;
            case 1601505219:
                if (str.equals("CheckBox")) {
                    c2 = 11;
                    break;
                }
                break;
            case 1666676343:
                if (str.equals("EditText")) {
                    c2 = 12;
                    break;
                }
                break;
            case 2001146706:
                if (str.equals("Button")) {
                    c2 = 13;
                    break;
                }
                break;
        }
        switch (c2) {
            case 0:
                view2 = l(context2, attributeSet);
                break;
            case 1:
                view2 = f(context2, attributeSet);
                break;
            case 2:
                view2 = j(context2, attributeSet);
                break;
            case 3:
                view2 = o(context2, attributeSet);
                break;
            case 4:
                view2 = h(context2, attributeSet);
                break;
            case 5:
                view2 = m(context2, attributeSet);
                break;
            case 6:
                view2 = n(context2, attributeSet);
                break;
            case 7:
                view2 = k(context2, attributeSet);
                break;
            case 8:
                view2 = p(context2, attributeSet);
                break;
            case 9:
                view2 = i(context2, attributeSet);
                break;
            case 10:
                view2 = c(context2, attributeSet);
                break;
            case 11:
                view2 = e(context2, attributeSet);
                break;
            case 12:
                view2 = g(context2, attributeSet);
                break;
            case 13:
                view2 = d(context2, attributeSet);
                break;
            default:
                view2 = q(context2, str, attributeSet);
                break;
        }
        v(view2, str);
        if (view2 == null && context != context2) {
            view2 = t(context2, str, attributeSet);
        }
        if (view2 != null) {
            b(view2, attributeSet);
            a(context2, view2, attributeSet);
        }
        return view2;
    }
}
