package androidx.appcompat.app;

import O.e;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.k;
import androidx.activity.t;
import androidx.appcompat.view.b;
import androidx.core.view.C0158t;
import androidx.lifecycle.F;
import e.C0233a;

public abstract class y extends k implements C0092e {

    /* renamed from: d  reason: collision with root package name */
    private C0094g f793d;

    /* renamed from: e  reason: collision with root package name */
    private final C0158t.a f794e = new x(this);

    public y(Context context, int i2) {
        super(context, h(context, i2));
        C0094g g2 = g();
        g2.N(h(context, i2));
        g2.y((Bundle) null);
    }

    private static int h(Context context, int i2) {
        if (i2 != 0) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0233a.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    private void i() {
        F.a(getWindow().getDecorView(), this);
        e.a(getWindow().getDecorView(), this);
        t.a(getWindow().getDecorView(), this);
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        g().e(view, layoutParams);
    }

    public void dismiss() {
        super.dismiss();
        g().z();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C0158t.e(this.f794e, getWindow().getDecorView(), this, keyEvent);
    }

    public View findViewById(int i2) {
        return g().j(i2);
    }

    public C0094g g() {
        if (this.f793d == null) {
            this.f793d = C0094g.i(this, this);
        }
        return this.f793d;
    }

    public void invalidateOptionsMenu() {
        g().u();
    }

    /* access modifiers changed from: package-private */
    public boolean j(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean k(int i2) {
        return g().H(i2);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        g().t();
        super.onCreate(bundle);
        g().y(bundle);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        g().E();
    }

    public void q(b bVar) {
    }

    public void setContentView(int i2) {
        i();
        g().I(i2);
    }

    public void setTitle(int i2) {
        super.setTitle(i2);
        g().O(getContext().getString(i2));
    }

    public void u(b bVar) {
    }

    public b w(b.a aVar) {
        return null;
    }

    public void setContentView(View view) {
        i();
        g().J(view);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        g().O(charSequence);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        i();
        g().K(view, layoutParams);
    }
}
