package androidx.appcompat.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import androidx.core.content.e;
import java.util.Calendar;

class G {

    /* renamed from: d  reason: collision with root package name */
    private static G f607d;

    /* renamed from: a  reason: collision with root package name */
    private final Context f608a;

    /* renamed from: b  reason: collision with root package name */
    private final LocationManager f609b;

    /* renamed from: c  reason: collision with root package name */
    private final a f610c = new a();

    private static class a {

        /* renamed from: a  reason: collision with root package name */
        boolean f611a;

        /* renamed from: b  reason: collision with root package name */
        long f612b;

        a() {
        }
    }

    G(Context context, LocationManager locationManager) {
        this.f608a = context;
        this.f609b = locationManager;
    }

    static G a(Context context) {
        if (f607d == null) {
            Context applicationContext = context.getApplicationContext();
            f607d = new G(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f607d;
    }

    private Location b() {
        Location location = null;
        Location c2 = e.b(this.f608a, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? c("network") : null;
        if (e.b(this.f608a, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            location = c("gps");
        }
        return (location == null || c2 == null) ? location != null ? location : c2 : location.getTime() > c2.getTime() ? location : c2;
    }

    private Location c(String str) {
        try {
            if (this.f609b.isProviderEnabled(str)) {
                return this.f609b.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e2) {
            Log.d("TwilightManager", "Failed to get last known location", e2);
            return null;
        }
    }

    private boolean e() {
        return this.f610c.f612b > System.currentTimeMillis();
    }

    private void f(Location location) {
        long j2;
        a aVar = this.f610c;
        long currentTimeMillis = System.currentTimeMillis();
        F b2 = F.b();
        F f2 = b2;
        f2.a(currentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
        f2.a(currentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z2 = b2.f606c == 1;
        long j3 = b2.f605b;
        long j4 = b2.f604a;
        long j5 = j3;
        b2.a(currentTimeMillis + 86400000, location.getLatitude(), location.getLongitude());
        long j6 = b2.f605b;
        if (j5 == -1 || j4 == -1) {
            j2 = currentTimeMillis + 43200000;
        } else {
            if (currentTimeMillis <= j4) {
                j6 = currentTimeMillis > j5 ? j4 : j5;
            }
            j2 = j6 + 60000;
        }
        aVar.f611a = z2;
        aVar.f612b = j2;
    }

    /* access modifiers changed from: package-private */
    public boolean d() {
        a aVar = this.f610c;
        if (e()) {
            return aVar.f611a;
        }
        Location b2 = b();
        if (b2 != null) {
            f(b2);
            return aVar.f611a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i2 = Calendar.getInstance().get(11);
        return i2 < 6 || i2 >= 22;
    }
}
