package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.b;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.M;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.Z;
import androidx.core.view.C0130e0;
import androidx.core.view.C0132f0;
import androidx.core.view.C0134g0;
import androidx.core.view.C0136h0;
import androidx.core.view.W;
import e.C0233a;
import e.f;
import e.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class H extends C0088a implements ActionBarOverlayLayout.d {

    /* renamed from: D  reason: collision with root package name */
    private static final Interpolator f613D = new AccelerateInterpolator();

    /* renamed from: E  reason: collision with root package name */
    private static final Interpolator f614E = new DecelerateInterpolator();

    /* renamed from: A  reason: collision with root package name */
    final C0132f0 f615A = new a();

    /* renamed from: B  reason: collision with root package name */
    final C0132f0 f616B = new b();

    /* renamed from: C  reason: collision with root package name */
    final C0136h0 f617C = new c();

    /* renamed from: a  reason: collision with root package name */
    Context f618a;

    /* renamed from: b  reason: collision with root package name */
    private Context f619b;

    /* renamed from: c  reason: collision with root package name */
    private Activity f620c;

    /* renamed from: d  reason: collision with root package name */
    ActionBarOverlayLayout f621d;

    /* renamed from: e  reason: collision with root package name */
    ActionBarContainer f622e;

    /* renamed from: f  reason: collision with root package name */
    M f623f;

    /* renamed from: g  reason: collision with root package name */
    ActionBarContextView f624g;

    /* renamed from: h  reason: collision with root package name */
    View f625h;

    /* renamed from: i  reason: collision with root package name */
    private ArrayList f626i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    private int f627j = -1;

    /* renamed from: k  reason: collision with root package name */
    private boolean f628k;

    /* renamed from: l  reason: collision with root package name */
    d f629l;

    /* renamed from: m  reason: collision with root package name */
    androidx.appcompat.view.b f630m;

    /* renamed from: n  reason: collision with root package name */
    b.a f631n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f632o;

    /* renamed from: p  reason: collision with root package name */
    private ArrayList f633p = new ArrayList();

    /* renamed from: q  reason: collision with root package name */
    private boolean f634q;

    /* renamed from: r  reason: collision with root package name */
    private int f635r = 0;

    /* renamed from: s  reason: collision with root package name */
    boolean f636s = true;

    /* renamed from: t  reason: collision with root package name */
    boolean f637t;

    /* renamed from: u  reason: collision with root package name */
    boolean f638u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f639v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f640w = true;

    /* renamed from: x  reason: collision with root package name */
    h f641x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f642y;

    /* renamed from: z  reason: collision with root package name */
    boolean f643z;

    class a extends C0134g0 {
        a() {
        }

        public void a(View view) {
            View view2;
            H h2 = H.this;
            if (h2.f636s && (view2 = h2.f625h) != null) {
                view2.setTranslationY(0.0f);
                H.this.f622e.setTranslationY(0.0f);
            }
            H.this.f622e.setVisibility(8);
            H.this.f622e.setTransitioning(false);
            H h3 = H.this;
            h3.f641x = null;
            h3.B();
            ActionBarOverlayLayout actionBarOverlayLayout = H.this.f621d;
            if (actionBarOverlayLayout != null) {
                W.n0(actionBarOverlayLayout);
            }
        }
    }

    class b extends C0134g0 {
        b() {
        }

        public void a(View view) {
            H h2 = H.this;
            h2.f641x = null;
            h2.f622e.requestLayout();
        }
    }

    class c implements C0136h0 {
        c() {
        }

        public void a(View view) {
            ((View) H.this.f622e.getParent()).invalidate();
        }
    }

    public class d extends androidx.appcompat.view.b implements e.a {

        /* renamed from: c  reason: collision with root package name */
        private final Context f647c;

        /* renamed from: d  reason: collision with root package name */
        private final e f648d;

        /* renamed from: e  reason: collision with root package name */
        private b.a f649e;

        /* renamed from: f  reason: collision with root package name */
        private WeakReference f650f;

        public d(Context context, b.a aVar) {
            this.f647c = context;
            this.f649e = aVar;
            e X2 = new e(context).X(1);
            this.f648d = X2;
            X2.W(this);
        }

        public boolean a(e eVar, MenuItem menuItem) {
            b.a aVar = this.f649e;
            if (aVar != null) {
                return aVar.b(this, menuItem);
            }
            return false;
        }

        public void b(e eVar) {
            if (this.f649e != null) {
                k();
                H.this.f624g.l();
            }
        }

        public void c() {
            H h2 = H.this;
            if (h2.f629l == this) {
                if (!H.A(h2.f637t, h2.f638u, false)) {
                    H h3 = H.this;
                    h3.f630m = this;
                    h3.f631n = this.f649e;
                } else {
                    this.f649e.d(this);
                }
                this.f649e = null;
                H.this.z(false);
                H.this.f624g.g();
                H h4 = H.this;
                h4.f621d.setHideOnContentScrollEnabled(h4.f643z);
                H.this.f629l = null;
            }
        }

        public View d() {
            WeakReference weakReference = this.f650f;
            if (weakReference != null) {
                return (View) weakReference.get();
            }
            return null;
        }

        public Menu e() {
            return this.f648d;
        }

        public MenuInflater f() {
            return new g(this.f647c);
        }

        public CharSequence g() {
            return H.this.f624g.getSubtitle();
        }

        public CharSequence i() {
            return H.this.f624g.getTitle();
        }

        public void k() {
            if (H.this.f629l == this) {
                this.f648d.i0();
                try {
                    this.f649e.a(this, this.f648d);
                } finally {
                    this.f648d.h0();
                }
            }
        }

        public boolean l() {
            return H.this.f624g.j();
        }

        public void m(View view) {
            H.this.f624g.setCustomView(view);
            this.f650f = new WeakReference(view);
        }

        public void n(int i2) {
            o(H.this.f618a.getResources().getString(i2));
        }

        public void o(CharSequence charSequence) {
            H.this.f624g.setSubtitle(charSequence);
        }

        public void q(int i2) {
            r(H.this.f618a.getResources().getString(i2));
        }

        public void r(CharSequence charSequence) {
            H.this.f624g.setTitle(charSequence);
        }

        public void s(boolean z2) {
            super.s(z2);
            H.this.f624g.setTitleOptional(z2);
        }

        public boolean t() {
            this.f648d.i0();
            try {
                return this.f649e.c(this, this.f648d);
            } finally {
                this.f648d.h0();
            }
        }
    }

    public H(Activity activity, boolean z2) {
        this.f620c = activity;
        View decorView = activity.getWindow().getDecorView();
        H(decorView);
        if (!z2) {
            this.f625h = decorView.findViewById(16908290);
        }
    }

    static boolean A(boolean z2, boolean z3, boolean z4) {
        if (z4) {
            return true;
        }
        return !z2 && !z3;
    }

    private M E(View view) {
        if (view instanceof M) {
            return (M) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Can't make a decor toolbar out of ");
        sb.append(view != null ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb.toString());
    }

    private void G() {
        if (this.f639v) {
            this.f639v = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f621d;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            O(false);
        }
    }

    private void H(View view) {
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(f.decor_content_parent);
        this.f621d = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.f623f = E(view.findViewById(f.action_bar));
        this.f624g = (ActionBarContextView) view.findViewById(f.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(f.action_bar_container);
        this.f622e = actionBarContainer;
        M m2 = this.f623f;
        if (m2 == null || this.f624g == null || actionBarContainer == null) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f618a = m2.r();
        boolean z2 = (this.f623f.j() & 4) != 0;
        if (z2) {
            this.f628k = true;
        }
        androidx.appcompat.view.a b2 = androidx.appcompat.view.a.b(this.f618a);
        v(b2.a() || z2);
        K(b2.e());
        TypedArray obtainStyledAttributes = this.f618a.obtainStyledAttributes((AttributeSet) null, j.f5321a, C0233a.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(j.f5341k, false)) {
            L(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(j.f5337i, 0);
        if (dimensionPixelSize != 0) {
            J((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    private void K(boolean z2) {
        this.f634q = z2;
        if (!z2) {
            this.f623f.n((Z) null);
            this.f622e.setTabContainer((Z) null);
        } else {
            this.f622e.setTabContainer((Z) null);
            this.f623f.n((Z) null);
        }
        boolean z3 = false;
        boolean z4 = F() == 2;
        this.f623f.y(!this.f634q && z4);
        ActionBarOverlayLayout actionBarOverlayLayout = this.f621d;
        if (!this.f634q && z4) {
            z3 = true;
        }
        actionBarOverlayLayout.setHasNonEmbeddedTabs(z3);
    }

    private boolean M() {
        return this.f622e.isLaidOut();
    }

    private void N() {
        if (!this.f639v) {
            this.f639v = true;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f621d;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(true);
            }
            O(false);
        }
    }

    private void O(boolean z2) {
        if (A(this.f637t, this.f638u, this.f639v)) {
            if (!this.f640w) {
                this.f640w = true;
                D(z2);
            }
        } else if (this.f640w) {
            this.f640w = false;
            C(z2);
        }
    }

    /* access modifiers changed from: package-private */
    public void B() {
        b.a aVar = this.f631n;
        if (aVar != null) {
            aVar.d(this.f630m);
            this.f630m = null;
            this.f631n = null;
        }
    }

    public void C(boolean z2) {
        View view;
        h hVar = this.f641x;
        if (hVar != null) {
            hVar.a();
        }
        if (this.f635r != 0 || (!this.f642y && !z2)) {
            this.f615A.a((View) null);
            return;
        }
        this.f622e.setAlpha(1.0f);
        this.f622e.setTransitioning(true);
        h hVar2 = new h();
        float f2 = (float) (-this.f622e.getHeight());
        if (z2) {
            int[] iArr = {0, 0};
            this.f622e.getLocationInWindow(iArr);
            f2 -= (float) iArr[1];
        }
        C0130e0 m2 = W.e(this.f622e).m(f2);
        m2.k(this.f617C);
        hVar2.c(m2);
        if (this.f636s && (view = this.f625h) != null) {
            hVar2.c(W.e(view).m(f2));
        }
        hVar2.f(f613D);
        hVar2.e(250);
        hVar2.g(this.f615A);
        this.f641x = hVar2;
        hVar2.h();
    }

    public void D(boolean z2) {
        View view;
        View view2;
        h hVar = this.f641x;
        if (hVar != null) {
            hVar.a();
        }
        this.f622e.setVisibility(0);
        if (this.f635r != 0 || (!this.f642y && !z2)) {
            this.f622e.setAlpha(1.0f);
            this.f622e.setTranslationY(0.0f);
            if (this.f636s && (view = this.f625h) != null) {
                view.setTranslationY(0.0f);
            }
            this.f616B.a((View) null);
        } else {
            this.f622e.setTranslationY(0.0f);
            float f2 = (float) (-this.f622e.getHeight());
            if (z2) {
                int[] iArr = {0, 0};
                this.f622e.getLocationInWindow(iArr);
                f2 -= (float) iArr[1];
            }
            this.f622e.setTranslationY(f2);
            h hVar2 = new h();
            C0130e0 m2 = W.e(this.f622e).m(0.0f);
            m2.k(this.f617C);
            hVar2.c(m2);
            if (this.f636s && (view2 = this.f625h) != null) {
                view2.setTranslationY(f2);
                hVar2.c(W.e(this.f625h).m(0.0f));
            }
            hVar2.f(f614E);
            hVar2.e(250);
            hVar2.g(this.f616B);
            this.f641x = hVar2;
            hVar2.h();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f621d;
        if (actionBarOverlayLayout != null) {
            W.n0(actionBarOverlayLayout);
        }
    }

    public int F() {
        return this.f623f.s();
    }

    public void I(int i2, int i3) {
        int j2 = this.f623f.j();
        if ((i3 & 4) != 0) {
            this.f628k = true;
        }
        this.f623f.z((i2 & i3) | ((~i3) & j2));
    }

    public void J(float f2) {
        W.x0(this.f622e, f2);
    }

    public void L(boolean z2) {
        if (!z2 || this.f621d.x()) {
            this.f643z = z2;
            this.f621d.setHideOnContentScrollEnabled(z2);
            return;
        }
        throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    }

    public void a(boolean z2) {
        this.f636s = z2;
    }

    public void b() {
        if (this.f638u) {
            this.f638u = false;
            O(true);
        }
    }

    public void c() {
        h hVar = this.f641x;
        if (hVar != null) {
            hVar.a();
            this.f641x = null;
        }
    }

    public void d(int i2) {
        this.f635r = i2;
    }

    public void e() {
        if (!this.f638u) {
            this.f638u = true;
            O(true);
        }
    }

    public void f() {
    }

    public boolean h() {
        M m2 = this.f623f;
        if (m2 == null || !m2.v()) {
            return false;
        }
        this.f623f.collapseActionView();
        return true;
    }

    public void i(boolean z2) {
        if (z2 != this.f632o) {
            this.f632o = z2;
            if (this.f633p.size() > 0) {
                android.support.v4.media.session.b.a(this.f633p.get(0));
                throw null;
            }
        }
    }

    public int j() {
        return this.f623f.j();
    }

    public Context k() {
        if (this.f619b == null) {
            TypedValue typedValue = new TypedValue();
            this.f618a.getTheme().resolveAttribute(C0233a.actionBarWidgetTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.f619b = new ContextThemeWrapper(this.f618a, i2);
            } else {
                this.f619b = this.f618a;
            }
        }
        return this.f619b;
    }

    public void m(Configuration configuration) {
        K(androidx.appcompat.view.a.b(this.f618a).e());
    }

    public boolean o(int i2, KeyEvent keyEvent) {
        Menu e2;
        d dVar = this.f629l;
        if (dVar == null || (e2 = dVar.e()) == null) {
            return false;
        }
        boolean z2 = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z2 = false;
        }
        e2.setQwertyMode(z2);
        return e2.performShortcut(i2, keyEvent, 0);
    }

    public void r(boolean z2) {
        if (!this.f628k) {
            s(z2);
        }
    }

    public void s(boolean z2) {
        I(z2 ? 4 : 0, 4);
    }

    public void t(int i2) {
        this.f623f.p(i2);
    }

    public void u(Drawable drawable) {
        this.f623f.x(drawable);
    }

    public void v(boolean z2) {
        this.f623f.q(z2);
    }

    public void w(boolean z2) {
        h hVar;
        this.f642y = z2;
        if (!z2 && (hVar = this.f641x) != null) {
            hVar.a();
        }
    }

    public void x(CharSequence charSequence) {
        this.f623f.setWindowTitle(charSequence);
    }

    public androidx.appcompat.view.b y(b.a aVar) {
        d dVar = this.f629l;
        if (dVar != null) {
            dVar.c();
        }
        this.f621d.setHideOnContentScrollEnabled(false);
        this.f624g.k();
        d dVar2 = new d(this.f624g.getContext(), aVar);
        if (!dVar2.t()) {
            return null;
        }
        this.f629l = dVar2;
        dVar2.k();
        this.f624g.h(dVar2);
        z(true);
        return dVar2;
    }

    public void z(boolean z2) {
        C0130e0 e0Var;
        C0130e0 e0Var2;
        if (z2) {
            N();
        } else {
            G();
        }
        if (M()) {
            if (z2) {
                e0Var = this.f623f.t(4, 100);
                e0Var2 = this.f624g.f(0, 200);
            } else {
                e0Var2 = this.f623f.t(0, 200);
                e0Var = this.f624g.f(8, 100);
            }
            h hVar = new h();
            hVar.d(e0Var, e0Var2);
            hVar.h();
        } else if (z2) {
            this.f623f.k(4);
            this.f624g.setVisibility(0);
        } else {
            this.f623f.k(0);
            this.f624g.setVisibility(8);
        }
    }

    public H(Dialog dialog) {
        H(dialog.getWindow().getDecorView());
    }
}
