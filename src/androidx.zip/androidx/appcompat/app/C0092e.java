package androidx.appcompat.app;

import androidx.appcompat.view.b;

/* renamed from: androidx.appcompat.app.e  reason: case insensitive filesystem */
public interface C0092e {
    void q(b bVar);

    void u(b bVar);

    b w(b.a aVar);
}
