package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

public final /* synthetic */ class w implements OnBackInvokedCallback {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ i f791a;

    public /* synthetic */ w(i iVar) {
        this.f791a = iVar;
    }

    public final void onBackInvoked() {
        this.f791a.D0();
    }
}
