package androidx.appcompat.app;

public abstract /* synthetic */ class p {
}
