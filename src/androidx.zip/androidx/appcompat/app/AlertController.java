package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.widget.S;
import androidx.core.view.W;
import androidx.core.widget.NestedScrollView;
import e.C0233a;
import e.j;
import java.lang.ref.WeakReference;

class AlertController {

    /* renamed from: A  reason: collision with root package name */
    NestedScrollView f465A;

    /* renamed from: B  reason: collision with root package name */
    private int f466B = 0;

    /* renamed from: C  reason: collision with root package name */
    private Drawable f467C;

    /* renamed from: D  reason: collision with root package name */
    private ImageView f468D;

    /* renamed from: E  reason: collision with root package name */
    private TextView f469E;

    /* renamed from: F  reason: collision with root package name */
    private TextView f470F;

    /* renamed from: G  reason: collision with root package name */
    private View f471G;

    /* renamed from: H  reason: collision with root package name */
    ListAdapter f472H;

    /* renamed from: I  reason: collision with root package name */
    int f473I = -1;

    /* renamed from: J  reason: collision with root package name */
    private int f474J;

    /* renamed from: K  reason: collision with root package name */
    private int f475K;

    /* renamed from: L  reason: collision with root package name */
    int f476L;

    /* renamed from: M  reason: collision with root package name */
    int f477M;

    /* renamed from: N  reason: collision with root package name */
    int f478N;

    /* renamed from: O  reason: collision with root package name */
    int f479O;

    /* renamed from: P  reason: collision with root package name */
    private boolean f480P;

    /* renamed from: Q  reason: collision with root package name */
    private int f481Q = 0;

    /* renamed from: R  reason: collision with root package name */
    Handler f482R;

    /* renamed from: S  reason: collision with root package name */
    private final View.OnClickListener f483S = new a();

    /* renamed from: a  reason: collision with root package name */
    private final Context f484a;

    /* renamed from: b  reason: collision with root package name */
    final y f485b;

    /* renamed from: c  reason: collision with root package name */
    private final Window f486c;

    /* renamed from: d  reason: collision with root package name */
    private final int f487d;

    /* renamed from: e  reason: collision with root package name */
    private CharSequence f488e;

    /* renamed from: f  reason: collision with root package name */
    private CharSequence f489f;

    /* renamed from: g  reason: collision with root package name */
    ListView f490g;

    /* renamed from: h  reason: collision with root package name */
    private View f491h;

    /* renamed from: i  reason: collision with root package name */
    private int f492i;

    /* renamed from: j  reason: collision with root package name */
    private int f493j;

    /* renamed from: k  reason: collision with root package name */
    private int f494k;

    /* renamed from: l  reason: collision with root package name */
    private int f495l;

    /* renamed from: m  reason: collision with root package name */
    private int f496m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f497n = false;

    /* renamed from: o  reason: collision with root package name */
    Button f498o;

    /* renamed from: p  reason: collision with root package name */
    private CharSequence f499p;

    /* renamed from: q  reason: collision with root package name */
    Message f500q;

    /* renamed from: r  reason: collision with root package name */
    private Drawable f501r;

    /* renamed from: s  reason: collision with root package name */
    Button f502s;

    /* renamed from: t  reason: collision with root package name */
    private CharSequence f503t;

    /* renamed from: u  reason: collision with root package name */
    Message f504u;

    /* renamed from: v  reason: collision with root package name */
    private Drawable f505v;

    /* renamed from: w  reason: collision with root package name */
    Button f506w;

    /* renamed from: x  reason: collision with root package name */
    private CharSequence f507x;

    /* renamed from: y  reason: collision with root package name */
    Message f508y;

    /* renamed from: z  reason: collision with root package name */
    private Drawable f509z;

    public static class RecycleListView extends ListView {

        /* renamed from: a  reason: collision with root package name */
        private final int f510a;

        /* renamed from: b  reason: collision with root package name */
        private final int f511b;

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.k2);
            this.f511b = obtainStyledAttributes.getDimensionPixelOffset(j.l2, -1);
            this.f510a = obtainStyledAttributes.getDimensionPixelOffset(j.m2, -1);
        }

        public void a(boolean z2, boolean z3) {
            if (!z3 || !z2) {
                setPadding(getPaddingLeft(), z2 ? getPaddingTop() : this.f510a, getPaddingRight(), z3 ? getPaddingBottom() : this.f511b);
            }
        }
    }

    class a implements View.OnClickListener {
        a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x001c, code lost:
            r3 = r0.f508y;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onClick(android.view.View r3) {
            /*
                r2 = this;
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f498o
                if (r3 != r1) goto L_0x000f
                android.os.Message r1 = r0.f500q
                if (r1 == 0) goto L_0x000f
            L_0x000a:
                android.os.Message r3 = android.os.Message.obtain(r1)
                goto L_0x0026
            L_0x000f:
                android.widget.Button r1 = r0.f502s
                if (r3 != r1) goto L_0x0018
                android.os.Message r1 = r0.f504u
                if (r1 == 0) goto L_0x0018
                goto L_0x000a
            L_0x0018:
                android.widget.Button r1 = r0.f506w
                if (r3 != r1) goto L_0x0025
                android.os.Message r3 = r0.f508y
                if (r3 == 0) goto L_0x0025
                android.os.Message r3 = android.os.Message.obtain(r3)
                goto L_0x0026
            L_0x0025:
                r3 = 0
            L_0x0026:
                if (r3 == 0) goto L_0x002b
                r3.sendToTarget()
            L_0x002b:
                androidx.appcompat.app.AlertController r3 = androidx.appcompat.app.AlertController.this
                android.os.Handler r0 = r3.f482R
                r1 = 1
                androidx.appcompat.app.y r3 = r3.f485b
                android.os.Message r3 = r0.obtainMessage(r1, r3)
                r3.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.a.onClick(android.view.View):void");
        }
    }

    class b implements NestedScrollView.d {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f513a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f514b;

        b(View view, View view2) {
            this.f513a = view;
            this.f514b = view2;
        }

        public void a(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5) {
            AlertController.f(nestedScrollView, this.f513a, this.f514b);
        }
    }

    class c implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f516a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f517b;

        c(View view, View view2) {
            this.f516a = view;
            this.f517b = view2;
        }

        public void run() {
            AlertController.f(AlertController.this.f465A, this.f516a, this.f517b);
        }
    }

    class d implements AbsListView.OnScrollListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f519a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f520b;

        d(View view, View view2) {
            this.f519a = view;
            this.f520b = view2;
        }

        public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
            AlertController.f(absListView, this.f519a, this.f520b);
        }

        public void onScrollStateChanged(AbsListView absListView, int i2) {
        }
    }

    class e implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ View f522a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f523b;

        e(View view, View view2) {
            this.f522a = view;
            this.f523b = view2;
        }

        public void run() {
            AlertController.f(AlertController.this.f490g, this.f522a, this.f523b);
        }
    }

    public static class f {

        /* renamed from: A  reason: collision with root package name */
        public int f525A;

        /* renamed from: B  reason: collision with root package name */
        public int f526B;

        /* renamed from: C  reason: collision with root package name */
        public int f527C;

        /* renamed from: D  reason: collision with root package name */
        public int f528D;

        /* renamed from: E  reason: collision with root package name */
        public boolean f529E = false;

        /* renamed from: F  reason: collision with root package name */
        public boolean[] f530F;

        /* renamed from: G  reason: collision with root package name */
        public boolean f531G;

        /* renamed from: H  reason: collision with root package name */
        public boolean f532H;

        /* renamed from: I  reason: collision with root package name */
        public int f533I = -1;

        /* renamed from: J  reason: collision with root package name */
        public DialogInterface.OnMultiChoiceClickListener f534J;

        /* renamed from: K  reason: collision with root package name */
        public Cursor f535K;

        /* renamed from: L  reason: collision with root package name */
        public String f536L;

        /* renamed from: M  reason: collision with root package name */
        public String f537M;

        /* renamed from: N  reason: collision with root package name */
        public AdapterView.OnItemSelectedListener f538N;

        /* renamed from: O  reason: collision with root package name */
        public boolean f539O = true;

        /* renamed from: a  reason: collision with root package name */
        public final Context f540a;

        /* renamed from: b  reason: collision with root package name */
        public final LayoutInflater f541b;

        /* renamed from: c  reason: collision with root package name */
        public int f542c = 0;

        /* renamed from: d  reason: collision with root package name */
        public Drawable f543d;

        /* renamed from: e  reason: collision with root package name */
        public int f544e = 0;

        /* renamed from: f  reason: collision with root package name */
        public CharSequence f545f;

        /* renamed from: g  reason: collision with root package name */
        public View f546g;

        /* renamed from: h  reason: collision with root package name */
        public CharSequence f547h;

        /* renamed from: i  reason: collision with root package name */
        public CharSequence f548i;

        /* renamed from: j  reason: collision with root package name */
        public Drawable f549j;

        /* renamed from: k  reason: collision with root package name */
        public DialogInterface.OnClickListener f550k;

        /* renamed from: l  reason: collision with root package name */
        public CharSequence f551l;

        /* renamed from: m  reason: collision with root package name */
        public Drawable f552m;

        /* renamed from: n  reason: collision with root package name */
        public DialogInterface.OnClickListener f553n;

        /* renamed from: o  reason: collision with root package name */
        public CharSequence f554o;

        /* renamed from: p  reason: collision with root package name */
        public Drawable f555p;

        /* renamed from: q  reason: collision with root package name */
        public DialogInterface.OnClickListener f556q;

        /* renamed from: r  reason: collision with root package name */
        public boolean f557r;

        /* renamed from: s  reason: collision with root package name */
        public DialogInterface.OnCancelListener f558s;

        /* renamed from: t  reason: collision with root package name */
        public DialogInterface.OnDismissListener f559t;

        /* renamed from: u  reason: collision with root package name */
        public DialogInterface.OnKeyListener f560u;

        /* renamed from: v  reason: collision with root package name */
        public CharSequence[] f561v;

        /* renamed from: w  reason: collision with root package name */
        public ListAdapter f562w;

        /* renamed from: x  reason: collision with root package name */
        public DialogInterface.OnClickListener f563x;

        /* renamed from: y  reason: collision with root package name */
        public int f564y;

        /* renamed from: z  reason: collision with root package name */
        public View f565z;

        class a extends ArrayAdapter {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ RecycleListView f566a;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            a(Context context, int i2, int i3, CharSequence[] charSequenceArr, RecycleListView recycleListView) {
                super(context, i2, i3, charSequenceArr);
                this.f566a = recycleListView;
            }

            public View getView(int i2, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i2, view, viewGroup);
                boolean[] zArr = f.this.f530F;
                if (zArr != null && zArr[i2]) {
                    this.f566a.setItemChecked(i2, true);
                }
                return view2;
            }
        }

        class b extends CursorAdapter {

            /* renamed from: a  reason: collision with root package name */
            private final int f568a;

            /* renamed from: b  reason: collision with root package name */
            private final int f569b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ RecycleListView f570c;

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ AlertController f571d;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            b(Context context, Cursor cursor, boolean z2, RecycleListView recycleListView, AlertController alertController) {
                super(context, cursor, z2);
                this.f570c = recycleListView;
                this.f571d = alertController;
                Cursor cursor2 = getCursor();
                this.f568a = cursor2.getColumnIndexOrThrow(f.this.f536L);
                this.f569b = cursor2.getColumnIndexOrThrow(f.this.f537M);
            }

            public void bindView(View view, Context context, Cursor cursor) {
                ((CheckedTextView) view.findViewById(16908308)).setText(cursor.getString(this.f568a));
                RecycleListView recycleListView = this.f570c;
                int position = cursor.getPosition();
                boolean z2 = true;
                if (cursor.getInt(this.f569b) != 1) {
                    z2 = false;
                }
                recycleListView.setItemChecked(position, z2);
            }

            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return f.this.f541b.inflate(this.f571d.f477M, viewGroup, false);
            }
        }

        class c implements AdapterView.OnItemClickListener {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ AlertController f573a;

            c(AlertController alertController) {
                this.f573a = alertController;
            }

            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                f.this.f563x.onClick(this.f573a.f485b, i2);
                if (!f.this.f532H) {
                    this.f573a.f485b.dismiss();
                }
            }
        }

        class d implements AdapterView.OnItemClickListener {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ RecycleListView f575a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ AlertController f576b;

            d(RecycleListView recycleListView, AlertController alertController) {
                this.f575a = recycleListView;
                this.f576b = alertController;
            }

            public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
                boolean[] zArr = f.this.f530F;
                if (zArr != null) {
                    zArr[i2] = this.f575a.isItemChecked(i2);
                }
                f.this.f534J.onClick(this.f576b.f485b, i2, this.f575a.isItemChecked(i2));
            }
        }

        public f(Context context) {
            this.f540a = context;
            this.f557r = true;
            this.f541b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        /* JADX WARNING: type inference failed for: r8v0, types: [android.widget.ListAdapter] */
        /* JADX WARNING: type inference failed for: r8v3 */
        /* JADX WARNING: type inference failed for: r8v4 */
        /* JADX WARNING: type inference failed for: r2v5, types: [android.widget.SimpleCursorAdapter] */
        /* JADX WARNING: type inference failed for: r1v24, types: [androidx.appcompat.app.AlertController$f$b] */
        /* JADX WARNING: type inference failed for: r1v25, types: [androidx.appcompat.app.AlertController$f$a] */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x008a  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0091  */
        /* JADX WARNING: Removed duplicated region for block: B:31:0x0096  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private void b(androidx.appcompat.app.AlertController r10) {
            /*
                r9 = this;
                android.view.LayoutInflater r0 = r9.f541b
                int r1 = r10.f476L
                r2 = 0
                android.view.View r0 = r0.inflate(r1, r2)
                androidx.appcompat.app.AlertController$RecycleListView r0 = (androidx.appcompat.app.AlertController.RecycleListView) r0
                boolean r1 = r9.f531G
                if (r1 == 0) goto L_0x0034
                android.database.Cursor r1 = r9.f535K
                if (r1 != 0) goto L_0x0025
                androidx.appcompat.app.AlertController$f$a r8 = new androidx.appcompat.app.AlertController$f$a
                android.content.Context r3 = r9.f540a
                int r4 = r10.f477M
                r5 = 16908308(0x1020014, float:2.3877285E-38)
                java.lang.CharSequence[] r6 = r9.f561v
                r1 = r8
                r2 = r9
                r7 = r0
                r1.<init>(r3, r4, r5, r6, r7)
                goto L_0x0069
            L_0x0025:
                androidx.appcompat.app.AlertController$f$b r8 = new androidx.appcompat.app.AlertController$f$b
                android.content.Context r3 = r9.f540a
                android.database.Cursor r4 = r9.f535K
                r5 = 0
                r1 = r8
                r2 = r9
                r6 = r0
                r7 = r10
                r1.<init>(r3, r4, r5, r6, r7)
                goto L_0x0069
            L_0x0034:
                boolean r1 = r9.f532H
                if (r1 == 0) goto L_0x003c
                int r1 = r10.f478N
            L_0x003a:
                r4 = r1
                goto L_0x003f
            L_0x003c:
                int r1 = r10.f479O
                goto L_0x003a
            L_0x003f:
                android.database.Cursor r1 = r9.f535K
                r2 = 16908308(0x1020014, float:2.3877285E-38)
                if (r1 == 0) goto L_0x005b
                android.widget.SimpleCursorAdapter r8 = new android.widget.SimpleCursorAdapter
                android.content.Context r3 = r9.f540a
                android.database.Cursor r5 = r9.f535K
                java.lang.String r1 = r9.f536L
                java.lang.String[] r6 = new java.lang.String[]{r1}
                int[] r7 = new int[]{r2}
                r2 = r8
                r2.<init>(r3, r4, r5, r6, r7)
                goto L_0x0069
            L_0x005b:
                android.widget.ListAdapter r8 = r9.f562w
                if (r8 == 0) goto L_0x0060
                goto L_0x0069
            L_0x0060:
                androidx.appcompat.app.AlertController$h r8 = new androidx.appcompat.app.AlertController$h
                android.content.Context r1 = r9.f540a
                java.lang.CharSequence[] r3 = r9.f561v
                r8.<init>(r1, r4, r2, r3)
            L_0x0069:
                r10.f472H = r8
                int r1 = r9.f533I
                r10.f473I = r1
                android.content.DialogInterface$OnClickListener r1 = r9.f563x
                if (r1 == 0) goto L_0x007c
                androidx.appcompat.app.AlertController$f$c r1 = new androidx.appcompat.app.AlertController$f$c
                r1.<init>(r10)
            L_0x0078:
                r0.setOnItemClickListener(r1)
                goto L_0x0086
            L_0x007c:
                android.content.DialogInterface$OnMultiChoiceClickListener r1 = r9.f534J
                if (r1 == 0) goto L_0x0086
                androidx.appcompat.app.AlertController$f$d r1 = new androidx.appcompat.app.AlertController$f$d
                r1.<init>(r0, r10)
                goto L_0x0078
            L_0x0086:
                android.widget.AdapterView$OnItemSelectedListener r1 = r9.f538N
                if (r1 == 0) goto L_0x008d
                r0.setOnItemSelectedListener(r1)
            L_0x008d:
                boolean r1 = r9.f532H
                if (r1 == 0) goto L_0x0096
                r1 = 1
            L_0x0092:
                r0.setChoiceMode(r1)
                goto L_0x009c
            L_0x0096:
                boolean r1 = r9.f531G
                if (r1 == 0) goto L_0x009c
                r1 = 2
                goto L_0x0092
            L_0x009c:
                r10.f490g = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.f.b(androidx.appcompat.app.AlertController):void");
        }

        public void a(AlertController alertController) {
            View view = this.f546g;
            if (view != null) {
                alertController.l(view);
            } else {
                CharSequence charSequence = this.f545f;
                if (charSequence != null) {
                    alertController.q(charSequence);
                }
                Drawable drawable = this.f543d;
                if (drawable != null) {
                    alertController.n(drawable);
                }
                int i2 = this.f542c;
                if (i2 != 0) {
                    alertController.m(i2);
                }
                int i3 = this.f544e;
                if (i3 != 0) {
                    alertController.m(alertController.c(i3));
                }
            }
            CharSequence charSequence2 = this.f547h;
            if (charSequence2 != null) {
                alertController.o(charSequence2);
            }
            CharSequence charSequence3 = this.f548i;
            if (!(charSequence3 == null && this.f549j == null)) {
                alertController.k(-1, charSequence3, this.f550k, (Message) null, this.f549j);
            }
            CharSequence charSequence4 = this.f551l;
            if (!(charSequence4 == null && this.f552m == null)) {
                alertController.k(-2, charSequence4, this.f553n, (Message) null, this.f552m);
            }
            CharSequence charSequence5 = this.f554o;
            if (!(charSequence5 == null && this.f555p == null)) {
                alertController.k(-3, charSequence5, this.f556q, (Message) null, this.f555p);
            }
            if (!(this.f561v == null && this.f535K == null && this.f562w == null)) {
                b(alertController);
            }
            View view2 = this.f565z;
            if (view2 == null) {
                int i4 = this.f564y;
                if (i4 != 0) {
                    alertController.r(i4);
                }
            } else if (this.f529E) {
                alertController.t(view2, this.f525A, this.f526B, this.f527C, this.f528D);
            } else {
                alertController.s(view2);
            }
        }
    }

    private static final class g extends Handler {

        /* renamed from: a  reason: collision with root package name */
        private WeakReference f578a;

        public g(DialogInterface dialogInterface) {
            this.f578a = new WeakReference(dialogInterface);
        }

        public void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == -3 || i2 == -2 || i2 == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f578a.get(), message.what);
            } else if (i2 == 1) {
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    private static class h extends ArrayAdapter {
        public h(Context context, int i2, int i3, CharSequence[] charSequenceArr) {
            super(context, i2, i3, charSequenceArr);
        }

        public long getItemId(int i2) {
            return (long) i2;
        }

        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, y yVar, Window window) {
        this.f484a = context;
        this.f485b = yVar;
        this.f486c = window;
        this.f482R = new g(yVar);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, j.f5300F, C0233a.alertDialogStyle, 0);
        this.f474J = obtainStyledAttributes.getResourceId(j.f5301G, 0);
        this.f475K = obtainStyledAttributes.getResourceId(j.f5303I, 0);
        this.f476L = obtainStyledAttributes.getResourceId(j.f5305K, 0);
        this.f477M = obtainStyledAttributes.getResourceId(j.f5306L, 0);
        this.f478N = obtainStyledAttributes.getResourceId(j.f5308N, 0);
        this.f479O = obtainStyledAttributes.getResourceId(j.f5304J, 0);
        this.f480P = obtainStyledAttributes.getBoolean(j.f5307M, true);
        this.f487d = obtainStyledAttributes.getDimensionPixelSize(j.f5302H, 0);
        obtainStyledAttributes.recycle();
        yVar.k(1);
    }

    static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    private void b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    static void f(View view, View view2, View view3) {
        int i2 = 4;
        if (view2 != null) {
            view2.setVisibility(view.canScrollVertically(-1) ? 0 : 4);
        }
        if (view3 != null) {
            if (view.canScrollVertically(1)) {
                i2 = 0;
            }
            view3.setVisibility(i2);
        }
    }

    private ViewGroup i(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    private int j() {
        int i2 = this.f475K;
        if (i2 == 0) {
            return this.f474J;
        }
        return this.f481Q == 1 ? i2 : this.f474J;
    }

    private void p(ViewGroup viewGroup, View view, int i2, int i3) {
        View view2;
        Runnable eVar;
        View findViewById = this.f486c.findViewById(e.f.scrollIndicatorUp);
        View findViewById2 = this.f486c.findViewById(e.f.scrollIndicatorDown);
        if (Build.VERSION.SDK_INT >= 23) {
            W.F0(view, i2, i3);
            if (findViewById != null) {
                viewGroup.removeView(findViewById);
            }
            if (findViewById2 == null) {
                return;
            }
        } else {
            if (findViewById != null && (i2 & 1) == 0) {
                viewGroup.removeView(findViewById);
                findViewById = null;
            }
            if (findViewById2 != null && (i2 & 2) == 0) {
                viewGroup.removeView(findViewById2);
                findViewById2 = null;
            }
            if (findViewById != null || findViewById2 != null) {
                if (this.f489f != null) {
                    this.f465A.setOnScrollChangeListener(new b(findViewById, findViewById2));
                    view2 = this.f465A;
                    eVar = new c(findViewById, findViewById2);
                } else {
                    ListView listView = this.f490g;
                    if (listView != null) {
                        listView.setOnScrollListener(new d(findViewById, findViewById2));
                        view2 = this.f490g;
                        eVar = new e(findViewById, findViewById2);
                    } else {
                        if (findViewById != null) {
                            viewGroup.removeView(findViewById);
                        }
                        if (findViewById2 == null) {
                            return;
                        }
                    }
                }
                view2.post(eVar);
                return;
            }
            return;
        }
        viewGroup.removeView(findViewById2);
    }

    private void u(ViewGroup viewGroup) {
        boolean z2;
        Button button;
        Button button2 = (Button) viewGroup.findViewById(16908313);
        this.f498o = button2;
        button2.setOnClickListener(this.f483S);
        if (!TextUtils.isEmpty(this.f499p) || this.f501r != null) {
            this.f498o.setText(this.f499p);
            Drawable drawable = this.f501r;
            if (drawable != null) {
                int i2 = this.f487d;
                drawable.setBounds(0, 0, i2, i2);
                this.f498o.setCompoundDrawables(this.f501r, (Drawable) null, (Drawable) null, (Drawable) null);
            }
            this.f498o.setVisibility(0);
            z2 = true;
        } else {
            this.f498o.setVisibility(8);
            z2 = false;
        }
        Button button3 = (Button) viewGroup.findViewById(16908314);
        this.f502s = button3;
        button3.setOnClickListener(this.f483S);
        if (!TextUtils.isEmpty(this.f503t) || this.f505v != null) {
            this.f502s.setText(this.f503t);
            Drawable drawable2 = this.f505v;
            if (drawable2 != null) {
                int i3 = this.f487d;
                drawable2.setBounds(0, 0, i3, i3);
                this.f502s.setCompoundDrawables(this.f505v, (Drawable) null, (Drawable) null, (Drawable) null);
            }
            this.f502s.setVisibility(0);
            z2 |= true;
        } else {
            this.f502s.setVisibility(8);
        }
        Button button4 = (Button) viewGroup.findViewById(16908315);
        this.f506w = button4;
        button4.setOnClickListener(this.f483S);
        if (!TextUtils.isEmpty(this.f507x) || this.f509z != null) {
            this.f506w.setText(this.f507x);
            Drawable drawable3 = this.f509z;
            if (drawable3 != null) {
                int i4 = this.f487d;
                drawable3.setBounds(0, 0, i4, i4);
                this.f506w.setCompoundDrawables(this.f509z, (Drawable) null, (Drawable) null, (Drawable) null);
            }
            this.f506w.setVisibility(0);
            z2 |= true;
        } else {
            this.f506w.setVisibility(8);
        }
        if (z(this.f484a)) {
            if (z2) {
                button = this.f498o;
            } else if (z2) {
                button = this.f502s;
            } else if (z2) {
                button = this.f506w;
            }
            b(button);
        }
        if (!z2) {
            viewGroup.setVisibility(8);
        }
    }

    private void v(ViewGroup viewGroup) {
        NestedScrollView nestedScrollView = (NestedScrollView) this.f486c.findViewById(e.f.scrollView);
        this.f465A = nestedScrollView;
        nestedScrollView.setFocusable(false);
        this.f465A.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroup.findViewById(16908299);
        this.f470F = textView;
        if (textView != null) {
            CharSequence charSequence = this.f489f;
            if (charSequence != null) {
                textView.setText(charSequence);
                return;
            }
            textView.setVisibility(8);
            this.f465A.removeView(this.f470F);
            if (this.f490g != null) {
                ViewGroup viewGroup2 = (ViewGroup) this.f465A.getParent();
                int indexOfChild = viewGroup2.indexOfChild(this.f465A);
                viewGroup2.removeViewAt(indexOfChild);
                viewGroup2.addView(this.f490g, indexOfChild, new ViewGroup.LayoutParams(-1, -1));
                return;
            }
            viewGroup.setVisibility(8);
        }
    }

    private void w(ViewGroup viewGroup) {
        View view = this.f491h;
        boolean z2 = false;
        if (view == null) {
            view = this.f492i != 0 ? LayoutInflater.from(this.f484a).inflate(this.f492i, viewGroup, false) : null;
        }
        if (view != null) {
            z2 = true;
        }
        if (!z2 || !a(view)) {
            this.f486c.setFlags(131072, 131072);
        }
        if (z2) {
            FrameLayout frameLayout = (FrameLayout) this.f486c.findViewById(e.f.custom);
            frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
            if (this.f497n) {
                frameLayout.setPadding(this.f493j, this.f494k, this.f495l, this.f496m);
            }
            if (this.f490g != null) {
                ((S.a) viewGroup.getLayoutParams()).weight = 0.0f;
                return;
            }
            return;
        }
        viewGroup.setVisibility(8);
    }

    private void x(ViewGroup viewGroup) {
        View view;
        if (this.f471G != null) {
            viewGroup.addView(this.f471G, 0, new ViewGroup.LayoutParams(-1, -2));
            view = this.f486c.findViewById(e.f.title_template);
        } else {
            this.f468D = (ImageView) this.f486c.findViewById(16908294);
            if (!(!TextUtils.isEmpty(this.f488e)) || !this.f480P) {
                this.f486c.findViewById(e.f.title_template).setVisibility(8);
                this.f468D.setVisibility(8);
                view = viewGroup;
            } else {
                TextView textView = (TextView) this.f486c.findViewById(e.f.alertTitle);
                this.f469E = textView;
                textView.setText(this.f488e);
                int i2 = this.f466B;
                if (i2 != 0) {
                    this.f468D.setImageResource(i2);
                    return;
                }
                Drawable drawable = this.f467C;
                if (drawable != null) {
                    this.f468D.setImageDrawable(drawable);
                    return;
                }
                this.f469E.setPadding(this.f468D.getPaddingLeft(), this.f468D.getPaddingTop(), this.f468D.getPaddingRight(), this.f468D.getPaddingBottom());
                this.f468D.setVisibility(8);
                return;
            }
        }
        view.setVisibility(8);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0092, code lost:
        if (r1 != null) goto L_0x009f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x009d, code lost:
        if (r1 != null) goto L_0x009f;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00a8  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x00c9  */
    /* JADX WARNING: Removed duplicated region for block: B:54:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void y() {
        /*
            r8 = this;
            android.view.Window r0 = r8.f486c
            int r1 = e.f.parentPanel
            android.view.View r0 = r0.findViewById(r1)
            int r1 = e.f.topPanel
            android.view.View r2 = r0.findViewById(r1)
            int r3 = e.f.contentPanel
            android.view.View r4 = r0.findViewById(r3)
            int r5 = e.f.buttonPanel
            android.view.View r6 = r0.findViewById(r5)
            int r7 = e.f.customPanel
            android.view.View r0 = r0.findViewById(r7)
            android.view.ViewGroup r0 = (android.view.ViewGroup) r0
            r8.w(r0)
            android.view.View r1 = r0.findViewById(r1)
            android.view.View r3 = r0.findViewById(r3)
            android.view.View r5 = r0.findViewById(r5)
            android.view.ViewGroup r1 = r8.i(r1, r2)
            android.view.ViewGroup r2 = r8.i(r3, r4)
            android.view.ViewGroup r3 = r8.i(r5, r6)
            r8.v(r2)
            r8.u(r3)
            r8.x(r1)
            int r0 = r0.getVisibility()
            r4 = 8
            r5 = 1
            r6 = 0
            if (r0 == r4) goto L_0x0052
            r0 = 1
            goto L_0x0053
        L_0x0052:
            r0 = 0
        L_0x0053:
            if (r1 == 0) goto L_0x005d
            int r7 = r1.getVisibility()
            if (r7 == r4) goto L_0x005d
            r7 = 1
            goto L_0x005e
        L_0x005d:
            r7 = 0
        L_0x005e:
            if (r3 == 0) goto L_0x0068
            int r3 = r3.getVisibility()
            if (r3 == r4) goto L_0x0068
            r3 = 1
            goto L_0x0069
        L_0x0068:
            r3 = 0
        L_0x0069:
            if (r3 != 0) goto L_0x0078
            if (r2 == 0) goto L_0x0078
            int r4 = e.f.textSpacerNoButtons
            android.view.View r4 = r2.findViewById(r4)
            if (r4 == 0) goto L_0x0078
            r4.setVisibility(r6)
        L_0x0078:
            if (r7 == 0) goto L_0x0095
            androidx.core.widget.NestedScrollView r4 = r8.f465A
            if (r4 == 0) goto L_0x0081
            r4.setClipToPadding(r5)
        L_0x0081:
            java.lang.CharSequence r4 = r8.f489f
            if (r4 != 0) goto L_0x008c
            android.widget.ListView r4 = r8.f490g
            if (r4 == 0) goto L_0x008a
            goto L_0x008c
        L_0x008a:
            r1 = 0
            goto L_0x0092
        L_0x008c:
            int r4 = e.f.titleDividerNoCustom
            android.view.View r1 = r1.findViewById(r4)
        L_0x0092:
            if (r1 == 0) goto L_0x00a2
            goto L_0x009f
        L_0x0095:
            if (r2 == 0) goto L_0x00a2
            int r1 = e.f.textSpacerNoTitle
            android.view.View r1 = r2.findViewById(r1)
            if (r1 == 0) goto L_0x00a2
        L_0x009f:
            r1.setVisibility(r6)
        L_0x00a2:
            android.widget.ListView r1 = r8.f490g
            boolean r4 = r1 instanceof androidx.appcompat.app.AlertController.RecycleListView
            if (r4 == 0) goto L_0x00ad
            androidx.appcompat.app.AlertController$RecycleListView r1 = (androidx.appcompat.app.AlertController.RecycleListView) r1
            r1.a(r7, r3)
        L_0x00ad:
            if (r0 != 0) goto L_0x00c1
            android.widget.ListView r0 = r8.f490g
            if (r0 == 0) goto L_0x00b4
            goto L_0x00b6
        L_0x00b4:
            androidx.core.widget.NestedScrollView r0 = r8.f465A
        L_0x00b6:
            if (r0 == 0) goto L_0x00c1
            if (r3 == 0) goto L_0x00bb
            r6 = 2
        L_0x00bb:
            r1 = r7 | r6
            r3 = 3
            r8.p(r2, r0, r1, r3)
        L_0x00c1:
            android.widget.ListView r0 = r8.f490g
            if (r0 == 0) goto L_0x00d7
            android.widget.ListAdapter r1 = r8.f472H
            if (r1 == 0) goto L_0x00d7
            r0.setAdapter(r1)
            int r1 = r8.f473I
            r2 = -1
            if (r1 <= r2) goto L_0x00d7
            r0.setItemChecked(r1, r5)
            r0.setSelection(r1)
        L_0x00d7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.y():void");
    }

    private static boolean z(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0233a.alertDialogCenterButtons, typedValue, true);
        return typedValue.data != 0;
    }

    public int c(int i2) {
        TypedValue typedValue = new TypedValue();
        this.f484a.getTheme().resolveAttribute(i2, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView d() {
        return this.f490g;
    }

    public void e() {
        this.f485b.setContentView(j());
        y();
    }

    public boolean g(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f465A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public boolean h(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f465A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public void k(int i2, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f482R.obtainMessage(i2, onClickListener);
        }
        if (i2 == -3) {
            this.f507x = charSequence;
            this.f508y = message;
            this.f509z = drawable;
        } else if (i2 == -2) {
            this.f503t = charSequence;
            this.f504u = message;
            this.f505v = drawable;
        } else if (i2 == -1) {
            this.f499p = charSequence;
            this.f500q = message;
            this.f501r = drawable;
        } else {
            throw new IllegalArgumentException("Button does not exist");
        }
    }

    public void l(View view) {
        this.f471G = view;
    }

    public void m(int i2) {
        this.f467C = null;
        this.f466B = i2;
        ImageView imageView = this.f468D;
        if (imageView == null) {
            return;
        }
        if (i2 != 0) {
            imageView.setVisibility(0);
            this.f468D.setImageResource(this.f466B);
            return;
        }
        imageView.setVisibility(8);
    }

    public void n(Drawable drawable) {
        this.f467C = drawable;
        this.f466B = 0;
        ImageView imageView = this.f468D;
        if (imageView == null) {
            return;
        }
        if (drawable != null) {
            imageView.setVisibility(0);
            this.f468D.setImageDrawable(drawable);
            return;
        }
        imageView.setVisibility(8);
    }

    public void o(CharSequence charSequence) {
        this.f489f = charSequence;
        TextView textView = this.f470F;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void q(CharSequence charSequence) {
        this.f488e = charSequence;
        TextView textView = this.f469E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void r(int i2) {
        this.f491h = null;
        this.f492i = i2;
        this.f497n = false;
    }

    public void s(View view) {
        this.f491h = view;
        this.f492i = 0;
        this.f497n = false;
    }

    public void t(View view, int i2, int i3, int i4, int i5) {
        this.f491h = view;
        this.f492i = 0;
        this.f497n = true;
        this.f493j = i2;
        this.f494k = i3;
        this.f495l = i4;
        this.f496m = i5;
    }
}
