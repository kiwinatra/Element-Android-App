package androidx.appcompat.app;

import android.window.OnBackInvokedDispatcher;

public abstract /* synthetic */ class s {
    public static /* bridge */ /* synthetic */ OnBackInvokedDispatcher a(Object obj) {
        return (OnBackInvokedDispatcher) obj;
    }
}
