package androidx.appcompat.app;

import O.e;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.t;
import androidx.appcompat.app.C0089b;
import androidx.appcompat.view.b;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.o0;
import androidx.core.app.h;
import androidx.core.app.m;
import androidx.fragment.app.C0180j;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import androidx.savedstate.a;
import b.C0209b;

/* renamed from: androidx.appcompat.app.d  reason: case insensitive filesystem */
public abstract class C0091d extends C0180j implements C0092e, m.a, C0089b.c {

    /* renamed from: A  reason: collision with root package name */
    private Resources f671A;

    /* renamed from: z  reason: collision with root package name */
    private C0094g f672z;

    /* renamed from: androidx.appcompat.app.d$a */
    class a implements a.c {
        a() {
        }

        public Bundle a() {
            Bundle bundle = new Bundle();
            C0091d.this.d0().C(bundle);
            return bundle;
        }
    }

    /* renamed from: androidx.appcompat.app.d$b */
    class b implements C0209b {
        b() {
        }

        public void a(Context context) {
            C0094g d02 = C0091d.this.d0();
            d02.t();
            d02.y(C0091d.this.e().b("androidx:appcompat"));
        }
    }

    public C0091d() {
        f0();
    }

    private void f0() {
        e().h("androidx:appcompat", new a());
        E(new b());
    }

    private void g0() {
        F.a(getWindow().getDecorView(), this);
        G.a(getWindow().getDecorView(), this);
        e.a(getWindow().getDecorView(), this);
        t.a(getWindow().getDecorView(), this);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
        r0 = getWindow();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean n0(android.view.KeyEvent r3) {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 26
            if (r0 >= r1) goto L_0x003e
            boolean r0 = r3.isCtrlPressed()
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getMetaState()
            boolean r0 = android.view.KeyEvent.metaStateHasNoModifiers(r0)
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getRepeatCount()
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getKeyCode()
            boolean r0 = android.view.KeyEvent.isModifierKey(r0)
            if (r0 != 0) goto L_0x003e
            android.view.Window r0 = r2.getWindow()
            if (r0 == 0) goto L_0x003e
            android.view.View r1 = r0.getDecorView()
            if (r1 == 0) goto L_0x003e
            android.view.View r0 = r0.getDecorView()
            boolean r3 = r0.dispatchKeyShortcutEvent(r3)
            if (r3 == 0) goto L_0x003e
            r3 = 1
            return r3
        L_0x003e:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.C0091d.n0(android.view.KeyEvent):boolean");
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        g0();
        d0().e(view, layoutParams);
    }

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(d0().g(context));
    }

    public void closeOptionsMenu() {
        C0088a e02 = e0();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (e02 == null || !e02.g()) {
            super.closeOptionsMenu();
        }
    }

    public C0094g d0() {
        if (this.f672z == null) {
            this.f672z = C0094g.h(this, this);
        }
        return this.f672z;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        C0088a e02 = e0();
        if (keyCode != 82 || e02 == null || !e02.p(keyEvent)) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    public C0088a e0() {
        return d0().s();
    }

    public View findViewById(int i2) {
        return d0().j(i2);
    }

    public MenuInflater getMenuInflater() {
        return d0().q();
    }

    public Resources getResources() {
        if (this.f671A == null && o0.c()) {
            this.f671A = new o0(this, super.getResources());
        }
        Resources resources = this.f671A;
        return resources == null ? super.getResources() : resources;
    }

    public void h0(m mVar) {
        mVar.b(this);
    }

    /* access modifiers changed from: protected */
    public void i0(androidx.core.os.b bVar) {
    }

    public void invalidateOptionsMenu() {
        d0().u();
    }

    /* access modifiers changed from: protected */
    public void j0(int i2) {
    }

    public void k0(m mVar) {
    }

    public void l0() {
    }

    public boolean m0() {
        Intent o2 = o();
        if (o2 == null) {
            return false;
        }
        if (q0(o2)) {
            m d2 = m.d(this);
            h0(d2);
            k0(d2);
            d2.e();
            try {
                androidx.core.app.b.h(this);
                return true;
            } catch (IllegalStateException unused) {
                finish();
                return true;
            }
        } else {
            p0(o2);
            return true;
        }
    }

    public Intent o() {
        return h.a(this);
    }

    public void o0(Toolbar toolbar) {
        d0().M(toolbar);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        d0().x(configuration);
        if (this.f671A != null) {
            this.f671A.updateConfiguration(super.getResources().getConfiguration(), super.getResources().getDisplayMetrics());
        }
    }

    public void onContentChanged() {
        l0();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        d0().z();
    }

    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (n0(keyEvent)) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent);
    }

    public final boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        C0088a e02 = e0();
        if (menuItem.getItemId() != 16908332 || e02 == null || (e02.j() & 4) == 0) {
            return false;
        }
        return m0();
    }

    public boolean onMenuOpened(int i2, Menu menu) {
        return super.onMenuOpened(i2, menu);
    }

    public void onPanelClosed(int i2, Menu menu) {
        super.onPanelClosed(i2, menu);
    }

    /* access modifiers changed from: protected */
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        d0().A(bundle);
    }

    /* access modifiers changed from: protected */
    public void onPostResume() {
        super.onPostResume();
        d0().B();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        d0().D();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        d0().E();
    }

    /* access modifiers changed from: protected */
    public void onTitleChanged(CharSequence charSequence, int i2) {
        super.onTitleChanged(charSequence, i2);
        d0().O(charSequence);
    }

    public void openOptionsMenu() {
        C0088a e02 = e0();
        if (!getWindow().hasFeature(0)) {
            return;
        }
        if (e02 == null || !e02.q()) {
            super.openOptionsMenu();
        }
    }

    public void p0(Intent intent) {
        h.e(this, intent);
    }

    public void q(androidx.appcompat.view.b bVar) {
    }

    public boolean q0(Intent intent) {
        return h.f(this, intent);
    }

    public C0089b.C0015b s() {
        return d0().n();
    }

    public void setContentView(int i2) {
        g0();
        d0().I(i2);
    }

    public void setTheme(int i2) {
        super.setTheme(i2);
        d0().N(i2);
    }

    public void u(androidx.appcompat.view.b bVar) {
    }

    public androidx.appcompat.view.b w(b.a aVar) {
        return null;
    }

    public void setContentView(View view) {
        g0();
        d0().J(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        g0();
        d0().K(view, layoutParams);
    }
}
