package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

public abstract /* synthetic */ class r {
    public static /* bridge */ /* synthetic */ OnBackInvokedCallback a(Object obj) {
        return (OnBackInvokedCallback) obj;
    }
}
