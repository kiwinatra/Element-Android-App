package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.app.C0089b;
import androidx.appcompat.widget.Toolbar;
import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.Executor;

/* renamed from: androidx.appcompat.app.g  reason: case insensitive filesystem */
public abstract class C0094g {

    /* renamed from: a  reason: collision with root package name */
    static c f676a = new c(new d());

    /* renamed from: b  reason: collision with root package name */
    private static int f677b = -100;

    /* renamed from: c  reason: collision with root package name */
    private static androidx.core.os.b f678c = null;

    /* renamed from: d  reason: collision with root package name */
    private static androidx.core.os.b f679d = null;

    /* renamed from: e  reason: collision with root package name */
    private static Boolean f680e = null;

    /* renamed from: f  reason: collision with root package name */
    private static boolean f681f = false;

    /* renamed from: g  reason: collision with root package name */
    private static final l.b f682g = new l.b();

    /* renamed from: h  reason: collision with root package name */
    private static final Object f683h = new Object();

    /* renamed from: i  reason: collision with root package name */
    private static final Object f684i = new Object();

    /* renamed from: androidx.appcompat.app.g$a */
    static class a {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }
    }

    /* renamed from: androidx.appcompat.app.g$b */
    static class b {
        static LocaleList a(Object obj) {
            return ((LocaleManager) obj).getApplicationLocales();
        }

        static void b(Object obj, LocaleList localeList) {
            ((LocaleManager) obj).setApplicationLocales(localeList);
        }
    }

    /* renamed from: androidx.appcompat.app.g$c */
    static class c implements Executor {

        /* renamed from: a  reason: collision with root package name */
        private final Object f685a = new Object();

        /* renamed from: b  reason: collision with root package name */
        final Queue f686b = new ArrayDeque();

        /* renamed from: c  reason: collision with root package name */
        final Executor f687c;

        /* renamed from: d  reason: collision with root package name */
        Runnable f688d;

        c(Executor executor) {
            this.f687c = executor;
        }

        /* access modifiers changed from: private */
        public /* synthetic */ void d(Runnable runnable) {
            try {
                runnable.run();
            } finally {
                e();
            }
        }

        /* access modifiers changed from: protected */
        public void e() {
            synchronized (this.f685a) {
                try {
                    Runnable runnable = (Runnable) this.f686b.poll();
                    this.f688d = runnable;
                    if (runnable != null) {
                        this.f687c.execute(runnable);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public void execute(Runnable runnable) {
            synchronized (this.f685a) {
                try {
                    this.f686b.add(new C0095h(this, runnable));
                    if (this.f688d == null) {
                        e();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* renamed from: androidx.appcompat.app.g$d */
    static class d implements Executor {
        d() {
        }

        public void execute(Runnable runnable) {
            new Thread(runnable).start();
        }
    }

    C0094g() {
    }

    static void F(C0094g gVar) {
        synchronized (f683h) {
            G(gVar);
        }
    }

    private static void G(C0094g gVar) {
        synchronized (f683h) {
            try {
                Iterator it = f682g.iterator();
                while (it.hasNext()) {
                    C0094g gVar2 = (C0094g) ((WeakReference) it.next()).get();
                    if (gVar2 == gVar || gVar2 == null) {
                        it.remove();
                    }
                }
            } finally {
            }
        }
    }

    static void P(Context context) {
        if (Build.VERSION.SDK_INT >= 33) {
            ComponentName componentName = new ComponentName(context, "androidx.appcompat.app.AppLocalesMetadataHolderService");
            if (context.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
                if (k().f()) {
                    String b2 = androidx.core.app.d.b(context);
                    Object systemService = context.getSystemService("locale");
                    if (systemService != null) {
                        b.b(systemService, a.a(b2));
                    }
                }
                context.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void Q(android.content.Context r3) {
        /*
            boolean r0 = v(r3)
            if (r0 != 0) goto L_0x0007
            return
        L_0x0007:
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L_0x001c
            boolean r0 = f681f
            if (r0 != 0) goto L_0x0057
            androidx.appcompat.app.g$c r0 = f676a
            androidx.appcompat.app.f r1 = new androidx.appcompat.app.f
            r1.<init>(r3)
            r0.execute(r1)
            goto L_0x0057
        L_0x001c:
            java.lang.Object r0 = f684i
            monitor-enter(r0)
            androidx.core.os.b r1 = f678c     // Catch:{ all -> 0x0032 }
            if (r1 != 0) goto L_0x0043
            androidx.core.os.b r1 = f679d     // Catch:{ all -> 0x0032 }
            if (r1 != 0) goto L_0x0034
            java.lang.String r3 = androidx.core.app.d.b(r3)     // Catch:{ all -> 0x0032 }
            androidx.core.os.b r3 = androidx.core.os.b.c(r3)     // Catch:{ all -> 0x0032 }
            f679d = r3     // Catch:{ all -> 0x0032 }
            goto L_0x0034
        L_0x0032:
            r3 = move-exception
            goto L_0x0058
        L_0x0034:
            androidx.core.os.b r3 = f679d     // Catch:{ all -> 0x0032 }
            boolean r3 = r3.f()     // Catch:{ all -> 0x0032 }
            if (r3 == 0) goto L_0x003e
            monitor-exit(r0)     // Catch:{ all -> 0x0032 }
            return
        L_0x003e:
            androidx.core.os.b r3 = f679d     // Catch:{ all -> 0x0032 }
            f678c = r3     // Catch:{ all -> 0x0032 }
            goto L_0x0056
        L_0x0043:
            androidx.core.os.b r2 = f679d     // Catch:{ all -> 0x0032 }
            boolean r1 = r1.equals(r2)     // Catch:{ all -> 0x0032 }
            if (r1 != 0) goto L_0x0056
            androidx.core.os.b r1 = f678c     // Catch:{ all -> 0x0032 }
            f679d = r1     // Catch:{ all -> 0x0032 }
            java.lang.String r1 = r1.h()     // Catch:{ all -> 0x0032 }
            androidx.core.app.d.a(r3, r1)     // Catch:{ all -> 0x0032 }
        L_0x0056:
            monitor-exit(r0)     // Catch:{ all -> 0x0032 }
        L_0x0057:
            return
        L_0x0058:
            monitor-exit(r0)     // Catch:{ all -> 0x0032 }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.C0094g.Q(android.content.Context):void");
    }

    static void d(C0094g gVar) {
        synchronized (f683h) {
            G(gVar);
            f682g.add(new WeakReference(gVar));
        }
    }

    public static C0094g h(Activity activity, C0092e eVar) {
        return new i(activity, eVar);
    }

    public static C0094g i(Dialog dialog, C0092e eVar) {
        return new i(dialog, eVar);
    }

    public static androidx.core.os.b k() {
        if (Build.VERSION.SDK_INT >= 33) {
            Object p2 = p();
            if (p2 != null) {
                return androidx.core.os.b.i(b.a(p2));
            }
        } else {
            androidx.core.os.b bVar = f678c;
            if (bVar != null) {
                return bVar;
            }
        }
        return androidx.core.os.b.e();
    }

    public static int m() {
        return f677b;
    }

    static Object p() {
        Context l2;
        Iterator it = f682g.iterator();
        while (it.hasNext()) {
            C0094g gVar = (C0094g) ((WeakReference) it.next()).get();
            if (gVar != null && (l2 = gVar.l()) != null) {
                return l2.getSystemService("locale");
            }
        }
        return null;
    }

    static androidx.core.os.b r() {
        return f678c;
    }

    static boolean v(Context context) {
        if (f680e == null) {
            try {
                Bundle bundle = A.a(context).metaData;
                if (bundle != null) {
                    f680e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
                f680e = Boolean.FALSE;
            }
        }
        return f680e.booleanValue();
    }

    /* access modifiers changed from: private */
    public static /* synthetic */ void w(Context context) {
        P(context);
        f681f = true;
    }

    public abstract void A(Bundle bundle);

    public abstract void B();

    public abstract void C(Bundle bundle);

    public abstract void D();

    public abstract void E();

    public abstract boolean H(int i2);

    public abstract void I(int i2);

    public abstract void J(View view);

    public abstract void K(View view, ViewGroup.LayoutParams layoutParams);

    public void L(OnBackInvokedDispatcher onBackInvokedDispatcher) {
    }

    public abstract void M(Toolbar toolbar);

    public abstract void N(int i2);

    public abstract void O(CharSequence charSequence);

    public abstract void e(View view, ViewGroup.LayoutParams layoutParams);

    public void f(Context context) {
    }

    public Context g(Context context) {
        f(context);
        return context;
    }

    public abstract View j(int i2);

    public abstract Context l();

    public abstract C0089b.C0015b n();

    public abstract int o();

    public abstract MenuInflater q();

    public abstract C0088a s();

    public abstract void t();

    public abstract void u();

    public abstract void x(Configuration configuration);

    public abstract void y(Bundle bundle);

    public abstract void z();
}
