package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.i;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.M;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.i0;
import androidx.core.view.W;
import java.util.ArrayList;
import x.h;

class E extends C0088a {

    /* renamed from: a  reason: collision with root package name */
    final M f588a;

    /* renamed from: b  reason: collision with root package name */
    final Window.Callback f589b;

    /* renamed from: c  reason: collision with root package name */
    final i.g f590c;

    /* renamed from: d  reason: collision with root package name */
    boolean f591d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f592e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f593f;

    /* renamed from: g  reason: collision with root package name */
    private ArrayList f594g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    private final Runnable f595h = new a();

    /* renamed from: i  reason: collision with root package name */
    private final Toolbar.h f596i;

    class a implements Runnable {
        a() {
        }

        public void run() {
            E.this.A();
        }
    }

    class b implements Toolbar.h {
        b() {
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            return E.this.f589b.onMenuItemSelected(0, menuItem);
        }
    }

    private final class c implements j.a {

        /* renamed from: a  reason: collision with root package name */
        private boolean f599a;

        c() {
        }

        public void a(androidx.appcompat.view.menu.e eVar, boolean z2) {
            if (!this.f599a) {
                this.f599a = true;
                E.this.f588a.h();
                E.this.f589b.onPanelClosed(108, eVar);
                this.f599a = false;
            }
        }

        public boolean b(androidx.appcompat.view.menu.e eVar) {
            E.this.f589b.onMenuOpened(108, eVar);
            return true;
        }
    }

    private final class d implements e.a {
        d() {
        }

        public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
            return false;
        }

        public void b(androidx.appcompat.view.menu.e eVar) {
            if (E.this.f588a.c()) {
                E.this.f589b.onPanelClosed(108, eVar);
            } else if (E.this.f589b.onPreparePanel(0, (View) null, eVar)) {
                E.this.f589b.onMenuOpened(108, eVar);
            }
        }
    }

    private class e implements i.g {
        e() {
        }

        public boolean a(int i2) {
            if (i2 != 0) {
                return false;
            }
            E e2 = E.this;
            if (e2.f591d) {
                return false;
            }
            e2.f588a.f();
            E.this.f591d = true;
            return false;
        }

        public View onCreatePanelView(int i2) {
            if (i2 == 0) {
                return new View(E.this.f588a.r());
            }
            return null;
        }
    }

    E(Toolbar toolbar, CharSequence charSequence, Window.Callback callback) {
        b bVar = new b();
        this.f596i = bVar;
        h.g(toolbar);
        i0 i0Var = new i0(toolbar, false);
        this.f588a = i0Var;
        this.f589b = (Window.Callback) h.g(callback);
        i0Var.setWindowCallback(callback);
        toolbar.setOnMenuItemClickListener(bVar);
        i0Var.setWindowTitle(charSequence);
        this.f590c = new e();
    }

    private Menu z() {
        if (!this.f592e) {
            this.f588a.i(new c(), new d());
            this.f592e = true;
        }
        return this.f588a.l();
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:21:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void A() {
        /*
            r5 = this;
            android.view.Menu r0 = r5.z()
            boolean r1 = r0 instanceof androidx.appcompat.view.menu.e
            r2 = 0
            if (r1 == 0) goto L_0x000d
            r1 = r0
            androidx.appcompat.view.menu.e r1 = (androidx.appcompat.view.menu.e) r1
            goto L_0x000e
        L_0x000d:
            r1 = r2
        L_0x000e:
            if (r1 == 0) goto L_0x0013
            r1.i0()
        L_0x0013:
            r0.clear()     // Catch:{ all -> 0x0028 }
            android.view.Window$Callback r3 = r5.f589b     // Catch:{ all -> 0x0028 }
            r4 = 0
            boolean r3 = r3.onCreatePanelMenu(r4, r0)     // Catch:{ all -> 0x0028 }
            if (r3 == 0) goto L_0x002a
            android.view.Window$Callback r3 = r5.f589b     // Catch:{ all -> 0x0028 }
            boolean r2 = r3.onPreparePanel(r4, r2, r0)     // Catch:{ all -> 0x0028 }
            if (r2 != 0) goto L_0x002d
            goto L_0x002a
        L_0x0028:
            r0 = move-exception
            goto L_0x0033
        L_0x002a:
            r0.clear()     // Catch:{ all -> 0x0028 }
        L_0x002d:
            if (r1 == 0) goto L_0x0032
            r1.h0()
        L_0x0032:
            return
        L_0x0033:
            if (r1 == 0) goto L_0x0038
            r1.h0()
        L_0x0038:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.E.A():void");
    }

    public void B(int i2, int i3) {
        this.f588a.z((i2 & i3) | ((~i3) & this.f588a.j()));
    }

    public boolean g() {
        return this.f588a.d();
    }

    public boolean h() {
        if (!this.f588a.v()) {
            return false;
        }
        this.f588a.collapseActionView();
        return true;
    }

    public void i(boolean z2) {
        if (z2 != this.f593f) {
            this.f593f = z2;
            if (this.f594g.size() > 0) {
                android.support.v4.media.session.b.a(this.f594g.get(0));
                throw null;
            }
        }
    }

    public int j() {
        return this.f588a.j();
    }

    public Context k() {
        return this.f588a.r();
    }

    public boolean l() {
        this.f588a.o().removeCallbacks(this.f595h);
        W.i0(this.f588a.o(), this.f595h);
        return true;
    }

    public void m(Configuration configuration) {
        super.m(configuration);
    }

    /* access modifiers changed from: package-private */
    public void n() {
        this.f588a.o().removeCallbacks(this.f595h);
    }

    public boolean o(int i2, KeyEvent keyEvent) {
        Menu z2 = z();
        if (z2 == null) {
            return false;
        }
        boolean z3 = true;
        if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() == 1) {
            z3 = false;
        }
        z2.setQwertyMode(z3);
        return z2.performShortcut(i2, keyEvent, 0);
    }

    public boolean p(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            q();
        }
        return true;
    }

    public boolean q() {
        return this.f588a.e();
    }

    public void r(boolean z2) {
    }

    public void s(boolean z2) {
        B(z2 ? 4 : 0, 4);
    }

    public void t(int i2) {
        this.f588a.p(i2);
    }

    public void u(Drawable drawable) {
        this.f588a.x(drawable);
    }

    public void v(boolean z2) {
    }

    public void w(boolean z2) {
    }

    public void x(CharSequence charSequence) {
        this.f588a.setWindowTitle(charSequence);
    }
}
