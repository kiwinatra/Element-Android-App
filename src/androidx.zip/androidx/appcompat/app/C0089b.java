package androidx.appcompat.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import g.C0240d;

/* renamed from: androidx.appcompat.app.b  reason: case insensitive filesystem */
public abstract class C0089b implements DrawerLayout.e {

    /* renamed from: a  reason: collision with root package name */
    private final C0015b f653a;

    /* renamed from: b  reason: collision with root package name */
    private final DrawerLayout f654b;

    /* renamed from: c  reason: collision with root package name */
    private C0240d f655c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f656d;

    /* renamed from: e  reason: collision with root package name */
    private Drawable f657e;

    /* renamed from: f  reason: collision with root package name */
    boolean f658f;

    /* renamed from: g  reason: collision with root package name */
    private final int f659g;

    /* renamed from: h  reason: collision with root package name */
    private final int f660h;

    /* renamed from: i  reason: collision with root package name */
    View.OnClickListener f661i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f662j;

    /* renamed from: androidx.appcompat.app.b$a */
    class a implements View.OnClickListener {
        a() {
        }

        public void onClick(View view) {
            C0089b bVar = C0089b.this;
            if (bVar.f658f) {
                bVar.j();
                return;
            }
            View.OnClickListener onClickListener = bVar.f661i;
            if (onClickListener != null) {
                onClickListener.onClick(view);
            }
        }
    }

    /* renamed from: androidx.appcompat.app.b$b  reason: collision with other inner class name */
    public interface C0015b {
        void a(Drawable drawable, int i2);

        Context b();

        boolean c();

        Drawable d();
    }

    /* renamed from: androidx.appcompat.app.b$c */
    public interface c {
        C0015b s();
    }

    /* renamed from: androidx.appcompat.app.b$d */
    private static class d implements C0015b {

        /* renamed from: a  reason: collision with root package name */
        private final Activity f664a;

        d(Activity activity) {
            this.f664a = activity;
        }

        public void a(Drawable drawable, int i2) {
            ActionBar actionBar = this.f664a.getActionBar();
            if (actionBar != null) {
                actionBar.setHomeAsUpIndicator(drawable);
                actionBar.setHomeActionContentDescription(i2);
            }
        }

        public Context b() {
            ActionBar actionBar = this.f664a.getActionBar();
            return actionBar != null ? actionBar.getThemedContext() : this.f664a;
        }

        public boolean c() {
            ActionBar actionBar = this.f664a.getActionBar();
            return (actionBar == null || (actionBar.getDisplayOptions() & 4) == 0) ? false : true;
        }

        public Drawable d() {
            TypedArray obtainStyledAttributes = b().obtainStyledAttributes((AttributeSet) null, new int[]{16843531}, 16843470, 0);
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        }
    }

    /* renamed from: androidx.appcompat.app.b$e */
    static class e implements C0015b {

        /* renamed from: a  reason: collision with root package name */
        final Toolbar f665a;

        /* renamed from: b  reason: collision with root package name */
        final Drawable f666b;

        /* renamed from: c  reason: collision with root package name */
        final CharSequence f667c;

        e(Toolbar toolbar) {
            this.f665a = toolbar;
            this.f666b = toolbar.getNavigationIcon();
            this.f667c = toolbar.getNavigationContentDescription();
        }

        public void a(Drawable drawable, int i2) {
            this.f665a.setNavigationIcon(drawable);
            e(i2);
        }

        public Context b() {
            return this.f665a.getContext();
        }

        public boolean c() {
            return true;
        }

        public Drawable d() {
            return this.f666b;
        }

        public void e(int i2) {
            if (i2 == 0) {
                this.f665a.setNavigationContentDescription(this.f667c);
            } else {
                this.f665a.setNavigationContentDescription(i2);
            }
        }
    }

    C0089b(Activity activity, Toolbar toolbar, DrawerLayout drawerLayout, C0240d dVar, int i2, int i3) {
        this.f656d = true;
        this.f658f = true;
        this.f662j = false;
        if (toolbar != null) {
            this.f653a = new e(toolbar);
            toolbar.setNavigationOnClickListener(new a());
        } else if (activity instanceof c) {
            this.f653a = ((c) activity).s();
        } else {
            this.f653a = new d(activity);
        }
        this.f654b = drawerLayout;
        this.f659g = i2;
        this.f660h = i3;
        if (dVar == null) {
            this.f655c = new C0240d(this.f653a.b());
        } else {
            this.f655c = dVar;
        }
        this.f657e = e();
    }

    private void h(float f2) {
        C0240d dVar;
        boolean z2;
        if (f2 == 1.0f) {
            dVar = this.f655c;
            z2 = true;
        } else {
            if (f2 == 0.0f) {
                dVar = this.f655c;
                z2 = false;
            }
            this.f655c.e(f2);
        }
        dVar.g(z2);
        this.f655c.e(f2);
    }

    public void a(int i2) {
    }

    public void c(View view, float f2) {
        if (this.f656d) {
            h(Math.min(1.0f, Math.max(0.0f, f2)));
        } else {
            h(0.0f);
        }
    }

    /* access modifiers changed from: package-private */
    public Drawable e() {
        return this.f653a.d();
    }

    public boolean f(MenuItem menuItem) {
        if (menuItem == null || menuItem.getItemId() != 16908332 || !this.f658f) {
            return false;
        }
        j();
        return true;
    }

    /* access modifiers changed from: package-private */
    public void g(Drawable drawable, int i2) {
        if (!this.f662j && !this.f653a.c()) {
            Log.w("ActionBarDrawerToggle", "DrawerToggle may not show up because NavigationIcon is not visible. You may need to call actionbar.setDisplayHomeAsUpEnabled(true);");
            this.f662j = true;
        }
        this.f653a.a(drawable, i2);
    }

    public void i() {
        h(this.f654b.C(8388611) ? 1.0f : 0.0f);
        if (this.f658f) {
            g(this.f655c, this.f654b.C(8388611) ? this.f660h : this.f659g);
        }
    }

    /* access modifiers changed from: package-private */
    public void j() {
        int q2 = this.f654b.q(8388611);
        if (this.f654b.F(8388611) && q2 != 2) {
            this.f654b.d(8388611);
        } else if (q2 != 1) {
            this.f654b.K(8388611);
        }
    }

    public C0089b(Activity activity, DrawerLayout drawerLayout, int i2, int i3) {
        this(activity, (Toolbar) null, drawerLayout, (C0240d) null, i2, i3);
    }
}
