package androidx.appcompat.app;

import android.view.KeyEvent;
import androidx.core.view.C0158t;

public final /* synthetic */ class x implements C0158t.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ y f792a;

    public /* synthetic */ x(y yVar) {
        this.f792a = yVar;
    }

    public final boolean n(KeyEvent keyEvent) {
        return this.f792a.j(keyEvent);
    }
}
