const PartitionName = ({ name }: { name: string }) => {
    return <div className='UI-PartitionName'>{name}</div>
};

export default PartitionName;