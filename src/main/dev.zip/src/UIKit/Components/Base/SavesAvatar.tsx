import { I_SAVE } from '../../../System/UI/IconPack';

export const SavesAvatar = () => (
  <div className='Avatar SavesAvatar'>
    <I_SAVE />
  </div>
);

export default SavesAvatar;
