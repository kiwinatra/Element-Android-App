const ErrorPage = () => {
    return (
        <img className="UI-E_IMG" src="/static_sys/Images/Error.png" />
    )
}

export default ErrorPage;