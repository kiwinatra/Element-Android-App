import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from '../../../System/Context/WebSocket';
import { useModalsStore } from '../../../Store/modalsStore';
import { Block } from '../../../UIKit';
import { HandleTimeAge } from '../../../System/Elements/Handlers';

interface Appeal {
    id: number;
    restriction_type: string;
    reason: string;
    status: 'pending' | 'under_review' | 'approved' | 'rejected';
    created_at: string;
    reviewed_at?: string;
    response?: string;
}

const MyAppealsListModal = () => {
    const { wsClient } = useWebSocket();
    const { openModal } = useModalsStore();
    const [appeals, setAppeals] = useState<Appeal[]>([]);
    const [loading, setLoading] = useState(true);

    const statusText = {
        pending: 'Ожидает рассмотрения',
        under_review: 'На рассмотрении',
        approved: 'Одобрена',
        rejected: 'Отклонена'
    };

    const statusColor = {
        pending: 'var(--WARNING_COLOR)',
        under_review: 'var(--INFO_COLOR)',
        approved: 'var(--SUCCESS_COLOR)',
        rejected: 'var(--ERROR_COLOR)'
    };

    const restrictionText = {
        posts: 'Публикация постов',
        comments: 'Написание комментариев',
        chat: 'Создание чатов',
        music: 'Загрузка музыки'
    };

    const loadAppeals = useCallback(async () => {
        try {
            setLoading(true);
            const response = await wsClient.send({
                type: 'social',
                action: 'appeals/load_my',
                payload: {}
            });

            if (response.status === 'success') {
                setAppeals(response.appeals || []);
            } else {
                console.error('Ошибка загрузки апелляций:', response.message);
            }
        } catch (error) {
            console.error('Ошибка загрузки апелляций:', error);
        } finally {
            setLoading(false);
        }
    }, [wsClient]);

    useEffect(() => {
        loadAppeals();
    }, [loadAppeals]);

    const formatRestrictionType = (type: string) => {
        return restrictionText[type] || type;
    };

    if (loading) {
        return (
            <div className="MyAppeals-Content">
                <Block>
                    <div className="loading-container">
                        <div className="loading-spinner">Загрузка...</div>
                    </div>
                </Block>
            </div>
        );
    }

    return (
        <div className="MyAppeals-Content">
            <Block>
                <div className="MyAppeals-Header">
                    <h3>Мои апелляции</h3>
                    <p>Здесь отображаются все ваши поданные апелляции</p>
                </div>

                {appeals.length === 0 ? (
                    <div className="MyAppeals-Empty">
                        <p>У вас нет поданных апелляций</p>
                    </div>
                ) : (
                    <div className="MyAppeals-List">
                        {appeals.map((appeal) => (
                            <div key={appeal.id} className="MyAppeals-Item">
                                <div className="MyAppeals-ItemHeader">
                                    <div className="MyAppeals-ItemType">
                                        {formatRestrictionType(appeal.restriction_type)}
                                    </div>
                                    <div 
                                        className="MyAppeals-ItemStatus"
                                        style={{ color: statusColor[appeal.status] }}
                                    >
                                        {statusText[appeal.status]}
                                    </div>
                                </div>

                                <div className="MyAppeals-ItemReason">
                                    <strong>Причина апелляции:</strong>
                                    <p>{appeal.reason}</p>
                                </div>

                                {appeal.response && (
                                    <div className="MyAppeals-ItemResponse">
                                        <strong>Ответ модератора:</strong>
                                        <p>{appeal.response}</p>
                                    </div>
                                )}

                                <div className="MyAppeals-ItemDates">
                                    <div className="MyAppeals-ItemDate">
                                        <strong>Подана:</strong> <HandleTimeAge inputDate={appeal.created_at} />
                                    </div>
                                    {appeal.reviewed_at && (
                                        <div className="MyAppeals-ItemDate">
                                            <strong>Рассмотрена:</strong> <HandleTimeAge inputDate={appeal.reviewed_at} />
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                <div className="MyAppeals-Actions">
                    <button
                        className="UI-Window_button"
                        onClick={() => openModal({ type: 'close' })}
                    >
                        Закрыть
                    </button>
                </div>
            </Block>
        </div>
    );
};

export default MyAppealsListModal;