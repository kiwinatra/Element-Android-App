const CURRENT_VERSION = 2.7;
// const WINDOWS_CURRENT_VERSION = '2.7.0';

const BaseConfig = {
    session: {
        name: `Element Web ${CURRENT_VERSION}`,
        device: 'browser',
        // name: `Element Windows ${WINDOWS_CURRENT_VERSION}`,
        // device: 'windows_app'
    },
    captcha: true,
    domains: {
        // client: 'https://elemsocial.com',
        // base: 'https://elemsocial.com',
        // share: 'https://share.elemsocial.com',
        // ws: [
        //     'wss://bpws.elemsocial.com/user_api',
        //     'wss://ws.elemsocial.com:8880/user_api'
        // ],
        client: 'http://localhost:3000',
        base: 'http://localhost:3000',
        share: 'https://share.elemsocial.com',
        ws: [
            'ws://localhost:8080/user_api',
        ],
    },
    vapid: {
        public_key: 'BP2xfmqDnX7-yoDsZQxgHt8aTd7fSRhLno0-fPwpGoglILifPqzVmEo0OLNYILeU0qVkC5qo_rLhzzcrBh_EIIs'
    },
    update: {
        version: CURRENT_VERSION,
        content: [
            {
                title: 'Общие изменения',
                changes: [
                    'Обновлена публикация видео/файлов/музыки в постах.',
                    'Максимальная длинна текста в постах/комментариях теперь 30 000 символов!',
                    'Добавлена экспериментальная тема «Жидкое стекло»',
                    'Добавлены «Продвинутые настройки»',
                    'Добавлен кошелёк.',
                    'Добавлены подарки.',
                    'Проведена оптимизация контента в постах, а так же интерфейс и оформление постов.',
                    'Добавлены переводы Е-Баллов между пользователями.',
                    'Полностью переделана система уведомлений, а так же сами уведомления перенесены в отдельную страницу.',
                    'При загрузке сайта теперь показывает домен к которому идёт попытка подключения.',
                    'Обновлена система диалоговых окон, удалены старые диалоговые окна с настроек.',
                    'Улучшена и оптимизирована загрузка видео.',
                    'Исправление ошибок.',
                    'Улучшен и оптимизирован интерфейс.',
                    'Незначительные улучшения.'
                ]
            }
        ]
    }
};

export default BaseConfig;