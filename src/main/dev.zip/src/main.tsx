import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { App } from './App';
import { DynamicIslandProvider, DynamicIsland } from './System/Context/DynamicIsland';
import { WebSocketProvider } from './System/Context/WebSocket';
import { MusicModalProvider } from './System/Context/MusicModal';
import store from './Store/store';
import AudioPlayer from './Components/AudioPlayer';
import ImageView from './Components/ImageView';
import { DatabaseProvider } from './System/Context/Database';
import Notifications from './Components/Notifications';
import ErrorBoundary from './System/Components/ErrorBoundary';
import ModalsRenderer from './Components/Modals/ModalsRenderer';
import { StrictMode } from 'react';
import { errorReporter } from './System/Services/ErrorReporter.js';

window.onerror = (message, filename, lineno, colno, error) => {
  errorReporter.sendJSError(String(message), filename, lineno, colno, error);
  return false;
};

window.addEventListener('unhandledrejection', (event) => {
  errorReporter.sendUnhandledRejection(event.reason);
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then(() => console.log('Service Worker зарегистрирован'))
    .catch(err => console.error('Ошибка регистрации Service Worker:', err));
}

const rootElement = document.getElementById('root') as HTMLElement;

createRoot(rootElement).render(
  <StrictMode>
    <ErrorBoundary>
      <DatabaseProvider>
        <Provider store={store}>
          <BrowserRouter>
            <DynamicIslandProvider>
              <WebSocketProvider>
                <MusicModalProvider>
                  <DynamicIsland />
                  <App />
                  <AudioPlayer />
                  <ImageView />
                  <Notifications />
                  <ModalsRenderer />
                </MusicModalProvider>
              </WebSocketProvider>
            </DynamicIslandProvider>
          </BrowserRouter>
        </Provider>
      </DatabaseProvider>
    </ErrorBoundary>
  </StrictMode>
);